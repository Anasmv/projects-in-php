<?php session_start();
if( isset($_SESSION['ktp']) && isset( $_SESSION['kid']) ) { $acc_typ = $_SESSION['ktp'];  $ssid = $_SESSION['kid']; } // k_typ = 'database account type' & k_typ = 'database account id' 
if( isset($_SESSION['ktp']) && isset( $_SESSION['kid']) ) {
include 'include/link.php';
include 'include/headerlog.php'; /* our admin super admin main admin admin mentadmin */ ?>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="container">
        <div class="row">
            <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                <?php
                include "include/sidenav.php"; ?>
            </div>
            <div class="col-xl-9 col-lg-9 col-md-9 col-sm-12 col-12 card shadow" id="main"> 
            </div>
        </div>
    </div>
</div>
<?php
include 'include/footer.php';
}
else
{
    header("Location: http://www.sahayikendra.com/kofasite"); 
    exit();
}
?>