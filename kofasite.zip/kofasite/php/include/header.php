<nav class=" navbar navbar-expand-lg navbar-gold bg-gold sticky-top">
    <div class="col-xl-1 col-lg-1 col-md-0 col-sm-0 col-0"></div>
    <div id="navbar">
        <a class="navbar-brand" href="#">
            <img class="round head-logo" src="http://www.sahayikendra.com/kofasite/images/KofaLogo.jpg" id="logo" alt="logo"  >
        </a>
    </div>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="http://www.sahayikendra.com/kofasite/">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Contact</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" onClick="registerbtn();">Register</a>
            </li>
        </ul>
        <ul class="nav navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link " id="loginBtn" href="#" ><span class="fas fa-unlock" ></span> Login</a>
            </li>
        </ul>
    </div>
    <div class="col-xl-1 col-lg-1 col-md-0 col-sm-0 col-0"></div>
</nav>

<div class="modal fade" id="loginModal" role="dialog">
    <div class="modal-dialog">
        <div class="round-curve modal-content">
            <div class="modal-header" >
                <h4><span class="fas fa-unlock"></span> Login</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body" style="padding:40px 40px;">
                <form  method="post" role="form">
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="text" class="round form-control" id="usrname" name="username" required />
                            <label for="username"><span class="fas fa-user"></span> Username</label>
                        </fieldset>
                    </div>
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="password" class="round form-control" name="password" id="psw" required />
                            <label for="psw"><span class="fas fa-eye"></span> Password</label>
                        </fieldset>
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox" value="" checked>Remember me</label>
                    </div>
                    <button type="submit" class="round btn btn-success btn-block form-control" name="submitlogin"><span class="fas fa-power-off"></span> Login</button>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $("#loginBtn").click(function(){
            $("#loginModal").modal();
        });
    });
    function registerbtn() {
        var registerclick = 'register';
        if (registerclick.length > 0) {
            $.ajax({
            type: "POST",
            url: "php/dashboard/ajx/ajaxkofa.php",
            data: "registerclick=" + registerclick,
            cache: false,
            success: function(html) {
                $("#registerclick").html(html);
            }
            });	
        }
        else {
            $("#registerclick").html("");
        }
    }
</script>
<?php
if(isset($_POST['submitlogin']))
{
    $unm = $_POST['username'];
    $pwd = $_POST['password'];
    $sqlg = "select * from kofa_login where username = '$unm'"; 
    $relg = mysqli_query($kofa_login, $sqlg);
    $rwlg = mysqli_fetch_array($relg);
    $pass = $rwlg['password'];
    $acctyp = $rwlg['account_type'];
    $lid = $rwlg['id'];
    if( password_verify($pwd, $pass) ) {
        $_SESSION['kid'] = $lid; $_SESSION['ktp'] = $acctyp; echo "<script>alert('login success');</script>";
        if($_SESSION['ktp']=='mentadmin') {
            echo "<script> window.location='php/dashboard/mentadmin.php?id=$lid&typ=$acctyp'; </script>" ;
        }
        else {
            echo "<script> window.location='php/index.php'; </script>" ;
        }
    }
    else
    {
        echo "<script> alert('incorrect name or password'); </script>";
    }
}
?>