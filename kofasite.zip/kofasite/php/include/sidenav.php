             <div class="container-fluid h-100">
                <div class="row h-100">
                    <aside class="col-12 col-md-12 p-0 bg-dark ">
                        <nav class="navbar navbar-expand navbar-dark bg-dark flex-md-column flex-row align-items-start py-2 fill">
                            <div class="collapse navbar-collapse align-items-start">
                                <ul class="flex-md-column flex-row navbar-nav w-100 justify-content-between">
<?php
if(!isset($_SESSION)) { session_start(); }
if(isset($_SESSION['ktp']) && isset($_SESSION['kid']))
{
    $acctyp = $_SESSION['ktp'];
    $ssid = $_SESSION['kid'];
}
/*
    our admin
    super admin
    main admin
    admin
    mentadmin
*/
if(isset($acctyp) || $acctyp != '')
{
    if($acctyp=='ouradmin')
    {
        
    ?>
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="createsuperacc();" target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Create Super Admin Account</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="createclubacc();" target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Create Club/Accamedic Account</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="viewclubdetfn();" target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">View Club Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="aproveclub();" target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Aprove Club Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="aprovedclubdet();" target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Aproved Club Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="createbatchacc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Create Batch Admin</span>
                                        </a>
                                    </li>
                                    
                                     <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="stdfeest();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Student fee structure</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="requestapprovefn();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Students Request Approve</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="approvedreq();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Approved Students</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="accountcalc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Accounting Calculation</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="expenditure();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Expenditures</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="feedet();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Fee Not Payed Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="feepaydet();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Fee Payed Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="instruc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Instructor Fee</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="createsubacc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Create Sub Admin Account</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="addbank();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Add Bank</span>
                                        </a>
                                    </li>
                                    
                                    <!--<li class="nav-item">-->
                                    <!--    <a class="nav-link pl-0 text-nowrap" onClick="creatementacc();"  target="_blank">-->
                                    <!--        <i class="fa fa-plus-circle fa-fw"></i>-->
                                    <!--        <span class="font-weight-bold">Create Ment Admin Account</span>-->
                                    <!--    </a>-->
                                    <!--</li>-->
                                    
                                    
                                    
    <?php
    }
    
        if($acctyp=='superadmin' )
        {
        
    
    ?>
                                   <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="createclubacc();" target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Create Club/Accamedic Account</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="viewclubdetfn();" target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">View Club Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="aproveclub();" target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Aprove Club Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="aprovedclubdet();" target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Aproved Club Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="createbatchacc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Create Batch</span>
                                        </a>
                                    </li>
                                    
                                     <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="stdfeest();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Student fee structure</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="requestapprovefn();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Students Request Approve</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="approvedreq();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Approved Students</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="accountcalc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Accounting Calculation</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="expenditure();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Expenditures</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="feedet();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Fee Not Payed Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="feepaydet();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Fee Payed Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="instruc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Instructor Fee</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="createsubacc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Create Sub Admin Account</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="addbank();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Add Bank</span>
                                        </a>
                                    </li>
                                    
                                    <!--<li class="nav-item">-->
                                    <!--    <a class="nav-link pl-0 text-nowrap" onClick="creatementacc();"  target="_blank">-->
                                    <!--        <i class="fa fa-plus-circle fa-fw"></i>-->
                                    <!--        <span class="font-weight-bold">Create Ment Admin Account</span>-->
                                    <!--    </a>-->
                                    <!--</li>-->
                                    
                                    
    <?php
        }
    
    if($acctyp == 'mainadmin')
    {
    ?>
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="createbatchacc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Create Batch</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="requestapprovefn();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Students Request Approve</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="approvedreq();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Approved Students</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="accountcalc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Accounting Calculation</span>
                                        </a>
                                    </li>
                                    
                                    
    <?php 
    }
    if($acctyp=='batchadmin')
    {
    ?>
                                    
                                     <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="stdfeest();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Student fee structure</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="expenditure();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Expenditures</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="feedet();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Fee Not Payed Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="feepaydet();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Fee Payed Details</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="instruc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Instructor Fee</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="createsubacc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Create Sub Admin Account</span>
                                        </a>
                                    </li>
    <?php 
    }
    
        if($acctyp=='clubadmin' )
        {
    ?>   
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="createbatchacc();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Create Batch</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="stdfeest();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Student fee structure</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" onClick="addbank();"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Add Bank</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item">
                                        <a class="nav-link pl-0 text-nowrap" href="http://sahayikendra.com/kofasite/php/dashboard/clubadmin.php?ss_id=<?php echo $ssid; ?>&acctyp=clubadm"  target="_blank">
                                            <i class="fa fa-plus-circle fa-fw"></i>
                                            <span class="font-weight-bold">Aprove Challan Details</span>
                                        </a>
                                    </li>
                                    
                                    <!--<li class="nav-item">-->
                                    <!--    <a class="nav-link pl-0 text-nowrap" onClick="creatementacc();"  target="_blank">-->
                                    <!--        <i class="fa fa-plus-circle fa-fw"></i>-->
                                    <!--        <span class="font-weight-bold">Create Ment Admin Account</span>-->
                                    <!--    </a>-->
                                    <!--</li>-->
                                    
        <?php
        }
        
    if($acctyp=='subadmin')
    { ?>
                <li class="nav-item">
                    <a class="nav-link pl-0 text-nowrap" onClick="dataentrydet();"  target="_blank">
                        <i class="fa fa-plus-circle fa-fw"></i>
                        <span class="font-weight-bold">Data Entry Details</span>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link pl-0 text-nowrap" onClick="checkdet();"  target="_blank">
                        <i class="fa fa-plus-circle fa-fw"></i>
                        <span class="font-weight-bold">Check Details</span>
                    </a>
                </li>
                
                <li class="nav-item">
                    <a class="nav-link pl-0 text-nowrap" href = "http://sahayikendra.com/kofasite/php/dashboard/clubadmin.php?ss_id=<?php echo $ssid; ?>&acctyp=subadm" target="_blank">
                        <i class="fa fa-plus-circle fa-fw"></i>
                        <span class="font-weight-bold">Approve Challan</span>
                    </a>
                </li>
       
<?php 
    }
        
     
    ?>
                                 
                                </ul>
                            </div>
                        </nav>
                    </aside>
                </div>
            </div>
        
       
    <br>
    <!-- path = "http://sahayikendra.com/kofasite/php/dashboard/ajx/ajaxkofa.php" -->
    
    <script>
        var acc_typ = '<?php echo $acctyp; ?>';
        var lg_id = '<?php echo $ssid; ?>';
    </script>
    <script>
    
    
        function createclubacc() {
            $(document).attr("title", "Create Club Account");
            var createclubacc = 'clubaccountcreataion';
            if (createclubacc.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { createclubacc : createclubacc, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    <script>
        function createmainacc() {
            $(document).attr("title", "Main ");
            var createmainacc = 'mainaccountcreataion';
            if (createmainacc.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { createmainacc : createmainacc, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    <script>
        function createbatchacc() {
            $(document).attr("title", "Create Batch Account");
            var createbatchacc = 'batchaccountcreataion';
            if (createbatchacc.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { createbatchacc : createbatchacc, acc_typ : acc_typ, lg_id : lg_id },
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    <script>
        function requestapprovefn() {
            $(document).attr("title", "Request Approve");
            var requestapprove = 'requestapprove';
            if (requestapprove.length > 0) {
                $.ajax({
                type: "GET",
                url: "./dashboard/ajx/ajaxkofa.php",
                data: { requestapprove : requestapprove, acc_typ : acc_typ, lg_id : lg_id },
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    
    <script>
        function approvedreq() {
            $(document).attr("title", "Approved Requests");
            var approvedreq = 'approvedreq';
            if (approvedreq.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { approvedreq : approvedreq, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    <script>
        function accountcalc() {
            $(document).attr("title", "Account Calculation");
            var accountcalc = 'acc calculation';
            if (accountcalc.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { accountcalc : accountcalc, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    
    
    
    
    <script>
        function expenditure() {
            $(document).attr("title", "Expenditures");
            var expenditure = 'expenditures';
            if (expenditure.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { expenditure : expenditure, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    <script>
        function feepaydet() {
            $(document).attr("title", "Fee Payed Details");
            var feepaydet = 'fee payed details';
            if (feepaydet.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { feepaydet : feepaydet, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    <script>
        function feedet() {
            $(document).attr("title", "Fee Details");
            var feedet = 'fee details';
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { feedet : feedet, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            
        } 
    </script>
    
    <script>
        function instruc() {
            $(document).attr("title", "Instructor Details");
            var instruc = 'istructor details';
            if (instruc.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { instruc : instruc, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    <script>
        function createsubacc() {
            $(document).attr("title", "Create Sub Admin");
            var createsubacc = 'mainaccountcreataion';
            if (createsubacc.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { createsubacc : createsubacc, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    <script>
        function creatementacc() {
            $(document).attr("title", "Create Ment Admin");
            var creatementacc = 'mentaccountcreataion';
            if (creatementacc.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { creatementacc : creatementacc, acc_typ : acc_typ, lg_id : lg_id },
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    
    
    <script>
        function dataentrydet() {
            $(document).attr("title", "");
            var dataentrydet = 'data entry details';
            if (dataentrydet.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { dataentrydet : dataentrydet, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    <script>
        function accountcalc() {
            $(document).attr("title", "Account Calculation");
            var accountcalc = 'account calculation';
            if (accountcalc.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { accountcalc : accountcalc, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    
    <script>
        function checkdet() {
            var checkdet = 'check details';
            if (checkdet.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { checkdet : checkdet, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    <script>
    
     function viewclubdetfn() {
         $(document).attr("title", "Club Details");
            var viwclb = 'clubdetailsview';
            $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { viewclubdetl : viwclb, acc_typ : acc_typ, lg_id : lg_id },
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
            });
        }
    </script>
    
    <script>
        function addbank() {
            var addbank = 'add bank in club';
            if (addbank.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { addbank : addbank, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        } 
    </script>
    
    
    <script>
        function aproveclub() {
            $(document).attr("title", "Approve Club");
            var aproveclub = 'Aprove Club Det';
                $.ajax({
                    type: "POST",
                    url: "dashboard/ajx/ajaxkofa.php",
                    data: { aproveclub : aproveclub, acc_typ : acc_typ, lg_id : lg_id},
                    cache: false,
                    success: function(html) {
                        $("#main").html(html);
                    }
                });
        }
    </script>
    
    <script>
        function aprovedclubdet() {
            $(document).attr("title", "Aproved Club");
            var aprovedclubdet = 'Approve Club det';
            if (aprovedclubdet.length > 0) {
                $.ajax({
                type: "POST",
                url: "dashboard/ajx/ajaxkofa.php",
                data: { aprovedclubdet : aprovedclubdet, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        }
    </script>
    
    
    
    
    <script>
        function createsuperacc() {
            $(document).attr("title", "Create Super Account");
            var createsuperacc = 'Create Super Acc';
            if (createsuperacc.length > 0) {
                $.ajax({
                type: "POST",
                
                url: "dashboard/ajx/ajaxkofa.php",
                data: { createsuperacc : createsuperacc, acc_typ : acc_typ, lg_id : lg_id},
                cache: false,
                success: function(html) {
                    $("#main").html(html);
                }
                });	
            }
            else {
                $("#main").html("");
            }
        }
    </script>
    
    
    
    <script>
        function stdfeest() {
            $(document).attr("title", "Fee Structure");
            var stdfeest = 'Student Fee Structure';
                $.ajax({
                    type: "POST",
                    url: "dashboard/ajx/ajaxkofa.php",
                    data: { stdfeest : stdfeest, acc_typ : acc_typ, lg_id : lg_id, lg_id : lg_id },
                    cache: false,
                    success: function(html) {
                        $("#main").html(html);
                    }
                });
        }
    </script>
    
<?php
}
?>