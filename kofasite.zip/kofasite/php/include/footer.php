        <br><br><br>
        <nav class="navbar bg-dark navbar-dark fixed-bottom">
            <div class="col-xl-1 col-lg-1 col-md-12 col-sm-12 col-12"></div>
            <div class=" col-xl-10 col-lg-10 col-md-12 col-sm-12 col-12">
                   <div class="float-left col-xl-2 col-lg-2 col-md-4 col-sm-4 col-4">
                       <img class="round foot-logo" src="http://www.sahayikendra.com/kofasite/images/KofaLogo.jpg"  alt="logo" >
                   </div>
                <div class="float-right col-xl-10 col-lg-10 col-md-8 col-sm-8 col-8">    
                        <span class="text-white"> Copy Right @  <a href="http://azalea.saypay.in/" target="_blank"> Azalea</a></span>
                </div>  
            </div>
            <div class="col-xl-1 col-lg-1 col-md-12 col-sm-12 col-12"></div>
        </nav>
          
        <script>
            // When the user scrolls down 80px from the top of the document, resize the navbar's padding and the logo's font size
            window.onscroll = function() {scrollFunction()};
            
            function scrollFunction() {     
              if (document.body.scrollTop > 0.01 || document.documentElement.scrollTop > 0.01) {
                document.getElementById("logo").style.width = "100px" ;
              } else {
                document.getElementById("logo").style.width = "250px";
              }
            }
        </script>
    </body>
</html>