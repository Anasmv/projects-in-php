<?php $kofa_batch = mysqli_connect('localhost', 'sahayikendra', 'sahayikendra@Azalea', 'kofa_batch');
$kofa_login = mysqli_connect('localhost', 'sahayikendra', 'sahayikendra@Azalea', 'kofa_login');
$kofa_transaction = mysqli_connect('localhost', 'sahayikendra', 'sahayikendra@Azalea', 'kofa_transaction');
$kofa_candidate = mysqli_connect('localhost', 'sahayikendra', 'sahayikendra@Azalea', 'kofa_candidate');
$kofa_club = mysqli_connect('localhost', 'sahayikendra', 'sahayikendra@Azalea', 'kofa_club');
$kofa_expenditure = mysqli_connect('localhost', 'sahayikendra', 'sahayikendra@Azalea', 'kofa_expenditure'); ?>