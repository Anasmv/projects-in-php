<?php session_start();
// &acctyp = clubadm OR subadm
if(isset($_GET['ss_id'])) { $ssid = $_GET['ss_id']; }


include '../include/link.php';
include '../include/headerlog.php';
include '../con/con.php';
if($_GET['acctyp']=='clubadm')
{
    $sqllogin="SELECT * FROM kofa_login WHERE id='$ssid'  ";
    $reslogin=mysqli_query($kofa_login,$sqllogin);
    $rowlogin=mysqli_fetch_array($reslogin);
    //echo $clubid = $rowlogin['uid'] = '17'; 
    echo 'club id = ' . $clubid = $rowlogin['uid']; 
    
    echo "  <script>
                setclubcookie();
                function setclubcookie()
                {
                     document.cookie = 'clubidcookie=' + '$clubid'; 
                }
            </script>" ;
    
    
    
    
    $sqlbatch="SELECT * FROM `kofa_batch` WHERE club_id='$clubid'  ";
    $resbatch=mysqli_query($kofa_batch,$sqlbatch);
    $rowbatch=mysqli_fetch_array($resbatch);
    echo 'batch id = ' . $batchid = $rowbatch['id'];
}
?>

<div class="container">
    <div class="row">
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
        <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
            
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow ">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">

<?php
if($_GET['acctyp']=='clubadm')
{
?>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 form-group">
                        <?php
                        $sqlbnk="SELECT * FROM `bank` where club_id = '$clubid' ";
                        $resbnk=mysqli_query($kofa_transaction,$sqlbnk);
                        //SELECT `challan_id`, `candidate_id`, `bank_id`, `transaction`, `date`, `approve` FROM `challan` WHERE 1
                        ?>
                        <SELECT name="mylist"  id="clubid" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 round form-control" name="country" onChange="banksel(this);">
                            <option disabled selected value>Select Bank</option>
                            <?php
                            while($rowbnk=$resbnk->fetch_assoc())
                            {
                                $bnk_id=$rowbnk['id'];
                                echo "<option  value='".$bnk_id."'>";
                                echo $rowbnk['bank_name'];
                                echo "</option>";
                            }
                            ?>
                        </SELECT>
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 form-group">
                        <SELECT name="mylist"  id="clubid" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 round form-control" onChange="" name="country">
                            <option disabled selected value>Select Batch</option>
                            <?php
                            $btcsql = "SELECT * FROM `kofa_batch`";
                            $btcres=mysqli_query($kofa_batch,$btcsql);
                            while($btcrow = mysqli_fetch_assoc($btcres))
                            {
                            ?>
                            <option value="<?php echo $btcrow['id']; ?>">
                                <?php echo $btcrow['name']; ?>
                            </option>
                            <?php
                            }
                            ?>
                        </SELECT>
                    </div>
                    
                    <?php
}

if($_GET['acctyp']=='subadm')
{ ?>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 form-group">
                        <?php
                        $sqlcb="SELECT * FROM `kofa_club`";
                        $rescb=mysqli_query($kofa_club,$sqlcb);
                        //SELECT `challan_id`, `candidate_id`, `bank_id`, `transaction`, `date`, `approve` FROM `challan` WHERE 1
                        ?>
                        <SELECT name="mylist"  id="clubid" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 round form-control" name="country" onChange="setclubcookie(this);">
                            <option disabled selected value>Select Club</option>
                            <?php
                            while($rowcb=$rescb->fetch_assoc())
                            {
                                $bnk_id=$rowcb['id'];
                                echo "<option  value='".$bnk_id."'>";
                                echo $rowcb['name'];
                                echo "</option>";
                            }
                            ?>
                        </SELECT>
                    </div>
                    <script>
                        function setclubcookie(sel)
                        {
                            var clubidi = sel.options[sel.selectedIndex].value;
                            document.cookie = 'clubidcookie=' + clubidi; 
                            $.ajax({
                                type: "POST",
                                url: "ajx/ajaxkofa.php",
                                data: { club_id_bank : clubidi , clubidcookie : clubidi},
                                cache: false,
                                beforeSend: function() {
                                        $('#bank_sel').html('<img src="loader.gif" alt="" width="24" height="24">');
                                },
                                success: function(html) {
                                    $("#bank_sel").html(html);
                                }
                            });
                            
                        }
                    </script>
                    
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 form-group">
                        <SELECT  id="bank_sel" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 round form-control" name="bank" onChange="bankselsub(this);">
                            <option disabled selected value>Select Bank</option>
                        </SELECT>
                    </div>
                    <script>
                        function bankselsub(sel) {
                            var bankid = sel.options[sel.selectedIndex].value;
                            document.cookie = "bankidckmnt=" + bankid;
                            
                            $.ajax({
                                type: "POST",
                                url: "ajx/ajaxkofa.php",
                                data: { bnk_id : bankid },
                                cache: false,
                                beforeSend: function() {
                                        $('#bank_ifrm').html('<img src="loader.gif" alt="" width="24" height="24">');
                                },
                                success: function(html) {
                                    $("#bank_ifrm").html(html);
                                }
                            });
                            
                            $.ajax({
                                type: "POST",
                                url: "ajx/ajaxkofa.php",
                                data: { bankidclubsub : bankid },
                                cache: false,
                                beforeSend: function() {
                                        $('#mentdett').html('<img src="loader.gif" alt="" width="24" height="24">');
                                },
                                success: function(html) {
                                    $("#mentdett").html(html);
                                }
                            });
                            
                            
                        } 
                    </script>

<?php
}
?>

                	    
                
                <!-- ajax select bank link this div-->
                <div class="col-xl-12 col-lg-12 cl-md-12 col-sm-12 col-12 ">
                    <div id ='mentdett'>

                    </div>
                </div>
                    
                    
                <!-- ajax next button link this div-->
                <div id ='nextclub' class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    
                </div>
            </div> 
            
            
        </div>
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
    </div>
</div>







<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 " id="bank_ifrm">   
    <!--<iframe class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" frameborder="0" scrolling="no" onload="resizeIframe(this)" style="overflow:hidden; border-style: none;width:  100%; height: 100%; " src="http://sahayikendra.com/"></iframe>      -->
</div>



<script>
    function resizeIframe(obj) {
        obj.style.height = obj.contentWindow.document.body.scrollHeight + 'px';
    }
</script>
<script>
    function banksel(sel) {
        var bankid = sel.options[sel.selectedIndex].value;
        document.cookie = "bankidckmnt=" + bankid;
        
        $.ajax({
            type: "POST",
            url: "ajx/ajaxkofa.php",
            data: { bnk_id : bankid },
            cache: false,
            beforeSend: function() {
                    $('#bank_ifrm').html('<img src="loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                $("#bank_ifrm").html(html);
            }
        });
        
        $.ajax({
            type: "POST",
            url: "ajx/ajaxkofa.php",
            data: { bankidclub : bankid },
            cache: false,
            beforeSend: function() {
                    $('#mentdett').html('<img src="loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                $("#mentdett").html(html);
            }
        });
        
        
    } 
</script>



<script>
    function next() {
        var nextcandidate = 'nextcandidate';
        $.ajax({
            type: "POST",
            url: "ajx/ajaxkofa.php",
            data: "nextcandidate=" + nextcandidate,
            cache: false,
             beforeSend: function() {
                $('#mentdett').html('<img src="loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                $("#mentdett").html(html);
            }
        });
    }
</script>


<script>
    function nextsub() {
        var nextsub = 'nextsub';
        $.ajax({
            type: "POST",
            url: "ajx/ajaxkofa.php",
            data: { nextsub : nextsub },
            cache: false,
             beforeSend: function() {
                $('#mentdett').html('<img src="loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                $("#mentdett").html(html);
            }
        });
    }
</script>

<script>
    chang_titl();
    function chang_titl()
    {
         $(document).attr("title", "Aprove Challan");
    }
</script>
  
<?php include('../include/footer.php'); ?>