<?php session_start();
session_unset();
if (session_destroy()) { 
echo "<script type='text/javascript'> alert('Successfully LogOut'); window.location='../../index.php'; </script>";
}
?>