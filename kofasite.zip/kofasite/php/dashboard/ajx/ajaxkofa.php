<?php session_start(); 
//delete error log
// $myFile = "error_log";
// $myFileLink = fopen($myFile, 'w') or die("can't open file");
// fclose($myFileLink);
// $myFile = "error_log";
// unlink($myFile) or die("Couldn't delete file");


//ajax kofa all
$db_selected = mysqli_connect('localhost', 'sahayikendra', 'sahayikendra@Azalea' );


if(isset($_SESSION['kid'])) {  $login_id = $_SESSION['kid']; }
if(!isset($_SESSION['kid'])) { if(isset($_POST['lg_id'])) { $lgid=$_POST['lg_id']; $_SESSION['kid']=$lgid; } }

if(isset($_SESSION['ktp'])) {  $acctyp = $_SESSION['ktp']; }
if(!isset($_SESSION['ktp'])) { if(isset($_POST['acc_typ'])) { $acctyp = $_POST['acc_typ']; $_SESSION['ktp'] = $acctyp; } }

//echo $status = session_status();
    //$acctyp = 'ouradmin';
    if($acctyp=='clubadmin' || $acctyp=='subadmin')
    {
        //club admin login id =  $login_id;
        $sqlselclg = "SELECT * FROM `kofa_login` WHERE id = '$login_id' ";
        $rselg = mysqli_query($kofa_login, $sqlselclg);
        $rwslg = mysqli_fetch_array($rselg);
        $clbidlg = $rwslg['uid'];
        
        $sqlselclub = "SELECT * FROM `kofa_club` WHERE id = '$clbidlg' ";
        $rsclub = mysqli_query($kofa_login, $sqlselclub);
        $rwclub = mysqli_fetch_array($rsclub);
        $clubid = $rwclub['uid'];
    }
    if($acctyp=='batchadmin')
    {
        //club admin login id =  $login_id;
        $sqlseluid = "SELECT * FROM `kofa_login` WHERE id = '$login_id' ";
        $rsuid = mysqli_query($kofa_login, $sqlseluid);
        $rwuid = mysqli_fetch_array($rsuid);
        $clbiuid = $rwuid['uid'];
        
        if($acctyp=='batchadmin')
        {
            $sqlselbtch = "SELECT * FROM `kofa_club` WHERE id = '$clbiuid' ";
            $rsbtch = mysqli_query($kofa_login, $sqlselbtch);
            $rwbtch = mysqli_fetch_array($rsbtch);
            $btchid = $rwbtch['uid'];
        }
        
        
    }
    
?>
<script> 
    var actyp = '<?php echo $_SESSION['ktp']; ?>'; 
    var loginid = '<?php echo $_SESSION['kid']; ?>'; 
</script>
<?php

    
    include('../../con/con.php');

    //show images in index page (first kofa page)
    if(isset($_POST['batchimage']))
    {
        $batch_name = $_POST['batchimage'];
        $sql = "SELECT * FROM `batch` where name = '$batch_name' ";
        $res=mysqli_query($con, $sql);
        while($row=mysqli_fetch_array($res))
        {
            echo '<img class="shadow col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"" src="data:image/jpeg;base64,'.base64_encode($row['batch_image']).'" />';
        }
    }
    
    
    if(isset($_GET['requestapprove']))
    {
      echo '54554545454';   
      ?>
      <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
        					<h2 align="center round bg-progress">CANDIDATE DETAILS APROVE</h2>
        				</div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                        <table class="table table-hover">
                            <style>
                                th, td {
                                  padding: 15px;
                                }
                            </style>
                            </style>
                        	<tr>
                        		<th><label>Name</label></th>
                        		<th><label>Address</label></th>
                        		<th><label>Place</label></th>
                        		<th><label>Mobile Number</label></th>
                        		<th><label>Date Of Birth</label></th>
                        		<th><label>Email</label></th>
                        		<th><label>Height</label></th>
                        		<th><label>Weight</label></th>
                        		<th><label>Sex</label></th>
                        		<th><label>Image</label></th>
                        		<th><label>Fee</label></th>
                        		<th><label>Action</label></th>
                        	</tr>
                        	<?php
                        	$sql="SELECT * FROM `candidate` WHERE aprove = '0' AND fee <> ''";
                        	$res=mysqli_query($kofa_candidate,$sql);
                        	while($row=mysqli_fetch_array($res))
                        	{ ?>
                        	<tr>
                        		<td><?php echo $row['name'];?></td>
                        		<td><?php echo $row['adds'];?></td>
                        		<td><?php echo $row['place'];?></td>
                        		<td><?php echo $row['mobile'];?></td>
                        		<td><?php echo $row['dob'];?></td>
                    			<td><?php echo $row['email'];?></td>
                        		<td><?php echo $row['height'];?></td>
                        		<td><?php echo $row['weight'];?></td>
                        		<td><?php echo $row['sex'];?></td>
                        		<td>
                                    <img  height='auto' width='50' alt='rounded' class='shadow col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12' src='data:image/jpeg;base64,<?php echo base64_encode($row['image']); ?>' />
                                </td>
                                <td><?php echo $row['fee'];?></td>
                        		<?php $candi = $row['id'];  ?> 
                        		<td>
                    		        <button class="btn btn-danger round "  id="<?php echo $candi; ?>" onClick=" aprvcd(this.id); ">Aprove Candidate</button>
                        		</td>
                        	</tr>
                        	<?php 
                        	}
                        	
                        	
                        	?>
                        	<?php
    }
    //side nav admission request approve in candidate details
    if(isset($_GET['requestpprove']))
    {
        //echo $_POST['requestapprove'];
        ?>
        <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
        					<h2 align="center round bg-progress">CANDIDATE DETAILS APROVE</h2>
        				</div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                        <table class="table table-hover">
                            <style>
                                th, td {
                                  padding: 15px;
                                }
                            </style>
                            </style>
                        	<tr>
                        		<th><label>Name</label></th>
                        		<th><label>Address</label></th>
                        		<th><label>Place</label></th>
                        		<th><label>Mobile Number</label></th>
                        		<th><label>Date Of Birth</label></th>
                        		<th><label>Email</label></th>
                        		<th><label>Height</label></th>
                        		<th><label>Weight</label></th>
                        		<th><label>Sex</label></th>
                        		<th><label>Image</label></th>
                        		<th><label>Fee</label></th>
                        		<th><label>Action</label></th>
                        	</tr>
                        	<?php
                        	$sql="SELECT * FROM `candidate` WHERE aprove = '0' AND fee <> ''";
                        	$res=mysqli_query($kofa_candidate,$sql);
                        	while($row=mysqli_fetch_array($res))
                        	{ ?>
                        	<tr>
                        		<td><?php echo $row['name'];?></td>
                        		<td><?php echo $row['adds'];?></td>
                        		<td><?php echo $row['place'];?></td>
                        		<td><?php echo $row['mobile'];?></td>
                        		<td><?php echo $row['dob'];?></td>
                    			<td><?php echo $row['email'];?></td>
                        		<td><?php echo $row['height'];?></td>
                        		<td><?php echo $row['weight'];?></td>
                        		<td><?php echo $row['sex'];?></td>
                        		<td>
                                    <?php echo '<img  height="auto" width="50" alt="rounded" class="shadow col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"" src="data:image/jpeg;base64,'.base64_encode($row['image']).'" />'; ?>
                                </td>
                                <td><?php echo $row['fee'];?></td>
                        		<?php $candi = $row['id'];  ?> 
                        		<td>
                    		        <button class="btn btn-danger round "  id="<?php echo $candi; ?>" onClick=" aprvcd(this.id); ">Aprove Candidate</button>
                        		</td>
                        	</tr>
                        	<?php 
                        	}
                        	?>
                        </table>
                        <script>
                            function aprvcd(id) {
                                var aprovcd =  id;
                                $.ajax({
                                    type: "POST",
                                    // url: "http://sahayikendra.com/kofa/php/dashboard/approvedordeleted.php",
                                    url: "dashboard/approvedordeleted.php",
                                    data: {actyp : actyp, loginid : loginid, apcdid : aprovcd },
                                    cache: false,
                                    success: function(html) {
                                        document.getElementById(id).innerHTML = "Aproved";
                                        document.getElementById(id).style.backgroundColor = "green";
                                        // alert('Aprove Success');
                                    }
                                });   
                            }
                        </script>
                        <script>
                            function cdfeestr(id) {
                                var cdfeestr =  id;
                                $.ajax({
                                    type: "POST",
                                    // url: "http://sahayikendra.com/kofa/php/dashboard/approvedordeleted.php",
                                    url: "dashboard/ajx/ajaxkofa.php",
                                    data: { cdfeestr : cdfeestr },
                                    cache: false,
                                    success: function(html) {
                                        $("#main").html(html);
                                    }
                                });
                            }
                        </script>
                    </div>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            </div>
        </div>
        <?php
    }//else if close request aprove
    
    // in kofa first header register click for register candidate 
    if(isset($_POST['registerclick']))
    { ?>  
        <br>
            <div class="container">
                <div class="row">
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-0 col-0"></div>
                        <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                                <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 "></div>
                                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 bg-secondary text-light round text-center" >
                                    <h2 align="center round bg-progress">
                                        REGISTER CANDIDATE
                                    </h2>
                                </div>
                                <form method='post' class='row' enctype="multipart/form-data">
                                    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                                            <input type="text" name="name" class='form-control round' required >
                                            <label>Name</label>
                					    </fieldset>
                					</div>
                					<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                                            <input type="text" name="adds" class='form-control round' required >
                                            <label>Address</label>
                					    </fieldset>
                					</div>
                					<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                                            <input type="text" name="place" class='form-control round' required >
                                            <label>Place</label>
                					    </fieldset>
                					</div>
                					<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                                            <input type="text" name="mob" class='form-control round' required >
                                            <label>Mobile Number</label>
                					    </fieldset>
                					</div>
                					<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                                            <input type="email" name="email" class='form-control round' required >
                                            <label>Email</label>
                					    </fieldset>
                					</div>
                					
                					<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                                            <input type="date" name="dob" class='form-control round' required >
                                            <label>Date Of Birth</label>
                					    </fieldset>
                					</div>
                					
            						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                                        <fieldset>
                                            <input type="file" name="imagefile" class="form-control  custom-file-input" required>
                                            <label class="round custom-file-label">Choose Image</label>    
                                        </fieldset>
                                    </div>
                                    
                                    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                					        <input type='text' name='height' class='form-control round' required />
                					        <label>Height</label>
                                        </fieldset>
                                    </div>
                                    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                					        <input type='text' name='weight' class='form-control round' required />
                					        <label>Weight</label>
                                        </fieldset>
                                    </div>
                                    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                					        <select name='sex' class='form-control round' required >
                					            <option  disabled selected value>Select Sex</option>
                					            <option value='male'>Male</option>
                					            <option value='male'>Female</option>
                					            <option value='male'>Other</option>
                					        </select>
                                        </fieldset>
                                    </div>
                                    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                					        <input type='text' name='fee' class='form-control round' required />
                					        <label>Fee</label>
                                        </fieldset>
                                    </div>
                                    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                					        <input type='text' name='username' class='form-control round' required />
                					        <label>User Name</label>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                					    <fieldset>
                					        <input type='password' name='password' class='form-control round' required />
                					        <label>Password</label>
                                        </fieldset>
                                    </div>
                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                        <input type='submit' name='registerbtn' value='Register' class="round btn btn-success btn-block form-control" />
                                    </div>
                                </form>
                            </div>
                         </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-0 col-0"></div>
                </div>
            </div>
<?php
    }
    
    
    
    if(isset($_POST['createsuperacc']))
    { ?>
        <div class="container">
        	<div class="row">
        		<div class="col-xl-1 col-lg-1 col-md-1"></div>
        		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
        		<br>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 "></div>
                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 bg-secondary text-light round text-center" >
                            <h2 align="center round bg-progress">
                               <?php
                               echo 'Create Super Admin'; ?>
                            </h2>
                        </div>
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12" ></div>
                    </div>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12  "><br>
            				<form name="myform" action="dashboard/insertform.php" method="post" id="spr_form" class="row" enctype="multipart/form-data">
            				    <input type="hidden" name="actyp" id="actyp" value="<?php echo $_SESSION['ktp']; ?>">
                                <input type="hidden" name="loginid" id="loginid" value="<?php echo $_SESSION['kid']; ?>">
                                
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="name" id="name" class='form-control round' required="reqired"/>
        								<label>Name:</label>
        							</fieldset>
        							<span id="name_err"></span>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="username" id="uname" class='form-control round' required="reqired"/>
        								<label>User Name:</label>
        							</fieldset>
        							<span id="unm_err"></span>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="password" name="password" id="psswd" class='form-control round' required="reqired"/>
        								<label>Password:</label>
        							</fieldset>
        							<span id="pwd_err"></span>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        								<input type="button" value="submit" id="spr_adm_ac" name="submitsuperacc" onClick="sper_ac_crt();" class='form-control btn btn-success round'/>
        						</div>
        					</form>
        					
						<script>
                            function sper_ac_crt() {
                                document.getElementById("pwd_err").style.color = "red"; document.getElementById("unm_err").style.color = "red"; document.getElementById("name_err").style.color = "red";
                                var sub_btn_spr = document.getElementById("spr_adm_ac").value;
                                var actyp =  document.getElementById("actyp").value;
                                var loginid =  document.getElementById("loginid").value;
                                var name = document.getElementById("name").value;
                                var pwd = document.getElementById("uname").value;
                                var unm = document.getElementById("psswd").value;
                                if (name == "" && pwd == "" && unm == "") 
                                {
                                    document.getElementById("name_err").innerHTML = "Please Enter a Name"; 
                                    document.getElementById("pwd_err").innerHTML = "Please Enter a Password"; 
                                    document.getElementById("unm_err").innerHTML = "Please Enter a User Name";
                                    alert('Please Enter Name, Password and User Name');
                                }
                                else if (name == "") { document.getElementById("name_err").innerHTML = "Please Enter a Name"; alert('Please Enter a Name'); }
                                else if (pwd == "") { document.getElementById("pwd_err").innerHTML = "Please Enter a Password"; alert('Please Enter a Password'); }
                                else if (unm == "") { document.getElementById("unm_err").innerHTML = "Please Enter a User Name"; alert('Please Enter a User Name'); }
                                
                                if(name != "" && pwd != "" && unm != "") 
                                {
                                    document.getElementById("name_err").innerHTML = "";
                                    document.getElementById("pwd_err").innerHTML = "";
                                    document.getElementById("unm_err").innerHTML = "";
                                    
                                }
                                else if (name != "") { document.getElementById("name_err").innerHTML = ""; }
                                else if (pwd != "") { document.getElementById("pwd_err").innerHTML = ""; }
                                else if (unm != "") { document.getElementById("unm_err").innerHTML = ""; }
                                
                                if (name != "" && pwd != "" && unm != "") {
                                    $.post("dashboard/insertform.php", {
                                        actyp : actyp, 
                                        loginid : loginid,
                                        sub_btn_spr : sub_btn_spr,
                                        name : name,
                                        pwd : pwd,
                                        unm : unm
                                    },
                                    function(data) {
                                        alert(data);
                                        //$("#ins_expndtr").prop('value', 'Success');
                                        $("#spr_adm_ac").css("backgroundColor","green");
                                        //$('#results').html(data);
                                        $('#spr_form')[0].reset();
                                        alert('success');
                                    });
                                } 
                            }
                        </script>  
        					
        				</div>
        			</div>
        		</div>
        	</div>
        </div>

<?php    
    }
    
    
    //side nav create club
    if(isset($_POST['createclubacc']))
    {
        //echo $_POST['createclubacc'];
        ?>
        <div class="container">
        	<div class="row">
        		<div class="col-xl-1 col-lg-1 col-md-1"></div>
        		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
        		<br>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 "></div>
        				
                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 bg-secondary text-light round text-center" >
                            <h2 align="center round bg-progress">
                               <?php
                               echo 'Create Club Account'; ?>
                            </h2>
                        </div>
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12" ></div>
                    </div>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12  "><br>
        				    <form name="myform"  method="post" class="row" action='dashboard/insertform.php' enctype="multipart/form-data">
        				        <input type="hidden" name="actyp"   id="actyp" value="<?php echo $_SESSION['ktp']; ?>">
                                <input type="hidden" name="loginid" id="loginid" value="<?php echo $_SESSION['kid']; ?>">
                                <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="name" class='form-control round' required="reqired"/>
        								<label>Name:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                                    <fieldset>
                                        <input type="file" name="imagefile" class="form-control round custom-file-input" required>
                                        <label class="round custom-file-label" for="inputGroupFile02">Choose Logo Image</label>    
                                    </fieldset>
                                </div>
                                
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="email" name="email" class='form-control round' required="reqired"/>
        								<label>E-mail:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="phone" class='form-control round' required="reqired"/>
        								<label>Contact number:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="webadds" class='form-control round' required="reqired"/>
        								<label>Web Address:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="uname" class='form-control round' required="reqired"/> 
        								<label>User Name</label>
        							</fieldset>
        						</div>
        						<div class="col-xl-3 col-lg-3 col-md-3"></div>
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="password" name="password" class='form-control round' required="reqired"/> 
        								<label>Password</label>
        							</fieldset>
        						</div>
        						<div class="col-xl-3 col-lg-3 col-md-3"></div>   
        						<div class="col-xl-3 col-lg-3 col-md-3"></div>
        						<div class="  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    								<input type="submit" name="clubcreationreg" class='form-control btn btn-success round' />
        						</div>
        						<div class="col-xl-3 col-lg-3 col-md-3"></div>   
        					</form>
        				</div>
        			</div>
        		</div>
        	</div>
        </div>
<?php
    } // club else if close
    
    
    
    //view club side nav
    if(isset($_POST['viewclubdetl']))
    {
      ?>
      <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
        					<h2 align="center round bg-progress">CLUB DETAILS</h2>
        				</div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                        <table class="table table-hover">
                        	<tr>
                        		<th><label>Name</label></th>
                        		<th><label>Logo</label></th>
                        		<th><label>Email</label></th>
                        		<th><label>Contact Number</label></th>
                        		<th><label>Web Address</label></th>
                        		<th><label>Action</label></th>
                        	</tr>
                        	<?php
                        	$sqlclbdet="SELECT * FROM `kofa_club`";
                        	$resclbdet=mysqli_query($kofa_club,$sqlclbdet);
                        	while($row=mysqli_fetch_array($resclbdet))
                        	{ 
                        	    $clbid = $row['id'];
                        	?>
                        	<tr>
                        		<td><?php echo $row['name'];?></td>
                        		<?php
                        	        $img_logo = base64_encode($row['logo']);
                        		 echo "
                        		 <td>
                        		    <img class='round shadow' hieght='120px' width='200px' src='data:image/jpeg;base64,$img_logo' />
                        		 </td>";
                        		?>
                        		<td><?php echo $row['email'];?></td>
                        		<td><?php echo $row['contact'];?></td>
                        		<td><?php echo $row['webadds'];?></td>
                        		<td>
                                     <button class="btn btn-danger round"  id="<?php echo $clbid; ?>" onClick=" delclubid(this.id); ">Delete</button>
                        		</td>
                        	</tr>
                        	<?php 
                        	}
                        	?>
                        </table>
                        
                        	       
                        		
                       
                        <script>
                            function delclubid(id) {
                                var delclbid =  id;
                                $.ajax({
                                    type: "POST",
                                    // url: "http://sahayikendra.com/kofa/php/dashboard/approvedordeleted.php",
                                     url: "dashboard/approvedordeleted.php",
                                    data: { actyp : actyp, loginid : loginid, delclubid : delclbid },
                                    cache: false,
                                    success: function(html) {
                                        document.getElementById(id).innerHTML = "Deleted";
                                        document.getElementById(id).style.backgroundColor = "green";
                                       
                                        // alert('Aprove Success');
                                    }
                                });   
                            }
                        </script>
                    </div>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            </div>
        </div>
<?php        
    }//view club side nav
    
    
    //side nav createmainacc
    if(isset($_POST['createmainacc']))
    {
        //echo $_POST['createmainacc'];
    ?>
        <div class="container">
        	<div class="row">
        		<div class="col-xl-1 col-lg-1 col-md-1"></div>
        		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
        		<br>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 "></div>
                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 bg-secondary text-light round text-center" >
                            <h2 align="center round bg-progress">
                               <?php
                               echo 'Create Main Admin'; ?>
                            </h2>
                        </div>
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12" ></div>
                    </div>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12  "><br>
            				<form name="myform" action="dashboard/insertform.php" method="post" class="row" enctype="multipart/form-data">
                                <input type="hidden" name="actyp" id="actyp"   value="<?php echo $_SESSION['ktp']; ?>">
                                <input type="hidden" name="loginid"    id="loginid"  value="<?php echo $_SESSION['kid']; ?>">
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="name" class='form-control round' required="reqired"/>
        								<label>Name:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="username" class='form-control round' required="reqired"/>
        								<label>User Name:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="password" name="password" class='form-control round' required="reqired"/>
        								<label>Password:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        								<input type="submit" name="submicreatmain" class='form-control btn btn-success round'/>
        						</div>
            				</form>
        				</div>
        			</div>
        		</div>
        	</div>
        </div>
<?php
    } //main admin else if close
    
    //side nav createbatchacc
    if(isset($_POST['createbatchacc']))
    {
        //echo $_POST['createbatchacc'];
        ?>
        <div class="container">
        	<div class="row">
        		<div class="col-xl-1 col-lg-1 col-md-1"></div>
        		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
        		<br>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 "></div>
                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 bg-secondary text-light round text-center" >
                            <h2 align="center round bg-progress">
                               <?php
                               echo 'Create Batch Account'; ?>
                            </h2>
                        </div>
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12" ></div>
                    </div>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12  card shadow">
        				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        				    <form name="myform"  method="post" id="btch_frm" class="row" enctype="multipart/form-data">
        				        <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="name" id="bname" class='form-control round' required="reqired"/>
        								<label>Batch Name:</label>
        							</fieldset>
        							<span id="nm_err"></span>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" id="ag_lm" name="agelimit" class='form-control round' required="reqired"/>
        								<label>Age Limit:</label>
        							</fieldset>
        							<span id="age_err"></span>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" id="unm" name="username" class='form-control round' required="reqired"/>
        								<label>User Name:</label>
        							</fieldset>
        							<span id="unm_err"></span>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="password" id="pswd" name="password" class='form-control round' required="reqired"/>
        								<label>Password:</label>
        								<span id="pwd_err"></span>
        							</fieldset>
        						</div>
        						
        						<?php
        						if($acctyp != 'clubadmin')
        						{
        						?>
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    								<select type="text" name="club_sel_id" id="sel_clb" class='form-control round' required="reqired">
    								    <option disabled selected value>Select Club</option>
    								
    								 <?php
    								    //all club id from kofa club table
    								    $sqclb_id="SELECT * FROM `kofa_club`";
    								    $resclb_id=mysqli_query($kofa_club, $sqclb_id);
    								    while($rowclb_id=mysqli_fetch_array($resclb_id))
    								    { ?>
            								<option value="<?php echo  $rowclb_id['id']; ?>">
            								   <?php     echo  $rowclb_id['name']; ?>
            								</option>
								<?php   }
    								    ?>
    								</select>
    								<span id="clb_err"></span>
        						</div> 
        						<?php
        						}
        						?>
                        	    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                                    <input type="button" id="btch_sbmt" onClick = "spr_ac_crt();" name="submitbatchform" class="form-control round btn btn-success btn-block" value='submit' >
                                </div>
                            </form>
                            <script>
                            function spr_ac_crt() {
                                
                                
                                document.getElementById("nm_err").style.color = "red"; 
                                document.getElementById("age_err").style.color = "red";
                                document.getElementById("unm_err").style.color = "red";
                                document.getElementById("pwd_err").style.color = "red";
                            <?php
                            if($_SESSION['ktp'] != "clubadmin")
                            { ?>
                                document.getElementById("clb_err").style.color = "red";
                            <?php } ?>
                                
                                var btch_sbmt = document.getElementById("btch_sbmt").value;
                                var bname = document.getElementById("bname").value;
                                var ag_lm = document.getElementById("ag_lm").value;
                                var unm = document.getElementById("unm").value;
                                var pswd = document.getElementById("pswd").value;
                                
                            <?php
                            if($_SESSION['ktp'] != "clubadmin")
                            { ?>
                                var sel_clb = document.getElementById("sel_clb").value; 
                            <?php } ?>
                                
                                
                                
                                
                                
                                if (bname == "" ) {
                                    alert('Enter a Name');
                                    document.getElementById("nm_err").innerHTML = "Please Enter a Name";
                                } else if (ag_lm == "") {
                                    alert('Enter a Age Limit');
                                    document.getElementById("age_err").innerHTML = "Please Enter a Age Limit";
                                } else if (unm == "") {
                                    alert('Enter a User name');
                                    document.getElementById("unm_err").innerHTML = "Please Enter a User Nmae";
                                } else if (pswd == "") {
                                    alert('Enter a Password');
                                    document.getElementById("pwd_err").innerHTML = "Please Enter a Password";
                                } 
                            <?php
                            if($_SESSION['ktp'] != "clubadmin")
                            { ?>
                                else if (sel_clb == "") {
                                    alert('Select a Club');
                                    document.getElementById("clb_err").innerHTML = "Please Select a Club";
                                }
                            <?php } ?>
                                
                                if (bname != "" ) {
                                    document.getElementById("nm_err").innerHTML = "";  
                                } 
                                if (ag_lm != "") {
                                    document.getElementById("age_err").innerHTML = "";
                                } 
                                if (unm != "") {
                                    document.getElementById("unm_err").innerHTML = "";
                                } 
                                if (pswd != "") {
                                    document.getElementById("pwd_err").innerHTML = "";
                                    
                                } 
                            <?php
                            if($_SESSION['ktp'] != "clubadmin")
                            { ?>
                                if (sel_clb != "") {
                                    document.getElementById("clb_err").innerHTML = ""; 
                                }
                            <?php } ?>
                                
                                    
                                
                               
                            <?php
                            if($_SESSION['ktp'] == "clubadmin")
                            { ?>
                            
                                if (bname != "" && ag_lm != "" && unm != "" && pswd != "") {
                                    $.ajax({
                                        type: "POST",
                                        url: "dashboard/insertform.php",
                                        data: { actyp : actyp, loginid : loginid, btch_sbmt : btch_sbmt, bname : bname, ag_lm : ag_lm,
                                            unm : unm, pswd : pswd },
                                        cache: false,
                                        success: function(html) {
                                            alert('success');
                                            $('#btch_frm')[0].reset();
                                        }
                                    });
                                }
                                
                            <?php
                            }
                            else
                            {
                            ?>
                                if (bname != "" && ag_lm != "" && unm != "" && pswd != "" && sel_clb != "") {
                                    $.ajax({
                                        type: "POST",
                                        url: "dashboard/insertform.php",
                                        data: { actyp : actyp, loginid : loginid, btch_sbmt : btch_sbmt, bname : bname, ag_lm : ag_lm,
                                            unm : unm, pswd : pswd, sel_clb : sel_clb },
                                        cache: false,
                                        success: function(html) {
                                            alert('success');
                                            $('#btch_frm')[0].reset();
                                        }
                                    });
                                
                                } 
                    <?php } ?>
                            }
                        </script>  
        				</div>
        			</div>
        		</div>
        	</div>
        </div>	
        <?php
    }//batch create else if close
    
    
    
    
    
    //students aproved details in side nav
    if(isset($_POST['approvedreq']))
    { ?>
    <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
        					<h2 align="center round bg-progress">APROVED CANDIDATE DETAILS</h2>
        				</div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                        <table class="table table-hover">
                        	<tr>
                        		<th><label>Name</label></th>
                        		<th><label>Address</label></th>
                        		<th><label>Place</label></th>
                        		<th><label>Mobile Number</label></th>
                        		<th><label>Date Of Birth</label></th>
                        		<th><label>Email</label></th>
                        		<th><label>Height</label></th>
                        		<th><label>Weight</label></th>
                        		<th><label>Sex</label></th>
                        		<th><label>Image</label></th>
                        		<th><label>Action</label></th>
                        	</tr>
                        	<?php
                        	$sql="select * from candidate where aprove = '1'";
                        	$res=mysqli_query($kofa_candidate,$sql);
                        	while($row=$res->fetch_assoc())
                        	{?>
                        	<tr>
                        		<td><?php echo $row['name'];?></td>
                        		<td><?php echo $row['adds'];?></td>
                        		<td><?php echo $row['place'];?></td>
                        		<td><?php echo $row['mobile'];?></td>
                        		<td><?php echo $row['dob'];?></td>
                    			<td><?php echo $row['email'];?></td>
                        		<td><?php echo $row['height'];?></td>
                        		<td><?php echo $row['weight'];?></td>
                        		<td><?php echo $row['sex'];?></td>
                        		<td>
                                    <?php    echo '<img  height="auto" width="50" alt="rounded" class="shadow col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"" src="data:image/jpeg;base64,'.base64_encode($row['image']).'" />';
                                    ?>
                                </td>
                        		<?php
                        		$candi = $row['id'];  ?>
                        		<td> 
                    		        <button class="btn btn-success round"  id="<?php echo $candi; ?>" onClick=" aprvcd(this.id); ">Aproved</button>
                        		</td>
                        	</tr>
                        	<?php 
                        	}
                        	?>
                        </table>
                    </div>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            </div>
        </div>
        
<?php        
    }
    
    
    //side nav accountcalc
    if(isset($_POST['accountcalc']))
    {
        echo $_POST['accountcalc'];
    }
    
    //side nav expenditure
    if(isset($_POST['expenditure']))
    {
        //echo $_POST['expenditure'];
        ?>
        <div class="container">
        	<div class="row">
        		<div class="col-xl-1 col-lg-1 col-md-1"></div>
        		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
        		<br>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 "></div>
                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 bg-secondary text-light round text-center" >
                            <h2 align="center round bg-progress">
                               <?php
                               echo 'Expenditure'; ?>
                            </h2>
                        </div>
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12" ></div>
                    </div>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12  "><br>
            				<form name="myform" id="expend_form" method="post" class="row" enctype="multipart/form-data">
                                
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="salary" id="salary" class='form-control round' required="reqired"/>
        								<label>Salary:</label>
        							</fieldset>
        							<span  id="salaryError"></span>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        								<input type="button" id="ins_expndtr" value = "submit" name="add_expend" onClick = "expend_add();" class='form-control btn btn-success round'/>
        						</div>
            				</form>
            				<div id = "results"></div>
            				
        				<script>
                            function expend_add() {
                                var salary = document.getElementById("salary").value;
                                if (salary == "") {
                                    document.getElementById("salaryError").style.color = "red";
                                    document.getElementById("salaryError").innerHTML = "Please Enter a salary";
                                    alert('Enter a salary');
                                }
                                else {
                                    $.post("dashboard/insertform.php", {
                                    salary: salary
                                    },
                                    function(data) {
                                        $("#salaryError").html("");
                                        //$("#ins_expndtr").prop('value', 'Success');
                                        $("#ins_expndtr").css("backgroundColor","green");
                                        //$('#results').html(data);
                                        $('#expend_form')[0].reset();
                                        alert('success');
                                    });
                                } 
                            }
                        </script>  
        				</div>
        			</div>
        		</div>
        	</div>
        </div>
        
        
        
        
        <?php
    } //expenditure close
    
    //side nav createsubacc
    if(isset($_POST['createsubacc']))
    {
        //echo $_POST['createsubacc']; ?>
        <div class="container">
        	<div class="row">
        		<div class="col-xl-1 col-lg-1 col-md-1"></div>
        		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
        		<br>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 "></div>
                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 bg-secondary text-light round text-center" >
                            <h2 align="center round bg-progress">
                               <?php
                               echo 'Create Sub Admin'; ?>
                            </h2>
                        </div>
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12" ></div>
                    </div>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12  "><br>
            				<form name="myform" action="dashboard/insertform.php" method="post" class="row" enctype="multipart/form-data">
            				    <input type="hidden" name="actyp" id="actyp"  value="<?php echo $_SESSION['ktp']; ?>">
                                <input type="hidden" name="loginid" id="loginid" value="<?php echo $_SESSION['kid']; ?>">
                                
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="name" class='form-control round' required="reqired"/>
        								<label>Name:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="username" class='form-control round' required="reqired"/>
        								<label>User Name:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="password" name="password" class='form-control round' required="reqired"/>
        								<label>Password:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        								<input type="submit" name="submisubacc" class='form-control btn btn-success round'/>
        						</div>
            				</form>
        				</div>
        			</div>
        		</div>
        	</div>
        </div>
        <?php
    }//else if close
    
    //side nav creatementacc
    if(isset($_POST['creatementacc']))
    {
        //echo $_POST['creatementacc']; ?>
        <div class="container">
        	<div class="row">
        		<div class="col-xl-1 col-lg-1 col-md-1"></div>
        		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
        		<br>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 "></div>
                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 bg-secondary text-light round text-center" >
                            <h2 align="center round bg-progress">
                               <?php
                               echo 'Create Ment Admin'; ?>
                            </h2>
                        </div>
                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12" ></div>
                    </div>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12  "><br>
            				<form name="myform" action="dashboard/insertform.php" method="post" class="row" enctype="multipart/form-data">
            				    <input type="hidden" name="actyp" id="actyp"  value="<?php echo $_SESSION['ktp']; ?>">
                                <input type="hidden" name="loginid" id="loginid" value="<?php echo $_SESSION['kid']; ?>">
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="name" class='form-control round' required="reqired"/>
        								<label>Name:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="text" name="username" class='form-control round' required="reqired"/>
        								<label>User Name:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
        							<fieldset>
        								<input type="password" name="password" class='form-control round' required="reqired"/>
        								<label>Password:</label>
        							</fieldset>
        						</div>
        						
        						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        								<input type="submit" name="submitcreatment" class=' form-control btn btn-success round'/>
        						</div>
            				</form>
        				</div>
        			</div>
        		</div>
        	</div>
        </div>
        <?php
    }//else if close create ment admin
    
    //side nav feedet
    if(isset($_POST['feedet']))
    { ?>
        <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
        					<h2 align="center round bg-progress">FEE NOT PAYED DETAILS </h2>
        				</div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                        <table class="table table-hover">
                        	<tr>
                        		<th><label>Name</label></th>
                        		<th><label>Address</label></th>
                        		<th><label>Place</label></th>
                        		<th><label>Mobile Number</label></th>
                        		<th><label>Email</label></th>
                        		<th><label>Sex</label></th>
                        	
                        	</tr>
                        	<?php
                        	$sql="select * from candidate where fee = '' ";
                        	$res=mysqli_query($kofa_candidate,$sql);
                        	while($row=$res->fetch_assoc())
                        	{?>
                        	<tr>
                        		<td><?php echo $row['name'];?></td>
                        		<td><?php echo $row['adds'];?></td>
                        		<td><?php echo $row['place'];?></td>
                        		<td><?php echo $row['mobile'];?></td>
                        		<td><?php echo $row['email'];?></td>
                        		<td><?php echo $row['sex'];?></td>
                        	</tr>
                        	<?php 
                        	}
                        	?>
                        </table>
                    </div>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            </div>
        </div>
        <?php
    }//else if close fee details
    
    
    //side nav fee apyed details
    if(isset($_POST['feepaydet']))
    {
        //echo $_POST['feepaydet']; ?>
                <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
        					<h2 align="center round bg-progress">FEE PAYED DETAILS </h2>
        				</div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                        <table class="table table-hover">
                        	<tr>
                        		<th><label>Name</label></th>
                        		<th><label>Address</label></th>
                        		<th><label>Place</label></th>
                        		<th><label>Mobile Number</label></th>
                        		<th><label>Email</label></th>
                        		<th><label>Sex</label></th>
                        	
                        	</tr>
                        	<?php
                        	$sql="select * from candidate where fee <> '' ";
                        	$res=mysqli_query($kofa_candidate,$sql);
                        	while($row=$res->fetch_assoc())
                        	{?>
                        	<tr>
                        		<td><?php echo $row['name'];?></td>
                        		<td><?php echo $row['adds'];?></td>
                        		<td><?php echo $row['place'];?></td>
                        		<td><?php echo $row['mobile'];?></td>
                        		<td><?php echo $row['email'];?></td>
                        		<td><?php echo $row['sex'];?></td>
                        	</tr>
                        	<?php 
                        	}
                        	?>
                        </table>
                    </div>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            </div>
        </div>
        
        <?php
    }//else if close fee apyed details
    
    //side nav instruc
    if(isset($_POST['instruc']))
    {
        echo $_POST['instruc']; ?>
        <?php
    }//else if close instructure
    
    //side nav dataentrydet
    if(isset($_POST['dataentrydet']))
    {
        echo $_POST['dataentrydet']; 
        ?>
        <?php
    }//else if close data entry details
    
    //side nav accountcalc
    if(isset($_POST['accountcalc']))
    {
        echo $_POST['accountcalc']; 
        ?>
        <?php
    }//else if close accounting calculation
    
    //side nav checkdet
    if(isset($_POST['checkdet']))
    {
        echo $_POST['checkdet'];
    }//else if close check details 
    

    
    
    
    
    
    
    //transaction details in ment admin
    if(isset($_POST['transactiondet']))
    {
        if(isset($_SESSION['kid']))
        {
            echo $lgid = $_SESSION['kid'];
            $sqllg = "SELECT *  FROM `kofa_login` WHERE id = '$lgid'";
            $reslg = mysqli_query($kofa_login, $sqllg);
            $rolg = mysqli_fetch_array($reslg);
            echo $cndtt = $rolg['uid'];
        }
        $sqlcln = "SELECT DISTINCT bank_id FROM `challan` WHERE candidate_id = '$cndtt'";
        $rescln = mysqli_query($kofa_transaction, $sqlcln);
        ?>
        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 " >
            <SELECT name="bank"  id="bankid" class="round form-control" >
                <option disabled selected value>
                    Select Bank
                </option>
        <?php
        while($rowcln=mysqli_fetch_array($rescln))
        { 
            //bank id from challan table
            $bnkchid = $rowcln['bank_id'];
            $sqbn = "SELECT * FROM `bank` WHERE id = '$bnkchid'";
            $rebn = mysqli_query($kofa_transaction, $sqbn);
            $robn=mysqli_fetch_array($rebn);   
        ?>
                <option value = "<?php echo $robn['id']; ?>" >
                    <?php echo $robn['bank_name']; ?>
                </option>
        <?php
        }
        ?>
            </SELECT>
        </div>
        <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
		    <fieldset>
		        <input type='text' name='transaction_id' class='form-control round' required />
		        <label>Transaction</label>
            </fieldset>
        </div>
        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
		    <fieldset>
		        <input type='date' name='date' class='form-control round' required />
		        <label>Date</label>
            </fieldset>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            <input type='submit' name='regbankdet' value='Register' class="round btn btn-success btn-block form-control" />
        </div>
    <?php
    } //transaction details in ment admin close
    
    
    
    //print challan button in ment admin 
    if(isset($_POST['printchallan']))
    {
        if(isset($_SESSION['kid']))
        {
            echo $lgin_id =  $_SESSION['kid'] ;
        }
        
        $sqlg = "SELECT `id`, `uid` FROM `kofa_login` WHERE id = '$lgin_id'";
        $relg=mysqli_query($kofa_login,$sqlg);
        $rolg=mysqli_fetch_array($relg);
        echo 'candidate id = '.$candidate_id = $rolg['uid'];
        
        $sqlcnd = "SELECT * FROM `candidate` WHERE id = '$candidate_id' ";
        $rec=mysqli_query($kofa_candidate,$sqlcnd);
        $roc=mysqli_fetch_array($rec);
        echo 'batch id = '.$btch_id = $roc['batch_id'];
        
        
        $sqbch = "SELECT * FROM `kofa_batch` WHERE id = '$btch_id' ";
        $rebch=mysqli_query($kofa_batch,$sqbch);
        $robch=mysqli_fetch_array($rebch);
        echo  'clubid = '.$club_id = $robch['club_id'];
       
        
        
        
        
    ?>
        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 " >
            
            <SELECT name="bank_print"  id="bankid" required class="round form-control" >
                <option disabled selected value>
                    Select Bank
                </option> 
        <?php
        $sqlchl = "SELECT * FROM `bank` WHERE club_id = '$club_id'";
        $reschl = mysqli_query($kofa_transaction, $sqlchl);
        while($row=mysqli_fetch_array($reschl))
        {
            echo $bnkid = $row['id'];
            $sqlbnk = "SELECT * FROM `bank` where id = '$bnkid'";
            $resbnk=mysqli_query($kofa_transaction, $sqlbnk);
            $rowbnk=mysqli_fetch_array($resbnk);  
            ?>    
                <option value="<?php echo $rowbnk['id']; ?>">
                    <?php echo $rowbnk['bank_name']; ?>
                </option>
        <?php
        } ?>
        </select>
        </div>
        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
            <input type='submit' name='printchallan' value='printchallan' class="round btn btn-success btn-block form-control" />
        </div>
        
        <?php
    } //print challan in ment admin close
    
    //club admin bank select candidate details preview
    if(isset($_POST['bankidclub']))
    {
            $idbnk = $_COOKIE['bankidckmnt'];
            
            $clubidck = $_COOKIE['clubidcookie'];
            
            $sqlbatch="SELECT * FROM kofa_batch WHERE club_id = '$clubidck'  ";
            $resbatch=mysqli_query($kofa_batch, $sqlbatch);
            $rowbatch=mysqli_fetch_array($resbatch);
            $idbatch = $rowbatch['id'];
            
            
            $sqcln="SELECT * FROM kofa_transaction.challan, kofa_candidate.candidate, kofa_batch.kofa_batch
            WHERE kofa_transaction.challan.candidate_id = kofa_candidate.candidate.id 
            AND challan.candidate_id <> '$cnd_id' 
            AND challan.approve <> '1'
            AND `candidate`.`batch_id` =  '$idbatch' 
            AND challan.bank_id = '$idbnk'
            AND kofa_batch.club_id = '$clubidck'";
            $recand= mysqli_query($db_selected, $sqcln);
            $rocand=mysqli_fetch_array($recand);
            echo 'candid = '. $canddid = $rocand['candidate_id'];
            
            $sqcanditt="SELECT * FROM candidate WHERE id = '$canddid' ORDER BY id ASC LIMIT 1";
            $rcanditt=mysqli_query($kofa_candidate,$sqcanditt);
            $rocandett=mysqli_fetch_array($rcanditt);
            echo 'candidate details in table id = '. $rocandett['id'];
                ?>
            <script> cookiid(); function cookiid() { document.cookie = "cdidck=" + '<?php echo $rocandett['id']; ?>'; } </script>
            <table class="table table-hover">
                <tr>
                    
                    <th><label>Name</label></th>
                    <th><label>Address</label></th>
                    <th><label>Mobile</label></th>
                    <th><label>Email</label></th>
                    <th><label>Place</label></th>
                </tr>
                <tr>
                    <td><?php echo $rocandett['name']; ?></td>
                    <td><?php echo $rocandett['adds']; ?></td>
                    <td><?php echo $rocandett['mobile']; ?></td>
                    <td><?php echo $rocandett['email']; ?></td>
                    <td><?php echo $rocandett['place']; ?></td>
                </tr>
            </table>
        <br>
            <form method='post' id="aprovechlnform" class='row' enctype="multipart/form-data">
                <input type="hidden" name="cand_id" id="cand_id" value="<?php echo   $rocandett['id']; ;?> " />
                <input type="hidden" name="bank_id" id="bank_id" value="<?php echo   $idbnk ;?> " />
                <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 texting-in ">
    			    <fieldset>
                        <input type="text" id="transaction" name="transaction" class='form-control round' required >
                        <label>Transaction id</label>
    			    </fieldset>
    			    <span id="TransactionError"></span>
    			</div>
    			<div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 texting-in ">
    			    <fieldset>
                        <input type="text" id="date" name="date" class='form-control round' required >
                        <label>Date</label>
    			    </fieldset>
    			    <span id="DateError"></span>
    			</div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                    <input type='button' id="aprovechallan" name='aprovechln' onClick="AproveDataid(this.id);" value='Aprove' class="round btn btn-danger btn-block form-control" />
                </div>
                
                
                
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
    	            <button type ="submit" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12  btn btn-info  form-control round" onClick="cookiid(); next();">Next</button>
                </div>
                <script>
        	        function cookiid()
        	        {
        	            document.cookie = "candidteidck=" + '<?php echo $rocandett['id']; ?>';
        	        }
        	    </script>
            </form>

            <div id="results"></div>
            <script>
                function AproveDataid() {
                    document.getElementById("TransactionError").style.color = "red";
                    document.getElementById("DateError").style.color = "red";
                    
                    
                    var Transaction = document.getElementById("transaction").value;
                    var DateTransaction = document.getElementById("date").value;
                    
                    if (Transaction == "" && DateTransaction == "") { document.getElementById("TransactionError").innerHTML = "Please Enter a Transaction"; document.getElementById("DateError").innerHTML = "Please Enter a Date"; alert('Please Enter a Transaction and Date'); }
                    else if (DateTransaction == "") { document.getElementById("TransactionError").innerHTML = "Please Enter a Transaction"; alert('Please Enter a Date'); }
                    else if (Transaction == "") { document.getElementById("DateError").innerHTML = "Please Enter a Date"; alert('Please Enter a Date'); }
                    
                    if(Transaction != "" && DateTransaction != "") { document.getElementById("TransactionError").innerHTML = ""; document.getElementById("DateError").innerHTML = ""; }
                    else if (Transaction != "") { document.getElementById("TransactionError").innerHTML = ""; }
                    else if (DateTransaction != "") { document.getElementById("DateError").innerHTML = ""; }
                    
                    if (Transaction != "" && DateTransaction != "") {
                        var cand_id = $("#cand_id").val();
                        var bank_id = $("#bank_id").val();
                        var aprovechalanbutton = $("#aprovechallan").val();
                        var transaction = $("#transaction").val();
                        var date = $("#date").val();
                        
                        $.post("approvedordeleted.php", { aprovechalanbutton: aprovechalanbutton, transaction: transaction, date: date, cand_id: cand_id, bank_id: bank_id },
                            function(data) {
                                $("#TransactionError").html(""); $("#DateError").html("");
                                $('#results').html(data);
                                $('#aprovechlnform')[0].reset();
                                $("#aprovechallan").prop('value', 'Aproved');
                                $("#aprovechallan").css("backgroundColor","green");
                                //document.getElementById("aprovechallan").className = "btn btn-" + themeType + "success";
                                document.getElementById("aprovechallan").disabled = true;
                            }
                        );
                    }
                }
            </script>
        <?php
            
    }//club admin bank select ajax close
    
    
    //club admin bank next button ajax in club admin for next candidate id details with transaction details approve challan 
    if(isset($_POST['nextcandidate']))
    {
        $idbnk = $_COOKIE['bankidckmnt'];

    	$sqlbnk="SELECT * FROM bank WHERE id='$idbnk'  ";
    	$res=mysqli_query($kofa_transaction,$sqlbnk);
    	$row=mysqli_fetch_array($res);
    	$clbid = $row['club_id']; 
    	
    	$sqlbatch="SELECT * FROM kofa_batch WHERE club_id='$clbid'  ";
    	$resbatch=mysqli_query($kofa_batch,$sqlbatch);
    	$rowbatch=mysqli_fetch_array($resbatch);
    	$idbatch = $rowbatch['id'];
        ?>
        <div>
    	<?php
    	echo 'candidateid='. $cnd_id = $_COOKIE['candidteidck'];
    	
            echo  'clubid in cookie ='. $clubidck = $_COOKIE['clubidcookie'];
            
            // $sqlbatch="SELECT * FROM kofa_batch WHERE club_id = '$clubidck'  ";
            // $resbatch=mysqli_query($kofa_batch, $sqlbatch);
            // $rowbatch=mysqli_fetch_array($resbatch);
            // echo 'batch_id = ' . $idbatch = $rowbatch['id'];
            
            // $sqlcand="SELECT * FROM candidate WHERE batch_id='$idbatch' AND id <> '$cnd_id' ";
            // $recand=mysqli_query($kofa_candidate,$sqlcand);
            // $rocand=mysqli_fetch_array($recand);
            // echo 'candid = '. $cid = $rocand['id'];
            
            $sqcln="SELECT * FROM kofa_transaction.challan, kofa_candidate.candidate, kofa_batch.kofa_batch
            WHERE kofa_transaction.challan.candidate_id = kofa_candidate.candidate.id 
            AND challan.candidate_id <> '$cnd_id' 
            AND challan.approve <> '1'
            AND challan.bank_id = '$idbnk'
            AND `candidate`.`batch_id` =  kofa_batch.id ";
            $recand= mysqli_query($db_selected, $sqcln);
            $rocand=mysqli_fetch_array($recand);
            echo 'candid = '. $canddid = $rocand['candidate_id'];
            if($canddid != '' || isset($canddid))
            {
            	$sqlcandidatedetails="SELECT * FROM candidate WHERE id = '$canddid' ORDER BY id ASC LIMIT 1";
            	 
            	$rescandidatedetails=mysqli_query($kofa_candidate,$sqlcandidatedetails);
            	$rowcandidatedetails=mysqli_fetch_array($rescandidatedetails);
            	$cid = $rowcandidatedetails['id'];
            	
                echo  $rowcandidatedetails['id'];
                if($rowcandidatedetails['id'] <> '')
                {
                    ?>
                    <table class="table table-hover col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" >
                    	<tr>
                            <th><label>Name</label></th>
                            <th><label>Address</label></th>
                            <th><label>Mobile</label></th>
                            <th><label>Email</label></th>
                            <th><label>Place</label></th>
                        </tr>
                        <tr>
                                <td><?php echo $rowcandidatedetails['name']; ?></td>
                                <td><?php echo $rowcandidatedetails['adds']; ?></td>
                                <td><?php echo $rowcandidatedetails['mobile']; ?></td>
                                <td><?php echo $rowcandidatedetails['email']; ?></td>
                                <td><?php echo $rowcandidatedetails['place']; ?></td>
                        </tr>
                    </table>
                    
                    <form method='post' id="aprovechlnform" class='row'  enctype="multipart/form-data">
                        <input type="hidden" name="cand_id" id="cand_id" value="<?php echo  $rowcandidatedetails['id'] ;?> " />
                        <input type="hidden" name="bank_id" id="bank_id" value="<?php echo   $idbnk ;?> " />
                        <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 texting-in ">
            			    <fieldset>
                                <input type="text" id="transaction" name="transaction" class='form-control round' required >
                                <label>Transaction id</label>
            			    </fieldset>
            			    <span id="TransactionError"></span>
            			</div>
            			<div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 texting-in ">
            			    <fieldset>
                                <input type="text" id="date" name="date" class='form-control round' required >
                                <label>Date</label>
            			    </fieldset>
            			    <span id="DateError"></span>
            			</div>
            		
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                            <input type='button' id="aprovechallan" name='aprovechln' onClick="AproveDataid(this.id);" value='Aprove' class="round btn btn-danger btn-block form-control" />
                        </div>
                        
                        
                        
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
            	            <button class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12  btn btn-info  form-control round" onClick="cookiid(); next();">Next</button>
                        </div>
                        
                        <script>
                            function cookiid()
                            {
                                document.cookie = "candidteidck=" + '<?php echo $rowcandidatedetails['id']; ?>';
                            }
                        </script>.
                    </form>
                    <div id="results"></div>
                    <script>
                    function AproveDataid() {
                    var Transaction = document.getElementById("transaction").value;
                    var DateTransaction = document.getElementById("date").value;
                    
                    if (Transaction == "" && DateTransaction == "") { document.getElementById("TransactionError").innerHTML = "Please Enter a Transaction"; document.getElementById("DateError").innerHTML = "Please Enter a Date"; alert('Please Enter a Transaction and Date'); }
                    else if (DateTransaction == "") { document.getElementById("TransactionError").innerHTML = "Please Enter a Transaction"; alert('Please Enter a Date'); }
                    else if (Transaction == "") { document.getElementById("DateError").innerHTML = "Please Enter a Date"; alert('Please Enter a Date'); }
                    
                    if(Transaction != "" && DateTransaction != "") { document.getElementById("TransactionError").innerHTML = ""; document.getElementById("DateError").innerHTML = ""; }
                    else if (Transaction != "") { document.getElementById("TransactionError").innerHTML = ""; }
                    else if (DateTransaction != "") { document.getElementById("DateError").innerHTML = ""; }
                    
                    if (Transaction != "" && DateTransaction != "") {
                        var cand_id = $("#cand_id").val();
                        var bank_id = $("#bank_id").val();
                        var aprovechalanbutton = $("#aprovechallan").val();
                        var transaction = $("#transaction").val();
                        var date = $("#date").val();
                        
                        $.post("approvedordeleted.php", { aprovechalanbutton: aprovechalanbutton, transaction: transaction, date: date, cand_id: cand_id, bank_id: bank_id },
                        //post_to_url('http://sahayikendra.com/kofa/test/ajx.php', {'ssssbbb': 'ssssbbb', 'name': 'name', 'email': 'email', 'phone': 'phone'});
                        function(data) {
                            if(data == 'no value')
                            {
                                $('#results').html(data);
                                $('#aprovechlnform')[0].reset();
                                $("#aprovechallan").prop('value', 'Aprove');
                                //$("#aprovechallan").css("backgroundColor","red");
                                document.getElementById("aprovechallan").className = "btn btn-" + themeType + "danger";
                            }
                            else
                            {
                                $('#results').html(data);
                                $("#aprovechallan").prop('value', 'Aproved');
                                //$("#aprovechallan").css("backgroundColor","green");
                                document.getElementById("aprovechallan").className = "btn btn-" + themeType + "success";
                            }
                            
                        });
                    }
                }
                    </script>
            <?php
                }
                
            }
            else
            {
                echo "<h1 align = 'center'>NO DATA</h1>";
            }
    	?> 
        </div>
        <?php  
    } //club admin bank next button ajax in club admin for next candidate id details with transaction details approve challan 
    
    //bank select ifram bank url
    if(isset($_POST['bnk_id']))
    {
        $id_bnk = $_POST['bnk_id'];
        $sqlb = "SELECT * FROM `bank` WHERE id = '$id_bnk'";
        $reb=mysqli_query($kofa_transaction,$sqlb);
        $rob=mysqli_fetch_array($reb);
        $burl = $rob['url'];
        ?>
        <iframe class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" frameborder="0" scrolling="no" onload="resizeIframe(this)" style="overflow:hidden; border-style: none;width:  100%; height: 100%; " src="<?php echo $burl; ?>"></iframe>
    <?php
    }
    
    //addbank in side nave in club/sub admin
    if(isset($_POST['addbank']))
    { ?>
     <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
    				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
    					<h2 align="center round bg-progress">ADD BANK DETAILS </h2>
    				</div>
    				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                        
                    <form method='post'  class='row' action='dashboard/insertform.php'  enctype="multipart/form-data">
                        <input type="hidden" name="actyp" id="actyp"  value="<?php echo $_SESSION['ktp']; ?>">
                                <input type="hidden" name="loginid" id="loginid" value="<?php echo $_SESSION['kid']; ?>">
                        
                        <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            			    <fieldset>
                                <input type="text" name="bankname" class='form-control round' required >
                                <label>Bank Name</label>
            			    </fieldset>
            			</div>
            			
            			    
            		    <?php
            		    if($acctyp == 'ouradmin')
            		    {
            		        $sqlclb = "select * from kofa_club";
            		        $resclb = mysqli_query($kofa_club, $sqlclb);
            		        ?>
                		    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
                                <select name="club_id" class='form-control round' required >
                                    <option disabled selected value>
                                        Select Club
                                    </option> 
                                    <?php
                                    while($rowclb = mysqli_fetch_array($resclb))
                    		        {
                    		        ?>
                                    <option value="<?php echo $rowclb['id']; ?>">
                                    <?php
                                        echo $rowclb['name'];
                    		        } ?>
                                    </option>
                                </select>
                			</div>
            			<?php  
                        }
                        ?>
            			<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            			    <fieldset>
                                <input type="text" name="Acc_no" class='form-control round' required >
                                <label>Account Number</label>
            			    </fieldset>
            			</div>
            			 <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            			    <fieldset>
                                <input type="text" name="Bank_brach" class='form-control round' required >
                                <label>Branch</label>
            			    </fieldset>
            			</div>
            			 <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            			    <fieldset>
                                <input type="text" name="ifc_code" class='form-control round' required >
                                <label>IFS code</label>
            			    </fieldset>
            			</div>
            			 <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            			    <fieldset>
                                <input type="text" name="Bank_date" class='form-control round' required >
                                <label>Date</label>
            			    </fieldset>
            			</div>
            			 
            			 <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            			    <fieldset>
                                <input type="text" name="Bank_url" class='form-control round' required >
                                <label>Bank Url</label>
            			    </fieldset>
            			</div>
            			
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                            <input type='submit' name='Add_bank' value='Add Bank' class="round btn btn-success btn-block form-control" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
        
        
    <?php    
    }//close addbank in side nave in club/sub admin
    
    
    
    //approve club from side nav aproveclub
    if(isset($_POST['aproveclub']))
    { ?>
        <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
        					<h2 align="center round bg-progress">CLUB DETAILS APROVE</h2>
        				</div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                        <table class="table table-hover">
                        	<tr>
                        	    
                        		<th><label>Name</label></th>
                        		<th><label>Logo</label></th>
                        		<th><label>Email</label></th>
                        		<th><label>Contact Number</label></th>
                        		<th><label>Web Address</label></th>
                        		<th><label>Action</label></th>
                        	</tr>
                        	<?php
                        	$sql="select * from kofa_club where aprove <> '1'";
                        	$res=mysqli_query($kofa_club,$sql);
                        	while($row=$res->fetch_assoc())
                        	{?>
                        	<tr>
                        		<td><?php echo $row['name'];?></td>	
                        		<td>
                                    <?php    echo '<img  height="auto" width="50" alt="rounded" class="shadow col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"" src="data:image/jpeg;base64,'.base64_encode($row['logo']).'" />';
                                    ?>
                                </td>
                    			<td><?php echo $row['email'];?></td>
                        		<td><?php echo $row['contact'];?></td>
                        		<td><?php echo $row['webadds'];?></td>
                        	
                        		<?php
                        		$clbapid = $row['id'];  ?>
                        		<td>
                    		        <button class="btn btn-danger round"  id="<?php echo $clbapid; ?>" onClick=" aproveclubdet(this.id); ">Aprove</button>
                    		        <script>
                                        function aproveclubdet(id) {
                                            var aproveclubdet =  "<?php echo $clbapid; ?>";
                                            $.ajax({
                                                type: "POST",
                                                // url: "http://sahayikendra.com/kofa/php/dashboard/approvedordeleted.php",
                                                url: "dashboard/approvedordeleted.php",
                                                data: { actyp : actyp, loginid : loginid, aproveclubdet : aproveclubdet },
                                                cache: false,
                                                
                                                success: function(html) {
                                                    alert('Aprove Success');
                                                    document.getElementById("<?php echo $clbapid; ?>").innerHTML = "Aproved";
                                                    document.getElementById("<?php echo $clbapid; ?>").style.backgroundColor = "green";
                                                    $(id).prop('value', 'Aproved');
                                                    $(id).css("backgroundColor","green");
                                                    
                                                }
                                            });   
                                        }
                                    </script>
                        		</td>
                        	</tr>
                        	<?php 
                        	}
                        	?>
                        </table>
                    </div>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            </div>
        </div>
        <?php
    }//aprove club close
    
    
    //aproved club details from side nav aproveclub
    if(isset($_POST['aprovedclubdet']))
    { 
        //echo $_POST['aprovedclubdet']; ?>
        <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
        					<h2 align="center round bg-progress">APROVED CLUB DETAILS</h2>
        				</div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                        <table class="table table-hover">
                        	<tr>
                        		<th><label>Name</label></th>
                        		<th><label>Logo</label></th>
                        		<th><label>Email</label></th>
                        		<th><label>Contact Number</label></th>
                        		<th><label>Web Address</label></th>
                        		<th><label>Action</label></th>
                        	</tr>
                        	<?php
                        	$sql="select * from kofa_club where aprove = '1'";
                        	$res=mysqli_query($kofa_club,$sql);
                        	while($row=$res->fetch_assoc())
                        	{?>
                        	<tr>
                        		<td><?php echo $row['name'];?></td>	
                        		<td>
                                    <?php    echo '<img  height="auto" width="50" alt="rounded" class="shadow col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"" src="data:image/jpeg;base64,'.base64_encode($row['logo']).'" />';
                                    ?>
                                </td>
                    			<td><?php echo $row['email'];?></td>
                        		<td><?php echo $row['contact'];?></td>
                        		<td><?php echo $row['webadds'];?></td>
                        	
                        		<?php
                        		$clbapid = $row['id'];  ?>
                        		<td>
                    		        <button class="btn btn-success round"  >Aproved</button>
                        		</td>
                        	</tr>
                        	<?php 
                        	}
                        	?>
                        </table>
                    </div>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            </div>
        </div>
        <?php
    }//aproved club details close
    
    //student fee structure
    if(isset($_POST['cdfeestr']))
    {
        $cand_id = $_POST['cdfeestr'];
    ?>
    
        <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
        					<h2 align="center round bg-progress">CANDIDATE DETAILS</h2>
        				</div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
                    <?php
                    $sqlcd = "select * from candidate where id = '$cand_id'"; 
                    $recd = mysqli_query($kofa_candidate, $sqlcd);
                    $rocd = mysqli_fetch_array($recd);
                    $rocd['id'];
                    
                    //fee
                    $fee = $rocd['fee'];
                    
                    //date
                    $fee_dt = $rocd['fee_structure'];
                    
                    $td_dt = date("Y-m-d");
                    
                    // $start_date = strtotime("2018-06-08"); 
                    // $end_date = strtotime("2018-09-19"); 
                    $start_date = strtotime($fee_dt); 
                    $end_date = strtotime($td_dt);
                    
                    $diff = abs($end_date - $start_date);
                    $years = floor($diff / (365*60*60*24));  
                    
                    $months = floor(($diff - $years * 365*60*60*24) / (30*60*60*24)); 
                    
                    $c = $fee * $months;
                    ?>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow ">
                        <div id="feestructure_form" class='row' >
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                                <fieldset>
        					        <select name='fee_sel' id = "fee_sel" class='form-control round' required >
        					            <option  disabled selected value>Select fee</option>
        					           <?php
        					           //check date and fee ,first fee multiplied by th number of months from the first fee addedd 
        					           for ($n = $fee; $n <= $c; $n+=$fee) { ?>
        					            <option value='<?php echo $n; ?>'><?php echo $n; ?></option>
        					            <?php
        					           }
        					           ?>
        					        </select>
                                </fieldset>
                            </div>
                            
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
    					        <input type = "button" id="print_cln_fe" name="print_cln_fe" value = "Print Challan" class=" form-control col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-danger round" onClick=" prnt_cln_fe(); " value = "Print Challan"/>
                            </div>
                        </div>
                        <div id= "results"></div>
                        <script>
                            function prnt_cln_fe() {
                                var print_cln_fe_btn = document.getElementById("print_cln_fe").value;
                                var fee_selected = document.getElementById("fee_sel").value;
                                $.post("dashboard/approvedordeleted.php", {
                                    print_cln_fe_btn: print_cln_fe_btn,
                                    fee_selected: fee_selected
                                },
                                function(data) {
                                    $("#print_cln_fe").prop('value', 'Success');
                                    $("#print_cln_fe").css("backgroundColor","green");
                                    document.getElementById("print_cln_fe").disabled = true;
                                    $('#results').html(data);
                                    
                                    
                                });
                            }
                        </script>  
                    </div>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            </div>
        </div>
        
<?php
    }//close student fee structure
    
    
    //student deteails fee structure
    if(isset($_POST['stdfeest']))
    {
        //echo $_POST['stdfeest'];
        ?>
        
        <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
        					<h2 align="center round bg-progress">CANDIDATE DETAILS</h2>
        				</div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                        <table class="table table-hover">
                            <style>
                                th, td {
                                  padding: 15px;
                                }
                            </style>
                            </style>
                        	<tr>
                        		<th><label>Name</label></th>
                        		<th><label>Address</label></th>
                        		<th><label>Place</label></th>
                        		<th><label>Mobile Number</label></th>
                        		<th><label>Date Of Birth</label></th>
                        		<th><label>Email</label></th>
                        		<th><label>Height</label></th>
                        		<th><label>Weight</label></th>
                        		<th><label>Sex</label></th>
                        		<th><label>Image</label></th>
                        		<th><label>Fee</label></th>
                        		<th><label>Action</label></th>
                        	</tr>
                        	<?php
                        	 // login uid select from club id = $clubid
                        	 // $acctyp = SESSION login account type
                        	if($acctyp == 'clubadmin')
                            {
                                $sqcndt="SELECT 
                                kofa_candidate.candidate.id as cd_id,
                                kofa_candidate.candidate.name as cd_nm,
                                kofa_candidate.candidate.adds as cd_adds ,
                                kofa_candidate.candidate.place as cd_place ,
                                kofa_candidate.candidate.mobile as cd_mobile ,
                                kofa_candidate.candidate.email as cd_email ,
                                kofa_candidate.candidate.dob as cd_dob ,
                                kofa_candidate.candidate.height as cd_height ,
                                kofa_candidate.candidate.weight as cd_weight ,
                                kofa_candidate.candidate.sex as cd_sex ,
                                kofa_candidate.candidate.fee as cd_fee ,
                                kofa_candidate.candidate.fee_structure as cd_fee_structure ,
                                kofa_candidate.candidate.aprove as cd_aprove ,
                                kofa_candidate.candidate.image as cd_image ,
                                kofa_candidate.candidate.batch_id as cd_batch_id ,
                                kofa_batch.kofa_batch.id,
                                kofa_club.kofa_club.id
                                FROM  kofa_candidate.candidate, kofa_batch.kofa_batch, kofa_club.kofa_club 
                                WHERE  kofa_candidate.candidate.batch_id = kofa_batch.kofa_batch.id
                                AND kofa_batch.kofa_batch.club_id = kofa_club.kofa_club.id
                                AND kofa_club.kofa_club.id = '$clubid' ";
                                
                                // kofa_club.kofa_club.id = $clubid
                                
                            }
                            
                            // login uid select from batch id = $btchid
                            if($acctyp == 'batchadmin')
                            {
                                $sqcndt="SELECT 
                                kofa_candidate.candidate.id as cd_id,
                                kofa_candidate.candidate.name as cd_nm,
                                kofa_candidate.candidate.adds as cd_adds ,
                                kofa_candidate.candidate.place as cd_place ,
                                kofa_candidate.candidate.mobile as cd_mobile ,
                                kofa_candidate.candidate.email as cd_email ,
                                kofa_candidate.candidate.dob as cd_dob ,
                                kofa_candidate.candidate.height as cd_height ,
                                kofa_candidate.candidate.weight as cd_weight ,
                                kofa_candidate.candidate.sex as cd_sex ,
                                kofa_candidate.candidate.fee as cd_fee ,
                                kofa_candidate.candidate.fee_structure as cd_fee_structure ,
                                kofa_candidate.candidate.aprove as cd_aprove ,
                                kofa_candidate.candidate.image as cd_image ,
                                kofa_candidate.candidate.batch_id as cd_batch_id ,
                                kofa_batch.kofa_batch.id,
                                kofa_club.kofa_club.id
                                FROM  kofa_candidate.candidate, kofa_batch.kofa_batch, kofa_club.kofa_club 
                                WHERE  kofa_candidate.candidate.batch_id = kofa_batch.kofa_batch.id
                                AND kofa_batch.kofa_batch.club_id = kofa_club.kofa_club.id
                                AND kofa_batch.kofa_batch.id = '$btchid'
                                AND kofa_candidate.candidate.batch_id = '$btchid' ";
                                // kofa_candidate.candidate.batch_id = '$btchid' ";
                                // kofa_club.kofa_club.id = $clubid
                                
                            }
                            if($acctyp != 'clubadmin' && $acctyp != 'batchadmin')
                            {

                                $sqcndt="SELECT 
                                kofa_candidate.candidate.id as cd_id,
                                kofa_candidate.candidate.name as cd_nm,
                                kofa_candidate.candidate.adds as cd_adds ,
                                kofa_candidate.candidate.place as cd_place ,
                                kofa_candidate.candidate.mobile as cd_mobile ,
                                kofa_candidate.candidate.email as cd_email ,
                                kofa_candidate.candidate.dob as cd_dob ,
                                kofa_candidate.candidate.height as cd_height ,
                                kofa_candidate.candidate.weight as cd_weight ,
                                kofa_candidate.candidate.sex as cd_sex ,
                                kofa_candidate.candidate.fee as cd_fee ,
                                kofa_candidate.candidate.fee_structure as cd_fee_structure ,
                                kofa_candidate.candidate.aprove as cd_aprove ,
                                kofa_candidate.candidate.image as cd_image ,
                                kofa_candidate.candidate.batch_id as cd_batch_id ,
                                kofa_batch.kofa_batch.id,
                                kofa_club.kofa_club.id
                               
                             
                                FROM kofa_candidate.candidate,
                                kofa_batch.kofa_batch, kofa_club.kofa_club
                                WHERE  kofa_candidate.candidate.batch_id = kofa_batch.kofa_batch.id
                                AND kofa_batch.kofa_batch.club_id = kofa_club.kofa_club.id
                                AND kofa_candidate.candidate.aprove = '0'
                                AND kofa_candidate.candidate.fee <> ''
                                ";
                            }
                            $recndt=mysqli_query($db_selected, $sqcndt);
                            while($rocndt=mysqli_fetch_array($recndt))
                            {
                                 echo  $rocndt['cd_id'];
                                 echo '<br>';
                        	?>
                        	<tr>

                        		<td><?php echo $rocndt['cd_nm'];?></td>
                        		<td><?php echo $rocndt['cd_adds'];?></td>
                        		<td><?php echo $rocndt['cd_place'];?></td>
                        		<td><?php echo $rocndt['cd_mobile'];?></td>
                        		<td><?php echo $rocndt['cd_dob'];?></td>
                    			<td><?php echo $rocndt['cd_email'];?></td>
                        		<td><?php echo $rocndt['cd_height'];?></td>
                        		<td><?php echo $rocndt['cd_weight'];?></td>
                        		<td><?php echo $rocndt['cd_sex'];?></td>
                        		<td>
                                    <?php    echo '<img  height="auto" width="50" alt="rounded" class="shadow col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12"" src="data:image/jpeg;base64,'.base64_encode($rocndt['cd_image']).'" />';
                                    ?>
                                </td>
                                <td><?php echo $rocndt['cd_fee'];?></td>
                        		<?php $candi = $rocndt['cd_id'];  ?>
                        		
                        		<td>
                    		        <button class="btn btn-danger round cd_fee_st"  id="<?php echo $candi; ?>" onClick=" cdfeestr(this.id); ">Candidate Fee structure</button>
                        		</td>
                        	</tr>
                        	<?php 
                        	}
                        	?>
                        </table>
                        
                        <script>
                            function cdfeestr(id) {
                                var cdfeestr =  id;
                                $.ajax({
                                    type: "POST",
                                    url: "dashboard/ajx/ajaxkofa.php",
                                    data: { cdfeestr : cdfeestr },
                                    cache: false,
                                    success: function(html) {
                                        $("#main").html(html);
                                    }
                                });
                            }
                        </script>
                    </div>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            </div>
        </div>
        
    <?php
    }
    
    //clubadmin  subadmin club select for showing banks
    if(isset($_POST['club_id_bank']))
    {
        $clubid = $_POST['club_id_bank'];
        $sqlbnk = "SELECT * FROM `bank` where club_id = '$clubid' ";
        $resbnk=mysqli_query($kofa_transaction,$sqlbnk);
        echo "<option disabled selected value>Select Bank</option>";
        while($rowbnk=$resbnk->fetch_assoc())
        {
            $bnk_id=$rowbnk['id'];
            echo "<option  value='".$bnk_id."'>";
            echo $rowbnk['bank_name'];
            echo "</option>";
        }
    }
    
    
    if(isset($_POST['bankidclubsub']))
    {
        
        $idbnk = $_COOKIE['bankidckmnt'];
            
            $clubidck = $_COOKIE['clubidcookie'];
            
            // $sqlbatch="SELECT * FROM kofa_batch WHERE club_id = '$clubidck'  ";
            // $resbatch=mysqli_query($kofa_batch, $sqlbatch);
            // $rowbatch=mysqli_fetch_array($resbatch);
            // $idbatch = $rowbatch['id'];
            
            
            $sqcln="SELECT * FROM kofa_transaction.challan, kofa_candidate.candidate, kofa_batch.kofa_batch
            WHERE kofa_transaction.challan.candidate_id = kofa_candidate.candidate.id
            AND challan.approve <> '1'
            AND challan.bank_id = '$idbnk'
            AND kofa_batch.club_id = '$clubidck'";
            $recand= mysqli_query($db_selected, $sqcln);
            $rocand=mysqli_fetch_array($recand);
            echo 'candid = '. $canddid = $rocand['candidate_id'];
            
            $sqcanditt="SELECT * FROM candidate WHERE id = '$canddid' ORDER BY id ASC LIMIT 1";
            $rcanditt=mysqli_query($kofa_candidate,$sqcanditt);
            $rocandett=mysqli_fetch_array($rcanditt);
            echo 'candidate details in table id = '. $rocandett['id'];
                ?>
            <script> cookiid(); function cookiid() { document.cookie = "cdidck=" + '<?php echo $rocandett['id']; ?>'; } </script>
            <table class="table table-hover">
                <tr>
                    
                    <th><label>Name</label></th>
                    <th><label>Address</label></th>
                    <th><label>Mobile</label></th>
                    <th><label>Email</label></th>
                    <th><label>Place</label></th>
                </tr>
                <tr>
                    <td><?php echo $rocandett['name']; ?></td>
                    <td><?php echo $rocandett['adds']; ?></td>
                    <td><?php echo $rocandett['mobile']; ?></td>
                    <td><?php echo $rocandett['email']; ?></td>
                    <td><?php echo $rocandett['place']; ?></td>
                </tr>
            </table>
        <br>
            <form method='post' id="aprovechlnform" class='row' enctype="multipart/form-data">
                <input type="hidden" name="cand_id" id="cand_id" value="<?php echo   $rocandett['id']; ;?> " />
                <input type="hidden" name="bank_id" id="bank_id" value="<?php echo   $idbnk ;?> " />
                <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 texting-in ">
    			    <fieldset>
                        <input type="text" id="transaction" name="transaction" class='form-control round' required >
                        <label>Transaction id</label>
    			    </fieldset>
    			    <span id="TransactionError"></span>
    			</div>
    			<div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 texting-in ">
    			    <fieldset>
                        <input type="text" id="date" name="date" class='form-control round' required >
                        <label>Date</label>
    			    </fieldset>
    			    <span id="DateError"></span>
    			</div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                    <input type='button' id="aprovechallan" name='aprovechln' onClick="AproveDataid(this.id);" value='Aprove' class="round btn btn-danger btn-block form-control" />
                </div>
                
                
                
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
    	            <button type ="submit" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12  btn btn-info  form-control round" onClick="cookiid(); nextsub();">Next</button>
                </div>
                <script>
        	        function cookiid()
        	        {
        	            document.cookie = "candidteidck=" + '<?php echo $rocandett['id']; ?>';
        	        }
        	    </script>
            </form>

            <div id="results"></div>
            <script>
                function AproveDataid() {
                    document.getElementById("TransactionError").style.color = "red";
                    document.getElementById("DateError").style.color = "red";
                    
                    
                    var Transaction = document.getElementById("transaction").value;
                    var DateTransaction = document.getElementById("date").value;
                    
                    if (Transaction == "" && DateTransaction == "") { document.getElementById("TransactionError").innerHTML = "Please Enter a Transaction"; document.getElementById("DateError").innerHTML = "Please Enter a Date"; alert('Please Enter a Transaction and Date'); }
                    else if (DateTransaction == "") { document.getElementById("TransactionError").innerHTML = "Please Enter a Transaction"; alert('Please Enter a Date'); }
                    else if (Transaction == "") { document.getElementById("DateError").innerHTML = "Please Enter a Date"; alert('Please Enter a Date'); }
                    
                    if(Transaction != "" && DateTransaction != "") { document.getElementById("TransactionError").innerHTML = ""; document.getElementById("DateError").innerHTML = ""; }
                    else if (Transaction != "") { document.getElementById("TransactionError").innerHTML = ""; }
                    else if (DateTransaction != "") { document.getElementById("DateError").innerHTML = ""; }
                    
                    if (Transaction != "" && DateTransaction != "") {
                        var cand_id = $("#cand_id").val();
                        var bank_id = $("#bank_id").val();
                        var aprovechalanbutton = $("#aprovechallan").val();
                        var transaction = $("#transaction").val();
                        var date = $("#date").val();
                        
                        $.post("approvedordeleted.php", { aprovechalanbutton: aprovechalanbutton, transaction: transaction, date: date, cand_id: cand_id, bank_id: bank_id },
                            function(data) {
                                $("#TransactionError").html(""); $("#DateError").html("");
                                $('#results').html(data);
                                $('#aprovechlnform')[0].reset();
                                $("#aprovechallan").prop('value', 'Aproved');
                                $("#aprovechallan").css("backgroundColor","green");
                                //document.getElementById("aprovechallan").className = "btn btn-" + themeType + "success";
                                document.getElementById("aprovechallan").disabled = true;
                            }
                        );
                    }
                }
            </script>
        
        <?php
    }
    
    //subadmin nextsub onlick ajax
    if(isset($_POST['nextsub']))
    { 
    $idbnk = $_COOKIE['bankidckmnt'];

    	$sqlbnk="SELECT * FROM bank WHERE id='$idbnk'  ";
    	$res=mysqli_query($kofa_transaction,$sqlbnk);
    	$row=mysqli_fetch_array($res);
    	$clbid = $row['club_id']; 
    	
    	$sqlbatch="SELECT * FROM kofa_batch WHERE club_id='$clbid'  ";
    	$resbatch=mysqli_query($kofa_batch,$sqlbatch);
    	$rowbatch=mysqli_fetch_array($resbatch);
    	$idbatch = $rowbatch['id'];
        ?>
        <div>
    	<?php
    	echo 'candidateid='. $cnd_id = $_COOKIE['candidteidck'];
    	
            echo  'clubid in cookie ='. $clubidck = $_COOKIE['clubidcookie'];
            
            // $sqlbatch="SELECT * FROM kofa_batch WHERE club_id = '$clubidck'  ";
            // $resbatch=mysqli_query($kofa_batch, $sqlbatch);
            // $rowbatch=mysqli_fetch_array($resbatch);
            // echo 'batch_id = ' . $idbatch = $rowbatch['id'];
            
            // $sqlcand="SELECT * FROM candidate WHERE batch_id='$idbatch' AND id <> '$cnd_id' ";
            // $recand=mysqli_query($kofa_candidate,$sqlcand);
            // $rocand=mysqli_fetch_array($recand);
            // echo 'candid = '. $cid = $rocand['id'];
            
            $sqcln="SELECT * FROM kofa_transaction.challan, kofa_candidate.candidate, kofa_batch.kofa_batch, kofa_club.kofa_club
            WHERE kofa_transaction.challan.candidate_id = kofa_candidate.candidate.id 
            AND challan.candidate_id <> '$cnd_id' 
            AND challan.approve <> '1'
            AND challan.bank_id = '$idbnk'
            AND `candidate`.`batch_id` =  kofa_batch.id 
            AND kofa_club.id = '$clubidck'";
            $recand= mysqli_query($db_selected, $sqcln);
            $rocand=mysqli_fetch_array($recand);
            echo 'candid = '. $canddid = $rocand['candidate_id'];
            if($canddid != '' || isset($canddid))
            {
            	$sqlcandidatedetails="SELECT * FROM candidate WHERE id = '$canddid' ORDER BY id ASC LIMIT 1";
            	 
            	$rescandidatedetails=mysqli_query($kofa_candidate,$sqlcandidatedetails);
            	$rowcandidatedetails=mysqli_fetch_array($rescandidatedetails);
            	$cid = $rowcandidatedetails['id'];
            	
                echo  $rowcandidatedetails['id'];
                if($rowcandidatedetails['id'] <> '')
                {
                    ?>
                    <table class="table table-hover col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" >
                    	<tr>
                            <th><label>Name</label></th>
                            <th><label>Address</label></th>
                            <th><label>Mobile</label></th>
                            <th><label>Email</label></th>
                            <th><label>Place</label></th>
                        </tr>
                        <tr>
                                <td><?php echo $rowcandidatedetails['name']; ?></td>
                                <td><?php echo $rowcandidatedetails['adds']; ?></td>
                                <td><?php echo $rowcandidatedetails['mobile']; ?></td>
                                <td><?php echo $rowcandidatedetails['email']; ?></td>
                                <td><?php echo $rowcandidatedetails['place']; ?></td>
                        </tr>
                    </table>
                    
                    <form method='post' id="aprovechlnform" class='row'  enctype="multipart/form-data">
                        <input type="hidden" name="cand_id" id="cand_id" value="<?php echo  $rowcandidatedetails['id'] ;?> " />
                        <input type="hidden" name="bank_id" id="bank_id" value="<?php echo   $idbnk ;?> " />
                        <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 texting-in ">
            			    <fieldset>
                                <input type="text" id="transaction" name="transaction" class='form-control round' required >
                                <label>Transaction id</label>
            			    </fieldset>
            			    <span id="TransactionError"></span>
            			</div>
            			<div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 texting-in ">
            			    <fieldset>
                                <input type="text" id="date" name="date" class='form-control round' required >
                                <label>Date</label>
            			    </fieldset>
            			    <span id="DateError"></span>
            			</div>
            		
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                            <input type='button' id="aprovechallan" name='aprovechln' onClick="AproveDataid(this.id);" value='Aprove' class="round btn btn-danger btn-block form-control" />
                        </div>
                        
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
            	            <button class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12  btn btn-info  form-control round" onClick="cookiid(); nextsub();">Next</button>
                        </div>
                        
                        <script>
                            function cookiid()
                            {
                                document.cookie = "candidteidck=" + '<?php echo $rowcandidatedetails['id']; ?>';
                            }
                        </script>.
                    </form>
                    <div id="results"></div>
                    <script>
                    function AproveDataid() {
                    var Transaction = document.getElementById("transaction").value;
                    var DateTransaction = document.getElementById("date").value;
                    
                    if (Transaction == "" && DateTransaction == "") { document.getElementById("TransactionError").innerHTML = "Please Enter a Transaction"; document.getElementById("DateError").innerHTML = "Please Enter a Date"; alert('Please Enter a Transaction and Date'); }
                    else if (DateTransaction == "") { document.getElementById("TransactionError").innerHTML = "Please Enter a Transaction"; alert('Please Enter a Date'); }
                    else if (Transaction == "") { document.getElementById("DateError").innerHTML = "Please Enter a Date"; alert('Please Enter a Date'); }
                    
                    if(Transaction != "" && DateTransaction != "") { document.getElementById("TransactionError").innerHTML = ""; document.getElementById("DateError").innerHTML = ""; }
                    else if (Transaction != "") { document.getElementById("TransactionError").innerHTML = ""; }
                    else if (DateTransaction != "") { document.getElementById("DateError").innerHTML = ""; }
                    
                    if (Transaction != "" && DateTransaction != "") {
                        var cand_id = $("#cand_id").val();
                        var bank_id = $("#bank_id").val();
                        var aprovechalanbutton = $("#aprovechallan").val();
                        var transaction = $("#transaction").val();
                        var date = $("#date").val();
                        
                        $.post("approvedordeleted.php", { aprovechalanbutton: aprovechalanbutton, transaction: transaction, date: date, cand_id: cand_id, bank_id: bank_id },
                        //post_to_url('http://sahayikendra.com/kofa/test/ajx.php', {'ssssbbb': 'ssssbbb', 'name': 'name', 'email': 'email', 'phone': 'phone'});
                        function(data) {
                            if(data == 'no value')
                            {
                                $('#results').html(data);
                                $('#aprovechlnform')[0].reset();
                                $("#aprovechallan").prop('value', 'Aprove');
                                //$("#aprovechallan").css("backgroundColor","red");
                                document.getElementById("aprovechallan").className = "btn btn-" + themeType + "danger";
                            }
                            else
                            {
                                $('#results').html(data);
                                $("#aprovechallan").prop('value', 'Aproved');
                                //$("#aprovechallan").css("backgroundColor","green");
                                document.getElementById("aprovechallan").className = "btn btn-" + themeType + "success";
                            }
                            
                        });
                    }
                }
                    </script>
            <?php
                }
            }
            else
            {
                echo "<h1 align = 'center'>NO DATA</h1>";
            }
    	?> 
        </div>
        
<?php
    } //subadmin nextsub onlick ajax close
?>

