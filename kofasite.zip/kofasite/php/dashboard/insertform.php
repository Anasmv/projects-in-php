<?php
session_start(); 
if(isset($_SESSION['kid'])) { echo $login_id = $_SESSION['kid']; echo $acctyp = $_SESSION['ktp']; } if(!isset($_SESSION['kid'])) { if(isset($_POST['loginid'])) { $login_id = $_SESSION['kid'] = $_POST['loginid']; } } if(!isset($_SESSION['ktp'])) { if(isset($_POST['actyp'])) { $login_id = $_SESSION['ktp'] = $_POST['actyp']; } }
    include '../con/con.php';
    
   
    
    //club registration from ajax
    if(isset($_POST['clubcreationreg']))
    {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $webadds = $_POST['webadds'];
        $uname = $_POST['uname'];
        $psd = $_POST['password'];
        $password = password_hash($psd, PASSWORD_DEFAULT);
        $imagge = $_FILES['imagefile']['tmp_name'];
        $image_view =file_get_contents($imagge);
        $image =addslashes(file_get_contents($imagge));
        $sql = "INSERT INTO `kofa_club`(`id`, `name`, `logo`, `email`, `contact`, `webadds`, `aprove`)  VALUES (NULL, '$name', '$image', '$email', '$phone', '$webadds', '0')";
        $qu = mysqli_query($kofa_club, $sql);
        if($qu)
        {
            $sqlid = "SELECT id FROM kofa_club where name = '$name' AND email = '$email' AND contact = '$phone'";
            $resid=mysqli_query($kofa_club,$sqlid);
        	$rowid=$resid->fetch_assoc();
        	echo $clubid = $rowid['id'];
        	$sqllg = "INSERT INTO `kofa_login`(`id`, `name`, `account_type`, `username`, `password`, `uid`) VALUES (NULL, '$name', 'clubadmin', '$uname', '$password', '$clubid')";
            $qus = mysqli_query($kofa_login, $sqllg);
            if($qus)
            {
                echo "<script>
                alert('insert success');
                window.location='../index.php';
                </script>";
            }
            else
            {
                // echo "<script>
                // alert('failed');
                // window.location='../index.php';
                // </script>";
            }
        }
    } //close clubcreationreg  if
    
    
    //create sub admin account from ajax kofa
    if(isset($_POST['submisubacc']))
    {
        echo $name = $_POST['name'];
        echo $username = $_POST['username'];
        echo $pass = $_POST['password'];
        echo $password = PASSWORD_HASH($pass, PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO `kofa_login`(`id`, `name`, `account_type`, `username`, `password`, `uid`) VALUES (NULL, '$name', 'subadmin', '$username', '$password', '')"; 
        $r=mysqli_query($kofa_login, $sql);
        if($r)
        {
            echo "<script>
            alert('insert success');
            window.location='../index.php';
            </script>";
        }
    }//close subadmin creation
    
    
    
    
    
    
    //create ment admin account from ajax kofa
    if(isset($_POST['submicreatmain']))
    {
        echo $name = $_POST['name'];
        echo $username = $_POST['username'];
        echo $pass = $_POST['password'];
        echo $password = PASSWORD_HASH($pass, PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO `kofa_login`(`id`, `name`, `account_type`, `username`, `password`, `uid`) VALUES (NULL, '$name', 'mainadmin', '$username', '$password', '')"; 
        $r=mysqli_query($kofa_login, $sql);
        if($r)
        {
            echo "<script>
            alert('insert success');
            window.location='../index.php';
            </script>";
        }
    }//close ment admin creation
    
    //create ment admin account from ajax kofa
    if(isset($_POST['submitcreatment']))
    {
         $name = $_POST['name'];
         $username = $_POST['username'];
         $pass = $_POST['password'];
         $password = PASSWORD_HASH($pass, PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO `kofa_login`(`id`, `name`, `account_type`, `username`, `password`, `uid`) VALUES (NULL, '$name', 'mentadmin', '$username', '$password', '')"; 
        $r=mysqli_query($kofa_login, $sql);
        if($r)
        {
            echo "<script>
            alert('insert success');
            window.location='../index.php';
            </script>";
        }
    }//close ment admin creation
    
    
    //batch registration from ajax
    if(isset($_POST['btch_sbmt']))
    {
        
         $name = $_POST['bname'];
         $agelimit = $_POST['ag_lm'];
         $username = $_POST['unm'];
         $batchpass = $_POST['pswd'];
         $password = PASSWORD_HASH($batchpass, PASSWORD_DEFAULT);
        
        if($acctyp == 'ouradmin')
        {
            $club_sel_id = $_POST['sel_clb'];
            $sql = "INSERT INTO `kofa_batch`(`id`, `name`, `club_id`, `age_limit`) VALUES (NULL,'$name', '$club_sel_id', '$agelimit')";
        }
        
        if($acctyp == 'clubadmin')
        {
            //session id from clubadmin login id of club admin
            $login_id = $_SESSION['k_id']; 
            $sqllg = "SELECT * from kofa_login WHERE id = '$login_id' ";
            $rwlg = mysqli_query($kofa_login, $sqllg);
            $rowclb = mysqli_fetch_array($rwlg);
            $club_sel_id = $rowclb['uid'];

            $sql = "INSERT INTO `kofa_batch`(`id`, `name`, `club_id`, `age_limit`) VALUES (NULL,'$name', '$club_sel_id', '$agelimit')";
        }
        $kofa_btchin = mysqli_query($kofa_batch, $sql);
        
        //select id from batch 
        $sqlsel = "SELECT * FROM kofa_batch WHERE name = '$name' AND age_limit = '$agelimit'";
        $rescln = mysqli_query($kofa_batch, $sqlsel);
        $rowcln=mysqli_fetch_array($rescln);
        $btchid = $rowcln['id'];
       
        //insert to login uid = batch id
        
        $sqllgn = "INSERT INTO `kofa_login`(`id`, `name`, `account_type`, `username`, `password`, `uid`) VALUES (NULL,'$name', 'batchadmin', '$username', '$password', '$btchid')";
        $logins = mysqli_query($kofa_login, $sqllgn);
        if ($kofa_btchin && $logins) 
        {
            echo "<script>
            alert('insert success');
            
            </script>";
        }
        else
        {
            echo "<script>
            alert('failed');
            
            </script>";
        }
    }//batch registration close
    
   
    
    
    //add bank from side nav in kofa ajax form submit
    if(isset($_POST['Add_bank']))
    {
        //INSERT INTO `bank`(`id`, `bank_name`, `club_id`, 
		//	    `account_no`, `branch`, `ifs_code`, `date`, `approve`, `url`)
        echo $banknm = $_POST['bankname'];
        echo $Acc_no = $_POST['Acc_no'];
        echo $Bank_brach = $_POST['Bank_brach'];
        echo $ifc_code = $_POST['ifc_code'];
        echo $Bank_date = $_POST['Bank_date'];
        echo $Bank_url = $_POST['Bank_url'];
        
        if($acctyp!='clubadmin')
        {
            echo $club_id = $_POST['club_id'];
            $sqbnkins = "INSERT INTO `bank`(`id`, `bank_name`, `club_id`, `account_no`, `branch`, `ifs_code`, `date`, `url`) VALUES (NULL, '$banknm', '$club_id', '$Acc_no', '$Bank_brach', '$ifc_code', '$Bank_date', '$Bank_url' )";
            $rebnkins = mysqli_query($kofa_transaction, $sqbnkins);
        }
        
        if($acctyp=='clubadmin')
        {
            //club admin login id =  $login_id;
            $sqlselclg = " SELECT * FROM `kofa_login` WHERE id = '$login_id' ";
            $rselg = mysqli_query($kofa_login, $sqlselclg);
            $rwslg = mysqli_fetch_array($rselg);
            echo $clbidlg = $rwslg['uid'];
            
            $sqbnkins = "INSERT INTO `bank`(`id`, `bank_name`, `club_id`, `account_no`, `branch`, `ifs_code`, `date`, `url`) VALUES (NULL, '$banknm', '$clbidlg', '$Acc_no', '$Bank_brach', '$ifc_code', '$Bank_date', $Bank_url' )";
            $rebnkins = mysqli_query($kofa_transaction, $sqbnkins);
        }
        
        
        if($rebnkins)
        {
            echo "<script> alert('sucess');
            window.location='../index.php';
            </script>";
        }
        else
        {
            echo "<script> alert('not');
            </script>";
            
        }
    }//addbank close
    
    
    
    if(isset($_POST['add_expend']))
    {
        $sal = $_POST['salary'];
        $sqexp = "INSERT INTO `kofa_expenditure`(`id`, `salary`) VALUES (NULL, '$sal')";
        $reexp = mysqli_query($kofa_expenditure, $sqexp);
        if($reexp)
        {
            echo "<script>
                        alert('success');
                  </script>";
        }
    }
    
    if(isset($_POST['salary']))
    {
        $salry = $_POST['salary'];
        $sqlins = "INSERT INTO `kofa_expenditure`(`id`, `salary`) VALUES (NULL, '$salry')";
        $resins = mysqli_query($kofa_expenditure, $sqlins);
        if($resins)
        {
            echo "successfull";
        }
        else
        {
            echo "<script> alert('not'); </script>";
        }
       
    }
    
    //create super admin account from ajax kofa
    if(isset($_POST['sub_btn_spr']))
    {
        $name = $_POST['name'];
        $uname = $_POST['pwd'];
        $pass = $_POST['unm'];
        $password = PASSWORD_HASH($pass, PASSWORD_DEFAULT);
        $sql = "INSERT INTO `kofa_login`(`id`, `name`, `account_type`, `username`, `password`, `uid`) VALUES (NULL, '$name', 'superadmin', '$uname', '$password', '')"; 
        $r=mysqli_query($kofa_login, $sql);
        if($r)
        {
            echo "<script>
            alert('insert success');
            window.location='../index.php';
            </script>";
        }
    }
?>

