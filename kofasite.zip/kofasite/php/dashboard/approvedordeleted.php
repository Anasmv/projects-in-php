<?php
//ktp
session_start();
if(isset($_SESSION['kid'])) { echo $ssid = $_SESSION['kid']; echo $sstyp = $_SESSION['ktp']; } else { echo 'no session'; }

include('../con/con.php');

//apclbid prove club id from ajax kofa club aprove
if(isset($_POST['delclubid']))
{
    $delclbid = $_POST['delclubid'];
    $sql="DELETE FROM kofa_club WHERE id = '$delclbid' ";
    mysqli_query($kofa_club,$sql);
}

//aprove club details from side nave ajaxkofa
if(isset($_POST['aproveclubdet']))
{
    echo $clbapid = $_POST['aproveclubdet'];
    $sqlsl = "select * from kofa_club where id = '$clbapid'";
    $ressl=mysqli_query($kofa_club,$sqlsl);
    $rowsl = mysqli_fetch_assoc($ressl);
    echo $apr = $rowsl['aprove'];
    if($apr == '1')
    {
        echo "<script> alert('already arproved');
    	</script>";
    }
    else
    {
        $sql="update kofa_club set aprove = '1' where id = '$clbapid' ";
        mysqli_query($kofa_club,$sql);
    }
}

//aprvcandid in ajax candidate details aprove from ajaxkofa.php
if(isset($_POST['apcdid']))
{
    echo $candid = $_POST['apcdid'];
    $sqlsl = "select * from candidate where id = '$candid'";
    $ressl=mysqli_query($kofa_candidate,$sqlsl);
    $rowsl = mysqli_fetch_assoc($ressl);
    echo $apr = $rowsl['aprove'];
    if($apr == '1')
    {
        echo "<script> alert('already arproved');
    	</script>";
    }
    else
    {
        $sql="update candidate set aprove = '1' where id = '$candid' ";
        mysqli_query($kofa_candidate,$sql);
    } 
}





//aprove challan from ajax kofa
if(isset($_POST['aprovechalanbutton']))
{
    $_POST['aprovechalanbutton'];
    //candidate id from first bank select  ajax in clubadmin
    $_COOKIE['cdidck'];
    //candidate id from next ajax
    $_COOKIE['candidteidck'];
    
    echo 'candidate id = '.$candid = $_POST['cand_id'];
    echo 'bankid = '.$bankid = $_POST['bank_id'];
    echo 'transaction = '.$trscn = $_POST['transaction'];
    echo 'date = '.$dateaprv = $_POST['date'];
    
    if($trscn != '' && $dateaprv != '' && $candid != '' && $bankid != '')
    {
        $sqlins = "INSERT INTO `challan`(`challan_id`, `candidate_id`, `bank_id`, `transaction`, `date`, `approve`) VALUES (NULL, '$candid', '$bankid', '$trscn', '$dateaprv', '1')";
        $resins = mysqli_query($kofa_transaction, $sqlins);
        if($resins)
        {
            $sqdel = " DELETE FROM challan WHERE candidate_id = '$candid' AND approve = '0' ";
            $redel = mysqli_query($kofa_transaction, $sqdel);
            if($redel)
            {
                 echo "<script> alert('Aproved') </script>";
            }
        }
        else
        {
            echo 'not insert';   
        }
    }
    else
    {
        echo 'no value';
    }
}


if(isset($_POST['print_cln_fe_btn']))
{
    //fee selected on select box 
    echo $feesltd = $_POST['fee_selected'];
}

if(isset($_POST['salary']))
{
    $salry = $_POST['salary'];
    $sqlins = "INSERT INTO `kofa_expenditure`(`id`, `salary`) VALUES (NULL, '$salry')";
    $resins = mysqli_query($kofa_expenditure, $sqlins);
    if($resins)
    {
        echo "successfull";
    }
    else
    {
        echo "<script> alert('not'); </script>";
    }
   
}
    
    


?>