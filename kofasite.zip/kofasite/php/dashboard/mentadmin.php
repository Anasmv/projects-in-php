<?php
session_start(); 
if(isset($_SESSION['kid'])) { echo $login_id = $_SESSION['kid']; /* $login_id=$_SESSION['kid']='15'; */ }
if(!isset($_SESSION['kid'])) { if(isset($_GET['id'])) { $login_id =$_GET['id']; } }

include '../include/link.php'; 
include '../include/headerlog.php'; 
include '../con/con.php';
?>
<br>
<div class="container">
    <div class="row">
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
        <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
					<h2 align="center round bg-progress">MENT ADMIN</h2>
				</div>
				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
            </div>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow ">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row ">
            	    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 "></div>
            	    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 row">
            	        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
            	             <button onclick="printchallan();" id="print_chalan_btn" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control">
                                 Print Challan
                             </button>
            	        </div>
            	        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
            	             <button onclick="transactiondet();" id="transaction_details_btn" class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control">
                                 Transaction Details
                             </button>
            	        </div>
            	    </div>
            	    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 "></div>
            		
            		<!--<a href='registercource.php'>Register Course</a>-->
                </div>
                
                <div>
                    <form name="myform" action="" method="post" class="form-group col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id = "bank_details" enctype="multipart/form-data">
                    </form>
                </div>
                <?php
                if (isset($_POST['printchallan']))
                {
                    echo $bnk_pr_id = $_POST['bank_print'];
                    $sqlcnd="SELECT * FROM kofa_login WHERE id = '$login_id'";
                    $rescnd=mysqli_query($kofa_login, $sqlcnd);
                    $rowcnd=mysqli_fetch_array($rescnd);
                    $cndtt=$rowcnd['uid'];
                    
                    $sqlprntchln = "insert into challan (`challan_id`, `candidate_id`, `bank_id`, `transaction`, `date`, `approve`)  VALUES (NULL, '$cndtt', '$bnk_pr_id', '' , '', '0')";
                    $resprtcln=mysqli_query($kofa_transaction, $sqlprntchln);
                    if($resprtcln)
                    {
                        echo"<script>
                        alert('inserted');
                        </script>
                        ";
                    } 
                }
                if (isset($_POST['challansubmit']))
                {
                    $bankidck = $_COOKIE['bankidcookie'];
                    $clubidck = $_COOKIE['clubidcookie'];
                    $sqlchallan = "insert into challan (`challan_id`, `candidate_id`, `bank_id`, `transaction`, `date`, `approve`)  VALUES (NULL, '$clubidck', '$bankidck', '' , '0')";
                    $resbnk=mysqli_query($kofa_transaction,$sqlchallan);
                    if($resbnk)
                    {
                        echo"<script>
                        alert('inserted');
                        </script>
                        ";
                    }
                    else
                    {
                        echo"<script>
                        alert('not');
                        </script>
                        ";
                    }
                }
                ?>
            </div>
        </div>
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
    </div>
</div>
    <script>
    var loginid = '<?php echo $login_id; ?>';
    var actyp = 'mentadmin';
        window.onload = function() {
           document.getElementById('transaction_details_btn').style.display = 'none';
        };
    </script>
    <script>
        function printchallan() {
            var printchallan = 'print challan btn';
            document.cookie = "bankidcookie=" + printchallan;
                $.ajax({
                type: "POST",
                // url: "http://www.sahayikendra.com/kofa/php/dashboard/ajx/ajaxkofa.php",
                url: "ajx/ajaxkofa.php",
                data: { actyp : actyp, loginid : loginid, printchallan : printchallan },
                cache: false,
                beforeSend: function() {
                    $('#bank_details').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#bank_details").html(html);
                     document.getElementById('transaction_details_btn').style.display = 'block';
                }
                });
        } 
    </script>
    <script>
        function transactiondet() {
            var transactiondet = 'transaction btn';
            document.cookie = "bankidcookie=" + transactiondet;
            $.ajax({
                type: "POST",
                url: "ajx/ajaxkofa.php",
                data: { actyp : actyp, loginid : loginid, transactiondet : transactiondet },
                cache: false,
                beforeSend: function() {
                    $('#bank_details').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#bank_details").html(html);
                }
            });
        }
    </script>
    <script> chang_titl(); function chang_titl() { $(document).attr("title", "Ment Admin"); } </script>
<?php
if(isset($_POST['regbankdet']))
{
    //session candidate login id
    $bank = $_POST['bank'];
    $trans_id = $_POST['transaction_id'];
    $date = $_POST['date'];
    //echo $bank.$trans_id.$date;
    $candid = $login_id;
    
    //UPDATE challan SET transaction='$trans_id', date='$date' WHERE candidate_id='$candid' AND  bank_id='$bank';
    $sqlchallan = "UPDATE challan SET transaction='$trans_id', date='$date' WHERE candidate_id='$candid' AND  bank_id='$bank'";
   
    //$sqlchallan = "insert into challan (`challan_id`, `candidate_id`, `bank_id`, `transaction`, `date`, `approve`)  VALUES (NULL, '$cid', '$bank', '$trans_id' , '$date', '0')";
    $resbnk=mysqli_query($kofa_transaction,$sqlchallan);
    if($resbnk)
    {
        echo"<script>
        alert('inserted');
        </script>
        ";
    }
    else
    {
        echo"<script>
        alert('not');
        </script>
        ";
    }
}
include('../include/footer.php');
?>