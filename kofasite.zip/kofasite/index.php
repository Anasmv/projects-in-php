<?php session_start();
    include "php/include/link.php";
    include "php/con/con.php";
    include "php/include/header.php";
?>
<div id="player">
    <audio autoplay hidden>
        <source src="http://sahayikendra.com/kofasite/World%20Cup%20-%20Waka%20Waka%20-%20Shakira%20(1).mp3" type="audio/mpeg">       
    </audio>
</div>
<div id="registerclick">
    <div class="w3-content w3-section" style="max-width:900px">
        <img class="mySlides w3-animate-fading" src="http://www.sahayikendra.com/kofasite/images/IM1.jpg" style="width:100%">
        <img class="mySlides w3-animate-left" src="http://www.sahayikendra.com/kofasite/images/IM2.jpg" style="width:100%">
        <img class="mySlides w3-animate-fading" src="http://www.sahayikendra.com/kofasite/images/im3.jpg" style="width:100%">
        <img class="mySlides w3-animate-fading" src="http://www.sahayikendra.com/kofasite/images/IM4.jpg" style="width:100%">
        <img class="mySlides w3-animate-fading" src="http://www.sahayikendra.com/kofasite/images/IM6.jpg" style="width:100%">
        <img class="mySlides w3-animate-top" src="http://www.sahayikendra.com/kofasite/images/IM7.jpg" style="width:100%">
        <img class="mySlides w3-animate-fading" src="http://www.sahayikendra.com/kofasite/images/IM8.jpg" style="width:100%">
        <img class="mySlides w3-animate-fading" src="http://www.sahayikendra.com/kofasite/images/IM9.jpg" style="width:100%">
    </div>
    <br>
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
        <div class="col-xl-3 col-lg-3 col-md-3"></div>
        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow round-curve">
                <div class="form-group  col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                    <SELECT class="round form-control" name="district" id="districtid" tabindex="6" onChange="showbatchimages(this);">
                        <option value="" >Select Batch</option>
                        <?php
                        $sql="select * from kofa_batch";
                        $res=mysqli_query($kofa_batch,$sql);
                        while($row=$res->fetch_assoc())
                        { ?>
                        <option value="<?php echo $row['name'];?>" ><?php echo $row['name'];?></option>
                        <?php   }
                        ?>
                    </SELECT>
                </div>
                <div id='batchimagediv' class="form-group  col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-3"></div>
    </div>
</div>
<script>
    function showbatchimages(sel) {
        var batch_image = sel.options[sel.selectedIndex].value;
        if (batch_image.length > 0) {
            $.ajax({
            type: "POST",
            url: "http://www.sahayikendra.com/kofa/php/dashboard/ajx/ajaxkofa.php",
            // url: "php/dashboard/ajx/ajaxkofa.php",
            data: "batchimage=" + batch_image,
            cache: false,
            success: function(html) {
                $("#batchimagediv").html(html);
            }
            });	
        }
        else {
            $("#batchimagediv").html("");
        }
    } 
</script>


<script>
//slide script
    var myIndex = 0;
    carousel();
    function carousel() {
        var i;
        var x = document.getElementsByClassName("mySlides");
        for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";  
        }
        myIndex++;
        if (myIndex > x.length) {myIndex = 1}    
        x[myIndex-1].style.display = "block";  
        setTimeout(carousel, 9000);    
    }
</script>
<?php
    echo $url = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
    // $sqclb = "SELECT * FROM kofa_club WHERE webadds = '$url'";
    $sqclb = "SELECT * FROM kofa_club WHERE webadds = '$url'";
    $resclb = mysqli_query($kofa_club, $sqclb);
    $rowclb = mysqli_fetch_array($resclb);
     $clubid = $rowclb['id'];
    
    $sqbatch = "SELECT * FROM kofa_batch WHERE club_id = '$clubid'";
    $rebatch=mysqli_query($kofa_batch,$sqbatch);
    $rowbatch=mysqli_fetch_array($rebatch);
     $batchid = $rowbatch['id'];




    if(isset($_POST['registerbtn']))
    {
        if (getimagesize($_FILES['imagefile']['tmp_name']) == true) 
        {
            $name = $_POST['name'];
            $adds = $_POST['adds'];
            $place = $_POST['place'];
            $mob = $_POST['mob'];
            $dob = $_POST['dob'];
            $email = $_POST['email'];
            $height = $_POST['height'];
            $weight = $_POST['weight'];
            $sex = $_POST['sex'];
            $fee = $_POST['fee'];
            $uname= $_POST['username'];
            $passwrd = $_POST['password'];
            $today_date = $date = date('Y-m-d');
        
            $imagge = $_FILES['imagefile']['tmp_name'];
           
            $image =addslashes(file_get_contents($imagge));
            
            $sqlreg = "INSERT INTO `candidate` (`id`, `name`, `adds`, `place`, `mobile`, `email`, `dob`, `height`, `weight`, `sex`, `fee`, `fee_structure`, `aprove`, `image`, `batch_id`) 
            VALUES (NULL, '$name', '$adds', '$place', '$mob', '$email', '$dob', '$height', '$weight', '$sex', '$fee', '$today_date', '0', '$image', '$batchid')";
            $regcnd = mysqli_query($kofa_candidate, $sqlreg);
            
            $sqlslcnf="SELECT * FROM `candidate` WHERE name = '$name' AND height = '$height' AND weight = '$weight' AND mobile = '$mob'";
            $cndres = mysqli_query($kofa_candidate, $sqlslcnf);
            $rwcnd =  mysqli_fetch_array($cndres);
            $cndid = $rwcnd['id'];
            
            
            $password = password_hash($passwrd, PASSWORD_DEFAULT);
            $sqllgncand = "INSERT INTO `kofa_login`(`id`, `name`, `account_type`, `username`, `password`, `uid`) VALUES (NULL, '$name', 'mentadmin', '$uname', '$password', '$cndid')";
            if ($regcnd) 
            {
                $regcndlg = mysqli_query($kofa_login, $sqllgncand);
                echo "<script>
                alert('insert success');
                </script>";
            }
            else
            {
                echo "<script>
                alert('Failed');
                </script>";
            }
        }
        else
        {
            echo "<script>
                alert('Select a Image');
                </script>";
        }
        
    }
include "php/include/footer.php";
?>