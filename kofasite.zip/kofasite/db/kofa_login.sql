-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 14, 2020 at 11:26 PM
-- Server version: 5.6.46-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kofa_login`
--
CREATE DATABASE IF NOT EXISTS `kofa_login` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `kofa_login`;

-- --------------------------------------------------------

--
-- Table structure for table `kofa_login`
--

CREATE TABLE `kofa_login` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `account_type` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL,
  `uid` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kofa_login`
--

INSERT INTO `kofa_login` (`id`, `name`, `account_type`, `username`, `password`, `uid`) VALUES
(10, 'admin', 'ouradmin', 'admin', '$2y$10$C7uWjphiH3zgbNlEE5To8emBKaxHitb/JyX77ifeh.zNrNHgGFMRG', ''),
(56, 'subadmin', 'subadmin', 'subadmin', '$2y$10$d2vXiHbO8iwQoAdbTfNr.enuZmG/UVzo2UfMmy4IyEjVOwwJQs7w.', ''),
(43, 'superadmin', 'superadmin', 'superadmin', '$2y$10$CG0nS/0CSaegIajryataVehJp0lCpdS4c/HKJ97vd4Rvc4rygCrqG', ''),
(49, 'batch 1', 'batchadmin', 'batch 1', '$2y$10$c3GwPj1yUthDe2RItsgyM.MY7h2WmCPyiiQ/RkEFW8uAZx8l66tmq', '24'),
(57, 'club 1', 'clubadmin', 'club 1', '$2y$10$l5Oika/eL/l28d36Avv0jOyzhI.YNungajuy6lQi/A0ZfTPxIjlg.', '30'),
(58, 'batch 1', 'batchadmin', 'batchadmin', '$2y$10$8qE7LjBYbr1Mkdou6abV6ejAep.lAYLaTfKcSuNN2b8I9qtkZjzXq', '25'),
(59, 'candidate', 'mentadmin', 'candidate', '$2y$10$4v4s7PHZpHxsuPncnSFA4ug5cT/3dRY5V.XhaCJ1fO1dl.Nl7E/nm', '55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `kofa_login`
--
ALTER TABLE `kofa_login`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `kofa_login`
--
ALTER TABLE `kofa_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
