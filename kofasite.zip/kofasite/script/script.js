jQuery(document).ready(function($) {

	// Starts  toggle function

		// if we click on the class "btn-login"
	$('.btn-login').click(function(e) {
		$login = $('.log-box');

		//  Here adds a class "toggled" with the class "log-box"
        $login.toggleClass('toggled');

		// If the class "toggled" is there
		if($login.hasClass('toggled')) {
			// Changes the html in between "btn-login a"
			$('.btn-login a').html('<span class="fa fa-close"></span> Close');
		}
		else {
			$('.btn-login a').html('<span class="fa fa-sign-in"></span> Login');
		}
    });

		//End  toggle function

	$('.btn-logout').click(function(e) {
        window.location.replace("../logout.php");
    });

	$loginClick = $('div.login form input[type=submit], div.login form div.loading-gif');
	$('div.log-box form').submit(function(e) {
		e.preventDefault();
        $loginClick.toggle();
		$.post('/php/login.php', $(this).serialize(), function(data) {
			if(data)
				$loginClick.toggle();
				$('div.response').html(data);
				if(/Login Successful/.test(data))
					window.location.replace('/php/dashboard/');
		});
    });
  });
