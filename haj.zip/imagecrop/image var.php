
<div class="container">
	<form action="" method="post" enctype="multipart/form-data">
		<input type="file" name="imagefile" /> 
		<input type="submit" name="submit" value="Submit" />
	</form>
</div>

<?php

if(isset($_POST['submit']))
{
        $imagge = $_FILES['imagefile']['tmp_name'];
            //$image_view =file_get_contents($imagge);
            echo $image =addslashes (file_get_contents($imagge));
}
            ?>