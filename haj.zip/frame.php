<html lang="en">
    <head>
        <title>Haj || Azalea</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="http://haj.saypay.in/haj.css">
        <link rel="icon" type="icon/png" href="http://www.sahayikendra.com/images/Logo.png">
        <link rel="stylesheet" type="text/css" href="http://cdn.webrupee.com/font">	
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    </head>
    <body>
        <div class="container"><br>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-xs-10 white b">
                    <center>For details contact : 8848888092</center>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
            </div>
        </div><br>
        <div class="frm1div" >
            <div class="frm2div" style="overflow:hidden;" height="100%" width="100%">
                <iframe class="frm"src="http://103.71.18.116/webapp/web18/" scrolling="yes" style="width: 1500px; height: 700px; margin-top: -105px;"></iframe>
            </div>
        </div>
        <!--div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"> </div>
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-xs-10 ">
                <form method="post" class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
    				    <fieldset>
    				        <input type='text' name='mob' class='form-control round' required />
    				        <label>Enter Mobile Number</label>
                        </fieldset>
                    </div>
                    
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
                        <input type="submit" class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" value="Go" id="" name="mobile_go" />
                    </div>
                </form>
            </div>
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
        </div-->
    </body>
</html>