<?php 
$mobile=$_GET['mobileno'];
if ($_GET['banknm']=="UBI"){ $chbank= "Union Bank"; $chaccount=' 318702010406010 “HAJ PILGRIM PROCESSING FEE ”';}
else{$chbank= "State Bank"; $chaccount=' 35398104789" HAJ PILGRIM PROCESSING FEE"';} 
/*
echo $chbank. "<br>";
echo $chaccount. "<br>";
echo $mobile;
*/
$conn = new mysqli('localhost', 'sahayikendra', 'sahayikendra@Azalea', 'haj_db');

$sql = "SELECT * FROM `challan` WHERE mobile = $mobile";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    $row['id'];
    $passport= $row['pass_no'];
    $head= strtoupper($row['name']);
    $add = strtoupper($row['adds']);
    $add0= explode(",",$add);
    $pil2= strtoupper($row['pil_2']);
    $pil3= strtoupper($row['pil_3']);
    $pil4= strtoupper($row['pil_4']);
    $pil5= strtoupper($row['pil_5']);
    $inf1= strtoupper($row['inf_1']);
    $inf2= strtoupper($row['inf_2']);
    $row['catagory'];
    $numpil= $row['pilgrim'];
    $numminf = $row['infant'];
    $row['mobile'];  
}


$add1=$add0[0];
$add2=$add0[1];
$add3=$add0[2];
$add4=$add0[3];

$year="HAJ 1441(H)-2020(CE)";
$ihead=strlen($head)-1;

$mobile=$_GET['mobileno'];
$bank = $_GET['banknm'];

$total=$numpil*300;
$cat='GENERAL';

$number = $total;
   $no = round($number);
   $point = round($number - $no, 2) * 100;
   $hundred = null;
   $digits_1 = strlen($no);
   $i = 0;
   $str = array();
   $words = array('0' => '', '1' => 'One', '2' => 'Two',
    '3' => 'Three', '4' => 'Four', '5' => 'Five', '6' => 'Six',
    '7' => 'Seven', '8' => 'Eight', '9' => 'Nine',
    '10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve',
    '13' => 'Thirteen', '14' => 'Fourteen',
    '15' => 'Fifteen', '16' => 'Sixteen', '17' => 'Seventeen',
    '18' => 'Eighteen', '19' =>'Nineteen', '20' => 'Twenty',
    '30' => 'Thirty', '40' => 'Forty', '50' => 'Fifty',
    '60' => 'Sixty', '70' => 'Seventy',
    '80' => 'Eighty', '90' => 'Ninety');
   $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
   while ($i < $digits_1) {
     $divider = ($i == 2) ? 10 : 100;
     $number = floor($no % $divider);
     $no = floor($no / $divider);
     $i += ($divider == 10) ? 1 : 2;
     if ($number) {
        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
        $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $str [] = ($number < 21) ? $words[$number] .
            " " . $digits[$counter] . $plural . " " . $hundred
            :
            $words[floor($number / 10) * 10]
            . " " . $words[$number % 10] . " "
            . $digits[$counter] . $plural . " " . $hundred;
     } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ?
    "." . $words[$point / 10] . " " . 
          $words[$point = $point % 10] : '';





include("../sahayi/php/mpdf57/mpdf.php");

    $mpdf=new mPDF('utf-8-s');
    $mpdf->debug=true;
    $mpdf->tabSpaces = 6;
    $mpdf->charset_in='windows-1252';
    //$mpdf = new mPDF('', 'A4');
    
    $title = 'Haj | AZALEA';
    $mpdf->SetTitle($title);
    
    
    /*AddPage ( [ string $orientation [, string $type [, string $resetpagenum [, string $pagenumstyle [, string $suppress [, float $margin-left [, float $margin-right [, float $$margin-top [, float $$margin-bottom [, float $$margin-header [, float $margin-footer [, string $odd-header-name [, string $even-header-name [, string $$odd-footer-name [, string $$even-footer-name [, mixed $$odd-header-value [, mixed $even-header-value [, mixed $odd-footer-value [, mixed $$even-footer-value [, string $pageselector [, mixed $sheet-size ]]]]]]]]]]]]]]]]]]]]])
    */
    
     $sql2 = "SELECT * FROM `table` WHERE id = '1' ";
$result2 = $conn->query($sql2);
while($row2 = $result2->fetch_assoc())
{
    $row2['id'];
    $passport= $row2['text'];

   
}
    
    
    $mpdf->AddPage('','A4','','','',10,10,10,10,10,10);
    $mpdf->WriteHTML($passport);
    $mpdf->SetAuthor('Aboobacker');
    $mpdf->SetDrawColor(100,100,100);
    // $mpdf->SetFont('Arial','B',12);
    
    
    
   
    


    
    
    $mpdf->Output();
     exit;
     
?>