<?php 
$mobile=$_GET['mobileno'];
if ($_GET['banknm']=="UBI"){ $chbank= "Union Bank"; $chaccount=' 318702010406010 “HAJ PILGRIM PROCESSING FEE ”';}
else{$chbank= "State Bank"; $chaccount=' 35398104789" HAJ PILGRIM PROCESSING FEE"';} 
/*
echo $chbank. "<br>";
echo $chaccount. "<br>";
echo $mobile;
*/
$conn = new mysqli('localhost', 'sahayikendra', 'sahayikendra@Azalea', 'haj_db');

$sql = "SELECT * FROM `challan` WHERE mobile = $mobile";
$result = $conn->query($sql);
while($row = $result->fetch_assoc()) {
    $row['id'];
    $passport= $row['pass_no'];
    $head= strtoupper($row['name']);
    $add = strtoupper($row['adds']);
    $add0= explode(",",$add);
    $pil2= strtoupper($row['pil_2']);
    $pil3= strtoupper($row['pil_3']);
    $pil4= strtoupper($row['pil_4']);
    $pil5= strtoupper($row['pil_5']);
    $inf1= strtoupper($row['inf_1']);
    $inf2= strtoupper($row['inf_2']);
    $row['catagory'];
    $numpil= $row['pilgrim'];
    $numminf = $row['infant'];
    $row['mobile'];  
}
$add1=$add0[0];
$add2=$add0[1];
$add3=$add0[2];
$add4=$add0[3];

$year="HAJ 1441(H)-2020(CE)";
$ihead=strlen($head)-1;

$mobile=$_GET['mobileno'];
$bank = $_GET['banknm'];

$total=$numpil*300;
$cat='GENERAL';

$number = $total;
   $no = round($number);
   $point = round($number - $no, 2) * 100;
   $hundred = null;
   $digits_1 = strlen($no);
   $i = 0;
   $str = array();
   $words = array('0' => '', '1' => 'One', '2' => 'Two',
    '3' => 'Three', '4' => 'Four', '5' => 'Five', '6' => 'Six',
    '7' => 'Seven', '8' => 'Eight', '9' => 'Nine',
    '10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve',
    '13' => 'Thirteen', '14' => 'Fourteen',
    '15' => 'Fifteen', '16' => 'Sixteen', '17' => 'Seventeen',
    '18' => 'Eighteen', '19' =>'Nineteen', '20' => 'Twenty',
    '30' => 'Thirty', '40' => 'Forty', '50' => 'Fifty',
    '60' => 'Sixty', '70' => 'Seventy',
    '80' => 'Eighty', '90' => 'Ninety');
   $digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
   while ($i < $digits_1) {
     $divider = ($i == 2) ? 10 : 100;
     $number = floor($no % $divider);
     $no = floor($no / $divider);
     $i += ($divider == 10) ? 1 : 2;
     if ($number) {
        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
        $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $str [] = ($number < 21) ? $words[$number] .
            " " . $digits[$counter] . $plural . " " . $hundred
            :
            $words[floor($number / 10) * 10]
            . " " . $words[$number % 10] . " "
            . $digits[$counter] . $plural . " " . $hundred;
     } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ?
    "." . $words[$point / 10] . " " . 
          $words[$point = $point % 10] : '';


include("../sahayi/php/mpdf57/mpdf.php");

    $mpdf=new mPDF('utf-8-s');
    $mpdf->debug=true;
    $mpdf->tabSpaces = 6;
    $mpdf->charset_in='windows-1252';
    //$mpdf = new mPDF('', 'A4');
    
    $title = 'Haj | AZALEA';
    $mpdf->SetTitle($title);
    
    
    /*AddPage ( [ string $orientation [, string $type [, string $resetpagenum [, string $pagenumstyle [, string $suppress [, float $margin-left [, float $margin-right [, float $$margin-top [, float $$margin-bottom [, float $$margin-header [, float $margin-footer [, string $odd-header-name [, string $even-header-name [, string $$odd-footer-name [, string $$even-footer-name [, mixed $$odd-header-value [, mixed $even-header-value [, mixed $odd-footer-value [, mixed $$even-footer-value [, string $pageselector [, mixed $sheet-size ]]]]]]]]]]]]]]]]]]]]])
    */
    
    
    
    $mpdf->AddPage('','A4','','','',10,10,10,10,10,10);
    $mpdf->WriteHTML('');
    $mpdf->SetAuthor('Aboobacker');
    $mpdf->SetDrawColor(100,100,100);
    $mpdf->SetFont('Arial','B',12);
    $mpdf->Cell(160,5,"",0,0,"C");
    $mpdf->Cell(30,10,"",1,0,"C");
    $mpdf->Cell(.01,.01,"",0,1,"C");
    $mpdf->Cell(160,2,"",0,0,"C");
    
    $mpdf->Cell(30,6,strtoupper($chbank), 0,1,"C");
    $mpdf->SetFont('Arial','B',10);
    $mpdf->Cell(160,2,"(PAY-IN-SLIP to deposit Rs.300/- per pilgrim and maximum of Rs.1500/- Only)",0,0,"C");
    $mpdf->SetFont('Arial','B',12);
    $mpdf->Cell(30,4,"of India", 0,1,"C");

    // STARTING 
    
    $mpdf->SetFont('Arial','',10);
    $mpdf->Cell(190,1,"", 0,1,"L");
    $mpdf->Cell(130,3.5,"Branch:", 1,0,"L");
    $mpdf->SetFont('Arial','B',12);
    $mpdf->Cell(60,8,"BANK COPY", 1,0,"C");
    $mpdf->Cell(.01,.01,"", 0,1,"C");
    $mpdf->SetFont('Arial','',10);
    $mpdf->Cell(65,3.5,"", 0,0,"C");
    $mpdf->Cell(65,3.5,"Code:", 0,1,"L");
    $mpdf->SetFont('Arial','B',10);
    $mpdf->Cell(65,4.5,"HAJ COMMITTEE OF INDIA", 1,0,"C");
    $mpdf->Cell(65,4.5,$year, 1,1,"C");
    $mpdf->SetFont('Arial','B',9.5);
    $mpdf->Cell(190,4,"COLLECTION DETAILS", 1,1,"C");
    
    
    $mpdf->Cell(190,20,"", 1,0,"C");
    $mpdf->Cell(.01,.01,"", 0,1,"C");
    $mpdf->Cell(1,4,'', 0,0);
    $mpdf->Cell(190,4,'ACCOUNT NUMBER: ' . $chaccount, 0,1,"l");
    $mpdf->Cell(2,4,'', 0,0);
    $mpdf->Cell(90,4,"PASSPORT NUMBER OF COVER HEAD", 1,0,"L");
    for($i=0;$i<=7;$i++)
    {
    $mpdf->Cell(5.08,4,$passport[$i], 1,0,"C");
    }
    $mpdf->Cell(.01,4,"", 0,1,"C");
    
    $mpdf->Cell(2,4,'', 0,0);
    $mpdf->Cell(42,4,"Name of Cover Head ", 1,0,"L");
    for($i=0;$i<=$ihead;$i++)
    {
    $mpdf->Cell(5,4,strtoupper($head[$i]), 1,0,"C");
    }
    for($i=0;$i<=27-$ihead;$i++)
    {
    $mpdf->Cell(5,4,"", 1,0,"C");
    }
    $mpdf->Cell(.01,4,"", 0,1,"C");
    $mpdf->Cell(2,4,'', 0,0);
    $mpdf->Cell(72,4,"Date of Deposit:", 1,0,"L");
    $mpdf->Cell(25,4,"", 0,0,"L");
    $mpdf->Cell(30,4,"Mobille Number", 1,0,"C");
    $mpdf->Cell(5,4,"0", 1,0,"C");
    for($i=0;$i<=9;$i++)
    {
    $mpdf->Cell(5,4,$mobile[$i], 1,0,"C");
    }
    
    $mpdf->SetFont('Arial','',9);
    $mpdf->Cell(5,4,"", 1,1,"C");
    $mpdf->Cell(72,4,"PARTICULARS OF THE PAYMENT:", 0,1,"L");
    $mpdf->Cell(12,4,"Sr. No.", 1,0,"L");
    $mpdf->Cell(63,4,"NAME OF THE PILGRIM", 1,0,"C");
    $mpdf->Cell(63,4,"ADDRESS OF THE PILGRIM", 1,0,"C");
    $mpdf->Cell(52,4,"CASH NOTE AMOUNT IN Rs.", 1,1,"C");
    
    $mpdf->SetFont('Arial','B',8);
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$head, 1,0,"L");
    $mpdf->Cell(63,3.75,$add1, 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil2, 1,0,"L");
    $mpdf->Cell(63,3.75,$add2, 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil3, 1,0,"L");
    $mpdf->Cell(63,3.75,$add3, 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil4, 1,0,"L");
    $mpdf->Cell(63,3.75,$add4, 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil5, 1,0,"L");
    $mpdf->Cell(63,3.75,"", 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$inf1, 1,0,"L");
    $mpdf->Cell(63,3.75,"", 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$inf2, 1,0,"L");
    $mpdf->Cell(63,3.75,"", 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    
    $mpdf->Cell(138,5,"", 1,0,"L");
    $mpdf->SetFont('Arial','B',12);
    $mpdf->Cell(52,5,"  Total Rs. " .$total. "/-", 1,0,"L");
    $mpdf->Cell(1,1,"", 0,1,"L");
    $mpdf->SetFont('Arial','I',8);
    $mpdf->Cell(138,4,"Amount (In words) Rupees  " .$result. "  Only" , 0,1,"L");
    $mpdf->Cell(58,4.5,"Transaction ID (Bank journal No.)", 1,0,"L");
    for($i=0;$i<=9;$i++)
    {
    $mpdf->Cell(7,4.5,"", 1,0,"C");
    }
    $mpdf->Cell(62,4.5,"", 1,1,"C");
    $mpdf->Cell(95,7.5,"Branch Stamp with Signature", 1,0,"C");
    $mpdf->Cell(95,7.5,"Deposited by", 1,1,"C");
    $mpdf->Cell(190,6,"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ", 0,1,"C");
    
    // HCoI Copy
    
    
    $mpdf->SetFont('Arial','B',12);
    $mpdf->Cell(190,4.5,"HAJ COMMITTEE OF INDIA", 0,1,"C");
    $mpdf->SetFont('Arial','',8);
    $mpdf->Cell(190,4.5,"Bait-ul-Hujjaj (Haj House), 7-A, M.R.A Marg (Palton Road), Mumbai-400 001.", 0,1,"C");
    $mpdf->SetFont('Arial','',10);
    $mpdf->Cell(190,1,"", 0,1,"L");
    $mpdf->Cell(130,3.5,"Branch:", 1,0,"L");
    $mpdf->SetFont('Arial','B',12);
    $mpdf->Cell(60,8,"HCoI COPY", 1,0,"C");
    $mpdf->Cell(.01,.01,"", 0,1,"C");
    $mpdf->SetFont('Arial','',10);
    $mpdf->Cell(65,3.5,"", 0,0,"C");
    $mpdf->Cell(65,3.5,"Code:", 0,1,"L");
    $mpdf->SetFont('Arial','B',10);
    $mpdf->Cell(65,4.5,"HAJ COMMITTEE OF INDIA", 1,0,"C");
    $mpdf->Cell(65,4.5,$year, 1,1,"C");
    $mpdf->SetFont('Arial','B',9.5);
    $mpdf->Cell(190,4,"COLLECTION DETAILS", 1,1,"C");
    
    
    $mpdf->Cell(190,20,"", 1,0,"C");
    $mpdf->Cell(.01,.01,"", 0,1,"C");
    $mpdf->Cell(1,4,'', 0,0);
    $mpdf->Cell(190,4,'ACCOUNT NUMBER: ' . $chaccount, 0,1,"l");
    $mpdf->Cell(2,4,'', 0,0);
    $mpdf->Cell(90,4,"PASSPORT NUMBER OF COVER HEAD", 1,0,"L");
    for($i=0;$i<=7;$i++)
    {
    $mpdf->Cell(5.08,4,$passport[$i], 1,0,"C");
    }
    $mpdf->Cell(.01,4,"", 0,1,"C");
    
    $mpdf->Cell(2,4,'', 0,0);
    $mpdf->Cell(42,4,"Name of Cover Head ", 1,0,"L");
    for($i=0;$i<=$ihead;$i++)
    {
    $mpdf->Cell(5,4,strtoupper($head[$i]), 1,0,"C");
    }
    for($i=0;$i<=27-$ihead;$i++)
    {
    $mpdf->Cell(5,4,"", 1,0,"C");
    }
    $mpdf->Cell(.01,4,"", 0,1,"C");
    $mpdf->Cell(2,4,'', 0,0);
    $mpdf->Cell(72,4,"Date of Deposit:", 1,0,"L");
    $mpdf->Cell(25,4,"", 0,0,"L");
    $mpdf->Cell(30,4,"Mobille Number", 1,0,"C");
    $mpdf->Cell(5,4,"0", 1,0,"C");
    for($i=0;$i<=9;$i++)
    {
    $mpdf->Cell(5,4,$mobile[$i], 1,0,"C");
    }
    
    $mpdf->SetFont('Arial','',9);
    $mpdf->Cell(5,4,"", 1,1,"C");
    $mpdf->Cell(72,4,"PARTICULARS OF THE PAYMENT:", 0,1,"L");
    $mpdf->Cell(12,4,"Sr. No.", 1,0,"L");
    $mpdf->Cell(63,4,"NAME OF THE PILGRIM", 1,0,"C");
    $mpdf->Cell(63,4,"ADDRESS OF THE PILGRIM", 1,0,"C");
    $mpdf->Cell(52,4,"CASH NOTE AMOUNT IN Rs.", 1,1,"C");
    
    $mpdf->SetFont('Arial','B',8);
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$head, 1,0,"L");
    $mpdf->Cell(63,3.75,$add1, 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil2, 1,0,"L");
    $mpdf->Cell(63,3.75,$add2, 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil3, 1,0,"L");
    $mpdf->Cell(63,3.75,$add3, 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil4, 1,0,"L");
    $mpdf->Cell(63,3.75,$add4 , 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil5, 1,0,"L");
    $mpdf->Cell(63,3.75,"", 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$inf1, 1,0,"L");
    $mpdf->Cell(63,3.75,"", 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$inf2, 1,0,"L");
    $mpdf->Cell(63,3.75,"", 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    
    $mpdf->Cell(138,5,"", 1,0,"L");
    $mpdf->SetFont('Arial','B',12);
    $mpdf->Cell(52,5,"  Total Rs. " .$total. "/-", 1,0,"L");
    $mpdf->Cell(1,1,"", 0,1,"L");
    $mpdf->SetFont('Arial','i',8);
    $mpdf->Cell(138,4,"Amount (In words) Rupees  " .$result. "  Only" , 0,1,"L");
    $mpdf->Cell(58,4.5,"Transaction ID (Bank journal No.)", 1,0,"L");
    for($i=0;$i<=9;$i++)
    {
    $mpdf->Cell(7,4.5,"", 1,0,"C");
    }
    $mpdf->Cell(62,4.5,"", 1,1,"C");
    $mpdf->Cell(95,7.5,"Branch Stamp with Signature", 1,0,"C");
    $mpdf->Cell(95,7.5,"Deposited by", 1,1,"C");
    $mpdf->Cell(190,6,"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - ", 0,1,"C");
    
    // Pilgrim Copy
    
    
    $mpdf->SetFont('Arial','',10);
    $mpdf->Cell(190,1,"", 0,1,"L");
    $mpdf->Cell(130,3.5,"Branch:", 1,0,"L");
    $mpdf->SetFont('Arial','B',12);
    $mpdf->Cell(60,8,"PILGRIM COPY", 1,0,"C");
    $mpdf->Cell(.01,.01,"", 0,1,"C");
    $mpdf->SetFont('Arial','',10);
    $mpdf->Cell(65,3.5,"", 0,0,"C");
    $mpdf->Cell(65,3.5,"Code:", 0,1,"L");
    $mpdf->SetFont('Arial','B',10);
    $mpdf->Cell(65,4.5,"HAJ COMMITTEE OF INDIA", 1,0,"C");
    $mpdf->Cell(65,4.5,$year, 1,1,"C");
    $mpdf->SetFont('Arial','B',9.5);
    $mpdf->Cell(190,4,"COLLECTION DETAILS", 1,1,"C");
    
    
    $mpdf->Cell(190,20,"", 1,0,"C");
    $mpdf->Cell(.01,.01,"", 0,1,"C");
    $mpdf->Cell(1,4,'', 0,0);
    $mpdf->Cell(190,4,'ACCOUNT NUMBER: ' . $chaccount, 0,1,"l");
    $mpdf->Cell(2,4,'', 0,0);
    $mpdf->Cell(90,4,"PASSPORT NUMBER OF COVER HEAD", 1,0,"L");
    for($i=0;$i<=7;$i++)
    {
    $mpdf->Cell(5.08,4,$passport[$i], 1,0,"C");
    }
    $mpdf->Cell(.01,4,"", 0,1,"C");
    
    $mpdf->Cell(2,4,'', 0,0);
    $mpdf->Cell(42,4,"Name of Cover Head ", 1,0,"L");
    for($i=0;$i<=$ihead;$i++)
    {
    $mpdf->Cell(5,4,strtoupper($head[$i]), 1,0,"C");
    }
    for($i=0;$i<=27-$ihead;$i++)
    {
    $mpdf->Cell(5,4,"", 1,0,"C");
    }
    $mpdf->Cell(.01,4,"", 0,1,"C");
    $mpdf->Cell(2,4,'', 0,0);
    $mpdf->Cell(72,4,"Date of Deposit:", 1,0,"L");
    $mpdf->Cell(25,4,"", 0,0,"L");
    $mpdf->Cell(30,4,"Mobille Number", 1,0,"C");
    $mpdf->Cell(5,4,"0", 1,0,"C");
    for($i=0;$i<=9;$i++)
    {
    $mpdf->Cell(5,4,$mobile[$i], 1,0,"C");
    }
    
    $mpdf->SetFont('Arial','',9);
    $mpdf->Cell(5,4,"", 1,1,"C");
    $mpdf->Cell(72,4,"PARTICULARS OF THE PAYMENT:", 0,1,"L");
    $mpdf->Cell(12,4,"Sr. No.", 1,0,"L");
    $mpdf->Cell(63,4,"NAME OF THE PILGRIM", 1,0,"C");
    $mpdf->Cell(63,4,"ADDRESS OF THE PILGRIM", 1,0,"C");
    $mpdf->Cell(52,4,"CASHE NOT AMOUNT IN Rs.", 1,1,"C");
    
    $mpdf->SetFont('Arial','B',8);
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$head, 1,0,"L");
    $mpdf->Cell(63,3.75,$add1, 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil2, 1,0,"L");
    $mpdf->Cell(63,3.75,$add2, 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil3, 1,0,"L");
    $mpdf->Cell(63,3.75,$add3, 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil4, 1,0,"L");
    $mpdf->Cell(63,3.75,$add4, 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$pil5, 1,0,"L");
    $mpdf->Cell(63,3.75,"", 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$inf1, 1,0,"L");
    $mpdf->Cell(63,3.75,"", 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    $mpdf->Cell(12,3.75,"", 1,0,"L");
    $mpdf->Cell(63,3.75,$inf2, 1,0,"L");
    $mpdf->Cell(63,3.75,"", 1,0,"L");
    $mpdf->Cell(52,3.75,"", 1,1,"L");
    
    
    $mpdf->Cell(138,5,"", 1,0,"L");
    $mpdf->SetFont('Arial','B',12);
    $mpdf->Cell(52,5,"  Total Rs. " .$total. "/-", 1,0,"L");
    $mpdf->Cell(1,1,"", 0,1,"L");
    $mpdf->SetFont('Arial','i',8);
    $mpdf->Cell(138,4,"Amount (In words) Rupees  " .$result. "  Only" , 0,1,"L");
    $mpdf->Cell(58,4.5,"Transaction ID (Bank journal No.)", 1,0,"L");
    for($i=0;$i<=9;$i++)
    {
    $mpdf->Cell(7,4.5,"", 1,0,"C");
    }
    $mpdf->Cell(62,4.5,"", 1,1,"C");
    $mpdf->Cell(95,7.5,"Branch Stamp with Signature", 1,0,"C");
    $mpdf->Cell(95,7.5,"Deposited by", 1,1,"C");
    
    /*
    
    $mpdf->SetFont('Arial','BU',22);
    $mpdf->Cell(190,10,"", 0,1,"C");
    $mpdf->Cell(190,10,"HAJ APPLICATION 2019", 0,1,"C");
    $mpdf->SetFont('Arial','B',15);
    $mpdf->Cell(190,5,"Category :  " .$cat."   No. of Pilgrims :  ".$numpil."   No.of infants :  ".$numminf, 0,1,"C");
    $mpdf->Cell(190,15,"", 0,1,"C");
    
    $mpdf->SetFont('Times','',11);
    $mpdf->Cell(95,5,"   To.", 0,0,"L");
    $mpdf->Cell(95,5,"   To.", 0,1,"L");
    $mpdf->SetFont('Arial','B',12);
    $mpdf->Cell(95,5,$head, 0,0,"L");
    $mpdf->Cell(95,5,"EXECUTIVE OFFICER", 0,1,"L");
    $mpdf->SetFont('Arial','',12);
    $mpdf->Cell(95,5,$add1, 0,0,"L");
    $mpdf->Cell(95,5,"KERALA STATE HAJ COMMITTEE", 0,1,"L");
    $mpdf->Cell(95,5,"HAJ HOUSE, CALICUT AIRPORT POST", 0,1,"L");
    $mpdf->Cell(95,5,$add2, 0,0,"L");
    $mpdf->Cell(95,5,"MALAPPURAM-673647", 0,1,"L");
    $mpdf->Cell(95,5, $add3. ", " .$add4, 0,1,"L");
    $mpdf->Cell(190,10,"", 0,1,"C");
    
    
    $mpdf->SetFont('Times','',8);
    $mpdf->Cell(95,3,"   From,", 0,1,"L");
    $mpdf->SetFont('Arial','B',8);
    $mpdf->Cell(95,3,$head, 0,1,"L");
    $mpdf->SetFont('Arial','',8);
    $mpdf->Cell(95,3,$add1, 0,1,"L");
    $mpdf->Cell(95,3,$add2, 0,1,"L");
    $mpdf->Cell(95,3, $add3. ", " .$add4, 0,1,"L");
    */
    
    $mpdf->Output();
     exit;
     
?>