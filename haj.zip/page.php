<?php
    include "con/con.php";
    if($con)
    {
       // echo "succ";
    }
if( (isset($_GET['mob']) || isset($_GET['idmob']) || isset($_GET['mobnumbck'])) || isset($_GET['id']) && isset($_COOKIE['mobck'])  )
{
    include "head.php";
    echo "<body>";
    
    if(isset($_GET['mob']))
    {
    ?>
        
            <div class="container"><br>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                     <button class="round btn btn-danger">
                   
                            <a class="nav-link" href="http://haj.saypay.in/page.php?mob=<?php echo $_COOKIE['mobck']; ?>">Home Page<span class="sr-only">(current)</span></a>
                        
                </button>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                    <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-xs-10 white b">
                        <center>For details contact : 8848888092</center>
                    </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                </div>
            </div>
            <br>
            <?php
            if($_GET['mob'] == 'notinclude')
            {
                ?>
            <div class=" row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-xs-10 ">
                    
                        <form method="post" class="row">
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
            				    <fieldset>
            				        <input type='text' name='mob' class='form-control round' value="<?php echo $_COOKIE['mobck']; ?>" required />
            				        <label>Enter Mobile Number</label>
                                </fieldset>
                            </div>
                            
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
                                <input type="submit" class="btn btn-success form-control round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" value="Go" id="" name="mobile_go" />
                            </div>
                        
                    
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" id="ajax_mob_det">
                            <div class="row">
                            <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        				        <select name='cat' class='form-control round' required onChange="catsel(this);">
        				            <option  disabled selected value>Select Category</option>
        				            <option value='70'>Reserved Category (70+)</option>
        				            <option value='WM'>Ladies without Mehram</option>
        				            <option value='G'>General</option>
        				        </select>
                            </div>
                            </div>
       
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group"></div>
                            
                          
                        </div>
                    <div class = "col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row" id="proceed_div_l">
                    </div>
                    
                    <div class = "col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row" id="proceed_div">
                    </div>
                    
                    </form>
                    
                    
                        
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1">
                    
                </div>
                
            </div>
            
            <?php
            }
            if($_GET['mob'] <> 'notinclude')
            {
                ?>
                        
    <div class="row">
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
        <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-xs-10 ">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                <form method="post" target="" class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
    				    <fieldset>
    				        <input type='text' name='mob' class='form-control round' value="<?php echo $_COOKIE['mobck']; ?>" required />
    				        <label>Enter Mobile Number</label>
                        </fieldset>
                    </div>
                    
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
                        <input type="submit" class="btn btn-success form-control round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" value="Go" id="" name="mobile_go" />
                    </div>
                    </form>
                
            </div>
            
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row" id="ajax_mob_det">
    
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group" >
                    <a href="http://haj.saypay.in/page.php?idmob='<?php echo $_COOKIE['mobck'];?>'" target='_blank'>
                        <button value="Print Challan"  name = "printchallanbtn" class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control">Print Challan</button>
                    </a>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group">
                    <a href="http://haj.saypay.in/page.php?mobnumbck=<?php echo $_COOKIE['mobck'];?>" target='_blank'>
                    <button  value="Get Details" name="" class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" id=""  >Get Details</button>
                    </a>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group">
                    <a href="http://haj.saypay.in/frame.php" target='_blank'>
                    <button  value = "Applay Online" name="apponline" class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" >Aplay Online</button>
                    </a>
                </div>     
            </div>
            </div>
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1">
        </div>
    </div>
    
                
                
            <?php   
            }
            ?>
            
        </body>
    </html>
    
    <script>
        function catsel(sel) {
            var catsel = sel.options[sel.selectedIndex].value;
            document.cookie = 'catselck =' + catsel;
            $.ajax({
                type: "POST",
                url: "ajx.php",
                data: "catsel=" + catsel,
                cache: false,
                 beforeSend: function() {
                    $('#ajax_mob_det').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#ajax_mob_det").html(html);
                }
            });   
        }
    </script>
    
    
    <script>
        function proceedFunc(sel) {
            
            $.ajax({
                type: "POST",
                url: "ajx.php",
                data: "proceedFunc=" + 'proceedfunction',
                cache: false,
                 beforeSend: function() {
                    $('#ajax_mob_det').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#ajax_mob_det").html(html);
                }
            });   
        }
    </script>
    
    <script>
        function proceedFunc70(sel) {
            
            $.ajax({
                type: "POST",
                url: "ajx.php",
                data: "proceedFunc70=" + 'proceedFunc70',
                cache: false,
                 beforeSend: function() {
                    $('#ajax_mob_det').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#ajax_mob_det").html(html);
                }
            });   
        }
    </script>
    
    
    <script>
        function proceedFuncgen(sel) {
            
            $.ajax({
                type: "POST",
                url: "ajx.php",
                data: "proceedFuncgen=" + 'proceedFuncgen',
                cache: false,
                 beforeSend: function() {
                    $('#ajax_mob_det').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#ajax_mob_det").html(html);
                }
            });   
        }
    </script>
    
    
    <script>
        function infants(sel) {
            var infsel = sel.options[sel.selectedIndex].value;
            $.ajax({
                type: "POST",
                url: "ajx.php",
                data: "infants=" + infsel,
                cache: false,
                 beforeSend: function() {
                    $('#ajax_mob_det').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#ajax_mob_det").html(html);
                }
            });   
        }
    </script>
    
    
    <script>
        function nopilgrims(sel) {
            var nopilgrims = sel.options[sel.selectedIndex].value;
            document.cookie = 'nopilgrms=' + nopilgrims;
             $.ajax({
                type: "POST",
                url: "ajx.php",
                data: "nopilgrims=" + nopilgrims,
                cache: false,
                 beforeSend: function() {
                    $('#ajax_mob_det').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#ajax_mob_det").html(html);
                }
            });   
            
        }
    </script>
    
    <script>
        function setinfck(sel) {
            var setinfck = sel.options[sel.selectedIndex].value;
            document.cookie = 'infntck =' + setinfck;
            
        }
    </script>
    
    
    <?php
    }
    if(isset($_POST['mobile_go']))
    {
        $mobile = $_POST['mob'];
        if (strlen($mobile) >= 10)
        {
            echo "<script> 
            setck(); 
            function setck() 
            { document.cookie = 'mobck = $mobile'; }
            </script>";
            $sqlmob = "SELECT * FROM challan WHERE mobile = '$mobile'";
            $resmob = mysqli_query($con, $sqlmob);
            $rowmob = mysqli_fetch_array($resmob);
            $mobile_id =  $rowmob['id'];
            if($mobile_id)
            {
                echo "<script> window.location='http://haj.saypay.in/page.php?mob=$mobile_id'; </script>";
                 //header("Location: ");  
            }
            else
            {
                echo "<script> window.location='http://haj.saypay.in/page.php?mob=notinclude'; </script>";
                //header("Location: http://haj.saypay.in/page.php?mob=notinclude");  
            }
        }
        else
        {
            echo "<script> alert('Number must be 10 digit'); </script>";
        }
    }
    
    if(isset($_POST['princhlln']))
    {
        $mobile = $_POST['mob'];
        
        //select box
        //$selcat = $_POST['cat'];
        $selcat = $_COOKIE['catselck'];
        
        
        $selpil = $_POST['Pil'];
        $selinf = $_POST['inf'];
        
        $pass = $_POST['pass'];
        
        //proceed text box pilgrims
        $pilname = $_POST['name1'];
        $piladd = $_POST['add'];
        $pilname2 = $_POST['name2'];
        $pilname3 = $_POST['name3'];
        $pilname4 = $_POST['name4'];
        $pilname5 = $_POST['name5'];
        
        //proceed text box infant
        $inf1 = $_POST['inf1'];
        $inf2 = $_POST['inf2'];
        
        //WM G
        if($_COOKIE['catselck'] == '70')
        {
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
				VALUES (NULL , '$pass', '$pilname',
				'$piladd', '$pilname2', '0', '0', '0', '0', '0', '$selcat', '2', '0',
				'$mobile')";
			
            
        }
		
		if($_COOKIE['catselck'] == 'WM')
        {
			if($selpil == '5' && $selinf == '2')
			{
             $sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '$pilname5', '$inf1', '$inf2', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			elseif($selpil == '5' && $selinf == '1')
			{
             $sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '$pilname5', '$inf1', '0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			elseif($selpil == '4' && $selinf == '2')
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '0', '$inf1', '$inf2', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			elseif($selpil == '4' && $selinf == '1')
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '0', '$inf1', '0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			elseif($selpil == '4' && $selinf == '0')
			{
             $sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '0', '0', '0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			elseif($selpil == '5' && $selinf == '0')
			{
             $sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '$pilname5', '0', '0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			
				
		}
            
        
        
        if($_COOKIE['catselck'] == 'G')
        {
			if( $selinf == '2' && $selpil == '1' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '0', '0', '0', '0', '$inf1', '$inf2', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '2' && $selpil == '2' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '0', '0', '0', '$inf1', '$inf2', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '2' && $selpil == '3' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3',  '0', '0', '$inf1', '$inf2', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '2' && $selpil == '4' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '0','$inf1', '$inf2', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '2' && $selpil == '5' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '$pilname5', '$inf1', '$inf2', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			
			if( $selinf == '1' && $selpil == '1' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '0','0','0','0','$inf1', '0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '1' && $selpil == '2' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '0','0','0', '$inf1', '0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '1' && $selpil == '3' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '0','0', '$inf1', '0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '1' && $selpil == '4' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '0', '$inf1', '0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '1' && $selpil == '5' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '$pilname5', '$inf1', '0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			
			if( $selinf == '0' && $selpil == '1' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '0','0','0','0', '0','0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '0' && $selpil == '2' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '0','0','0', '0','0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '0' && $selpil == '3' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '0','0', '0','0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '0' && $selpil == '4' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '0', '0','0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			}
			if( $selinf == '0' && $selpil == '5' )
			{
				$sql = "INSERT INTO `challan`(`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) 
            VALUES (NULL , '$pass', '$pilname',
            '$piladd', '$pilname2', '$pilname3', '$pilname4', '$pilname5', '0','0', '$selcat', '$selpil', '$selinf',
            '$mobile')";
			} 
        }
        
        
        if (mysqli_query($con, $sql)) 
        {
            echo "<script> alert('sucess'); </script>";
            
            //clear all cookie datas
            if( isset($_COOKIE['infntck']) ) { unset($_COOKIE['infntck']); }
            if( isset($_COOKIE['nopilgrms']) ) { unset($_COOKIE['nopilgrms']); }
            if( isset($_COOKIE['catselck']) ) { unset($_COOKIE['catselck']); }
            
            
            setcookie("infntck", "", time() - 3600); 
            setcookie("nopilgrms", "", time() - 3600); 
            setcookie("catselck", "", time() - 3600); 
            
            
            echo "<script>
            delete_cookie();
                function delete_cookie(){
                    document.cookie = infntck + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
                    document.cookie = nopilgrms + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
                    
                    
                    document.cookie = catselck + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
                    
                    document.cookie = infntck + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT; domain=.haj.saypay.in';
                    document.cookie = nopilgrms + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT; domain=.haj.saypay.in';
                    
                    document.cookie = catselck + '=;expires=Thu, 01 Jan 1970 00:00:00 GMT; domain=.haj.saypay.in';
                   
                }
            </script>";
           
            $sqlsel = "SELECT id FROM `challan` WHERE pass_no = '$pass' AND mobile = '$mobile'";
            $ressel = mysqli_query($con, $sqlsel);
            $rowsel = mysqli_fetch_array($ressel);
            $id = $rowsel['id'];
            // echo "
            // <script>
            // window.location = 'http://haj.saypay.in/page.php?ins_id=$id';
            // http://haj.saypay.in/page.php?idmob='<?php echo $_COOKIE['mobck'];// </script> ";
            $mobilcook = $_COOKIE['mobck'];
        
        ?>
            <script>
            window.location = 'http://haj.saypay.in/page.php?id=<?php echo $id; ?>&idmob=<?php echo $mobilcook; ?>';
            </script> ";
            <?php
        }
    }
    
    if(isset($_GET['idmob']) || isset($_GET['id']))
    {
        if($_GET['idmob'] != '')
        { 
            include "head.php";
        ?>
        
            <div class="container"><br>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                    <button class="round btn btn-danger">
                   
                            <a class="nav-link" href="http://haj.saypay.in/page.php?mob=<?php echo $_COOKIE['mobck']; ?>">Home Page<span class="sr-only">(current)</span></a>
                        
                </button>
                </div>
            </div>
             <br><br><br><br><br>
            <div class=" row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-xs-10 ">
                <form method = "post" target="_blank">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-3 "></div>
                        <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
    				        <select name='banknm' class='form-control round' required >
    				            <option  disabled selected value>Select Bank</option>
    				            <option value='UBI'>Union Baank of India</option>
    				            <option value='SBI'>State Bank of India</option>
    				        </select>
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-3 "></div>
                    </div>
                    
                     <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-3 "></div>
                        
                        <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
                            <input type="submit" class="btn btn-success form-control round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" value="Go"  name="bankgo" />
                        </div>
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-3 "></div>
                    </div>
                </form>
                <br>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-3 "></div>
                    
                    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-3 col-xs-3 "></div>
                    </div>
                </div>
                
            </div>
                
    <?php        
        }
    }
    
    
    
    if(isset($_POST['apponline']))
    {
        
    }
    
    if(isset($_GET['mobnumbck']))
    {
        $mobileno = $_GET['mobnumbck'];
        ?>
        <div class="container"><br>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                    
                        
                            
                            <button class="round btn btn-danger">
                   
                            <a class="nav-link" href="http://haj.saypay.in/page.php?mob=<?php echo $_COOKIE['mobck']; ?>">Home Page<span class="sr-only">(current)</span></a>
                        
                </button>
                        
                    
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                    <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-xs-10 white b">
                        <center>For details contact : 8848888092</center>
                    </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                </div>
        </div>
        
        <br>
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                <h2 align="center" >Details</h2>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card1 shadow">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <table class="table table-hover" >
                            <?php
                            $sql = "SELECT * FROM `challan` where mobile = '$mobileno' ";
                            $res=mysqli_query($con,$sql);
                            while($row=$res->fetch_assoc())
                            { 
                                $cat = $row['catagory']; 
                                $inf = $row['infant'];
                                $pil = $row['pilgrim'];
                                $pass = $row['pass_no'];
                                $name = $row['name'];
                                $mob = $row['mobile'];
                                $adds = $row['adds'];
                                $p2 = $row['pil_2'];
                                $p3 = $row['pil_3'];
                                $p4 = $row['pil_4'];
                                $p5 = $row['pil_5'];
                                $i1 = $row['inf_1'];
                                $i2 = $row['inf_2'];
                            ?>
                            <tr>
                                <th>Type</th>
                                <th>Passport No</th>
                               
                                <th>Mobile</th>
                                
                                <?php if($pil=='1' || $pil=='2' || $pil=='3' || $pil=='4' || $pil=='5')
                                {
                                    echo "<th>Name</th>";
                                    echo "<th>Address</th>";
                                }
                                if($pil=='2' || $pil=='3' || $pil=='4' || $pil=='5')
                                {
                                    echo "<th>Name of Pilgrim 2</th>";
                                }
                                if( $pil=='3' || $pil=='4' || $pil=='5')
                                {
                                    echo "<th>Name of Pilgrim 3</th>";
                                }
                                if( $pil=='4' || $pil=='5')
                                {
                                    echo "<th>Name of Pilgrim 4</th>";
                                }
                                if($pil=='5')
                                {
                                    echo "<th>Name of Pilgrim 5</th>";
                                }
                                
                                if( $inf=='2' || $inf=='1')
                                {
                                    echo "<th>Name of Infant 1</th>";
                                }
                                if($inf=='2')
                                {
                                    echo "<th>Name of Infant 2</th>";
                                }
                                ?>
                                <th>Number of pilgrim</th>
                                <th>Number of Infant</th>
                            </tr>
                            <tr>											
                                <td><?php echo $row['catagory']; ?></td>
                                <td><?php echo $row['pass_no']; ?></td>
                                
                                <?php if($pil=='1' || $pil=='2' || $pil=='3' || $pil=='4' || $pil=='5')
                                {?>
                                    <td><?php echo $row['name']; ?></td>
                                    <td><?php echo $row['adds']; ?></td>
                                <?php    
                                }
                                if($pil=='2' || $pil=='3' || $pil=='4' || $pil=='5')
                                { ?>
                                    <td><?php echo $row['pil_2']; ?></td>
                                <?php
                                    
                                }
                                if( $pil=='3' || $pil=='4' || $pil=='5')
                                { ?>
                                    <td><?php echo $row['pil_3']; ?></td>
                                <?php
                                }
                                if( $pil=='4' || $pil=='5')
                                { ?>
                                    <td><?php echo $row['pil_4']; ?></td>
                                <?php 
                                }
                                if($pil=='5')
                                { ?>
                                    <td><?php echo $row['pil_5']; ?></td>
                                <?php
                                }
                                
                                if( $inf=='2' || $inf=='1')
                                { ?>
                                    <td><?php echo $row['inf_1']; ?></td>
                                <?php
                                }
                                if($inf=='2')
                                { ?>
                                    <td><?php echo $row['inf_2']; ?></td>
                                <?php
                                }
                                ?>
                                <td><?php echo $row['mobile']; ?></td>
                                <td><?php echo $row['pilgrim']; ?></td>
                                <td><?php echo $row['infant']; ?></td>
                            </tr>
                            <?php    
                            }
                            ?>
                        </table>
                        
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    if(isset($_POST['bankgo']))
    {
        $bnk = $_POST['banknm'];
        $mobile = $_COOKIE['mobck'];
        echo "<script>
        window.location.href='http://haj.saypay.in/challan.php?mobileno=$mobile&banknm=$bnk'
        </script>
        ";
    }

}
else
{
    echo "<script>
    window.location.href='http://haj.saypay.in/'
    </script>";
}
?>
</body>
</html>