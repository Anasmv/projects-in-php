<?php
//haj ajax all 
if(isset($_POST['proceedFunc70']))
{ 
    $infck = $_COOKIE['infntck'];
    ?>

    <div class="row">
    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
				        <select name='cat' class='form-control round' required onChange="catsel(this);">
				            <option  selected value='70'>Reserved Category (70+)</option>
				            <option value='70'>Reserved Category (70+)</option>
				            <option value='WM'>Ladies without Mehram</option>
				            <option value='G'>General</option>
				        </select>
                    </div>

                    

                <!--<form method="post" class=" row" target="_blank">-->
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
    				    <fieldset>
    				        <input type='text' name='pass' class='form-control round' required />
    				        <label>Enter Passport Number of Cover Head</label>
                        </fieldset>
                    </div>
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
    				    <fieldset>
    				        <input type='text' name='name1' class='form-control round' required />
    				        <label>Enter Name of Cover Head</label>
                        </fieldset>
                    </div>
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
    				    <fieldset>
    				        <input type='text' name='add' class='form-control round' required />
    				        <label>Enter Address of Cover Head</label>
                        </fieldset>
                    </div>
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
    				    <fieldset>
    				        <input type='text' name='name2' class='form-control round' required />
    				        <label>Enter Name of Pilgrim2</label>
                        </fieldset>
                    </div>
                    
                
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group">
                      
                            <input type = "submit" name="princhlln" value="Print Challan " class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" id="" onClick=" ">
                       
                    </div>
                    
                </form>

</div>
<?php
}

if(isset($_POST['proceedFuncgen']))
{ 
    $infck = $_COOKIE['infntck'];
     $pilno = $_COOKIE['nopilgrms'];
    
?>
 

<div class="row">
    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
				        <select name='cat' class='form-control round' required onChange="catsel(this);">
				            <option   selected value='G'>General</option>
				            <option value='70'>Reserved Category (70+)</option>
				            <option value='WM'>Ladies without Mehram</option>
				            <option value='G'>General</option>
				        </select>
                    </div>

                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 ">
				        <select name='Pil' class='form-control round' required onChange="nopilgrims(this);">
				            <option   selected value = '<?php echo $pilno; ?>'><?php 
				            if($pilno == '1' || $pilno == '2' || $pilno == '3' || $pilno == '4' || $pilno == '5')
				            {
				            echo $pilno;
				            }
				            else
				            {
				            echo "Select Pilgrim";
				            } ?></option>
				            <option value='1'>1</option>
				            <option value='2'>2</option>
				            <option value='3'>3</option>
				            <option value='4'>4</option>
				            <option value='5'>5</option>
				        </select>
                    </div>
                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
				        <select name='inf' class='form-control round' required onChange="setinfck(this); infants(this);">
				            <option   selected value = '<?php echo $infck ;?>'>
				                <?php 
				                if($infck == '0' || $infck == '1' || $infck == '2')
				                {
				                echo $infck;
				                }
				                else
				                {
				                echo "Select Infant";
				                }
				                ?>
				            </option>
				            <option value='0'>0</option>
				            <option value='1'>1</option>
				            <option value='2'>2</option>
				        </select>
                    </div>
                
                    
    
   
   
        <!--<form method="post" class=" row" target="_blank" >-->
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
			    <fieldset>
			        <input type='text' name='pass' class='form-control round' required />
			        <label>Enter Passport Number of Cover Head</label>
                </fieldset>
            </div>
            
            
           
           
                
              
           <?php
           
           if($pilno == '1' || $pilno == '2' || $pilno == '3' || $pilno == '4' || $pilno == '5') 
           { ?>
              
           
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in " id="p1">
			    <fieldset>
			        <input type='text' name='name1' class='form-control round' required />
			        <label>Enter Name of Cover Head</label>
                </fieldset>
            </div>
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in " id="p1">
			    <fieldset>
			        <input type='text' name='add' class='form-control round' required />
			        <label>Enter Address of Cover Head</label>
                </fieldset>
            </div>
        
 
          


           
          <?php
          }
           if($pilno == '2' || $pilno == '3' || $pilno == '4' || $pilno == '5' )
           { ?>
           <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in " id="p2">
			    <fieldset>
			        <input type='text' name='name2' class='form-control round' required />
			        <label>Enter Name of Pilgrim2</label>
                </fieldset>
            </div>
       
          <?php
           }
           if($pilno == '3' || $pilno == '4' || $pilno == '5')
           {
               ?>
             <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in " id="p3">
			    <fieldset>
			        <input type='text' name='name3' class='form-control round' required />
			        <label>Enter Name of Pilgrim3</label>
                </fieldset>
            </div>
          <?php
           }
           if($pilno == '4' || $pilno == '5')
           {
               ?>
          <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in " id="p4">
			    <fieldset>
			        <input type='text' name='name4' class='form-control round' required />
			        <label>Enter Name of Pilgrim4</label>
                </fieldset>
            </div>
          <?php
           }
           if($pilno == '5')
           {
               ?>
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in " id="p5">
			    <fieldset>
			        <input type='text' name='name5' class='form-control round' required />
			        <label>Enter Name of Pilgrim5</label>
                </fieldset>
            </div>
          <?php
           }
        if($infck == '1' || $infck == '2')
           {
           ?>
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
			    <fieldset>
			        <input type='text' name='inf1' class='form-control round' required />
			        <label>Enter Name of Infant1</label>
                </fieldset>
            </div>
            <?php
           }
           
           if($infck == '2')
           {
           ?>
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
			    <fieldset>
			        <input type='text' name='inf2' class='form-control round' required />
			        <label>Enter Name of Infant2</label>
                </fieldset>
            </div>   
            <?php
           } 
           ?>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group">
               
                    <input type = "submit" name="princhlln" value = "Print Challan" class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" id="" onClick=" ">
                        
                
             
            </div>
            
        </form>
        </div>

<?php
}

if(isset($_POST['proceedFunc']))
{
    $pilno = $_COOKIE['nopilgrms'];
     $infck = $_COOKIE['infntck'];
    //echo $_POST['proceedFunc'];
    ?>
    <div class="row">
    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
				        <select name='cat' class='form-control round' required onChange="catsel(this);">
				            <option   selected value='WM'>Ladies without Mehram</option>
				            <option value='70'>Reserved Category (70+)</option>
				            <option value='WM'>Ladies without Mehram</option>
				            <option value='G'>General</option>
				        </select>
                    </div>

                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 ">
				        <select name='Pil' class='form-control round' required onChange="nopilgrims(this);">
				            <option   selected value = '<?php echo $pilno ?>'><?php 
				            if($pilno == '1' || $pilno == '2' || $pilno == '3' || $pilno == '4' || $pilno == '5')
				            {
				            echo $pilno;
				            }
				            else
				            {
				            echo "Select Pilgrim";
				            }
				            ?></option>
				            <!--<option value='1'>1</option>-->
				            <!--<option value='2'>2</option>-->
				            <!--<option value='3'>3</option>-->
				            <option value='4'>4</option>
				            <option value='5'>5</option>
				        </select>
                    </div>
                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
				        <select name='inf' class='form-control round' required onChange="setinfck(this); infants(this);">
				            <option   selected value = '<?php echo $infck ;?>'>
				                <?php 
				                if($infck == '0' || $infck == '1' || $infck == '2')
				                {
				                echo $infck;
				                }
				                else
				                {
				                echo "Select Infant";
				                }
				                ?>
				            </option>
				            <option value='0'>0</option>
				            <option value='1'>1</option>
				            <option value='2'>2</option>
				        </select>
                    </div>
                
                
                    
    
   
        
        <!--<form method="post" class=" row"  target="_blank">-->
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
			    <fieldset>
			        <input type='text' name='pass' class='form-control round' required />
			        <label>Enter Passport Number of Cover Head</label>
                </fieldset>
            </div>
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
			    <fieldset>
			        <input type='text' name='name1' class='form-control round' required />
			        <label>Enter Name of Cover Head</label>
                </fieldset>
            </div>
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
			    <fieldset>
			        <input type='text' name='add' class='form-control round' required />
			        <label>Enter Address of Cover Head</label>
                </fieldset>
            </div>
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
			    <fieldset>
			        <input type='text' name='name2' class='form-control round' required />
			        <label>Enter Name of Pilgrim2</label>
                </fieldset>
            </div>
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
			    <fieldset>
			        <input type='text' name='name3' class='form-control round' required />
			        <label>Enter Name of Pilgrim3</label>
                </fieldset>
            </div>
            
            <?php
            if( $pilno == '' || $pilno == '4' || $pilno == '5')
           {
               ?>
          <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in " id="p4">
			    <fieldset>
			        <input type='text' name='name4' class='form-control round' required />
			        <label>Enter Name of Pilgrim4</label>
                </fieldset>
            </div>
          <?php
           }
           if($pilno == '5')
           {
               ?>
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in " id="p5">
			    <fieldset>
			        <input type='text' name='name5' class='form-control round' required />
			        <label>Enter Name of Pilgrim5</label>
                </fieldset>
            </div>
          <?php
           }
           
           if($infck == '1' || $infck == '2')
           {
           ?>
            
            
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
			    <fieldset>
			        <input type='text' name='inf1' class='form-control round' required />
			        <label>Enter Name of Infant1</label>
                </fieldset>
            </div>
            <?php
           }
           
           if($infck == '2')
           {
           ?>
            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
			    <fieldset>
			        <input type='text' name='inf2' class='form-control round' required />
			        <label>Enter Name of Infant2</label>
                </fieldset>
            </div>   
            <?php
           } 
           ?>
        
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group">
                
                    <input type="submit" name="princhlln" value = "Print Challan" class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" id="" onClick=" ">
                     
                
            </div>
            
        </form>
        </div>
        
                    
<?php
}

// if( isset($_POST['nopilgrims']))
// {
//     echo $_POST['nopilgrims'];
//     echo $_COOKIE['catselck'];
// }


if( isset($_POST['nopilgrims']) || isset($_POST['catsel']) )
{
    $pilno = $_COOKIE['nopilgrms'];
     //$cat = $_POST['catsel'];
     $cat = $_COOKIE['catselck'];
     
    
    if($cat == '70')
    {
    ?>
    
    <div class="row">
            <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
				        <select name='cat' class='form-control round' required onChange="catsel(this);">
				            <option  selected value='70'>Reserved Category (70+)</option>
				            <option value='70'>Reserved Category (70+)</option>
				            <option value='WM'>Ladies without Mehram</option>
				            <option value='G'>General</option>
				        </select>
                    </div>
                    
                    
                    <div class=" ml ">
                        1.  താങ്കളുടെ പാസ്‌പോര്‍ട്ടിന്റെ ആദ്യ പേജില്‍ പാസ്‌പോര്‍ട്ട് ഓഫീസറുടെ ഒപ്പും സീലുമുണ്ടെന്ന് ഉറപ്പുവരുത്തുക.
                        <br>2.  തുടര്‍ച്ചയായി ഒഴിവുള്ള രണ്ട് പേജുകള്‍ പാസ്‌പോര്‍ട്ടിലുണ്ടെന്ന് ഉറപ്പാക്കുക.
                        <br>3.  പാസ്‌പോര്‍ട്ടിന് 20/01/2021 വരെ കാവാലധിയുണ്ടെന്ന് ഉറപ്പാക്കുക.
                        <br>4.  ഫോട്ടോ 5-20 kbps ല്‍ 100 X 148 px ലും മറ്റുള്ളവ 80-250 kbsp ല്‍ 570 X 795 px ലും .jpeg ഫോര്‍മാറ്റില്‍ സെറ്റ് ചെയ്യുക.
                        <br>5.  പൂരിപ്പിച്ച് സബ്മിറ്റ് ചെയ്ത അപേക്ഷകള്‍ ഹജ്ജ് ഹൗസിലേക്ക് അയക്കേണ്ടതില്ല. 12 ദിവസത്തിനുള്ളില്‍ കവര്‍ നമ്പര്‍ ലഭിക്കുന്നതാണ്. 
                        <br>6.  സെലക്ഷനായ ശേഷം മാത്രം 15-01-2020 നുമുമ്പായി അപേക്ഷ ഉള്‍പ്പെടേ മുഴുവന്‍ ഒറിജിനല്‍ രേഖകളും ഹജ്ജ് ഹൗസില്‍ എത്തിക്കേണ്ടതാണ്.
                        <br>7.  N.R.I കാര്‍ ശവ്വാല്‍ 10 നുമുമ്പ് പോസ്‌പോര്‍ട്ട് നല്‍കണം. സെലക്ഷനായ ഉടനെ പാസ്‌പോര്‍ട്ടിന്റെ കോപ്പിയും അപേക്ഷ അടക്കം മറ്റുരേഖകളും ഹജ്ജ് ഹൗസില്‍ എത്തിക്കണം.
                        <br>8.  പാസ്‌പോര്‍ട്ടിലെ ജനന തിയ്യതി
                        30-05-1950 ക്ക് മുമ്പാണെന്ന് ഉറപ്പുവരുത്തുക.
                    </div>
                    
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group"></div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group">
                        <button class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" id="" onClick="proceedFunc70() ">Proceed</button>
                    </div>
                </div>
                <div class = "col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row" id="proceed_div">
                </div>
                </div>

<?php        
    }
    elseif($cat == 'WM')
    { ?>
    
    <div class="row">
                    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
				        <select name='cat' class='form-control round' required onChange="catsel(this);">
				            <option   selected value='WM'>Ladies without Mehram</option>
				            <option value='70'>Reserved Category (70+)</option>
				            <option value='WM'>Ladies without Mehram</option>
				            <option value='G'>General</option>
				        </select>
                    </div>

                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 ">
				        <select name='Pil' class='form-control round' required onChange="nopilgrims(this);">
				            <option   selected value = '<?php echo $pilno ?>'><?php 
    				            if($pilno == '1' || $pilno == '2' || $pilno == '3' || $pilno == '4' || $pilno == '5')
    				            {
    				            echo $pilno;
    				            }
    				            else
    				            {
    				            echo "Number of Pilgrims";
    				            }
				            ?>
				            </option>
				            <!--<option value='1'>1</option>-->
				            <!--<option value='2'>2</option>-->
				            <!--<option value='3'>3</option>-->
				            <option value='4'>4</option>
				            <option value='5'>5</option>
				        </select>
                    </div>
                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
				        <select name='inf' class='form-control round' required onChange="setinfck(this); infants(this);">
				            <option  disabled selected value>Number of Infants</option>
				            <option value='0'>0</option>
				            <option value='1'>1</option>
				            <option value='2'>2</option>
				        </select>
                    </div>
                    
                    <div class=" ml ">
                        1.  താങ്കളുടെ പാസ്‌പോര്‍ട്ടിന്റെ ആദ്യ പേജില്‍ പാസ്‌പോര്‍ട്ട് ഓഫീസറുടെ ഒപ്പും സീലുമുണ്ടെന്ന് ഉറപ്പുവരുത്തുക.
                        <br>2.  തുടര്‍ച്ചയായി ഒഴിവുള്ള രണ്ട് പേജുകള്‍ പാസ്‌പോര്‍ട്ടിലുണ്ടെന്ന് ഉറപ്പാക്കുക.
                        <br>3.  പാസ്‌പോര്‍ട്ടിന് 20/01/2021 വരെ കാവാലധിയുണ്ടെന്ന് ഉറപ്പാക്കുക.
                        <br>4.  ഫോട്ടോ 5-20 kbps ല്‍ 100 X 148 px ലും മറ്റുള്ളവ 80-250 kbsp ല്‍ 570 X 795 px ലും .jpeg ഫോര്‍മാറ്റില്‍ സെറ്റ് ചെയ്യുക.
                        <br>5.  പൂരിപ്പിച്ച് സബ്മിറ്റ് ചെയ്ത അപേക്ഷകള്‍ ഹജ്ജ് ഹൗസിലേക്ക് അയക്കേണ്ടതില്ല. 12 ദിവസത്തിനുള്ളില്‍ കവര്‍ നമ്പര്‍ ലഭിക്കുന്നതാണ്. 
                        <br>6.  സെലക്ഷനായ ശേഷം മാത്രം 15-01-2020 നുമുമ്പായി അപേക്ഷ ഉള്‍പ്പെടേ മുഴുവന്‍ ഒറിജിനല്‍ രേഖകളും ഹജ്ജ് ഹൗസില്‍ എത്തിക്കേണ്ടതാണ്.
                        <br>7.  N.R.I കാര്‍ ശവ്വാല്‍ 10 നുമുമ്പ് പോസ്‌പോര്‍ട്ട് നല്‍കണം. സെലക്ഷനായ ഉടനെ പാസ്‌പോര്‍ട്ടിന്റെ കോപ്പിയും അപേക്ഷ അടക്കം മറ്റുരേഖകളും ഹജ്ജ് ഹൗസില്‍ എത്തിക്കണം.
                        <br>8.  പാസ്‌പോര്‍ട്ടിലെ ജനന തിയ്യതി
                            30-05-1975
                        ക്ക് മുമ്പാണെന്ന് ഉറപ്പുവരുത്തുക.
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group"></div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group">
                        <button class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" id="" onClick="proceedFunc() ">Proceed</button>
                    </div>
                </div>
                <div class = "col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row" id="proceed_div">
                </div>
                </div>

<?php        
    }
    
    elseif($cat == 'G')
    { ?>
    <div class="row">
                    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
				        <select name='cat' class='form-control round' required onChange="catsel(this);">
				            <option   selected value='G'>General</option>
				            <option value='70'>Reserved Category (70+)</option>
				            <option value='WM'>Ladies without Mehram</option>
				            <option value='G'>General</option>
				        </select>
                    </div>

                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 ">
				        <select name='Pil' class='form-control round' required onChange="nopilgrims(this);">
				            <option   selected value = '<?php echo $pilno ?>'><?php 
    				            if($pilno == '1' || $pilno == '2' || $pilno == '3' || $pilno == '4' || $pilno == '5')
    				            {
    				            echo $pilno;
    				            }
    				            else
    				            {
    				            echo "Number of Pilgrims";
    				            }
				            ?>
				            </option>
				            <option value='1'>1</option>
				            <option value='2'>2</option>
				            <option value='3'>3</option>
				            <option value='4'>4</option>
				            <option value='5'>5</option>
				        </select>
                    </div>
                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
				        <select name='inf' class='form-control round' required onChange="setinfck(this); infants(this);">
				            <option  disabled selected value>Number of Infants</option>
				            <option value='0'>0</option>
				            <option value='1'>1</option>
				            <option value='2'>2</option>
				        </select>
			        
                    </div>
                    <div class=" ml ">
                        1.  താങ്കളുടെ പാസ്‌പോര്‍ട്ടിന്റെ ആദ്യ പേജില്‍ പാസ്‌പോര്‍ട്ട് ഓഫീസറുടെ ഒപ്പും സീലുമുണ്ടെന്ന് ഉറപ്പുവരുത്തുക.
                        <br>2.  തുടര്‍ച്ചയായി ഒഴിവുള്ള രണ്ട് പേജുകള്‍ പാസ്‌പോര്‍ട്ടിലുണ്ടെന്ന് ഉറപ്പാക്കുക.
                        <br>3.  പാസ്‌പോര്‍ട്ടിന് 20/01/2021 വരെ കാവാലധിയുണ്ടെന്ന് ഉറപ്പാക്കുക.
                        <br>4.  ഫോട്ടോ 5-20 kbps ല്‍ 100 X 148 px ലും മറ്റുള്ളവ 80-250 kbsp ല്‍ 570 X 795 px ലും .jpeg ഫോര്‍മാറ്റില്‍ സെറ്റ് ചെയ്യുക.
                        <br>5.  പൂരിപ്പിച്ച് സബ്മിറ്റ് ചെയ്ത അപേക്ഷകള്‍ ഹജ്ജ് ഹൗസിലേക്ക് അയക്കേണ്ടതില്ല. 12 ദിവസത്തിനുള്ളില്‍ കവര്‍ നമ്പര്‍ ലഭിക്കുന്നതാണ്. 
                        <br>6.  സെലക്ഷനായ ശേഷം മാത്രം 15-01-2020 നുമുമ്പായി അപേക്ഷ ഉള്‍പ്പെടേ മുഴുവന്‍ ഒറിജിനല്‍ രേഖകളും ഹജ്ജ് ഹൗസില്‍ എത്തിക്കേണ്ടതാണ്.
                        <br>7.  N.R.I കാര്‍ ശവ്വാല്‍ 10 നുമുമ്പ് പോസ്‌പോര്‍ട്ട് നല്‍കണം. സെലക്ഷനായ ഉടനെ പാസ്‌പോര്‍ട്ടിന്റെ കോപ്പിയും അപേക്ഷ അടക്കം മറ്റുരേഖകളും ഹജ്ജ് ഹൗസില്‍ എത്തിക്കണം.
                        <br>
                        8.  ഇന്‍ഫാന്റിന്റെ (ചെറിയ കുട്ടി) പാസ്‌പോര്‍ട്ടിലെ ജനന തിയ്യതി 09-09-2020 ന് മുമ്പാണെന്ന് ഉറപ്പുവരുത്തുക.
                        
                    </div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group"></div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group">
                        <button class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" id="" onClick="proceedFuncgen() ">Proceed</button>
                    </div>
                </div>
                <div class = "col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row" id="proceed_div">
                </div>
                </div>

<?php        
    }
        
}


if(isset($_POST['infants']))
{ 
     $catck = $_COOKIE['catselck'];
     $pilno = $_COOKIE['nopilgrms'];
     $infck = $_COOKIE['infntck'];
     $inf = $_POST['infants'];
    if($inf <> 0)
    {
    ?>
    <div class="row">
                <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
				        <select name='cat' class='form-control round' required onChange="catsel(this);">
				            <option   selected value = "<?php echo $catck; ?>"><?php 
				            if($catck == '70')
				            {
				            echo "Reserved Category (70+)";
				            }
				            elseif($catck == 'WM')
				            {
				                echo "Ladies without Mehram";
				            }
				            elseif($catck == 'G')
				            {
				                echo "General";
				            }
				            else
				            {
				                echo "Select Catagory";
				            }
				            
				            
				            ?>
				            </option>
				            <option value='70'>Reserved Category (70+)</option>
				            <option value='WM'>Ladies without Mehram</option>
				            <option value='G'>General</option>
				        </select>
                    </div>
                    
                    

                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 ">
				        <select name='Pil' class='form-control round' required onChange="nopilgrims(this);">
				            <option   selected value = "<?php echo $pilno ?>"><?php
				            if($pilno == '1' || $pilno == '2' || $pilno == '3' || $pilno == '4' || $pilno == '5')
				            {
				            echo $pilno;
				            }
				            else
				            {
				            echo "Select Pilgrim";
				            }
				            ?></option>
				            <option value='1'>1</option>
				            <option value='2'>2</option>
				            <option value='3'>3</option>
				            <option value='4'>4</option>
				            <option value='5'>5</option>
				        </select>
                    </div>
                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
				        <select name='inf' class='form-control round' required onChange="setinfck(this); infants(this);">
				            <option   selected value = "<?php echo $infck; ?>"><?php echo $infck; ?></option>
				            <option value='0'>0</option>
				            <option value='1'>1</option>
				            <option value='2'>2</option>
				        </select>
                    </div>
                    
                    <div class=" ml ">
                        1.  താങ്കളുടെ പാസ്‌പോര്‍ട്ടിന്റെ ആദ്യ പേജില്‍ പാസ്‌പോര്‍ട്ട് ഓഫീസറുടെ ഒപ്പും സീലുമുണ്ടെന്ന് ഉറപ്പുവരുത്തുക.
                        <br>2.  തുടര്‍ച്ചയായി ഒഴിവുള്ള രണ്ട് പേജുകള്‍ പാസ്‌പോര്‍ട്ടിലുണ്ടെന്ന് ഉറപ്പാക്കുക.
                        <br>3.  പാസ്‌പോര്‍ട്ടിന് 20/01/2021 വരെ കാവാലധിയുണ്ടെന്ന് ഉറപ്പാക്കുക.
                        <br>4.  ഫോട്ടോ 5-20 kbps ല്‍ 100 X 148 px ലും മറ്റുള്ളവ 80-250 kbsp ല്‍ 570 X 795 px ലും .jpeg ഫോര്‍മാറ്റില്‍ സെറ്റ് ചെയ്യുക.
                        <br>5.  പൂരിപ്പിച്ച് സബ്മിറ്റ് ചെയ്ത അപേക്ഷകള്‍ ഹജ്ജ് ഹൗസിലേക്ക് അയക്കേണ്ടതില്ല. 12 ദിവസത്തിനുള്ളില്‍ കവര്‍ നമ്പര്‍ ലഭിക്കുന്നതാണ്. 
                        <br>6.  സെലക്ഷനായ ശേഷം മാത്രം 15-01-2020 നുമുമ്പായി അപേക്ഷ ഉള്‍പ്പെടേ മുഴുവന്‍ ഒറിജിനല്‍ രേഖകളും ഹജ്ജ് ഹൗസില്‍ എത്തിക്കേണ്ടതാണ്.
                        <br>7.  N.R.I കാര്‍ ശവ്വാല്‍ 10 നുമുമ്പ് പോസ്‌പോര്‍ട്ട് നല്‍കണം. സെലക്ഷനായ ഉടനെ പാസ്‌പോര്‍ട്ടിന്റെ കോപ്പിയും അപേക്ഷ അടക്കം മറ്റുരേഖകളും ഹജ്ജ് ഹൗസില്‍ എത്തിക്കണം.
                        <br>8.  പാസ്‌പോര്‍ട്ടിലെ ജനന തിയ്യതി 
                        
                        30-05-1950 ക്ക് മുമ്പാണെന്ന് ഉറപ്പുവരുത്തുക.
                        <br>9.  ഇന്‍ഫാന്റിന്റെ (ചെറിയ കുട്ടി) പാസ്‌പോര്‍ട്ടിലെ ജനന തിയ്യതി 09-09-2020 ന് ശേഷമാണെന്ന് ഉറപ്പുവരുത്തുക.
                        <br>
                    </div>
                    
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group"></div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group">
                        <?php if($catck == '70')
				            { ?>
				            <button class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" id="" onClick="proceedFunc70() ">Proceed</button>
				      
				            
				           <?php
				           }
				            elseif($catck == 'WM')
				            { ?>
				                <button class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" id="" onClick="proceedFunc() ">Proceed</button>
				        <?php
				        }
				            elseif($catck == 'G')
				            { ?>
				                
				                <button class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" id="" onClick="proceedFuncgen() ">Proceed</button>
				         <?php
				         }
				            
				            ?>
                        
                        
                        
                        <?php ?>
                    </div>
                </div>
                <div class = "col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row" id="proceed_div">
                </div>
                </div>

<?php
    }
    else
    { ?>
    <div class="row">
    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
				        <select name='cat' class='form-control round' required onChange="catsel(this);">
				            <option   selected value = "<?php echo $catck; ?>"><?php  
				            if($catck == '70')
				            {
				            echo "Reserved Category (70+)";
				            }
				            elseif($catck == 'WM')
				            {
				                echo "Ladies without Mehram";
				            }
				            elseif($catck == 'G')
				            {
				                echo "General";
				            }
				            else
				            {
				                echo "Select Catagory";
				            }
				            ?></option>
				            <option value='70'>Reserved Category (70+)</option>
				            <option value='WM'>Ladies without Mehram</option>
				            <option value='G'>General</option>
				        </select>
                    </div>
                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 ">
				        <select name='Pil' class='form-control round' required onChange="nopilgrims(this);">
				            <option   selected value = "<?php echo $pilno ?>">
				            <?php if($pilno == '1' || $pilno == '2' || $pilno == '3' || $pilno == '4' || $pilno == '5')
				            {
				            echo $pilno;
				            }
				            else
				            {
				            echo "Select Pilgrim";
				            } ?></option>
				            <option value='1'>1</option>
				            <option value='2'>2</option>
				            <option value='3'>3</option>
				            <option value='4'>4</option>
				            <option value='5'>5</option>
				        </select>
                    </div>
                    <div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
				        <select name='inf' class='form-control round' required onChange="setinfck(this); infants(this);">
				            <option   selected value  = "<?php echo $infck; ?>"><?php echo $infck; ?></option>
				            <option value='0'>0</option>
				            <option value='1'>1</option>
				            <option value='2'>2</option>
				        </select>
                    </div>
                    <div class=" ml ">
                        1.  താങ്കളുടെ പാസ്‌പോര്‍ട്ടിന്റെ ആദ്യ പേജില്‍ പാസ്‌പോര്‍ട്ട് ഓഫീസറുടെ ഒപ്പും സീലുമുണ്ടെന്ന് ഉറപ്പുവരുത്തുക.
                        <br>2.  തുടര്‍ച്ചയായി ഒഴിവുള്ള രണ്ട് പേജുകള്‍ പാസ്‌പോര്‍ട്ടിലുണ്ടെന്ന് ഉറപ്പാക്കുക.
                        <br>3.  പാസ്‌പോര്‍ട്ടിന് 20/01/2021 വരെ കാവാലധിയുണ്ടെന്ന് ഉറപ്പാക്കുക.
                        <br>4.  ഫോട്ടോ 5-20 kbps ല്‍ 100 X 148 px ലും മറ്റുള്ളവ 80-250 kbsp ല്‍ 570 X 795 px ലും .jpeg ഫോര്‍മാറ്റില്‍ സെറ്റ് ചെയ്യുക.
                        <br>5.  പൂരിപ്പിച്ച് സബ്മിറ്റ് ചെയ്ത അപേക്ഷകള്‍ ഹജ്ജ് ഹൗസിലേക്ക് അയക്കേണ്ടതില്ല. 12 ദിവസത്തിനുള്ളില്‍ കവര്‍ നമ്പര്‍ ലഭിക്കുന്നതാണ്. 
                        <br>6.  സെലക്ഷനായ ശേഷം മാത്രം 15-01-2020 നുമുമ്പായി അപേക്ഷ ഉള്‍പ്പെടേ മുഴുവന്‍ ഒറിജിനല്‍ രേഖകളും ഹജ്ജ് ഹൗസില്‍ എത്തിക്കേണ്ടതാണ്.
                        <br>7.  N.R.I കാര്‍ ശവ്വാല്‍ 10 നുമുമ്പ് പോസ്‌പോര്‍ട്ട് നല്‍കണം. സെലക്ഷനായ ഉടനെ പാസ്‌പോര്‍ട്ടിന്റെ കോപ്പിയും അപേക്ഷ അടക്കം മറ്റുരേഖകളും ഹജ്ജ് ഹൗസില്‍ എത്തിക്കണം.
                        <br>8.  പാസ്‌പോര്‍ട്ടിലെ ജനന തിയ്യതി 
                                30-05-1950 ക്ക് മുമ്പാണെന്ന് ഉറപ്പുവരുത്തുക.
                    </div>
                   
                    
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group"></div>
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 form-group">
                        <button class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 form-control" id="" onClick="proceedFunc() ">Proceed</button>
                        
                    </div>
                </div>
            </div>
                <div class = "col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row" id="proceed_div">
                </div>
    
    <?php    
    }
    
}

?>