-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 14, 2020 at 11:33 PM
-- Server version: 5.6.46-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `haj_db`
--
CREATE DATABASE IF NOT EXISTS `haj_db` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `haj_db`;

-- --------------------------------------------------------

--
-- Table structure for table `challan`
--

CREATE TABLE `challan` (
  `id` int(11) NOT NULL,
  `pass_no` varchar(50) NOT NULL,
  `name` varchar(60) NOT NULL,
  `adds` varchar(80) NOT NULL,
  `pil_2` varchar(50) NOT NULL,
  `pil_3` varchar(50) NOT NULL,
  `pil_4` varchar(50) NOT NULL,
  `pil_5` varchar(50) NOT NULL,
  `inf_1` varchar(50) NOT NULL,
  `inf_2` varchar(50) NOT NULL,
  `catagory` varchar(20) NOT NULL,
  `pilgrim` varchar(20) NOT NULL,
  `infant` varchar(20) NOT NULL,
  `mobile` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `challan`
--

INSERT INTO `challan` (`id`, `pass_no`, `name`, `adds`, `pil_2`, `pil_3`, `pil_4`, `pil_5`, `inf_1`, `inf_2`, `catagory`, `pilgrim`, `infant`, `mobile`) VALUES
(1, 'K6730817', 'MOIDEEN KUTTY', 'mulanhippulan house, Indianoor post, kottakal, pin-676503', '0', '0', '0', '0', '0', '0', 'G', '1', '0', '8301846714'),
(2, 'S6735620', 'ABDUNAZER OTTATHENGAN', 'OTTATHENGAN HOUSE, KUNNATHUVALAPPU, EDARIKODE PO, 676501, MALAPPURAM, KERALA', 'SHAHIDA PALACHIRAKKAL', '0', '0', '0', '0', '0', 'G', '2', '0', '9847127746'),
(3, 'k979856', 'safi', 'vadak, kavatah,kottakka post,676503', 'shafiya', '0', '0', '0', '0', '0', 'G', '2', '0', '8606434315'),
(4, 'M884813', 'Kadeeja', 'Mekkal house, dawn hill post,malappuram', '0', '0', '0', '0', '0', '0', 'G', '1', '0', '9747577714'),
(5, 'M7298743', 'SAIDALAVI', 'KUNNAKKADAN HOUSE, CHERUKUNNU, OTHUKKUNGAL POST, 676503', 'KADEEJA SAIDALAVI', '0', '0', '0', '0', '0', 'G', '2', '0', '7907634600'),
(6, 'S0124843', 'MARIYAMU', 'AYAPPALLI KILIYAMANNIL HOUSE, KAREKKAD POST, KADAMPUZHA ', 'SAFIYA', 'KHADEEJA', 'PATHUMMAKUTTY', '0', '0', '0', 'WM', '4', '0', '7558892453'),
(7, 'R4221676', 'KUNHI MOIDEEN', 'NATTUKALLINGAL HOUSE, SHUNOOR, CHENGOTTUR POST, 676503', 'KADEEJA', '0', '0', '0', '0', '0', 'G', '2', '0', '9847240432'),
(8, 'T7867196', 'YAKKOOB', 'Mulanhppulakkal house, Thalakappu, Chengottur Post, 676503', 'SAJIDHA', '0', '0', '0', '0', '0', 'G', '2', '0', '9388019041'),
(9, 'j6960585', 'PARAKKAL MOHAMMED', 'KOORIYAD, INDIANOOR POST, 676503', '0', '0', '0', '0', '0', '0', 'G', '1', '0', '9744373780'),
(10, 'K2511747', 'UMMER', 'KAMBRATH PULIKKODAN HOUSE, ATTEERI, PUTHUR POST', 'HASSAN KUTTY', '0', '0', '0', '0', '0', 'G', '2', '0', '9846155901'),
(11, 'P3242919', 'MOHAMMED', 'THAYYILTHODI HOUSE, KIZHAKKETHALA, PONMALA, 676528', '0', '0', '0', '0', '0', '0', 'G', '1', '0', '9847990162'),
(12, 'R4217556', 'MOIDEENKUTTY', 'PUTHENPEEDIYAKKAL HOUSE, KADAMPUZHA POST, PILATHARA', 'KADEEJA', 'ZUBAIDA', '0', '0', '0', '0', 'G', '3', '0', '9447632239'),
(13, 'M4573324', 'HASSAIN', 'KIZHAKKATHIL HOUSE, KOTTAKKAL VIA, KOORIYAD, INDIANOOR POST 676503', 'KHADEEJA', '0', '0', '0', '0', '0', 'G', '2', '0', '9544644442'),
(14, 'M0314499', 'SAIDALAVI', 'UMMERAKUNNAAN HOUSE, PANIKKARKUNDU, INDIANOOR POST, 676503', 'KADHEEJA', '0', '0', '0', '0', '0', 'G', '2', '0', '9744212658'),
(15, 'S7872145', 'RAYIN', 'ERANIYAN HOUSE, INDIANOOR POST, PANIKKERKUNDU, 676503', '0', '0', '0', '0', '0', '0', 'G', '1', '0', '9847999532'),
(16, 'S67406666', 'MOIDUTTY', 'PATHAYATHINGAL HOUSE, CHENGOTTUR POST, 676503', 'RAIHANATH', 'ASYA', '0', '0', '0', '0', 'G', '3', '0', '9946812599'),
(17, 'M6905387', 'SAIDALAVI', 'VELANGALIL HOUSE, PUTHUR POST, KOTTAKKAL, 676503', 'ZAINABA', '0', '0', '0', '0', '0', 'G', '2', '0', '9961196267'),
(18, 'K7510955', 'ABDU', 'NECHITHADATHIL HOUSE, CHAPPANANGADI POST, 676503', '0', '0', '0', '0', '0', '0', 'G', '1', '0', '9400706915'),
(19, 'S8939842', 'ALAVI MOHAMED', 'VADAKKETHIL HOUSE, PUTHUR POST, KOTTAKKAL', 'SAKEENAA', 'BIYYAKUTTY', '0', '0', '0', '0', 'G', '3', '0', '9847116760'),
(20, 'K8156004', 'MOHAMED KUTTY', 'KALODI HOUSE, THOKKAMPARA, KOTTAKKAL POST, 676503', 'AISHABI', '0', '0', '0', '0', '0', 'G', '2', '0', '9947482615'),
(21, 'U2222783', 'MARAKKAR KUTTY', 'KARUVAKKOTTIL HOUSE, KOTTOOR, INDIANOOR POST, 676503', '0', '0', '0', '0', '0', '0', 'G', '1', '0', '7558039852'),
(22, 'S0287649', 'SAINUDHEEN', 'THATHRAMPALLY HOUSE, EARKKARA, MARAKKARA POST, 676553', 'FATHIMA', '0', '0', '0', '0', '0', 'G', '2', '0', '9846666971'),
(23, 'J9725250', 'KUNHALASSAN', 'KUNIYIL HOUSE', 'KADEEJA', '0', '0', '0', '0', '0', 'G', '2', '0', '7736262632'),
(24, 'R5129113', 'KOMU', 'KURUVAKKOTTIL HOUSE, THOKKAMPARA, KOTTAKKAL POST, 676503', 'KADIYAMU', '0', '0', '0', '0', '0', 'G', '2', '0', '9048002785'),
(25, 'K0764869', 'MAAN PATH SYEDALVI', 'MAMPATTA HOUSE, ARICHOL, PUTHUR POST, 676503', 'SAIBUNNISA', '0', '0', '0', '0', '0', 'G', '2', '0', '9946618984'),
(26, 'K07464869', 'MAAN PATH SYED ALVI', 'MAMPATTA HOUSE, ARICHOL, PUTHUR POST, 676503', 'SAIBUNNISA', '0', '0', '0', '0', '0', 'G', '2', '0', '9946618984'),
(27, 'K0764869', 'MAAN PATH SYED ALVI', 'MAMPATTA HOUSE, ARICHOL, PUTHUR POST, 676503', 'SAIBUNNISA', '0', '0', '0', '0', '0', 'G', '2', '0', '9946618984');

-- --------------------------------------------------------

--
-- Table structure for table `table`
--

CREATE TABLE `table` (
  `id` int(11) NOT NULL,
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `table`
--

INSERT INTO `table` (`id`, `text`) VALUES
(1, '<?php $mpdf->SetFont(\'Arial\',\'B\',12);\r\n    $mpdf->Cell(160,5,\"\",0,0,\"C\");\r\n    $mpdf->Cell(30,10,\"\",1,0,\"C\");\r\n    $mpdf->Cell(.01,.01,\"\",0,1,\"C\");\r\n    $mpdf->Cell(160,2,\"\",0,0,\"C\");\r\n    \r\n    $mpdf->Cell(30,6,strtoupper($chbank), 0,1,\"C\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',10);\r\n    $mpdf->Cell(160,2,\"(PAY-IN-SLIP to deposit Rs.300/- per pilgrim and maximum of Rs.1500/- Only)\",0,0,\"C\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',12);\r\n    $mpdf->Cell(30,4,\"of India\", 0,1,\"C\");\r\n\r\n    // STARTING \r\n    \r\n    $mpdf->SetFont(\'Arial\',\'\',10);\r\n    $mpdf->Cell(190,1,\"\", 0,1,\"L\");\r\n    $mpdf->Cell(130,3.5,\"Branch:\", 1,0,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',12);\r\n    $mpdf->Cell(60,8,\"BANK COPY\", 1,0,\"C\");\r\n    $mpdf->Cell(.01,.01,\"\", 0,1,\"C\");\r\n    $mpdf->SetFont(\'Arial\',\'\',10);\r\n    $mpdf->Cell(65,3.5,\"\", 0,0,\"C\");\r\n    $mpdf->Cell(65,3.5,\"Code:\", 0,1,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',10);\r\n    $mpdf->Cell(65,4.5,\"HAJ COMMITTEE OF INDIA\", 1,0,\"C\");\r\n    $mpdf->Cell(65,4.5,$year, 1,1,\"C\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',9.5);\r\n    $mpdf->Cell(190,4,\"COLLECTION DETAILS\", 1,1,\"C\");\r\n    \r\n    \r\n    $mpdf->Cell(190,20,\"\", 1,0,\"C\");\r\n    $mpdf->Cell(.01,.01,\"\", 0,1,\"C\");\r\n    $mpdf->Cell(1,4,\'\', 0,0);\r\n    $mpdf->Cell(190,4,\'ACCOUNT NUMBER: \' . $chaccount, 0,1,\"l\");\r\n    $mpdf->Cell(2,4,\'\', 0,0);\r\n    $mpdf->Cell(90,4,\"PASSPORT NUMBER OF COVER HEAD\", 1,0,\"L\");\r\n    for($i=0;$i<=7;$i++)\r\n    {\r\n    $mpdf->Cell(5.08,4,$passport[$i], 1,0,\"C\");\r\n    }\r\n    $mpdf->Cell(.01,4,\"\", 0,1,\"C\");\r\n    \r\n    $mpdf->Cell(2,4,\'\', 0,0);\r\n    $mpdf->Cell(42,4,\"Name of Cover Head \", 1,0,\"L\");\r\n    for($i=0;$i<=$ihead;$i++)\r\n    {\r\n    $mpdf->Cell(5,4,strtoupper($head[$i]), 1,0,\"C\");\r\n    }\r\n    for($i=0;$i<=27-$ihead;$i++)\r\n    {\r\n    $mpdf->Cell(5,4,\"\", 1,0,\"C\");\r\n    }\r\n    $mpdf->Cell(.01,4,\"\", 0,1,\"C\");\r\n    $mpdf->Cell(2,4,\'\', 0,0);\r\n    $mpdf->Cell(72,4,\"Date of Deposit:\", 1,0,\"L\");\r\n    $mpdf->Cell(25,4,\"\", 0,0,\"L\");\r\n    $mpdf->Cell(30,4,\"Mobille Number\", 1,0,\"C\");\r\n    $mpdf->Cell(5,4,\"0\", 1,0,\"C\");\r\n    for($i=0;$i<=9;$i++)\r\n    {\r\n    $mpdf->Cell(5,4,$mobile[$i], 1,0,\"C\");\r\n    }\r\n    \r\n    $mpdf->SetFont(\'Arial\',\'\',9);\r\n    $mpdf->Cell(5,4,\"\", 1,1,\"C\");\r\n    $mpdf->Cell(72,4,\"PARTICULARS OF THE PAYMENT:\", 0,1,\"L\");\r\n    $mpdf->Cell(12,4,\"Sr. No.\", 1,0,\"L\");\r\n    $mpdf->Cell(63,4,\"NAME OF THE PILGRIM\", 1,0,\"C\");\r\n    $mpdf->Cell(63,4,\"ADDRESS OF THE PILGRIM\", 1,0,\"C\");\r\n    $mpdf->Cell(52,4,\"CASH NOTE AMOUNT IN Rs.\", 1,1,\"C\");\r\n    \r\n    $mpdf->SetFont(\'Arial\',\'B\',8);\r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$head, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add1, 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil2, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add2, 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil3, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add3, 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil4, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add4, 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil5, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$inf1, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$inf2, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    \r\n    $mpdf->Cell(138,5,\"\", 1,0,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',12);\r\n    $mpdf->Cell(52,5,\"  Total Rs. \" .$total. \"/-\", 1,0,\"L\");\r\n    $mpdf->Cell(1,1,\"\", 0,1,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'I\',8);\r\n    $mpdf->Cell(138,4,\"Amount (In words) Rupees  \" .$result. \"  Only\" , 0,1,\"L\");\r\n    $mpdf->Cell(58,4.5,\"Transaction ID (Bank journal No.)\", 1,0,\"L\");\r\n    for($i=0;$i<=9;$i++)\r\n    {\r\n    $mpdf->Cell(7,4.5,\"\", 1,0,\"C\");\r\n    }\r\n    $mpdf->Cell(62,4.5,\"\", 1,1,\"C\");\r\n    $mpdf->Cell(95,7.5,\"Branch Stamp with Signature\", 1,0,\"C\");\r\n    $mpdf->Cell(95,7.5,\"Deposited by\", 1,1,\"C\");\r\n    $mpdf->Cell(190,6,\"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \", 0,1,\"C\");\r\n    \r\n    // HCoI Copy\r\n    \r\n    \r\n    $mpdf->SetFont(\'Arial\',\'B\',12);\r\n    $mpdf->Cell(190,4.5,\"HAJ COMMITTEE OF INDIA\", 0,1,\"C\");\r\n    $mpdf->SetFont(\'Arial\',\'\',8);\r\n    $mpdf->Cell(190,4.5,\"Bait-ul-Hujjaj (Haj House), 7-A, M.R.A Marg (Palton Road), Mumbai-400 001.\", 0,1,\"C\");\r\n    $mpdf->SetFont(\'Arial\',\'\',10);\r\n    $mpdf->Cell(190,1,\"\", 0,1,\"L\");\r\n    $mpdf->Cell(130,3.5,\"Branch:\", 1,0,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',12);\r\n    $mpdf->Cell(60,8,\"HCoI COPY\", 1,0,\"C\");\r\n    $mpdf->Cell(.01,.01,\"\", 0,1,\"C\");\r\n    $mpdf->SetFont(\'Arial\',\'\',10);\r\n    $mpdf->Cell(65,3.5,\"\", 0,0,\"C\");\r\n    $mpdf->Cell(65,3.5,\"Code:\", 0,1,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',10);\r\n    $mpdf->Cell(65,4.5,\"HAJ COMMITTEE OF INDIA\", 1,0,\"C\");\r\n    $mpdf->Cell(65,4.5,$year, 1,1,\"C\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',9.5);\r\n    $mpdf->Cell(190,4,\"COLLECTION DETAILS\", 1,1,\"C\");\r\n    \r\n    \r\n    $mpdf->Cell(190,20,\"\", 1,0,\"C\");\r\n    $mpdf->Cell(.01,.01,\"\", 0,1,\"C\");\r\n    $mpdf->Cell(1,4,\'\', 0,0);\r\n    $mpdf->Cell(190,4,\'ACCOUNT NUMBER: \' . $chaccount, 0,1,\"l\");\r\n    $mpdf->Cell(2,4,\'\', 0,0);\r\n    $mpdf->Cell(90,4,\"PASSPORT NUMBER OF COVER HEAD\", 1,0,\"L\");\r\n    for($i=0;$i<=7;$i++)\r\n    {\r\n    $mpdf->Cell(5.08,4,$passport[$i], 1,0,\"C\");\r\n    }\r\n    $mpdf->Cell(.01,4,\"\", 0,1,\"C\");\r\n    \r\n    $mpdf->Cell(2,4,\'\', 0,0);\r\n    $mpdf->Cell(42,4,\"Name of Cover Head \", 1,0,\"L\");\r\n    for($i=0;$i<=$ihead;$i++)\r\n    {\r\n    $mpdf->Cell(5,4,strtoupper($head[$i]), 1,0,\"C\");\r\n    }\r\n    for($i=0;$i<=27-$ihead;$i++)\r\n    {\r\n    $mpdf->Cell(5,4,\"\", 1,0,\"C\");\r\n    }\r\n    $mpdf->Cell(.01,4,\"\", 0,1,\"C\");\r\n    $mpdf->Cell(2,4,\'\', 0,0);\r\n    $mpdf->Cell(72,4,\"Date of Deposit:\", 1,0,\"L\");\r\n    $mpdf->Cell(25,4,\"\", 0,0,\"L\");\r\n    $mpdf->Cell(30,4,\"Mobille Number\", 1,0,\"C\");\r\n    $mpdf->Cell(5,4,\"0\", 1,0,\"C\");\r\n    for($i=0;$i<=9;$i++)\r\n    {\r\n    $mpdf->Cell(5,4,$mobile[$i], 1,0,\"C\");\r\n    }\r\n    \r\n    $mpdf->SetFont(\'Arial\',\'\',9);\r\n    $mpdf->Cell(5,4,\"\", 1,1,\"C\");\r\n    $mpdf->Cell(72,4,\"PARTICULARS OF THE PAYMENT:\", 0,1,\"L\");\r\n    $mpdf->Cell(12,4,\"Sr. No.\", 1,0,\"L\");\r\n    $mpdf->Cell(63,4,\"NAME OF THE PILGRIM\", 1,0,\"C\");\r\n    $mpdf->Cell(63,4,\"ADDRESS OF THE PILGRIM\", 1,0,\"C\");\r\n    $mpdf->Cell(52,4,\"CASH NOTE AMOUNT IN Rs.\", 1,1,\"C\");\r\n    \r\n    $mpdf->SetFont(\'Arial\',\'B\',8);\r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$head, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add1, 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil2, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add2, 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil3, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add3, 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil4, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add4 , 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil5, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$inf1, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$inf2, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    \r\n    $mpdf->Cell(138,5,\"\", 1,0,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',12);\r\n    $mpdf->Cell(52,5,\"  Total Rs. \" .$total. \"/-\", 1,0,\"L\");\r\n    $mpdf->Cell(1,1,\"\", 0,1,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'i\',8);\r\n    $mpdf->Cell(138,4,\"Amount (In words) Rupees  \" .$result. \"  Only\" , 0,1,\"L\");\r\n    $mpdf->Cell(58,4.5,\"Transaction ID (Bank journal No.)\", 1,0,\"L\");\r\n    for($i=0;$i<=9;$i++)\r\n    {\r\n    $mpdf->Cell(7,4.5,\"\", 1,0,\"C\");\r\n    }\r\n    $mpdf->Cell(62,4.5,\"\", 1,1,\"C\");\r\n    $mpdf->Cell(95,7.5,\"Branch Stamp with Signature\", 1,0,\"C\");\r\n    $mpdf->Cell(95,7.5,\"Deposited by\", 1,1,\"C\");\r\n    $mpdf->Cell(190,6,\"- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - \", 0,1,\"C\");\r\n    \r\n    // Pilgrim Copy\r\n    \r\n    \r\n    $mpdf->SetFont(\'Arial\',\'\',10);\r\n    $mpdf->Cell(190,1,\"\", 0,1,\"L\");\r\n    $mpdf->Cell(130,3.5,\"Branch:\", 1,0,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',12);\r\n    $mpdf->Cell(60,8,\"PILGRIM COPY\", 1,0,\"C\");\r\n    $mpdf->Cell(.01,.01,\"\", 0,1,\"C\");\r\n    $mpdf->SetFont(\'Arial\',\'\',10);\r\n    $mpdf->Cell(65,3.5,\"\", 0,0,\"C\");\r\n    $mpdf->Cell(65,3.5,\"Code:\", 0,1,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',10);\r\n    $mpdf->Cell(65,4.5,\"HAJ COMMITTEE OF INDIA\", 1,0,\"C\");\r\n    $mpdf->Cell(65,4.5,$year, 1,1,\"C\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',9.5);\r\n    $mpdf->Cell(190,4,\"COLLECTION DETAILS\", 1,1,\"C\");\r\n    \r\n    \r\n    $mpdf->Cell(190,20,\"\", 1,0,\"C\");\r\n    $mpdf->Cell(.01,.01,\"\", 0,1,\"C\");\r\n    $mpdf->Cell(1,4,\'\', 0,0);\r\n    $mpdf->Cell(190,4,\'ACCOUNT NUMBER: \' . $chaccount, 0,1,\"l\");\r\n    $mpdf->Cell(2,4,\'\', 0,0);\r\n    $mpdf->Cell(90,4,\"PASSPORT NUMBER OF COVER HEAD\", 1,0,\"L\");\r\n    for($i=0;$i<=7;$i++)\r\n    {\r\n    $mpdf->Cell(5.08,4,$passport[$i], 1,0,\"C\");\r\n    }\r\n    $mpdf->Cell(.01,4,\"\", 0,1,\"C\");\r\n    \r\n    $mpdf->Cell(2,4,\'\', 0,0);\r\n    $mpdf->Cell(42,4,\"Name of Cover Head \", 1,0,\"L\");\r\n    for($i=0;$i<=$ihead;$i++)\r\n    {\r\n    $mpdf->Cell(5,4,strtoupper($head[$i]), 1,0,\"C\");\r\n    }\r\n    for($i=0;$i<=27-$ihead;$i++)\r\n    {\r\n    $mpdf->Cell(5,4,\"\", 1,0,\"C\");\r\n    }\r\n    $mpdf->Cell(.01,4,\"\", 0,1,\"C\");\r\n    $mpdf->Cell(2,4,\'\', 0,0);\r\n    $mpdf->Cell(72,4,\"Date of Deposit:\", 1,0,\"L\");\r\n    $mpdf->Cell(25,4,\"\", 0,0,\"L\");\r\n    $mpdf->Cell(30,4,\"Mobille Number\", 1,0,\"C\");\r\n    $mpdf->Cell(5,4,\"0\", 1,0,\"C\");\r\n    for($i=0;$i<=9;$i++)\r\n    {\r\n    $mpdf->Cell(5,4,$mobile[$i], 1,0,\"C\");\r\n    }\r\n    \r\n    $mpdf->SetFont(\'Arial\',\'\',9);\r\n    $mpdf->Cell(5,4,\"\", 1,1,\"C\");\r\n    $mpdf->Cell(72,4,\"PARTICULARS OF THE PAYMENT:\", 0,1,\"L\");\r\n    $mpdf->Cell(12,4,\"Sr. No.\", 1,0,\"L\");\r\n    $mpdf->Cell(63,4,\"NAME OF THE PILGRIM\", 1,0,\"C\");\r\n    $mpdf->Cell(63,4,\"ADDRESS OF THE PILGRIM\", 1,0,\"C\");\r\n    $mpdf->Cell(52,4,\"CASHE NOT AMOUNT IN Rs.\", 1,1,\"C\");\r\n    \r\n    $mpdf->SetFont(\'Arial\',\'B\',8);\r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$head, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add1, 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil2, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add2, 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil3, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add3, 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil4, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$add4, 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$pil5, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$inf1, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    $mpdf->Cell(12,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,$inf2, 1,0,\"L\");\r\n    $mpdf->Cell(63,3.75,\"\", 1,0,\"L\");\r\n    $mpdf->Cell(52,3.75,\"\", 1,1,\"L\");\r\n    \r\n    \r\n    $mpdf->Cell(138,5,\"\", 1,0,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'B\',12);\r\n    $mpdf->Cell(52,5,\"  Total Rs. \" .$total. \"/-\", 1,0,\"L\");\r\n    $mpdf->Cell(1,1,\"\", 0,1,\"L\");\r\n    $mpdf->SetFont(\'Arial\',\'i\',8);\r\n    $mpdf->Cell(138,4,\"Amount (In words) Rupees  \" .$result. \"  Only\" , 0,1,\"L\");\r\n    $mpdf->Cell(58,4.5,\"Transaction ID (Bank journal No.)\", 1,0,\"L\");\r\n    for($i=0;$i<=9;$i++)\r\n    {\r\n    $mpdf->Cell(7,4.5,\"\", 1,0,\"C\");\r\n    }\r\n    $mpdf->Cell(62,4.5,\"\", 1,1,\"C\");\r\n    $mpdf->Cell(95,7.5,\"Branch Stamp with Signature\", 1,0,\"C\");\r\n    $mpdf->Cell(95,7.5,\"Deposited by\", 1,1,\"C\");\r\n\r\n\r\n?>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `challan`
--
ALTER TABLE `challan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `table`
--
ALTER TABLE `table`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `challan`
--
ALTER TABLE `challan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `table`
--
ALTER TABLE `table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
