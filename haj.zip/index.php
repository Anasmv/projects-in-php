<?php
    include "con/con.php";
    if($con)
    {
        //echo "succ";
    }
    include "head.php";
?>
    <body>
        <div class="container"><br>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                
                <button class="round btn btn-danger">
                   
                            <a class="nav-link" href="http://haj.saypay.in">Home Page<span class="sr-only">(current)</span></a>
                        
                </button>
                            
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-xs-10 white b">
                    <center>For details contact : 8848888092</center>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
            </div>
        </div><br>
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"> </div>
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-xs-10 ">
                <form method="post" class="row col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12 row">
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 texting-in ">
    				    <fieldset>
    				        <input type='text' name='mob' class='form-control round' required />
    				        <label>Enter Mobile Number</label>
                        </fieldset>
                    </div>
                    
                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-xs-12 ">
                        <input type="submit" class="btn btn-success round col-xl-12 col-lg-12 col-md-12 col-sm-12 col-xs-12" value="Go" id="" name="mobile_go" />
                    </div>
                </form>
            </div>
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
        </div>
    </body>
</html>



<?php
if(isset($_POST['mobile_go']))
{
    $mobile = $_POST['mob'];
    if (strlen($mobile) >= 10)
    {
        echo "<script> 
        setck(); 
        function setck() 
        { document.cookie = 'mobck = $mobile'; }
        </script>";
        $sqlmob = "SELECT * FROM challan WHERE mobile = '$mobile'";
        $resmob = mysqli_query($con, $sqlmob);
        $rowmob = mysqli_fetch_array($resmob);
        $mobile_id =  $rowmob['id'];
        if($mobile_id)
        {
            echo "<script> window.location='http://haj.saypay.in/page.php?mob=$mobile_id'; </script>";
              
        }
        else
        {
            echo "<script> window.location='http://haj.saypay.in/page.php?mob=notinclude'; </script>";
            
        }
    }
    else
    {
        echo "<script> alert('Number must be 10 digit'); </script>";
    }
}
?>