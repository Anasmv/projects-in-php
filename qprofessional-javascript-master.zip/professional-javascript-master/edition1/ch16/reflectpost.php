<?php
    echo $name."\n";
    echo $book."\n";
?>