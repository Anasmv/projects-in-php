<?php include 'con.php'; 
include 'link.php';
session_start(); ?>


<form method='post'>
    <label>Name:</label>
    <input type="text" name="Name"  class='form-control round' /><br>
    
    <label>Email:</label>
    <input type="text" name="Email"  class='form-control round' /><br>
    
    <label>Phone:</label>
    <input type="text" name="Phone"  required class='form-control round' /> 
    
    
    <?php $sql_typ = "SELECT * FROM phone_type";
    $res_typ = mysqli_query($con, $sql_typ); ?>
    <select name="phone_type" onChange=" addnewfnc(this); " required>
        <option desable selected value="">select value</option>
    <?php
    while($row_type=mysqli_fetch_array($res_typ))
    { ?>
        <option value="<?php echo $row_type['id']; ?>"><?php echo $row_type['type']; ?></option>
    <?php
    }
    ?>
        <option value = "add_new_tp" >Add new</option>
    </select>
    <button type="button" onClick="addElement();">+</button> 
    <button type="button" onClick="removeElement();">-</button>
    <div id ="add_new_type"></div>
    <div id="next_phone" ></div>
    
    
    <label>Adds:</label>
    <input type="text" name="Adds"  class='form-control round' /><br>
    
    
    <input type="submit" name="Submit_contact_det" class='form-control round' /><br> 
</form>

<?php
if(isset($_POST['Submit_contact_det']))
{
    $Name=$_POST['Name'];
    $Email=$_POST['Email'];
    $Phone=$_POST['Phone'];
    $phone_type=$_POST['phone_type'];
    if($phone_type != 'add_new_tp')
    {
        echo '<br>';
        $ph_typ=$_POST['ph_typ'];
        $phone_no=$_POST['phone_no'];
        echo 'phone typ ';
        for ($i=0; $i<sizeof($ph_typ);$i++)
    	{
    	    $ph_no_typ[] = '{' . $ph_typ[$i] . ',' .$phone_no[$i] . '}';
    	}
    	 $fr_phn_typ =implode("", $ph_no_typ);
    	
    	echo $phone_phone_type = '{' . $phone_type . ',' . $Phone . '}' . $fr_phn_typ;
        echo '<br>';
        echo 'phone no ';
        // 	for ($i=0; $i<sizeof($phone_no);$i++)
        // 	{
        // 	    echo  $a=$check[$i];			
        // 	}
        $Adds=$_POST['Adds'];
        
        $sql_typ = "INSERT INTO `contacts`(`id`, `name`, `adds`, `email`, `phone`) VALUES (NULL, '$Name', '$Adds', '$Email', '$phone_phone_type')";
        $res_typ = mysqli_query($con, $sql_typ);
        
        $parent = $_SESSION['cid'];
        if(isset($parent))
        {
            $sql_lg = "INSERT INTO `login`(`id`, `name`, `email`, `phone`, `adds`, `parent`) VALUES (NULL, '$Name', '$Email', '$Phone', '$Adds', '$parent')";
        }
        else
        {
            $sql_lg = "INSERT INTO `login`(`id`, `name`, `email`, `phone`, `adds`, `parent`) VALUES (NULL, '$Name', '$Email', '$Phone', '$Adds', '0')";
        }
        $res_lg=mysqli_query($con, $sql_lg);
        if($res_lg && $res_typ)
        {
            echo " <script> alert('success'); </script> ";
        }
    }
    else
    {
        echo "<script> alert('Select a type') </script>";
    }
}
?>
<br><br><br>
<script>
    var intTextBox = 1;
    function addElement() {
        intTextBox++;
        var objNewDiv = document.createElement('div');
        objNewDiv.setAttribute('id', 'div_' + intTextBox);
        objNewDiv.innerHTML = 'Phone ' + intTextBox + ': <input type="text" required  id="phone_no' + intTextBox + '" name="phone_no[]' + intTextBox + '"/>' +
        '<select required name="ph_typ[]' + intTextBox + '" id="ph_typ' + intTextBox + '"  onChange="addnewfnc(this);" > <option desable selected value="">select value</option>' +
        <?php $sql_typ = "SELECT * FROM phone_type";
        $res_typ = mysqli_query($con, $sql_typ); ?>
        <?php
        while($row_type=mysqli_fetch_array($res_typ))
        { ?>
            '<option value = "<?php echo $row_type['0']; ?>"><?php echo $row_type[1]; ?></option>'+
        <?php
        }
        ?>
        '<option value = "add_new_tp">Add new</option>' +
        '</select>';
        document.getElementById('next_phone').appendChild(objNewDiv);
    }
    
    function removeElement() {
        if(0 < intTextBox) {
            document.getElementById('next_phone').removeChild(document.getElementById('div_' + intTextBox));
            intTextBox--;
        } else {
            alert("No textbox to remove");
        }
    }
</script>



<script>
    function addnewfnc(sel)
    {
        var phn_typ = sel.options[sel.selectedIndex].value;
        if(phn_typ == "add_new_tp")
        {
            //alert('add_new_tp');
            var objNewDiv = document.createElement('div');
            //objNewDiv.setAttribute('id', 'div_');
            objNewDiv.innerHTML = '<input type="text" placeholder="Enter New Type"  id="addnew_typ" name="add_new_typ"/>' +
            '<input type="button" onClick = "addnewbtnfnc();" name="addnewtypbtn" value="add" id="addnewtypbtn"/>';
            document.getElementById('add_new_type').appendChild(objNewDiv);
        }
    }
    
    function addnewbtnfnc()
    {
        var x = document.getElementById("add_new_type");
        var add_nw_tp = document.getElementById('addnew_typ').value;
        if(add_nw_tp != '')
        {
            $.ajax({
                url: "ajx.php",
                type: "POST",
                data: { 'add_new_type' : add_nw_tp },
                beforeSend: function() {
                    $('#add_new_type').html('');
                },
                success: function(html) {
                    if (x.style.display === "none") {
                    x.style.display = "block";
                    } 
                }
            }); 
        }
    }
</script>