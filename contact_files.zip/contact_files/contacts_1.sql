-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 09, 2020 at 11:23 PM
-- Server version: 5.6.46-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `contacts_1`
--
CREATE DATABASE IF NOT EXISTS `contacts_1` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `contacts_1`;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `adds` varchar(68) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `adds`, `email`, `phone`) VALUES
(6, 'c', 'c', 'c', '{1,7687689789}'),
(5, 'b', 'trete', 'b', '{2,565656}{4,555555}'),
(4, 'a', 'a@a.a', 'a', '{4,1234567890}'),
(7, 'new', 'new', 'new', '{1,789956322}{2,2222}{3,3333}{4,4444444}{5,5555555}{5,1111122224554}{2,545879794514}'),
(11, 'w', 'rtert', 'w', '{add_new_tp,4324324324234}'),
(12, '56', 'rtert', '56', '{add_new_tp,675675}');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `adds` varchar(68) NOT NULL,
  `parent` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `phone`, `adds`, `parent`) VALUES
(1, 'a', 'a', '1234567890', 'a@a.a', '0'),
(2, 'b', 'b', '565656', 'trete', '1'),
(3, 'c', 'c', '7687689789', 'c', '1'),
(4, 'new', 'new', '789956322', 'new', '1'),
(10, '56', '56', '675675', 'rtert', '1'),
(9, 'w', 'w', '4324324324234', 'rtert', '1');

-- --------------------------------------------------------

--
-- Table structure for table `phone_type`
--

CREATE TABLE `phone_type` (
  `id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `phone_type`
--

INSERT INTO `phone_type` (`id`, `type`) VALUES
(1, 'whatsapp'),
(2, 'home'),
(3, 'personal'),
(4, 'private'),
(5, 'business'),
(30, '45');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `phone_type`
--
ALTER TABLE `phone_type`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `phone_type`
--
ALTER TABLE `phone_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
