<br>
<?php
session_start();
include 'con.php';

//more... in log_index.php
if(isset($_POST['more_det']))
{
    $mor_id = $_POST['more_det'];
    $sql_lg="SELECT * FROM login WHERE id = '$mor_id'";
    $res=mysqli_query($con, $sql_lg);
    $row=mysqli_fetch_array($res);
    $lg_name=$row['name'];
    $lg_email=$row['email'];
    $lg_adds=$row['adds'];
        
    $sql_c="SELECT * FROM contacts WHERE name = '$lg_name' AND adds = '$lg_adds' AND email = '$lg_email'";
    $res_c=mysqli_query($con, $sql_c); ?>
        <table>
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Phone</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
            
            <?php
        $row_c=mysqli_fetch_array($res_c);
         ?>
                <tr>
                    <td><?php echo $row_c['name'];?></td>
                    <td><?php echo $row_c['adds'];?></td>
                                            <td>
                            <?php $phone = $row_c['phone'];
                             //print_r(explode("{",$phone));
                             
                             $array  = explode("{", $phone);

                                //print_r($array);
                                
                                $no = 1;
                                foreach ($array as $line) {
                                    $line.'<br>';
                                    $no1 = 1;
                                    $array1  = explode(",", $line);
                                    foreach ($array1 as $line1) {
                                        //$line1.'---';
                                        $sqltp = "SELECT * FROM phone_type WHERE id = '$line1'";
                                        $restp = mysqli_query($con, $sqltp);
                                        $rowtp = mysqli_fetch_array($restp);
                                        $phtyp_id=$rowtp[0];
                                        $phtyp_nm = $rowtp[1];
                                        if($phtyp_id==$line1)
                                        {
                                            if($phtyp_id != '')
                                            {
                                                //for the type of phone
                                                echo $phtyp_nm.' - ';
                                            }
                                        }
                                        else
                                        {
                                            // for the number of phone
                                            //echo $line1;
                                            echo substr($line1, 0, -1).'<br>';
                                        }
                                    $no1++;
                                    }
                                    $no++;
                                }
                            ?>
                        </td>
                    <td><?php echo $row_c['email'];?></td>
                    <td><a href="edit.php?id=<?php echo $row_c['id']; ?>">Edit</a></td>
                    <td><a href="edit.php?delid=<?php echo $row_c['id']; ?>">Delete</a></td>
                    <td><button onclick="more_chld_det();">Child Dtails...</button></td>
                </tr>
            </table>
            <div id="more_child_det"></div>
            <script>
                function more_chld_det() {
                    $.ajax({
                        url: "ajx.php",
                        type: "POST",
                        data: { 'more_chld_det' : <?php echo $mor_id; ?> },
                        beforeSend: function() {
                            $('#more_child_det').html('<img src="loader.gif" alt="" width="24" height="24">');
                        },
                        success: function(html) {
                            $("#more_child_det").html(html);
                        }
                    });
                }
            </script>
            
        <?php
}




if(isset($_POST['more_chld_det']))
{
    $parent=$_POST['more_chld_det'];
    //$parent = $_SESSION['cid'];
        $sql_lg="SELECT * FROM login WHERE parent = '$parent'";
        $res=mysqli_query($con, $sql_lg); ?>
                <table>
                    <tr>
                        <th>Name</th>
                        <th>Address</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Action</th>
                    </tr>
        <?php
        while($row=mysqli_fetch_array($res))
        {
            $lg_name=$row['name'];
            $lg_email=$row['email'];
            $lg_adds=$row['adds'];
            $sql_c="SELECT * FROM contacts WHERE name = '$lg_name' AND adds = '$lg_adds' AND email = '$lg_email'";
            $res_c=mysqli_query($con, $sql_c);
            while($row_c=mysqli_fetch_array($res_c))
            { ?>
                    <tr>
                        <td><?php echo $row_c['name'];?></td>
                        <td><?php echo $row_c['adds'];?></td>
                        <td>
                            <?php $phone = $row_c['phone'];
                             //print_r(explode("{",$phone));
                             
                             $array  = explode("{", $phone);

                                //print_r($array);
                                
                                $no = 1;
                                foreach ($array as $line) {
                                    $line.'<br>';
                                    $no1 = 1;
                                    $array1  = explode(",", $line);
                                    foreach ($array1 as $line1) {
                                        
                                        $sqltp = "SELECT * FROM phone_type WHERE id = '$line1'";
                                        $restp = mysqli_query($con, $sqltp);
                                        $rowtp = mysqli_fetch_array($restp);
                                        $phtyp_id=$rowtp[0];
                                        $phtyp_nm = $rowtp[1];
                                        if($phtyp_id==$line1)
                                        {
                                            if($phtyp_id != '')
                                            {
                                                //for the type of phone
                                                echo $phtyp_nm.' - ';
                                            }
                                        }
                                        else
                                        {
                                            // for the number of phone
                                            //echo $line1;
                                            echo substr($line1, 0, -1).'<br>';
                                        }
                                        
                                    $no1++;
                                    }
                                    $no++;
                                }
                            ?>
                        </td>
                        <td><?php echo $row_c['email'];?></td>
                        <td><a href="edit.php?id=<?php echo $row_c['id']; ?>">Edit</a></td>
                        <td><a href="edit.php?delid=<?php echo $row_c['id']; ?>">Delete</a></td>
                    </tr>  
            <?php
            }
        }
        ?>
        </table>
    <?php
}


if(isset($_POST['add_new_type']))
{
    $new_phontyp=$_POST['add_new_type'];
    $sql_n_typ = "INSERT INTO `phone_type`(`id`, `type`) VALUES (NULL, '$new_phontyp')";
    mysqli_query($con, $sql_n_typ);
}
?>