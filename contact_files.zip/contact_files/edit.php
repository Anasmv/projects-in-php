<?php
include 'con.php';
include 'link.php';
if(isset($_GET['id']))
{
    $id=$_GET['id'];
    
    $sql_c_id="SELECT * FROM contacts WHERE id = '$id'";
    $res_c_id=mysqli_query($con, $sql_c_id);
    $row_c_id=mysqli_fetch_array($res_c_id);
    $em = $row_c_id['email'];
    $nm =$row_c_id['name'];
    $ads = $row_c_id['adds'];
    
    $sql_lg_id = "SELECT * FROM login WHERE name= '$nm' AND adds='$ads' AND email='$em' ";
    $res_lg_id = mysqli_query($con, $sql_lg_id);
    $row_lg_id=mysqli_fetch_array($res_lg_id);
    $login_id =$row_lg_id['id'];
    
    
        ?>
        <form method="post">
        <?php
                $sql_c="SELECT * FROM contacts WHERE id = '$id'";
                $res_c=mysqli_query($con, $sql_c);
                while($row_c=mysqli_fetch_array($res_c))
                { ?>
                        <label>Name :</label><input type="text" name="name" value="<?php echo $row_c['name'];?>" ><br>
                        <label>Address :</label><input type="text" name="adds" value="<?php echo $row_c['adds'];?>" ><br>
                        <label>Phone :</label>
                        <?php $phone = $row_c['phone'];
                                 $array  = explode("{", $phone);
                                    $no = 0;
                                    foreach ($array as $line)
                                    {
                                        if($no != '0')
                                        {
                                            echo 'Phone'.$no;
                                        }
                                        $no1 = 1;
                                        $array1  = explode(",", $line);
                                        foreach ($array1 as $line1)
                                        {
                                            $sqltp = "SELECT * FROM phone_type WHERE id = '$line1'";
                                            $restp = mysqli_query($con, $sqltp);
                                            $rowtp = mysqli_fetch_array($restp);
                                            $phtyp_id=$rowtp['id'];
                                            $phtyp_nm = $rowtp['type'];
                                            if($phtyp_id==$line1)
                                            {
                                                if($phtyp_id != '')
                                                {
                                                    //for the type of phone ?>
                                                    <select name="phone_type[]<?php echo $no1; ?>">
                                                        <option selected value = '<?php echo $phtyp_nm; ?>'><?php echo $phtyp_nm; ?></option>
                                                        
                                                        <?php $sql_type="SELECT * FROM phone_type";
                                                            $res_type=mysqli_query($con, $sql_type);
                                                            while($row_type=mysqli_fetch_array($res_type))
                                                            {
                                                                echo '<option>'.$row_type['type'].'</option>';
                                                            } ?>
                                                       
                                                    </select>
                                                    <?php
                                                    //echo $phtyp_nm;
                                                }
                                            }
                                            else
                                            {
                                                // for the number of phone
                                                //echo $line1; ?>
                                                <input type = 'text' name = "phoneno[]<?php echo $no1; ?>" value='<?php echo substr($line1, 0, -1); ?>' />
                                                <?php
                                            }
                                            
                                        $no1++;
                                        
                                        }
                                        $no++;
                                        if($line!='')
                                        {
                                            echo '<br>';
                                        }
                                    }
                                ?>
                        <button type="button" onClick="addElement();">+</button> 
                        <button type="button" onClick="removeElement();">-</button>
                        <button type="button" onClick="addType();">+ type</button>
                        <div id="add_new_type"></div>
                        <br>
                        <div id="next_phone" ></div>
                        <input type="submit" name="edit_sub">
                        <label>Email :</label><input type="text" name="email" value="<?php echo $row_c['email'];?>">      
                <?php
                }
            ?>
        </form>   
        
        
        <?php
        if(isset($_POST['edit_sub']))
        {
            $name = $_POST['name'];
            $adds = $_POST['adds'];
            $email = $_POST['email'];
            
            $phone_type = $_POST['phone_type'];
            $phoneno = $_POST['phoneno'];
            for ($i=0; $i<sizeof($phoneno);$i++)
        	{
        	    //$ph_no_typ[] = '{' . $ph_typ[$i] . ',' .$phone_no[$i] . '}';
        	    $sql_tp ="SELECT id FROM phone_type WHERE type ='$phone_type[$i]'";
        	    $res_tp = mysqli_query($con, $sql_tp);
        	    $row_tp = mysqli_fetch_array($res_tp);
        	    $type = $row_tp['id'];
        	    $ph_no_typ[] = '{' . $type . ',' .$phoneno[$i] . '}'; 
        	}
        	$fr_phn_old =implode("", $ph_no_typ);
        	
        	if(isset($_POST['ph_typ']) && isset($_POST['phone_no']))
        	{
            	$phone_type_new = $_POST['ph_typ'];
                $phoneno_new = $_POST['phone_no'];
                echo '<br>';
                for ($i=0; $i<sizeof($phoneno_new);$i++)
            	{
            	    $ph_no_typ_nw[] = '{' . $phone_type_new[$i] . ',' .$phoneno_new[$i] . '}';
            	}
            	$fr_phn_nw =implode("", $ph_no_typ_nw);
            	$fr_phn_typ =  $fr_phn_old.$fr_phn_nw;
             	echo $fr_phn_typ;
            	$content= $fr_phn_typ;
        	}
        	else
        	{
        	    $fr_phn_typ =  $fr_phn_old;
                 echo $fr_phn_typ;
        	    $content = $fr_phn_typ;
        	}
            preg_match('#\{(.*?)\}#', $content, $match);
            $cnt_comma = $match[1];
            $arr = explode(",", $cnt_comma);
            $phone_lg = $arr[1];
            
            
        	
        	
        	$sql_edt = "UPDATE `contacts` SET `name` = '$name', `adds` = '$adds', `phone` = '$fr_phn_typ', `email` ='$email' WHERE `contacts`.`id` = '$id'";
            // id// name// email// phone// adds// parent
        	$sql_lg = "UPDATE `login` SET `name` = '$name', `adds` = '$adds', `email` ='$email', phone = '$phone_lg' WHERE `login`.`id` = '$login_id'";
        	if( (mysqli_query($con, $sql_lg)) && (mysqli_query($con, $sql_edt)) ) {
                echo "<script> alert('upadeted'); </script>";  
        	}
        	else {
        	    echo 'not';
        	}
        	
        }
        ?>
        
    <script>
        var intTextBox = 1;
        function addElement() {
            intTextBox++;
            var objNewDiv = document.createElement('div');
            objNewDiv.setAttribute('id', 'div_' + intTextBox);
            objNewDiv.innerHTML = 'Phone ' + intTextBox + ': <input type="text" required  id="phone_no' + intTextBox + '" name="phone_no[]' + intTextBox + '"/>' +
            '<select required name="ph_typ[]' + intTextBox + '" id="ph_typ' + intTextBox + '" > <option desable selected value="">select value</option>' +
            <?php $sql_typ = "SELECT * FROM phone_type";
            $res_typ = mysqli_query($con, $sql_typ); ?>
            <?php
            while($row_type=mysqli_fetch_array($res_typ))
            { ?>
                '<option value = "<?php echo $row_type['0']; ?>"><?php echo $row_type[1]; ?></option>' +
            <?php
            }
            ?>
            '<option value = "add_new_tp">Add new</option>' +
            '</select>';
            document.getElementById('next_phone').appendChild(objNewDiv);
        }
        
        function removeElement() {
            if(0 < intTextBox) {
                document.getElementById('next_phone').removeChild(document.getElementById('div_' + intTextBox));
                intTextBox--;
                //document.write(intTextBox);
            } else {
                alert("No textbox to remove");
            }
        }
    </script>
    
    <script>
        function addnewfnc(sel)
        {
            var phn_typ = sel.options[sel.selectedIndex].value;
            if(phn_typ == "add_new_tp")
            {
                //alert('add_new_tp');
                var objNewDiv = document.createElement('div');
                //objNewDiv.setAttribute('id', 'div_');
                objNewDiv.innerHTML = '<input type="text" placeholder="Enter New Type"  id="addnew_typ" name="add_new_typ"/>' +
                '<input type="button" onClick = "addnewbtnfnc();" name="addnewtypbtn" value="add" id="addnewtypbtn"/>';
                document.getElementById('add_new_type').appendChild(objNewDiv);
            }
        }
        
        function addnewbtnfnc()
        {
            var x = document.getElementById("add_new_type");
            var add_nw_tp = document.getElementById('addnew_typ').value;
            if(add_nw_tp != '')
            {
                $.ajax({
                    url: "ajx.php",
                    type: "POST",
                    data: { 'add_new_type' : add_nw_tp },
                    beforeSend: function() {
                        $('#add_new_type').html('');
                    },
                    success: function(html) {
                        if (x.style.display === "none") {
                        x.style.display = "block";
                        } 
                    }
                }); 
            }
        }
    </script>
    
    <script>
        function addType()
        {
            var objNewDiv = document.createElement('div');
            //objNewDiv.setAttribute('id', 'div_');
            objNewDiv.innerHTML = '<input type="text" placeholder="Enter New Type"  id="addnew_typ" name="add_new_typ"/>' +
            '<input type="button" onClick = "addnewbtnfnc();" name="addnewtypbtn" value="add" id="addnewtypbtn"/>';
            document.getElementById('add_new_type').appendChild(objNewDiv);
        }
    </script>
    
    <?php
}



if(isset($_GET['delid']))
{
    $del_id=$_GET['delid'];
    $sql_c_id="SELECT * FROM contacts WHERE id = '$del_id'";
    $res_c_id=mysqli_query($con, $sql_c_id);
    $row_c_id=mysqli_fetch_array($res_c_id);
    $em = $row_c_id['email'];
    $nm =$row_c_id['name'];
    $ads = $row_c_id['adds'];
    
    $sql_lg_id = "SELECT * FROM login WHERE name= '$nm' AND adds='$ads' AND email='$em' ";
    $res_lg_id = mysqli_query($con, $sql_lg_id);
    $row_lg_id=mysqli_fetch_array($res_lg_id);
    $login_id =$row_lg_id['id'];
    
    $sql_del_c="DELETE FROM contacts WHERE id = '$del_id'";
    $sql_del_lg="DELETE FROM login WHERE id = '$login_id'";
    
    if( (mysqli_query($con, $sql_del_c)) && (mysqli_query($con, $sql_del_lg)) )
    {
        echo "<script> alert('deleted'); </script>";
    }
}



?>
