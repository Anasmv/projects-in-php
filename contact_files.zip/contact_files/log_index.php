<?php session_start(); 
include 'link.php'; include 'con.php';
echo $parent = $_SESSION['cid']; ?>

<a href='contacts.php'>Add new Contact</a><br><br>



<br><br>
    <?php
        $sql_lg="SELECT * FROM login WHERE id = '$parent'";
        $res=mysqli_query($con, $sql_lg);
        while($row=mysqli_fetch_array($res))
        { ?>
        <table>
            <tr>
                <th>Name</th>
            </tr> 
            <?php
            $lg_name=$row['name'];
            $lg_email=$row['email'];
            $lg_adds=$row['adds'];
            $sql_c="SELECT * FROM contacts WHERE name = '$lg_name' AND adds = '$lg_adds' AND email = '$lg_email'";
            $res_c=mysqli_query($con, $sql_c);
            while($row_c=mysqli_fetch_array($res_c))
            { ?>
                    <tr>
                        <td><?php echo $row_c['name'];?></td>
                        <td><button onclick="more_det();">more...</button></td>
                    </tr>  
            <?php
            }
        }
        ?>
        </table>    




<br>
<div id='details_sel'> </div>


<br><br>
<a href='logout.php'>logout</a>
<script>
    function view_contact(sel)
    {
        var sel_contact = sel.options[sel.selectedIndex].value;
        $.ajax({
            url: "ajx.php",
            type: "POST",
            data: { 'contact_selected' : sel_contact },
            beforeSend: function() {
                $('#details_sel').html('<img src="loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                $("#details_sel").html(html);
            }
        });
    }
    
    function more_det()
    {
        $.ajax({
            url: "ajx.php",
            type: "POST",
            data: { 'more_det' : <?php echo $parent; ?> },
            beforeSend: function() {
                $('#details_sel').html('<img src="loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                $("#details_sel").html(html);
            }
        });
    }
</script>