<?php

$arr = '[
   {
      "id":1,
      "name":"Charlie"
   },
   {
      "id":2,
      "name":"Brown"
   },
   {
      "id":3,
      "name":"Subitem",
      "children":[
         {
            "id":4,
            "name":"Alfa"
         },
         {
            "id":5,
            "name":"Bravo"
         }
      ]
   },
   {
      "id":8,
      "name":"James"
   }
]';
$arr = json_decode($arr, TRUE);
$arr[] = ['id' => '9999', 'name' => 'Name'];
$json = json_encode($arr);

echo '<pre>';
print_r($json);
echo '</pre>';



$jsonString = '[
		   {
			  "activity_code":"1",
			  "activity_name":"FOOTBALL"
		   },
		   {
			  "activity_code":"2",
			  "activity_name":"CRICKET"
		   }
		]';
		
$data = json_decode($jsonString, true);


$data[0]['activity_name'] = "TENNIS";
// or if you want to change all entries with activity_code "1"
foreach ($data as $key => $entry) {
    if ($entry['activity_code'] == '1') {
        $data[$key]['activity_name'] = "GHJJJJ";
    }
}


echo $newJsonString = json_encode($data);