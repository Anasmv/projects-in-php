<?php session_start(); 
include 'con.php'; 
include 'link.php';?>

<form method='post'>
    <label>Name:</label>
    <input type="text" name="Name" class='form-control round' required="reqired"/><br>
    
    <label>Email/Phone:</label>
    <input type="text" name="Emailorphone" class='form-control round' required="reqired"/><br>
    
    <input type="submit" name="Submit_log" class='form-control round' required="reqired"/><br>
</form>




<form method='post'>
    <label>Name:</label>
    <input type="text" name="Name" class='form-control round' required="reqired"/><br>
    
    <label>Email:</label>
    <input type="text" name="Email" class='form-control round' required="reqired"/><br>
    
    <label>Phone:</label>
    <input type="text" name="Phone" class='form-control round' required="reqired"/><br>
    
    <label>Adds:</label>
    <input type="text" name="Adds" class='form-control round' required="reqired"/><br>
    
    <input type="submit" name="Submit_lg_add" class='form-control round' required="reqired"/><br> 
</form>
<?php
if(isset($_POST['Submit_lg_add']))
{
    $Name = $_POST['Name'];
    $Email = $_POST['Email'];
    $Phone = $_POST['Phone'];
    $Adds = $_POST['Adds'];
    
    //login : 	id	name	email	phone	adds	parent
    $sql_lg = "INSERT INTO `login`(`id`, `name`, `email`, `phone`, `adds`, `parent`) VALUES (NULL, '$Name', '$Email', '$Phone', '$Adds', '0')";
    $res_lg=mysqli_query($con, $sql_lg);
    if($res_lg)
    {
        echo "<script> alert('success'); </script>";
    } 
}

if(isset($_POST['Submit_log']))
{
    $Name = $_POST['Name'];
    $Emailorphone = $_POST['Emailorphone'];
    $sql_lgin="SELECT * FROM login WHERE name = '$Name' AND email = '$Emailorphone' OR phone = '$Emailorphone' ";
    $res_lgin=mysqli_query($con, $sql_lgin);
    $row_lgin=mysqli_fetch_array($res_lgin);
    $_SESSION['cid'] = $row_lgin['id']; 
    if(isset($_SESSION['cid']))
    {
        echo "<script> alert('success'); 
        window.location = 'log_index.php';
        </script> " ;
    }
    else
    {
        echo "<script> alert('Incurrect Name or Phone');
        </script> " ;
    }
}
?>


