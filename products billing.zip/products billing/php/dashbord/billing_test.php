<?php
session_start();
include('../connect/con.php');
$nxt_bill = "{p2,410}{p1,510}";
$nxt_bill1=ltrim(substr_replace($nxt_bill,"",-1),"{");


$delimiter = array(" ","/","}{","{","}",);
$replace = str_replace($delimiter, $delimiter[0], $nxt_bill1);

$explode = explode($delimiter[0], $replace);


$odd = array_filter($input, "oddCmp");
echo "print r <br>";
$t=print_r($explode);






//$array0  = explode("-", $nxt_bill);
echo "<table>";
echo "<tr><th>1</th><th>2</th></tr>";
foreach ($explode as $line) {
    echo "<tr>";
    //echo $line.'<br>';
    $array1  = explode(",", $line);
    foreach ($array1 as $line1) {
        if($line1 != '')
        {
            $sq_prdt1 = "SELECT * FROM products WHERE name = '$line1'";
            $re_prdt1 = mysqli_query($clogin, $sq_prdt1);
            $ro_prdt1 = mysqli_fetch_array($re_prdt1);
            $phtyp_id=$ro_prdt1['name'];
         
            echo '<td>';
            if($line1 != $phtyp_id)
            {
                echo $line1;
                
            }
            else
            {
                echo $phtyp_id;
              
            }
            echo '</td>';
             
        }
         
    }
    echo "</tr>";
}
echo "</table>";

echo '<br>';

        $sq_prdt1 = "SELECT * FROM billing WHERE id = '101'";
                    $re_prdt1 = mysqli_query($clogin, $sq_prdt1);
                    $ro_prdt1 = mysqli_fetch_array($re_prdt1);
                    echo "<pre>";
                    print_r($ro_prdt1);
                    echo "</pre>";
        
        
        
        echo '<br>'; echo '<br>'; echo '<br>'; echo '<br>'; echo '<br>'; echo '<br>'; echo '<br>';
        
       
    
    ?>
    <table>
        <tr>
            <th>Sl no</th>
            <th>Commodity</th>
            <th>Code</th>
            <th>Sales Rate</th>
            <th>QUANTITY</th>
            <th>Total</th>
            <th>GST</th>
            <th>GST Rate</th>
            <th>Sub Total</th>
        </tr>
        <?php
        echo '$insert_id'.$insert_id = $_SESSION['ins_id']='101';
        $sq_b2="SELECT * FROM billing WHERE id = '$insert_id'"; 
        $re_b2=mysqli_query($clogin, $sq_b2);
        $rw_b2=mysqli_fetch_array($re_b2);
        $nxt_bill = $rw_b2['bill'];
        $nxt_bill1=ltrim(substr_replace($nxt_bill,"",-1),"{");
        $delimiter = array(" ","/","}{","{","}",);
        $replace = str_replace($delimiter, $delimiter[0], $nxt_bill1);
        $explode = explode($delimiter[0], $replace);
        //$odd = array_filter($input, "oddCmp");
        
        //for testing
        //echo $explode = "{8,15}";
        print_r($explode);
        $no=1;
        $sum_qty = 0;
            $sum_ttl = 0;
            $sum_gst = 0;
            $sum_subttl = 0;
        foreach ($explode as $line) {
            echo "<tr>";
            //echo $line.'<br>';
            $array1  = explode(",", $line);
            
            foreach ($array1 as $line1) {
                //echo $line1;
                if($line1 != '')
                {
                    $sq_prdt1 = "SELECT * FROM products WHERE id = '$line1'";
                    $re_prdt1 = mysqli_query($clogin, $sq_prdt1);
                    $ro_prdt1 = mysqli_fetch_array($re_prdt1);
                    
                    $prt_nm = $ro_prdt1['name'];
                    
                    $prt_id = $ro_prdt1['id'];
                    
                    if($line1 == $prt_id)
                    {
                        if($prt_id != '')
                        {
                            echo "<td>$no</td>";
                            $pdt_2nm=$prt_nm;
                            echo '<td>'.$prt_nm .'</td>';
                            $p_code=$ro_prdt1['code'];
                            echo "<td>".$ro_prdt1['code']."</td>";
                            $s_rate = $ro_prdt1['sales_rate'];
                            echo "<td>".$s_rate."</td>";
                            $sqst = $ro_prdt1['sgst'];
                            $igst = $ro_prdt1['igst'];
                            $cgst = $ro_prdt1['cgst'];
                            
                        }
                    }
                    else
                    {
                        
                        $qnty1 = $line1;
                        
                        $sum_qty +=  $qnty1;
                        echo '<td>'.$qnty1.'</td>';
                        $ttl = ($s_rate * $qnty1);
                        $sum_ttl += $ttl;
                        echo "<td>$ttl</td>";
                        
                        if($sqst == '' && $cgst == '')
                        {
                            $ggst = $igst;
                            echo "<td>$ggst</td>";
                        }
                        else
                        {
                            $ggst = $sqst;
                            echo "<td>$ggst</td>";
                        }
                        
                        $y = ($ttl * (($ggst)/100));
                        echo "<td>$y</td>";
                        
                        $sum_gst += $y;
                        
                        $subttl = ($ttl + $y);
                        $sum_subttl += $subttl;
                        echo "<td>$subttl</td>";
                       
                       
                    }
                }
            }
            echo "</tr>";
            $no++;
            
        }
?>

   
        
        
        <tr>
            <td>total</td>
            <td></td>
            <td id=""></td>
            <td id=''></td>
            <td><?php
                echo $sum_qty;
            ?></td>
            <td id=''><?php echo $sum_ttl; ?></td>
            <td id=''></td>
            <td id=''><?php echo $sum_gst; ?></td>
            <td id=''><?php echo $sum_subttl; ?></td>
        </tr>
        
        
    </table>
    

        
        
        
        
        <style> 
            
            #left { 
                float: left; 
                width: 30%; 
                 
               /*border: 1px solid black; */
            } 
    		#middle { 
                float: left; 
                width: 10%; 
                ; 
               /*border: 1px solid black; */
            } 
    		
            #right { 
                width: 100%; 
                
                /*border: 1px solid black; */
            } 
        </style>
        <div id="left"> 
            <table>
                <tr>
                    <td>cgst</td>
                    <td>percentege</td>
                </tr>
                <tr>
                    <td>sgst</td>
                    <td>percentege</td>
                </tr>
            </table>
        </div> 
		
		<div id="middle"> 
            DIV_mid 
			<br>
			DIV_mid
        </div> 
          
        <div id="right"> 
            <table id='celltable'>
                <tr>
                    <td id='celltable'>Total</td>
                    <td id='celltable'>$sum_ttl</td>
                </tr>
                <tr>
                    <td id='celltable'>SGST</td>
                    <td id='celltable'>SGST</td>
                </tr>
                <tr>
                    <td id='celltable'>CGST</td>
                    <td id='celltable'>CGST</td>
                </tr>
                <tr>
                    <td id='celltable'>Cess</td>
                    <td id='celltable'>Cess</td>
                </tr>
                <tr>
                    <td id='celltable'>GRAND TOTAL</td>
                    <td id='celltable'>GST</td>
                </tr>
            </table>
        </div>
        
        
<?php
$billler_id='1';
$con = new mysqli("localhost", "sahayikendra", "sahayikendra@Azalea", 'commonlog');
$res=mysqli_query($con,"select * from biller WHERE id='$billler_id'");
$row=mysqli_fetch_array($res);
$billr_nm=$row['name']; 
$billr_ad=$row['adds']; //array (,,,)
$billr_ft=$row['font_styl'];
$billr_lg=$row['logo']; 
$bill_ads_ar = explode(",", $billr_ad);
$bill_logo = base64_encode($billr_lg);


echo $billr_table="
        <style>
            table {
              border-collapse: collapse;
            }
            
            table, td, th {
              border: 1px solid black;
            }
        </style>
        <table style='border-collapse: collapse'>
            <tr>
                <th>Name</th>
                <th>Address</th>
                <th>Place</th>
                <th>Post</th>
                <th>District</th>
                <th>State</th>
                <th>Pincode</th>
                <th>Font</th>
                <th>Logo</th>
            </tr>";
            ?>
            <tr>
                <td><?php echo $billr_nm ; ?></td>
            	<td><?php echo $billr_ad[0]; ?></td>
            	<td><?php echo $bill_ads_ar[1]; ?></td>
            	<td><?php echo $bill_ads_ar[2]; ?></td>
            	<td><?php echo $bill_ads_ar[3]; ?></td>
            	<td><?php echo $bill_ads_ar[4]; ?></td>
            	<td><?php echo $bill_ads_ar[5]; ?></td>
                <td><?php echo $billr_ft ; ?></td>
                <td><img  src='data:image/jpeg;base64,<?php echo $bill_logo; ?>' height='50' width='50' /></td>
            </tr>
        </table>
        <br><br><br>
        ";
?>


<a href="billingpdf2.php?type=original" ><button>original</button></a><br>
<a href="billingpdf2.php?type=duplicate" ><button>duplicate</button></a><br>
<a href="billingpdf2.php?type=triplicate" ><button>triplicate</button></a>