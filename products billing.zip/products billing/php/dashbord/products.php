<?php
if (!isset($_SESSION)) { session_start(); }
$login_id=$_SESSION['id'];
echo 'login_id = '. $login_id; echo '<br>';
include('../connect/con.php');
if(!$clogin)
{
    echo "connection error";
}
?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<input type="text" class="searchTerm" oninput="serachingepic();" id='sear_prd' placeholder="search product name or code">
<script>
      function serachingepic() {
           var sear_p=$('#sear_prd').val();
           //alert(sear_p);
            $.ajax({
                type: "POST",
                url: "ajx.php",
                data: "serc_p=" + sear_p,
                cache: false,
                beforeSend: function() {
                    $('#rslt_serchlst').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#rslt_serchlst").html(html);
                }
            });
      }
</script>
<div id="rslt_serchlst"></div>

<?php
// from ajx page add qty
if(isset($_POST['quantity_submit_btn']))
{
    //echo 'code = ';
    $code =  $_POST['code']; echo '<br>';
    //echo 'qty = ';
    $qt_no = $_POST['qt_no']; echo '<br>';
    
    $sq_f="SELECT * FROM products WHERE code = '$code'";
    $re_f=mysqli_query($clogin, $sq_f);
    $rw_f=mysqli_fetch_array($re_f);
    // echo 'database qty = ';
    $db_qty = $rw_f['quantity']; echo '<br>';
    $total = ($db_qty + $qt_no);
    // echo 'total = ';
    $total;

    $sql_qt="UPDATE products SET quantity = '$total' WHERE code = '$code'";
    $res_qt = mysqli_query($clogin, $sql_qt);
    if($res_qt)
    {
        echo "
        <script>
            alert('success');
        </script>";
    }
}
?>







<?php
if(isset($_GET['addnew']))
{
    ?>
               <form action="" method="POST">
                <div class="log">
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="text" class="rounded form-control" name="pname" id="name" required />
                            <label for="psw"><span class="fas fa-eye"></span>Product Name:</label>
                        </fieldset>
                    </div>
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="text" class="rounded form-control" name="pcode" id="un" required />
                            <label for="psw"><span class="fas fa-lock"></span>Product Code</label>
                        </fieldset>
                    </div>
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="text" class="rounded form-control" name="p_rate" id="un" required />
                            <label for="psw"><span class="fas fa-lock"></span>Purchase Rate</label>
                        </fieldset>
                    </div>
                    
                    
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="text" class="rounded form-control" name="s_rate" id="un" required />
                            <label for="psw"><span class="fas fa-lock"></span>Sales Rate</label>
                        </fieldset>
                    </div>
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="text" class="rounded form-control" name="qty" id="un" required />
                            <label for="psw"><span class="fas fa-lock"></span>Quantity</label>
                        </fieldset>
                    </div>
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="text" class="rounded form-control" name="sgst" id="un" required />
                            <label for="psw"><span class="fas fa-lock"></span>SGST</label>
                        </fieldset>
                    </div>
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="text" class="rounded form-control" name="cgst" id="un" required />
                            <label for="psw"><span class="fas fa-lock"></span>CGST</label>
                        </fieldset>
                    </div>
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="text" class="rounded form-control" name="igst" id="un" required />
                            <label for="psw"><span class="fas fa-lock"></span>IGST</label>
                        </fieldset>
                    </div>
                    
    
                     
            		<button type="submit" name="regist_prdcut" value="SUBMIT" class="rounded btn btn-success btn-block">Register</button><br>
                </div>
        	</form>
        </body>
    </html>	
    <?php
    if(isset($_POST['regist_prdcut']))
    {
        $name=$_POST['pname'];
        $pcode=$_POST['pcode'];
        $p_rate = $_POST['p_rate'];
        $s_rate = $_POST['s_rate'];
        $qty = $_POST['qty'];
        $sgst = $_POST['sgst'];
        $cgst = $_POST['cgst'];
        $igst = $_POST['igst'];
        $min_qty = '10';
        $sql="INSERT INTO `products`(`id`, `name`, `code`, `pur_rate`, `sales_rate`, `quantity`, `min_qty`, `sgst`, `cgst`, `igst`, `user`, `admin`) VALUES (NULL, '$name', '$pcode' ,'$p_rate', '$s_rate', '$qty', '$min_qty', '$sgst', '$cgst', '$igst', '$login_id', '')";
        $res=mysqli_query($clogin,$sql);
        if($res)
        {
            echo "  <script>
                        alert('success');
                    </script>";
        }
        else
        {
            echo 'not';
        }
    } 
    ?>
        
    
    <?php
}
?>
