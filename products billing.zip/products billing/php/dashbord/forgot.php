<html>
<head>
<title>Forgot password</title>
</head>
<body>
<form action='php/dashbord/checkdb.php' method="POST">
<table>
<tr>
<td><label>User name</label>
<td><input type ="text" name = "uname" ></td>
</tr>
<tr>
<td><label>Email</label>
<td><input type ="email" name = "mail" ></td>
</tr>
   <td><input type="submit" name="ffff" value="submit"></td>
   </tr>
</table>
</form>
</body>
</html>

