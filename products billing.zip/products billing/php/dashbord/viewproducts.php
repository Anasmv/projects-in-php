<?php
if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
include('../connect/con.php');
if(!$clogin)
{
    echo "hi";
}
?>

<table>
    <tr>
        <th>name</th>
        <th>product code</th>
        <th>count</th>
    </tr>
    <?php 
    $sql="SELECT * FROM products ";
    $res=mysql
    ?>
    <tr>
        <td>
            
        </td>
    </tr>
</table>
