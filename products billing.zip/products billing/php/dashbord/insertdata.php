<?php
if (!isset($_SESSION)) { session_start(); }
include('../connect/con.php');
if(!$clogin) {  echo "hi"; }
?>
    <style>
        
    </style>
    <body><br><br><br><br>
        <form action="" method="POST">
            <div class="log">
                <div class="form-group texting-in">
                    <fieldset>
                        <input type="text" class="rounded form-control" name="name" id="name" required />
                        <label for="psw"><span class="fas fa-eye"></span> Name:</label>
                    </fieldset>
                </div>
                <div class="form-group texting-in">
                    <fieldset>
                        <input type="text" class="rounded form-control" name="uname" id="un" required />
                        <label for="psw"><span class="fas fa-lock"></span> User Name</label>
                    </fieldset>
                </div>
                <div class="form-group texting-in">
                    <fieldset>
                        <input type="email" class="rounded form-control" name="email" id="un" required />
                        <label for="psw"><span class="fas fa-lock"></span> Email</label>
                    </fieldset>
                </div>
                <div class="form-group texting-in">
                    <fieldset>
                        <input type="passsword" class="rounded form-control" name="password" id="par" required />
                        <label for="psw"><span class="fas fa-lock"></span> password</label>
                    </fieldset>
                </div>
                 <div class="form-group texting-in">
                    <fieldset>
                        <input type="passsword" class="rounded form-control" name="cpassword" id="par" required />
                        <label for="psw"><span class="fas fa-lock"></span> Confirm password</label>
                    </fieldset>
                </div>
                 <div class="form-group texting-in">
                    <fieldset>
                        <input type="text" class="rounded form-control" name="parent" id="par" required />
                        <label for="psw"><span class="fas fa-lock"></span> Parent</label>
                    </fieldset>
                </div>
        		<button type="submit" name="regist" value="SUBMIT" class="rounded btn btn-success btn-block">Register</button><br>
            </div>
    	</form>
    </body>
</html>	
<?php
    if(isset($_POST['regist']))
    {
        $name=$_POST['name'];
        $usname=$_POST['uname'];
        $email=$_POST['email'];
        $pwd1=$_POST['password'];
        $pwd2=$_POST['cpassword'];
        $par=$_POST['parent'];
        if($pwd1==$pwd2)
        {
            $pwd=password_hash($pwd1, PASSWORD_DEFAULT);  
            $sql="INSERT INTO `comlog`( `name`,`user_name`, `email`,`password`,`parent`,`api_key`) VALUES('$name','$usname','$email','$pwd','$par','0')";
            $res=mysqli_query($clogin,$sql);
        }
        else
        {
            echo'<script>alert("PASSWORD DOESNOT MATCH");</script>';
        }
        if($res)
        {
            echo'<script>alert("success");</script>';
        }
        else
        {
            echo'<script>alert("Not Registerd");</script>';   
        }
    }
?>