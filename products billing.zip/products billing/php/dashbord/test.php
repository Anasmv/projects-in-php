<?php
$input = array("a" => "green", "red", "b" => "green", "blue", "red", "red",  "c" => "green", "d" => "white");
$result = array_unique($input);
print_r($result);
?>