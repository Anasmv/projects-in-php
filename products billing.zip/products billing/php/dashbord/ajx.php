<?php
if(!isset($_SESSION)) { session_start(); }
$login_id=$_SESSION['id'];// echo '<br>';echo '<br>';
//echo 'login_id = '. $login_id; echo '<br>';
include('../connect/con.php');
?>
<?php    

//from product.php
if(isset($_POST['serc_p']))
{ 
    $sear_val = $_POST['serc_p']; 
//INSERT INTO `products`(`id`, `name`, `code`, `pur_rate`, `sales_rate`, `quantity`, `sgst`, `cgst`, `igst`, `user`)
$sql="SELECT * FROM products WHERE code LIKE '%$sear_val%' OR name LIKE '%$sear_val%'";
$res=mysqli_query($clogin ,$sql);


?>
    <table>
        <?php 
        if(mysqli_num_rows($res) > 0)
        {
            while($row_pr=mysqli_fetch_array($res))
            { ?>
                <tr>
                    <th>name</th>
                    <th>code</th>
                    <th>sales_rate</th>
                    <th>quantity</th>
                    <th>total</th>
                    <th>gst</th>
                    <th>gst rate</th>
                    <th>subtotal</th>
                </tr>
                <tr>
                    <td><?php echo $row_pr['name']; ?></td>
                    <td><?php echo $row_pr['code']; ?></td>
                    <td><?php echo $s_rate = $row_pr['sales_rate']; ?></td>
                    <td><?php echo $qty = $row_pr['quantity']; ?></td>
                    
                    <td><?php echo $ttl = $s_rate * $qty; ?></td>
                    
                    <td><?php echo $row_pr['sgst']; ?></td>
                    
                    <td><?php echo $y = $ttl * (6/100); ?></td>
                    <td><?php echo $ttl + $y; ?></td>
                    <td><button id ="<?php echo $row_pr['code']; ?>" onClick="Add_qty(this.id);" >add quantity</button></td>
                </tr>
                <?php
            }
        }
        else
        {
            echo "no product";
            echo "<a href='http://sahayikendra.com/commonlogin/php/dashbord/products.php?addnew=products'>add new</a>";
        }
        ?>
    </table>
    <div id="add_qty_id"></div>
    
    <script>
        function Add_qty(id)
        {
             $.ajax({
                url: "ajx.php",
                type: "POST",
                data: { 'add_qty' : id },
                beforeSend: function() {
                    $('#add_qty_id').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#add_qty_id").html(html);
                }
            });
        }
        
        function Add_to_bill(id)
        {
            $.ajax({
                url: "ajx.php",
                type: "POST",
                data: { 'add_qty' : id },
                beforeSend: function() {
                    $('#add_qty_id').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#add_qty_id").html(html);
                }
            });
            
        }
    </script>
<?php    
}

//from product.php
if(isset($_POST['add_qty']))
{ 
    $code = $_POST['add_qty'];
    ?>
    <form method="post">
        <input type="hidden" name = code value="<?php echo $code; ?>">
        <input type="text" id="qty_no" name="qt_no">
        <input type="submit" name="quantity_submit_btn" value="add quantity"></button>
    </form>
    <?php
}

//from billing2.php ajax datalist party select
if(isset($_POST['serc_part']))
{  ?>
    <?php
    $_SESSION['party_sel'] = $sear_val = $_POST['serc_part'];
    //user = '$login_id'"
    $sq_prt = "SELECT * FROM party WHERE name LIKE '%$sear_val%' " ;
    $re_prt = mysqli_query($clogin, $sq_prt);
    while($row_prt=mysqli_fetch_array($re_prt))
    {
        echo ' &nbsp;'.$row_prt['adds'];
        echo ' &nbsp;'.$row_prt['phon'];
        echo ' &nbsp;'.$row_prt['GSTIN'];
    }
    ?>
    <br>
    <table>
        <tr>
            <th>Sl no</th>
            <th>Commodity</th>
            <th>Code</th>
            <th>Sales Rate</th>
            <th>QUANTITY</th>
            <th>Total</th>
            <th>GST</th>
            <th>GST Rate</th>
            <th>Sub Total</th>
        </tr>
        <tr>
            <td></td>
            <td>
                <input list="plist" required form="next_form" placeholder = "search a product name" id="prdt_plist" name="prdt_plist_f" oninput='prdct_srch();'>
                <datalist id="plist">
                      <?php 
                      $sql_p="SELECT * FROM products ";
                      $re_p=mysqli_query($clogin, $sql_p);
                      while ($rw_p = mysqli_fetch_array($re_p))
                      {
                          $name=$rw_p['name'];
                          $id=$rw_p['id'];
                          echo "<option value='$name'></option>";
                      }
                      ?>
                </datalist>
            </td>
            <td id="td_code"></td>
            <td id='td_Sales'></td>
            <td><input type="text" name="qty_enter" form="next_form" id="qty_input" placeholder="Enter quantity" oninput='Qty_inp();'></td>
            <td id='td_Total'></td>
            <td id='td_GST'></td>
            <td id='td_GST_R'></td>
            <td id='td_Sub'></td>
            <td>
                <button  id="fst_frm_btn" name="fst_button" onClick="fst_frmsubmit();">+</button>
            </td>
        </tr>
        
        <tr>
            <td>total</td>
            <td></td>
            <td id=""></td>
            <td id=''></td>
            <td id='qty_sum'><?php ?></td>
            <td id='total_sum'><?php  ?></td>
            <td id=''></td>
            <td id='gst_sum'><?php   ?></td>
            <td id='subtotal_sum'><?php   ?></td>
            <td>
                
            </td>
        </tr>
    </table>
           
            
           
            
    <?php
}


if(isset($_POST['serc_prdt']))
{
    $p_nm = $_POST['serc_prdt'];
    //WHERE user =  seiion id / login id
    $sq_u="SELECT * FROM party WHERE name = '$p_nm'";
    $re_u=mysqli_query($clogin, $sq_u);
    $rw_u = mysqli_fetch_array($re_u);
    echo 'user _id ='. $user = $rw_u['user']; echo '<br>';
    
    $sq_lg="SELECT * FROM comlog WHERE id = '$user'";
    $re_lg=mysqli_query($clogin, $sq_lg);
    $rw_lg = mysqli_fetch_array($re_lg);
    echo $parent = $rw_lg['parent'];
    


    //WHERE user =  seiion id / login id
    $sq_prd="SELECT * FROM products ";
    $re_prd=mysqli_query($clogin, $sq_prd);
    //$rw_prd = mysqli_fetch_array($re_prd);
    //echo $user = $rw_prd['user'];
    ?>
    <table>
        <tr>
            <th>Name</th>
            <th>Product Code</th>
            <th>Purchase Rate</th>
            <th>Sales Rate</th>
            <th>Quantity</th>
            <th>SGST</th>
            <th>CGST</th>
            <th>IGST</th>
        </tr>
        <?php while($rw_prd = mysqli_fetch_array($re_prd)) 
            { ?>
        <tr>
            <?php $prdct_id = $rw_prd['id']; ?>
            <td><?php echo $rw_prd['name']; ?></td>
            <td><?php echo $rw_prd['code']; ?></td>
            <td><?php echo $rw_prd['pur_rate']; ?></td>
            <td><?php echo $rw_prd['sales_rate']; ?></td>
            <td><?php echo $rw_prd['quantity']; ?></td>
            <td><?php echo $rw_prd['sgst']; ?></td>
            <td><?php echo $rw_prd['cgst']; ?></td>
            <td><?php echo $rw_prd['igst']; ?></td>
            <td><button onClick = "add_to_bill(<?php echo $prdct_id ?>);">add to bill</button></td>
            <td><button onClick="edit_bill();">edit bill</button></td>
        </tr>
        <?php } ?>
    </table>
    <div id="add_to_bill_id"></div>
    <script>
        function add_to_bill(prduct_id) {
            $.ajax({
                url: "ajx.php",
                type: "POST",
                data: { 'add_to_bill' : prduct_id },
                beforeSend: function() {
                    $('#add_to_bill_id').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#add_to_bill_id").html(html);
                }
            });
        }
    </script>
    <?php
}

//from billing.php add tobill
if(isset($_POST['add_to_bill']))
{
    $product_sel = $_POST['add_to_bill'];
    echo 'selected product id = '.$product_sel; echo '<br>'; 
    echo 'last prdct cookie = '.$_COOKIE['lastid_nextpdt']; echo '<br>'; 
    ?>
    <form method="post">
        <input type="hidden" name="product_id" value="<?php echo $product_sel; ?>">
        <input type="text" name="p_bill_qty" placeholder="Enter no of quantity">
        <input type="submit" name="bill_add_sub" value="add">
    </form>
<?php
}

//product list from billling.php product search
if(isset($_POST['serc_prdct']))
{
    echo $nm = $_POST['serc_prdct'];
    //WHERE user =  seiion id / login id
    $sq_prd="SELECT * FROM products WHERE name = '$nm'";
    $re_prd=mysqli_query($clogin, $sq_prd);
    //$rw_prd = mysqli_fetch_array($re_prd);
    //echo $user = $rw_prd['user'];
    ?>

        
    <?php
    while($rw_pdt=mysqli_fetch_array($re_prd))
    {
       echo "<tr>" ;
        echo "<td>slno</td>";
        echo '<td>'.$rw_pdt['code'].'</td>';
        $s_rate = $rw_pdt['sales_rate'];
        echo '<td>'.$s_rate.'</td>';
        $qty = $rw_pdt['quantity']; 
        echo "<td>"."<input required type='text' name='nw_qty' placeholder='enter number of quantity'>"."</td>";
        $ttl = $s_rate * $qty;
        echo '<td>'.$ttl.'</td>';
        $sqst = $rw_pdt['sgst'];
        echo '<td>'.$sqst.'</td>';
        $y = $ttl * (($sqst)/100);
        echo '<td>'.$y.'</td>';
        $subttl = $ttl + $y;
        echo '<td>'.$subttl.'</td>';
        echo "</tr>";
        //echo ' &nbsp;'.$grt_totl = $qty + $ttl + $y + $subttl ;
        //echo " &nbsp;"."<button type='button' onClick='add_bill_to();'>add to bill</button>";
        
    } ?>
    <td id="next_pdct_s"></td>
        
    </table>
    <br>
    

<?php    
}


//product list from billling.php product search
if(isset($_POST['serc_prdct_next']))
{
    $_SESSION['pdt_last']=$_POST['pdt_lst_last_id'];
    $nm=$_POST['serc_prdct_next'];
    //WHERE user =  seiion id / login id
    $sq_prd="SELECT * FROM products WHERE name= '$nm'";
    $re_prd=mysqli_query($clogin, $sq_prd);
    //$rw_prd = mysqli_fetch_array($re_prd);
    //echo $user = $rw_prd['user'];
    
    while($rw_pdt=mysqli_fetch_array($re_prd))
    { echo '<tr>';
        //echo '<td>'.$rw_pdt['name'].'</td>';
        echo '<td>'.$rw_pdt['code'].'</td>';
        echo '<td>'.$s_rate = $rw_pdt['sales_rate'].'</td>';
        echo '<td>'.$qty = $rw_pdt['quantity'].'</td>'; 
        
        echo '<td>'.$ttl = $s_rate * $qty.'</td>';
        echo '<td>'.$sqst = $rw_pdt['sgst'].'</td>';
        echo '<td>'.$y = $ttl * (($sqst)/100).'</td>';
        $subttl = $ttl + $y;
        echo '<td>'.$subttl.'</td>';
    echo '</tr>';
    } ?>
<?php    
}



//from dashboard/index.php add user
if(isset($_POST['add_us']))
{
    //
// Full texts	
// id
// name
// user_name
// password
// email
// parent ?>
    <form method='post'>
        <input type='text' name='name' required>
        <input type='text' name='user_name' required>
        <input type='text' name='password' required>
        <input type='text' name='email' required>
        <input type='submit' name='add_nw_user_sub'>
    </form>
<?php
}



if(isset($_POST['serc_prdct_code']))
{
    $nm = $_POST['serc_prdct_code'];
    $sq_prd="SELECT * FROM products WHERE name = '$nm'";
    $re_prd=mysqli_query($clogin, $sq_prd);
    $rw_pdt=mysqli_fetch_array($re_prd);
    echo $rw_pdt['code'];
}

if(isset($_POST['serc_prdct_s_rt']))
{
    $nm = $_POST['serc_prdct_s_rt'];
    $_SESSION['prdt_nm'] = $nm ;
    $sq_prd="SELECT * FROM products WHERE name = '$nm'";
    $re_prd=mysqli_query($clogin, $sq_prd);
    $rw_pdt=mysqli_fetch_array($re_prd);
    echo $_SESSION['sl_rate']= $rw_pdt['sales_rate'];
}

if(isset($_POST['qty_inp_ttl']))
{
    $nm = $_SESSION['prdt_nm'];
    $qty_inp_ttl = $_POST['qty_inp_ttl'];
    $sq_prd="SELECT * FROM products WHERE name = '$nm'";
    $re_prd=mysqli_query($clogin, $sq_prd);
    $rw_pdt=mysqli_fetch_array($re_prd);
    $s_rt = $rw_pdt['sales_rate'];
    $ttl= ( $s_rt * $qty_inp_ttl );
    $_SESSION['ttl'] = $ttl;
    echo  $ttl;
}

if(isset($_POST['qty_inp_gst']))
{
    $qty_inp_gst = $_POST['qty_inp_gst'];
    $nm = $_SESSION['prdt_nm'];
    $sq_prd="SELECT * FROM products WHERE name = '$nm'";
    $re_prd=mysqli_query($clogin, $sq_prd);
    $rw_pdt=mysqli_fetch_array($re_prd);
    $s_sgrt = $rw_pdt['sgst'];
    echo  $s_sgrt;
}

if(isset($_POST['qty_inp_gstr']))
{
    $qty_inp_gstr = $_POST['qty_inp_gstr'];
    $nm = $_SESSION['prdt_nm'];
    $sq_prd="SELECT * FROM products WHERE name = '$nm'";
    $re_prd=mysqli_query($clogin, $sq_prd);
    $rw_pdt=mysqli_fetch_array($re_prd);
    $s_sgrt = $rw_pdt['sgst'];
    $s_rt = $rw_pdt['sales_rate'];
    $gst_rt=(($s_rt * $qty_inp_gstr) * ($s_sgrt / 100));
    echo $gst_rt;
    $_SESSION['yyy'] = $gst_rt;
}

if(isset($_POST['qty_inp_sub']))
{
    $gst_rt = $_SESSION['yyy'];
    $ttl = $_SESSION['ttl'];
    $qty_inp_sub = $_POST['qty_inp_sub'];
    $fin_sub = ($gst_rt + $ttl);
    echo $fin_sub;
    
}

//forst fom submit inserting from billing.php or ajx.php
if(isset($_POST['fst_frm_sub']))
{
    $_SESSION['party_sel'] = $sear_val = $_POST['serc_part'];
    //user = '$login_id'"
    $sq_prt = "SELECT * FROM party WHERE name LIKE '%$sear_val%' " ;
    $re_prt = mysqli_query($clogin, $sq_prt);
    while($row_prt=mysqli_fetch_array($re_prt))
    {
        echo ' &nbsp;'.$row_prt['adds'];
        echo ' &nbsp;'.$row_prt['phon'];
        echo ' &nbsp;'.$row_prt['GSTIN'];
    }
    
    $sq_lg="SELECT * FROM comlog WHERE user = '$login_id' ";
    $re_lg=mysqli_query($clogin, $sq_lg);
    $rw_lg=mysqli_fetch_array($re_lg);
    $parent=$rw_lg['parent'];
    
    $sq_bill="SELECT * FROM billing WHERE admin = '$parent' ";
    $re_bill=mysqli_query($clogin, $sq_bill);
    $rw_bill=mysqli_fetch_array($re_bill);
    $rowcount=mysqli_num_rows($re_bill);
    $bill_no = $rowcount + 1;
    $_SESSION['bill_no'] = $bill_no;
    
    //{ ( inserting start
        $fst_qty_input = $_POST['fst_qty_input']; 
        $fst_prdt_plist = $_POST['fst_prdt_plist']; 
        $party_dlist = $_POST['party_dlist'];
        
        
        
        $sq_pdt1 =  "SELECT * FROM products WHERE name = '$fst_prdt_plist'";
        $re_pdt1=mysqli_query($clogin, $sq_pdt1);
        $rw_pdt1=mysqli_fetch_array($re_pdt1);
        $prdt_id  = $rw_pdt1['id'];
        $pdt_qty = $rw_pdt1['quantity'];
        $fin_qttt= ($pdt_qty - $fst_qty_input);
        $sq_b3="UPDATE products SET quantity = '$fin_qttt' WHERE id = '$pdt_id'";
        $re_b3=mysqli_query($clogin, $sq_b3);
       
        $bill = '{'.$prdt_id.','.$fst_qty_input.'}';
        $date=date("Y/m/d");
        
        $sq_pqty="INSERT INTO `billing`(`id`, `bill_no`, `bill`, `date`, `party`, `user`, `admin`) VALUES (NULL, '$bill_no', '$bill', '$date', '$party_dlist', '$login_id', '$parent')";
        $re_pqty=mysqli_query($clogin, $sq_pqty);
        
        if($re_pqty)
        {
            echo "<script> alert('success'); </script>";
        }
        else
        {
            echo "<script> alert('insert error'); </script>";
        }
        
        $sq_bil_sel="SELECT * FROM billing WHERE date = '$date' AND bill = '$bill' AND party = '$party_dlist' AND user = '$login_id' AND admin = '$parent'";
        $re_bill_sel=mysqli_query($clogin, $sq_bil_sel);
        $rw_bill_sel=mysqli_fetch_array($re_bill_sel);
        $insert_id=$rw_bill_sel['id'];
        $_SESSION['ins_id']=$insert_id;
    //) } inserting end
?>
<table>
        <tr>
            <th>Sl no</th>
            <th>Commodity</th>
            <th>Code</th>
            <th>Sales Rate</th>
            <th>QUANTITY</th>
            <th>Total</th>
            <th>GST</th>
            <th>GST Rate</th>
            <th>Sub Total</th>
        </tr>
        
        <?php
        echo $insert_id = $_SESSION['ins_id'];
        $sq_b2="SELECT * FROM billing WHERE id = '$insert_id'"; 
        $re_b2=mysqli_query($clogin, $sq_b2);
        $rw_b2=mysqli_fetch_array($re_b2);
        echo $nxt_bill = $rw_b2['bill'];
        
        
        
        
        $nxt_bill1=ltrim(substr_replace($nxt_bill,"",-1),"{");
        $delimiter = array(" ","/","}{","{","}",);
        $replace = str_replace($delimiter, $delimiter[0], $nxt_bill1);
        $explode = explode($delimiter[0], $replace);
        //$odd = array_filter($input, "oddCmp");
        
        //for testing
        //echo $explode = "{8,15}";
        //print_r($explode);
        
        foreach ($explode as $line) {
            echo "<tr>";
            //echo $line.'<br>';
            $array1  = explode(",", $line);
            foreach ($array1 as $line1) {
                //echo $line1;
                if($line1 != '')
                {
                    $sq_prdt1 = "SELECT * FROM products WHERE id = '$line1'";
                    $re_prdt1 = mysqli_query($clogin, $sq_prdt1);
                    $ro_prdt1 = mysqli_fetch_array($re_prdt1);
                    $prt_nm = $ro_prdt1['name'];
                    
                    $prt_id = $ro_prdt1['id'];
                    
                    if($line1 == $prt_id)
                    {
                        if($prt_id != '')
                        {
                            echo "<td>1</td>";
                            $pdt_2nm=$prt_nm;
                            echo '<td>'.$prt_nm .'</td>';
                            $p_code=$ro_prdt1['code'];
                            echo "<td>".$ro_prdt1['code']."</td>";
                            $s_rate = $ro_prdt1['sales_rate'];
                            echo "<td>".$s_rate."</td>";
                            $sqst = $ro_prdt1['sgst'];
                        }
                    }
                    else
                    {
                        $qnty1 = $line1;
                        echo '<td>'.$qnty1.'</td>';
                        $ttl = ($s_rate * $qnty1);
                        echo "<td>$ttl</td>";
                        
                        echo "<td>$sqst</td>";
                        $y = ($ttl * (($sqst)/100));
                        echo "<td>$y</td>";
                        $subttl = ($ttl + $y);
                        echo "<td>$subttl</td>";
                        
                        
                        echo "<td>"; ?>
                        <button  id='del_bll'  name='_ delete_bill' onClick='del_bill("<?php echo $pdt_2nm; ?>","<?php echo $qnty1; ?>");'>-</button>
                        <?php
                        echo "</td>";
                    }
                }
            }
            echo "</tr>";
        }// foreach close
?>

   
        <tr>
            <td></td>
            <td>
                <input list="plist" required form="next_form_next" placeholder = "search a product name" id="prdt_plist" name="prdt_plist_nxt" oninput='prdct_srch();'>
                <datalist id="plist">
                      <?php 
                      $sql_p="SELECT * FROM products ";
                      $re_p=mysqli_query($clogin, $sql_p);
                      while ($rw_p = mysqli_fetch_array($re_p))
                      {
                          $name=$rw_p['name'];
                          $id=$rw_p['id'];
                          echo "<option value='$name'></option>";
                      }
                      ?>
                </datalist>
            </td>
            <td id="td_code"></td>
            <td id='td_Sales'></td>
            <td><input type="text" name="qty_enter" form="next_form_next" id="qty_input" placeholder="Enter quantity" oninput='Qty_inp();'></td>
            <td id='td_Total'></td>
            <td id='td_GST'></td>
            <td id='td_GST_R'></td>
            <td id='td_Sub'></td>
            <td>
                <button  id="nxt_frm_sub" name="+next" onClick="nxt_frm_sub();">+</button>
            </td>
        </tr>
        
        <tr>
            <td>total</td>
            <td></td>
            <td id=""></td>
            <td id=''></td>
            <td id=''><?php echo $qnty1; ?></td>
            <td id=''><?php echo $ttl; ?></td>
            <td id=''></td>
            <td id=''><?php echo  $y; ?></td>
            <td id=''><?php echo  $subttl; ?></td>
            <td>
                
            </td>
        </tr>
    </table>
    <a href='billingpdf2.php'><button>print</button></a>
<?php
}




//next fom submit updating from billing.php or ajx.php
if(isset($_POST['nxt_frm_sub']))
{
    
    $sear_val = $_SESSION['party_sel'] ;
    //user = '$login_id'"
    $sq_prt = "SELECT * FROM party WHERE name LIKE '%$sear_val%' " ;
    $re_prt = mysqli_query($clogin, $sq_prt);
    while($row_prt=mysqli_fetch_array($re_prt))
    {
        echo ' &nbsp;'.$row_prt['adds'];
        echo ' &nbsp;'.$row_prt['phon'];
        echo ' &nbsp;'.$row_prt['GSTIN'];
    }
    
    $insert_id = $_SESSION['ins_id']; 
    $prdt_plist_nxt = $_POST['product_next']; 
    $qty_input_nxt = $_POST['quantity_next']; 
    if($prdt_plist_nxt != '' && $qty_input_nxt != '')
    {
        $sq_pid="SELECT * FROM products WHERE name = '$prdt_plist_nxt'";
        $re_pid=mysqli_query($clogin, $sq_pid);
        $rw_pid=mysqli_fetch_array($re_pid);
        $pdt_id = $rw_pid['id'];
        $pdt_qty = $rw_pid['quantity'];
        $fin_qttt= ($pdt_qty - $qty_input_nxt);
        $sq_b3="UPDATE products SET quantity = '$fin_qttt' WHERE id = '$pdt_id'";
        $re_b3=mysqli_query($clogin, $sq_b3);
        
        
        echo '<br>';
        $sq_b2="SELECT * FROM billing WHERE id = '$insert_id'"; 
        $re_b2=mysqli_query($clogin, $sq_b2);
        $rw_b2=mysqli_fetch_array($re_b2);
        $bill2 = $rw_b2['bill'];
        $party = $rw_b2['party'];
        echo 'database bill data = '. $bill2.'<br>';
        echo 'posted array = '.$bil_prd=$bill2.'{'.$pdt_id.','.$qty_input_nxt.'}';
        echo '<br>';
        $sql_in2="UPDATE `billing` SET bill = '$bil_prd' WHERE id = '$insert_id'";
        
        
        
        $re_in2=mysqli_query($clogin, $sql_in2);
        if($re_in2) {
            echo '<script>
                    alert("update success");
                  </script>';
        }
    }
    ?>
    <table>
        <tr>
            <th>Sl no</th>
            <th>Commodity</th>
            <th>Code</th>
            <th>Sales Rate</th>
            <th>QUANTITY</th>
            <th>Total</th>
            <th>GST</th>
            <th>GST Rate</th>
            <th>Sub Total</th>
        </tr>
        <?php
        echo '$insert_id'.$insert_id = $_SESSION['ins_id'];
        $sq_b2="SELECT * FROM billing WHERE id = '$insert_id'"; 
        $re_b2=mysqli_query($clogin, $sq_b2);
        $rw_b2=mysqli_fetch_array($re_b2);
        $nxt_bill = $rw_b2['bill'];
        $nxt_bill1=ltrim(substr_replace($nxt_bill,"",-1),"{");
        $delimiter = array(" ","/","}{","{","}",);
        $replace = str_replace($delimiter, $delimiter[0], $nxt_bill1);
        $explode = explode($delimiter[0], $replace);
        //$odd = array_filter($input, "oddCmp");
        
        //for testing
        //echo $explode = "{8,15}";
        print_r($explode);
        $no=1;
        $sum_qty = 0;
            $sum_ttl = 0;
            $sum_gst = 0;
            $sum_subttl = 0;
        foreach ($explode as $line) {
            echo "<tr>";
            //echo $line.'<br>';
            $array1  = explode(",", $line);
            
            foreach ($array1 as $line1) {
                //echo $line1;
                if($line1 != '')
                {
                    $sq_prdt1 = "SELECT * FROM products WHERE id = '$line1'";
                    $re_prdt1 = mysqli_query($clogin, $sq_prdt1);
                    $ro_prdt1 = mysqli_fetch_array($re_prdt1);
                    $prt_nm = $ro_prdt1['name'];
                    
                    $prt_id = $ro_prdt1['id'];
                    
                    if($line1 == $prt_id)
                    {
                        if($prt_id != '')
                        {
                            echo "<td>$no</td>";
                            $pdt_2nm=$prt_nm;
                            echo '<td>'.$prt_nm .'</td>';
                            $p_code=$ro_prdt1['code'];
                            echo "<td>".$ro_prdt1['code']."</td>";
                            $s_rate = $ro_prdt1['sales_rate'];
                            echo "<td>".$s_rate."</td>";
                            $sqst = $ro_prdt1['sgst'];
                        }
                    }
                    else
                    {
                        
                        $qnty1 = $line1;
                        
                        $sum_qty +=  $qnty1;
                        echo '<td>'.$qnty1.'</td>';
                        $ttl = ($s_rate * $qnty1);
                        $sum_ttl += $ttl;
                        echo "<td>$ttl</td>";
                        
                        echo "<td>$sqst</td>";
                        $y = ($ttl * (($sqst)/100));
                        echo "<td>$y</td>";
                        
                        $sum_gst += $y;
                        
                        $subttl = ($ttl + $y);
                        $sum_subttl += $subttl;
                        echo "<td>$subttl</td>";
                       
                        echo "<td>"; ?>
                        <button  id='<?php echo $no; ?>'  name='_ delete_bill' onClick='del_bill("<?php echo $pdt_2nm; ?>","<?php echo $qnty1; ?>");'>-</button>
                        <?php
                        echo "</td>";
                    }
                }
            }
            echo "</tr>";
            $no++;
            
        }
?>

   
        <tr>
            <td></td>
            <td>
                <input list="plist" required form="next_form_next" placeholder = "search a product name" id="prdt_plist" name="prdt_plist" oninput='prdct_srch();'>
                <datalist id="plist">
                      <?php 
                      $sql_p="SELECT * FROM products ";
                      $re_p=mysqli_query($clogin, $sql_p);
                      while ($rw_p = mysqli_fetch_array($re_p))
                      {
                          $name=$rw_p['name'];
                          $id=$rw_p['id'];
                          echo "<option value='$name'></option>";
                      }
                      ?>
                </datalist>
            </td>
            <td id="td_code"></td>
            <td id='td_Sales'></td>
            <td><input type="text" name="qty_enter" form="next_form_next" id="qty_input" placeholder="Enter quantity" oninput='Qty_inp();'></td>
            <td id='td_Total'></td>
            <td id='td_GST'></td>
            <td id='td_GST_R'></td>
            <td id='td_Sub'></td>
            <td>
                <input type="button"  id="nxt_frm_sub" name="+po" onClick="nxt_frm_sub();" value="+"/>
            </td>
        </tr>
        
        <tr>
            <td>total</td>
            <td></td>
            <td id=""></td>
            <td id=''></td>
            <td><?php
                echo $sum_qty;
            ?></td>
            <td id=''><?php echo $sum_ttl; ?></td>
            <td id=''></td>
            <td id=''><?php echo $sum_gst; ?></td>
            <td id=''><?php echo $sum_subttl; ?></td>
            <td>
                
            </td>
        </tr>
        
        
    </table>
    <a href='billingpdf2.php'><button>print</button></a>
        
<?php
}


if(isset($_POST['delete_bill']) && isset($_POST['pdt_2']) && isset($_POST['qty_2']))
{
    $no_p = $_SESSION['$no'];
    $no2=$no_p-1;
    
    $_SESSION['$no']=$no2;
    $pdt_2=$_POST['pdt_2'];
    $qty_2=$_POST['qty_2'];
    
    $sq_p="SELECT * FROM products WHERE name='$pdt_2'";
    $re_p=mysqli_query($clogin, $sq_p);
    $rw_p=mysqli_fetch_array($re_p);
    $pdt_id=$rw_p['id'];
    $pdt_qty=$rw_p['quantity'];
    
    $fin_qttt = ($pdt_qty + $qty_2);
    $sq_b3="UPDATE products SET quantity = '$fin_qttt' WHERE id = '$pdt_id'";
    $re_b3=mysqli_query($clogin, $sq_b3);
    
    
    
    
    $insert_id = $_SESSION['ins_id'];
    $sq_b2="SELECT * FROM billing WHERE id = '$insert_id'"; 
    $re_b2=mysqli_query($clogin, $sq_b2);
    $rw_b2=mysqli_fetch_array($re_b2);
    echo $nxt_bill = $rw_b2['bill'];
    
    echo '$fin_p_q = ' .$fin_p_q = '{'.$pdt_id.','.$qty_2.'}';
    
    
    
   echo  '$fin_up_val ='.$fin_up_val = str_replace($fin_p_q, "", $nxt_bill);
    
    $sql_in2="UPDATE `billing` SET bill = '$fin_up_val' WHERE id = '$insert_id'";
    $re_in2=mysqli_query($clogin, $sql_in2);
    if($re_in2) {
        echo '<script>
                alert("update success");
              </script>';
    }
    else
    {
        '<script>
                alert("no ");
              </script>';
    }
}

?>