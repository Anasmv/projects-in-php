<?php
include("../connect/con.php");
     
        if(isset($_POST['editwts']))
	    {
	   $he=$_POST['hid'];
	    $headw=$_POST['un'];
	    $textw=$_POST['nm'];
	    $texte=$_POST['em'];
	    
	     
       
        
            $sqls3="UPDATE `comlog` SET `name`='$textw',`user_name`='$headw',`email`='$texte' WHERE id='$he'";
			  
			$result= mysqli_query($clogin,$sqls3);
	
           
    
			 if($result)
			 {
				 echo"<script>alert('Your Account profile has been Updated successfully, Thanks')</script>";
                //echo"<script>window.open('page.php','_self')</script>";
			 }
			 else
			 {
				 echo "not update";
			 }
	    }
   

?>


<?php
include("../connect/con.php");
    if(!$clogin)
    {
        echo"failed";
    }

if(isset($_POST['ffff']))
{
 echo $us=$_POST['uname'];
 echo$mail=$_POST['mail'];
  $pass=rand ( 10000 , 99999 );

$sql="select * from comlog  where  email='$mail' ";
$ww=mysqli_query($clogin,$sql);
$s=mysqli_num_rows($ww);
$row=mysqli_fetch_array($ww);
 echo $o=$row['email'];
if($s>0)
{
	$sql1="select * from comlog where user_name='$us' or email='$mail' ";
	$a=mysqli_query($clogin,$sql1);
	$b=mysqli_num_rows($a);
	if($b>0)
    {
     $to = $o;
     $subject = "My subject";
     $txt = $pass;
    $headers = "From:azalea@gmail.com";
    $ma=mail($to,$subject,$txt,$headers);
    if($ma)
    {
        $pas=password_hash($pass, PASSWORD_DEFAULT);
	    $query="update comlog set password='$pas' where user_name='$us'";
		$c=mysqli_query($clogin,$query);
		if($c)
		{
			echo"<script>alert('SENDING SUCCESSFULLY')</script>";
		}
}
}
}
else
{
		echo "<h1>MSG NOT SEND</h1>";
}

}
?>
