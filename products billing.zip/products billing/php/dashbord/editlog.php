   
        <?php
include("../connect/con.php");
if(isset($_POST['rr1']))
{
echo $selw=$_POST['rr1'];
$sql="select * from comlog where id=$selw";
$r=mysqli_query($clogin,$sql);
if($r->num_rows>0)
{				     
$row=$r->fetch_assoc();
  $xx=$row['id'];
            $as=$row['user_name'];
            $bs=$row['name'];
            $abcs=$row['email'];

}
?>
<form class="row" role="form" action="checkdb.php" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" onsubmit=" return validateform()">
<table border="1">
<tr>
<td>
<label for="InputName">User Name: </label> 
<input type="text" class="form-control round" name="un" id="InputName" value="<?php echo $as; ?>"/><br>
<label for="InputName">Name: </label>  
<input type="text" class="form-control round" name="nm" id="InputName" value="<?php echo $bs; ?>"/><br><br>
<label for="InputName">Email: </label>  
<input type="text" class="form-control round" name="em" id="InputName" value="<?php echo $abcs; ?>"/><br><br>
<input type="hidden"  name="hid"  value="<?php echo $selw; ?>"/><br><br>

<input type="submit" name="editwts" value="Submit" >
</td>
</tr>
</table>
</form>

<?php
}
?>
