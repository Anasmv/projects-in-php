<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<?php
if (!isset($_SESSION)) { session_start(); }
include("../connect/con.php");
echo $urlc = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
if(!$clogin)
{
    echo "hello";
}
$log_id=$_SESSION['id'];
$sql="select * from comlog where id=$log_id";
$r=mysqli_query($clogin,$sql);
if($r->num_rows>0)
{
    while($row=$r->fetch_assoc())
    {
        $x=$row['id'];
        $a=$row['user_name'];
        $b=$row['name'];
        $abc=$row['email'];
    }
}
?>
        
        
    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 col-xl-12 row border border-dark">
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6 ">
            User Name: <?php echo $a; ?><br>
            Name: <?php echo $b; ?><br>
            Email: <?php echo $abc; ?><br>
        </div>
    
        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 col-xl-6">
            <button title="Edit" class="fas fa-cog" type="submit" id=<?php echo $log_id;?> name="sub1" onclick="editt(this.id)";>Edit</button>
        </div>
    </div>
    
    <div id='viewpart'></div>
    <script>
        function editt(r) {
            alert('fdfvd');
            $(document).attr("title","UPDATE Welcome");
            var rr=r;
            $("#viewpart").html("");
            $.ajax({
                type: "POST",
                url: "<?php $urlc?>/commonlogin/php/dashbord/editlog.php",
                data:{rr1:rr},
                cache: false,
                beforeSend: function() {
                    $('#viewpart').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#viewpart").html(html);
                }
            });
        }
    </script>
    
    <a onClick="Add_User('<?php echo $log_id; ?>');">Add user</a>
    
    <div id="new_user_div"></div>
    <a href='products.php' >Products</a><br>
    <a href="billing2.php"  >billing</a><br>
    <a href="party.php"  >party</a><br>
     
     
     
     
    <script>
        function Add_User(nw_user) {
            $(document).attr("title","ADD USER");
            $("#new_user_div").html("");
            $.ajax({
                type: "POST",
                url: "ajx.php",
                data:{add_us:nw_user},
                cache: false,
                beforeSend: function() {
                    $('#new_user_div').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#new_user_div").html(html);
                }
            });
        }
    </script>
    




    <?php
    if(isset($_POST['add_nw_user_sub']))
    {
        $name = $_POST['name'];
        $user_name = $_POST['user_name'];
        $password = $_POST['password'];
        $pwd=password_hash($password, PASSWORD_DEFAULT); 
        $email = $_POST['email'];
        $sq_nw_u="INSERT INTO `comlog`(`id`, `name`, `user_name`, `password`, `email`, `parent`) VALUES (NULL, '$name', '$user_name', '$pwd', '$email', '$log_id')";
    }
    
    ?>