<?php
include('../connect/con.php');
if (!isset($_SESSION)) { session_start(); }
$login_id=$_SESSION['id'];

$sq_lg="SELECT * FROM comlog WHERE user = '$login_id' ";
$re_lg=mysqli_query($clogin, $sq_lg);
$rw_lg=mysqli_fetch_array($re_lg);
$parent=$rw_lg['parent'];

$sq_bill="SELECT * FROM billing WHERE admin = '$parent' ";
$re_bill=mysqli_query($clogin, $sq_bill);
$rw_bill=mysqli_fetch_array($re_bill);
$rowcount=mysqli_num_rows($re_bill);
echo 'bill_no = '.$bill_no = $rowcount + 1;



?>


    
    
    
    <?php
    
    
    