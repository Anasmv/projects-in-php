<?php
if (!isset($_SESSION)) { session_start(); }
$login_id=$_SESSION['id'];
echo '<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>';
include('../connect/con.php');



$sq_lg="SELECT * FROM comlog WHERE user = '$login_id' ";
$re_lg=mysqli_query($clogin, $sq_lg);
$rw_lg=mysqli_fetch_array($re_lg);
$parent=$rw_lg['parent'];

$sq_bill="SELECT * FROM billing WHERE admin = '$parent' ";
$re_bill=mysqli_query($clogin, $sq_bill);
$rw_bill=mysqli_fetch_array($re_bill);
$rowcount=mysqli_num_rows($re_bill);
echo 'bill_no = '.$bill_no = $rowcount + 1;
$_SESSION['bill_no'] = $bill_no;
?>
<div>
    <input list="dlist" form="next_form" required placeholder = "search a party name" id="party_dlist" name="party_dlist" oninput='onInput();'>
    <datalist id="dlist">
          <?php 
          $sql_p="SELECT * FROM party ";
          $re_p=mysqli_query($clogin, $sql_p);
          while ($rw_p = mysqli_fetch_array($re_p))
          {
              $name=$rw_p['name'];
              $id=$rw_p['id'];
              echo "<option value='$name'></option>";
          }
          ?>
    </datalist>
    <label for="whatev" id="party_list"></label>
</div>


<script>
    function onInput() {
        var val = document.getElementById("party_dlist").value;
        var opts = document.getElementById('dlist').childNodes;
        for (var i = 0; i < opts.length; i++) {
          if (opts[i].value === val) {
            // An item was selected from the list!
            // yourCallbackHere()
            var select_prt = opts[i].value;
            //alert(opts[i].value);
            break;
          }
        }
        $.ajax({
            type: "POST",
            url: "ajx.php",
            data: "serc_part=" + select_prt,
            cache: false,
           beforeSend: function() {
                $('#party_list').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                    $("#party_list").html(html);
            }
        });
  }
</script>


<script>
        function prdct_srch() {
            var val = document.getElementById("prdt_plist").value;
            var opts = document.getElementById('plist').childNodes;
            for (var i = 0; i < opts.length; i++) {
              if (opts[i].value === val) {
                var select_prdct = opts[i].value;
                break;
              }
            }
            $.ajax({
                type: "POST",
                url: "ajx.php",
                data: "serc_prdct_code=" + select_prdct,
                cache: false,
              beforeSend: function() {
                    $('#td_code').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                        $("#td_code").html(html);
                }
            });
            $.ajax({
                type: "POST",
                url: "ajx.php",
                data: "serc_prdct_s_rt=" + select_prdct,
                cache: false,
              beforeSend: function() {
                    $('#td_Sales').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                        $("#td_Sales").html(html);
                }
            });
      }
</script>

<script>
    function Qty_inp()
    {
        var sel_qty = document.getElementById("qty_input").value;
        $.ajax({
            type: "POST",
            url: "ajx.php",
            data: "qty_inp_ttl=" + sel_qty,
            cache: false,
          beforeSend: function() {
                $('#td_Total').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                    $("#td_Total").html(html);
            }
        });
         $.ajax({
            type: "POST",
            url: "ajx.php",
            data: "qty_inp_gst=" + sel_qty,
            cache: false,
          beforeSend: function() {
                $('#td_GST').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                    $("#td_GST").html(html);
            }
        });
         $.ajax({
            type: "POST",
            url: "ajx.php",
            data: "qty_inp_gstr=" + sel_qty,
            cache: false,
          beforeSend: function() {
                $('#td_GST_R').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                    $("#td_GST_R").html(html);
            }
        });
         $.ajax({
            type: "POST",
            url: "ajx.php",
            data: "qty_inp_sub=" + sel_qty,
            cache: false,
          beforeSend: function() {
                $('#td_Sub').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                    $("#td_Sub").html(html);
            }
        });
    }
</script>

<label id='second_label'></label>
<script>
    function fst_frmsubmit()
    {
        fst_qty_input = $("#qty_input").val();
        document.cookie = "qty_cokie="+fst_qty_input;
        fst_prdt_plist = $("#prdt_plist").val();
        document.cookie = "pdt_cokie="+fst_prdt_plist;
        party_dlist = $("#party_dlist").val();
        if(fst_qty_input != '' && fst_prdt_plist != '')
        {
            $.ajax({
                type: "POST",
                url: "ajx.php",
                data: {  
                        fst_frm_sub : 'formfirst',
                        fst_qty_input : fst_qty_input,
                        fst_prdt_plist : fst_prdt_plist,
                        party_dlist : party_dlist
                    },
                cache: false,
                beforeSend: function() {
                    $('#party_list').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                        $("#party_list").html(html);
                }
            });
        }
        else
        {
            alert('quantity and products not be empty')
        }
    }
</script>

<script>
    function nxt_frm_sub()
    {
        prdt_plist_nxt = $("#prdt_plist").val();
        qty_input_nxt = $("#qty_input").val();
        
        if(prdt_plist_nxt != '' && qty_input_nxt != '')
        {
            $.ajax({
                type: "POST",
                url: "ajx.php",
                data: {  
                        nxt_frm_sub : 'formnext',
                        product_next : prdt_plist_nxt,
                        quantity_next : qty_input_nxt
                    },
                cache: false,
                beforeSend: function() {
                    $('#party_list').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                        $("#party_list").html(html);
                }
            });
        }
        else
        {
            alert('quantity and products not be empty')
        }
        
        
    }
</script>

<script>
    function del_bill(pdt_2,qty_2)
    {
        prdt_plist_nxt ='';
        qty_input_nxt = '';
        alert(pdt_2+qty_2);
        $.ajax({
                type: "POST",
                url: "ajx.php",
                data: {  
                        delete_bill : 'bill_del',
                        pdt_2 : pdt_2,
                        qty_2 : qty_2
                        
                    },
                cache: false,
                beforeSend: function() {
                    $('#party_list').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#party_list").html(html);
                    // nxt_frm_sub();
                    $.ajax({
                        type: "POST",
                        url: "ajx.php",
                        data: {  
                                nxt_frm_sub : 'formnext',
                                product_next : prdt_plist_nxt,
                                quantity_next : qty_input_nxt
                            },
                        cache: false,
                        beforeSend: function() {
                            $('#party_list').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
                        },
                        success: function(html) {
                                $("#party_list").html(html);
                        }
                    });
                }
            });
        
    }
</script>


<a href="billingpdf2.php?type=original" ><button>original</button></a><br>
<a href="billingpdf2.php?type=duplicate" ><button>duplicate</button></a><br>
<a href="billingpdf2.php?type=triplicate" ><button>triplicate</button></a>


<br><br><br><br>
<form method="post" enctype="multipart/form-data">
    <label>Name: </label> <input type="text" name="name" placeholder="Name"> <br>
    <label>Address:</label> <input type="text" name="adds" placeholder="Address"> <br>
    <label>Place:</label> <input type="text" name="place" placeholder="Place"> <br>
    <label>Post:</label> <input type="text" name="post" placeholder="Post"> <br>
    <label>District:</label> <input type="text" name="dist" placeholder="District"> <br>
    <label>State:</label> <input type="text" name="state" placeholder="State"> <br>
    <label>Pincode:</label> <input type="text" name="pin" placeholder="Pincode"> <br>
    <label>Font style:</label> <input type="text" name="font_style" placeholder="Font"> <br>
    <label>Logo:</label><input type="file" name="billr_logo" multiple> <br>
    <input type="submit" name="biller_form_sub" >
</form>

<?php
    if(isset($_POST['biller_form_sub']))
    {
        $name=$_POST['name'];
        $adds=$_POST['adds'];
        $place=$_POST['place'];
        $post=$_POST['post'];
        $dist=$_POST['dist'];
        $state=$_POST['state'];
        $pin=$_POST['pin'];
        $font_style=$_POST['font_style'];
        
        echo $fin_adds = $adds.",".$place.",".$post.",".$dist.",".$state.",".$pin;            
        echo "<br>";
        $imagge = $_FILES['billr_logo']['tmp_name'];
        $image_view =file_get_contents($imagge);
        echo $image =addslashes(file_get_contents($imagge));
        if($name != '' && $fin_adds != '')
        {
            $sq_bllr="INSERT INTO `biller`(`id`, `name`, `adds`, `font_styl`, `logo`) VALUES (NULL, '$name', '$fin_adds', '$font_style', '$image')";
            $re_bllr=mysqli_query($clogin, $sq_bllr);
            if($re_bllr)
            {
                echo "<script>alert('success');</script>";
            }
            
            $sq_bllrsel="SELECT * FROM biller WHERE name = '$name' AND adds='$fin_adds' AND font_styl='$font_style'";
            $re_bllrsel=mysqli_query($clogin, $sq_bllrsel);
            $rw_bllrsel=mysqli_fetch_array($re_bllrsel);
            $SESSION['biller_id']=$rw_bllrsel['id'];
        }
        else
        {
            echo "<script>alert('values not be empty');</script>";
            
        }
        
        if(isset( $_SESSION['biller_id']))
        {
            echo  $_SESSION['biller_id'];
        }
        
        
    }
?>