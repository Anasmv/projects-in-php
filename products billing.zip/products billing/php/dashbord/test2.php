<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>


<button type='button' onclick='next_prdt()'>+</button>
<table id="next_pdct_s">aa</table>
    <script>
        var intTextBox = 1;
        function next_prdt()
        {
            intTextBox++;
            var objNewDiv = document.createElement('div');
            objNewDiv.setAttribute('id', 'div_' + intTextBox);
            objNewDiv.innerHTML = "<input list='plist' placeholder = 'search a product name' id='next_prdlist" +intTextBox+ "' required name='prdt_plist[]"+intTextBox+"' oninput='nxt_prdct_srch(" +intTextBox+ ");'>" +
                "<datalist id='plist"+intTextBox+"'>" +
                      <?php 
                      $sql_p='SELECT * FROM products ';
                      $re_p=mysqli_query($clogin, $sql_p);
                      while ($rw_p = mysqli_fetch_array($re_p)) { $name=$rw_p['name']; $id=$rw_p['id']; ?>
                          "<option value='<?php echo $name; ?>'></option>" +
                      <?php
                      } ?>
                "</datalist> " +
                "<label id='prdct_list" + intTextBox + "'></label>" + 
                "<input type='text' required name='nw_qty_arr[]"+intTextBox+"' placeholder='enter number of quantity'>";
            document.getElementById('next_pdct_s').appendChild(objNewDiv);
            document.cookie = "lastid_nextpdt="+intTextBox;
        }
    </script>