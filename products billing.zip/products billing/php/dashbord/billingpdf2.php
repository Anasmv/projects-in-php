<?php
session_start();
//$billler_id=$_SESSION['biller_id'];
$billler_id='1'; //for testing
include("../../../sahayi/php/mpdf57/mpdf.php");
$mpdf = new mPDF();
$title = 'Billing | PDF';
$mpdf->SetTitle($title);
//$mpdf->SetHeader('Document Title Document Title |Center Text|{PAGENO}');
//$mpdf->SetFooter('Document Title');

$con = new mysqli("localhost", "sahayikendra", "sahayikendra@Azalea", 'commonlog');
// $res=mysqli_query($con,"select * from biller WHERE id='$billler_id'");
// $row=mysqli_fetch_array($res);
$sql="select * from biller WHERE id='$billler_id'";
$res = $con->query($sql);
$row = $res->fetch_assoc();
    
$billr_nm=$row['name'];
$billr_ad=$row['adds']; //array (,,,)
$billr_ft=$row['font_styl'];
$billr_lg=$row['logo'];
$bill_ads_ar = explode(",", $billr_ad);
//$mpdf->AliasNbPages();
//$mpdf->AddPage();

$html_open="
<html>
    <head>
        <style>
            #celltable {
              border-collapse: collapse;
            }
            #celltable, #celltd, #cellth {
              border: 1px solid black;
            }
        </style>
    </head>
    <body>
    ";

//biller table structure head

if(isset($_GET['type']))
{
    if($_GET['type'] == 'original')
    {
        $lg_nm.="<h3>Original</h3>";
    }
    if($_GET['type'] == 'duplicate')
    {
        $lg_nm.="<h3>Duplicate</h3>";
    }
    if($_GET['type'] == 'triplicate')
    {
        $lg_nm.="<h3>Triplicate</h3>";
    }
}

$lg_nm.="
        <table id='celltable'>
            <tr>
                <td  style='width:200px; height:100;' id='celltd'>LOGO</td>
                <td  style='width:700px; height:100;' align='center' id='celltd'>c_name_address</td>
            </tr>
        </table>
        <br>
        <table id='celltable'>
            <tr>
                <td align='center' style='width:900px;' id='celltd'>
                    <h2>Tax Invoice</h2>
                </td>
            </tr>
        </table>
        
        <table>
            <tr>
                <td align='left' style='width:300px;'>
                    <label>Bill No:</label>
                </td>
                <td align='right' style='width:300px;'>
                    <label align='right'>Date:</label>
                </td>
            </tr>
        </table>
        
        <table id='celltable'>
            <tr>
                <td align='center' style='width:450px;' id='celltd'>Billed to:</td>
                <td align='center' style='width:450px;' id='celltd'>Shipped to:</td>
            </tr>
            <tr>
                <td  style='width:450px; height:100;' id='celltd'>
                    <b>$billr_nm</b> <br>
                    $bill_ads_ar[0] <br>
                    $bill_ads_ar[1], $bill_ads_ar[2] <br>
                    $bill_ads_ar[3], $bill_ads_ar[4]-$bill_ads_ar[5]
                </td>
                <td  style='width:450px; height:100;' id='celltd'>
                    <b>$billr_nm</b> <br>
                    $bill_ads_ar[0] <br>
                    $bill_ads_ar[1], $bill_ads_ar[2] <br>
                    $bill_ads_ar[3], $bill_ads_ar[4]-$bill_ads_ar[5]
                </td>
            </tr>
        </table>
    ";
$mpdf->SetHTMLHeader($lg_nm);
//header html
$mpdf->WriteHTML($html_open);

//billing table
$table_bill = "
<br><br><br><br><br><br><br><br><br><br><br><br><br>
        <style>
            #celltable {
              border-collapse: collapse;
            }
            #celltable, #celltd, #cellth {
              border: 1px solid black;
            }
            table.c {
              table-layout: auto;
              width: 100%;  
            }
        </style>
    <table id='celltable' class='c'>
        <tr>
            <th id='celltd'>Sl no</th>
            <th id='celltd'>Commodity</th>
            <th id='celltd'>Code</th>
            <th id='celltd'>Sales Rate</th>
            <th id='celltd'>QUANTITY</th>
            <th id='celltd'>Total</th>
            <th id='celltd'>GST</th>
            <th id='celltd'>IGST</th>
            <th id='celltd'>GST Rate</th>
            <th id='celltd'>Sub Total</th>
        </tr>";
        
        $insert_id = $_SESSION['ins_id']='101';
        $sq_b2="SELECT * FROM billing WHERE id = '$insert_id'"; 
        $re_b2=mysqli_query($con, $sq_b2);
        $rw_b2=mysqli_fetch_array($re_b2);
        $nxt_bill = $rw_b2['bill'];
        $nxt_bill1=ltrim(substr_replace($nxt_bill,"",-1),"{");
        $delimiter = array(" ","/","}{","{","}",);
        $replace = str_replace($delimiter, $delimiter[0], $nxt_bill1);
        $explode = explode($delimiter[0], $replace);
        //$odd = array_filter($input, "oddCmp");
        //for testing
        //echo $explode = "{8,15}";
        print_r($explode);
        $no=1;
        $sum_qty = 0;
        $sum_ttl = 0;
        $sum_gst = 0;
        $sum_subttl = 0;
        foreach ($explode as $line) {
            $table_bill.= "<tr>";
            //echo $line.'<br>';
            $array1  = explode(",", $line);
            
            foreach ($array1 as $line1) {
                //echo $line1;
                if($line1 != '')
                {
                    $sq_prdt1 = "SELECT * FROM products WHERE id = '$line1'";
                    $re_prdt1 = mysqli_query($con, $sq_prdt1);
                    $ro_prdt1 = mysqli_fetch_array($re_prdt1);
                    
                    $prt_nm = $ro_prdt1['name'];
                    $prt_id = $ro_prdt1['id'];
                    if($line1 == $prt_id)
                    {
                        if($prt_id != '')
                        {
                            $table_bill.= "<td id='celltable'>$no</td>";
                            $pdt_2nm=$prt_nm;
                            $table_bill.= "<td id='celltable'>".$prt_nm .'</td>';
                            $p_code=$ro_prdt1['code'];
                            $table_bill.= "<td id='celltable'>".$ro_prdt1['code']."</td>";
                            $s_rate = $ro_prdt1['sales_rate'];
                            $table_bill.= "<td id='celltable'>".$s_rate."</td>";
                            $sqst = $ro_prdt1['sgst'];
                            $igst = $ro_prdt1['igst'];
                            $cgst = $ro_prdt1['cgst'];
                            $sum_sgst += $sqst;
                            $sum_cgst += $cgst;
                        }
                    }
                    else
                    {
                        $qnty1 = $line1;
                        $sum_qty +=  $qnty1;
                        $table_bill.= "<td id='celltable'>".$qnty1.'</td>';
                        $ttl = ($s_rate * $qnty1);
                        $sum_ttl += $ttl;
                        $table_bill.= "<td id='celltable'>$ttl</td>";
                        
                        
                        if($sqst == '' && $cgst == '')
                        {
                            $ggst = $igst;
                            
                            $table_bill.= "<td id='celltable'></td>";
                            $table_bill.= "<td id='celltable'>$ggst</td>";
                        }
                        else
                        {
                            $ggst = $sqst;
                            
                            $table_bill.= "<td id='celltable'>$ggst</td>";
                            $table_bill.= "<td id='celltable'></td>";
                        }
                        
                        
                        $y = ($ttl * (($ggst)/100));
                        $table_bill.= "<td id='celltable'>$y</td>";
                        
                        $sum_gst += $y;
                        
                        $subttl = ($ttl + $y);
                        $sum_subttl += $subttl;
                        $table_bill.= "<td id='celltable'>$subttl</td>";
                    }
                }
            }
            $table_bill.= "</tr>";
            $no++; 
        }
        
        $table_bill.="
        <tr>
            <td id='celltable'>total</td>
            <td id='celltable'></td>
            <td ></td>
            <td id=''></td>
            <td id='celltable'>$sum_qty</td>
            <td id='celltable'>$sum_ttl</td>
            <td id='celltable'></td>
            <td id='celltable'>$sum_gst</td>
            <td id='celltable'>$sum_subttl</td>
        </tr>
    </table>
    <br>
    ";
    
$table_test= "
        <style>
            #left {
                float: left; 
                width: 40%;
            }
    		#middle {
                float: left; 
                width: 40%;
            }
            #right {
                width: 20%;
            }
        </style>";
        
$table_test.="
    <div id='left'> 
        <table>";
            $insert_id = $_SESSION['ins_id']='101';
            $sq_b2="SELECT * FROM billing WHERE id = '$insert_id'"; 
            $re_b2=mysqli_query($con, $sq_b2);
            $rw_b2=mysqli_fetch_array($re_b2);
            $nxt_bill = $rw_b2['bill'];
            $nxt_bill1=ltrim(substr_replace($nxt_bill,"",-1),"{");
            $delimiter = array(" ","/","}{","{","}",);
            $replace = str_replace($delimiter, $delimiter[0], $nxt_bill1);
            $explode = explode($delimiter[0], $replace);
            foreach ($explode as $line) {
                $table_bill.= "<tr>";
                //echo $line.'<br>';
                $array1  = explode(",", $line);
                foreach ($array1 as $line1) {
                    //echo $line1;
                    if($line1 != '')
                    {
                        $sq_prdt1 = "SELECT * FROM products WHERE id = '$line1'";
                        $re_prdt1 = mysqli_query($con, $sq_prdt1);
                        $ro_prdt1 = mysqli_fetch_array($re_prdt1);
                        
                        $prt_nm = $ro_prdt1['name'];
                        $prt_id = $ro_prdt1['id'];
                        $sqst_arry[] = $sqst = $ro_prdt1['sgst'];
                        $igst_arry[] = $igst = $ro_prdt1['igst'];
                        $cgst_arry[] = $cgst = $ro_prdt1['cgst'];
                        if($line1 == $prt_id)
                        {
                            if($prt_id != '')
                            {
                                if($sgst != '' || $cgst != '')
                                {
                                //     $table_test.="<tr>
                                //                     <td>CGST</td><td>";
                                //     $table_test.=$cgst;
                                    
                                //     $table_test.="</td></tr>";
                                // // }
                                // // if($sgst != '')
                                // // {
                                //     $table_test.="<tr>
                                //                     <td>SGST</td><td>";
                                //     $table_test.=$sqst;
                                //     $table_test.="</td></tr>";
                                }
                            }
                        }
                    }
                }  
            }
            
            $uniq_sgst = array_unique($sqst_arry);
            foreach($uniq_sgst as $sgst1)
            {
                if($sgst1 != '')
                {
                    $table_test.="<tr>
                                    <td>SGST</td><td>";
                    $table_test.=$sgst1;
                    
                    $table_test.="</td></tr>";
                }
            }
            
            $uniq_cgst = array_unique($cgst_arry);
            foreach($uniq_cgst as $cgst1)
            {
                if($cgst1 != '')
                {
                    $table_test.="<tr>
                                    <td>CGST</td><td>";
                    $table_test.=$cgst1;
                    
                    $table_test.="</td></tr>";
                }
            }
            
$table_test.="
        </table>
    </div> 
		
		<div id='middle'>
		<br><br>
        </div> 
          
        <div id='right'> 
            <table id='celltable'>
                <tr>
                    <td id='celltable'>Total</td>
                    <td id='celltable'>$sum_ttl</td>
                </tr>
                <tr>
                    <td id='celltable'>SGST</td>
                    <td id='celltable'>$sum_sgst</td>
                </tr>
                <tr>
                    <td id='celltable'>CGST</td>
                    <td id='celltable'>$sum_cgst</td>
                </tr>
                <tr>
                    <td id='celltable'>Cess</td>
                    <td id='celltable'>0</td>
                </tr>
                <tr>
                    <td id='celltable'>GRAND TOTAL</td>";
                    $g_ttl =  ($sum_ttl + $sum_sgst + $sum_cgst) ;
$table_test.=     "<td id='celltable'>$g_ttl</td>
                </tr>
            </table>
        </div>
        ";
        
        
           
$number = $g_ttl;
   $no = floor($number);
   $point = round($number - $no, 2) * 100;
   $hundred = null;
   $digits_1 = strlen($no);
   $i = 0;
   $str = array();
   $words = array('0' => '', '1' => 'one', '2' => 'two',
    '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
    '7' => 'seven', '8' => 'eight', '9' => 'nine',
    '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
    '13' => 'thirteen', '14' => 'fourteen',
    '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
    '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
    '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
    '60' => 'sixty', '70' => 'seventy',
    '80' => 'eighty', '90' => 'ninety');
   $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
   while ($i < $digits_1) {
     $divider = ($i == 2) ? 10 : 100;
     $number = floor($no % $divider);
     $no = floor($no / $divider);
     $i += ($divider == 10) ? 1 : 2;
     if ($number) {
        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
        $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $str [] = ($number < 21) ? $words[$number] .
            " " . $digits[$counter] . $plural . " " . $hundred
            :
            $words[floor($number / 10) * 10]
            . " " . $words[$number % 10] . " "
            . $digits[$counter] . $plural . " " . $hundred;
     } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ?
    "." . $words[$point / 10] . " " . 
          $words[$point = $point % 10] : '';
  //echo $result . "Rupees  " . $points . " Paise";
  
     
$table_test.=     "<p>$result</p>";
 
    
    
    

$mpdf->writeHtml($table_bill);
$mpdf->writeHtml($table_gst);
$mpdf->writeHtml($table_ttl);
$mpdf->writeHtml($table_test);

$html_close="
    </body>
</html>";
$mpdf->writeHtml($html_close);
$mpdf->Output();
exit;
?>