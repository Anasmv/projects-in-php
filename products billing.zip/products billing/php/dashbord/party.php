<?php if(!isset($_SESSION)) { session_start(); }
echo $login_id=$_SESSION['id'];
include('../connect/con.php'); ?>
<form method="post">
    <input type="text" name="party_nm" placeholder="Enter name"><br>
    <input type="text" name="party_adds" placeholder="Enter address"><br>
    <input type="text" name="party_ph" placeholder="Enter phone number"><br>
    <input type="text" name="party_gst" placeholder="Enter GSTIN"><br>
    <input type="submit" name="party_add" value="add party">
</form>

<?php
if(isset($_POST['party_add']))
{
    $party_nm=$_POST['party_nm'];
    $party_adds=$_POST['party_adds'];
    $party_ph=$_POST['party_ph'];
    $party_gst=$_POST['party_gst'];
    $sq_prt="INSERT INTO party (`id`, `name`, `adds`, `phon`, `GSTIN`, `user`) VALUES (NULL, '$party_nm', '$party_adds', '$party_ph', '$party_gst', '$login_id')";
    $re_prt=mysqli_query($clogin, $sq_prt);
    if($re_prt)
    {
        echo "<script> alert('success'); </script>";
    }
}
?>