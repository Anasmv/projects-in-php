<?php
    $hostname = "localhost";
    $userid = "sahayikendra";
    $password = "sahayikendra@Azalea";
    $clogin = mysqli_connect($hostname, $userid, $password, 'commonlog');
   
?>