<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<?php
if (!isset($_SESSION)) { session_start(); }
$urlc = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
include('php/connect/con.php');
?>
    <body><br><br><br><br>
        <form action="" method="POST" id="viewpart">
            <div class="log">
                <div class="form-group texting-in">
                    <fieldset>
                        <input type="text" class="rounded form-control" name="name" id="user" required />
                        <label for="psw"><span class="fas fa-eye"></span> Username</label>
                    </fieldset>
                </div>
                <div class="form-group texting-in">
                    <fieldset>
                        <input type="password" class="rounded form-control" name="password" id="password" required />
                        <label for="psw"><span class="fas fa-lock"></span> Password</label>
                    </fieldset>
                </div>
                <!--input  id="username" name="name" required="required" placeholder="Email" type="text">
        		<input class="form-control" id="password" name="password"   required="required" placeholder="password" type="password"-->
        		<button type="submit" name="sub" value="SUBMIT" class="rounded btn btn-success btn-block">login</button><br>
        	<a onclick='forgttt();'>Forgot Password ?</a>  
            </div>
    	</form>
    </body>
    
	<script>
        function forgttt() { 
            $(document).attr("title","FORGOT");
            $("#viewpart").html("");
            $.ajax({
                type: "POST",
                url: "<?php $urlc?>/commonlogin/php/dashbord/forgot.php",
                cache: false,
                beforeSend: function() {
                    $('#viewpart').html('<img src="http://www.sahayikendra.com/sahayi/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#viewpart").html(html);
                }
            });
        }
    </script>
        
<?php  
    if(isset($_POST['sub']))
    {
        $us=$_POST['name'];
        $pwd=$_POST['password'];
        
        $sql="select * from comlog where (email='$us' or user_name='$us')";
        $ww=mysqli_query($clogin,$sql);
        $s=mysqli_num_rows($ww);
        $row=mysqli_fetch_array($ww);
        $uid=$row['id'];
        $_SESSION['id']=$uid;
        $pass=$row['password'];
        if(password_verify($pwd, $pass))
        {
            if($s>0)
            {
                echo'<script>alert("logined ");</script>';        
                echo"<script>window.open('php/dashbord/index.php','_self')</script>";
            } 
        }
        else
        {
            echo'<script>alert("error");</script>';  
            //   echo"<script>window.open('regcand.php','_self')</script>"; 
        }
    }
?>