This is the sample code from the book [Professional PHP: 
Learn how to build maintainable and secure applications
](http://patricklouys.com/professional-php/).

### Disclaimer

This code is not ready for production. This repository is just intended as a reference for the readers of the book.