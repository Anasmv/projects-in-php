<?php declare(strict_types=1);

namespace SocialNews\Framework\Rbac\Permission;

use SocialNews\Framework\Rbac\Permission;

final class SubmitLink extends Permission
{
}