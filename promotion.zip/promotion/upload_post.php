<?php
require_once('database1.php');
$qr="select * from login";
$data=mysqli_query($con,$qr);
$row=mysqli_fetch_assoc($data);
?>
<html>
<head><title>
	</title>
</head>
<body>
	<table  align="center">
	<form action="upload_action_post.php" method=POST>
	<tr><td>type:&nbsp&nbsp</td><td><input type="text" name="type" value="<?php echo $row['acc_type'];?>"></td></tr><br>
	<tr><td>upload:&nbsp&nbsp</td><td><input type="file" name="upload"></td></tr><br>
	<tr><td>email:&nbsp&nbsp</td><td><input type="text" name="email" value="<?php echo $row['email'];?>"></td></tr><br>
	<tr><td colspan=2><input type="submit" value="upload" name="submit"></td></tr>
	</form>
</table>
	</body>
</html>