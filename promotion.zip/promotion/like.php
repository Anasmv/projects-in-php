<?php
require_once('database1.php');
if(isset($_GET['id']))
{
$id=$_GET['id'];
$qr1="select like from like";
$data=mysqli_query($con,$qr1);
while($row=mysqli_fetch_assoc($data))
{
	$like=$row['like'];
}
$qr="update like set like=$like+1 where id='$id'";
echo $qr;
mysqli_query($con,$qr);
}
?>