<?php
require_once('database1.php');
if(isset($_POST['uu']))
{
$id=$_GET['id'];
$acc_type=$_POST['acc_type'];
$max_chlimit=$_POST['max_chlimit'];
$mon_postlimit=$_POST['mon_postlimit'];
$lin_viewlimit=$_POST['lin_viewlimit'];
$ch_sublimit=$_POST['ch_sublimit'];
$qr="update acc_tbl set acc_type='$acc_type',max_chlimit='$max_chlimit',mon_postlimit='$mon_postlimit',lin_viewlimit='$lin_viewlimit',ch_sublimit='$ch_sublimit' where id='$id'";
echo $qr;
mysqli_query($con,$qr);
}
?>