<?php
require_once('database1.php');
$qr="select * from acc_tbl";
$data=mysqli_query($con,$qr);
$row=mysqli_fetch_assoc($data);
?>
<html>
<head><title>
	</title>
</head>
<body>
	<table  align="center">
	<form action="userreg1_form.php" method=POST>
	<tr><td>firstname:&nbsp&nbsp</td><td><input type="text" name="firstname"></td></tr><br>
	<tr><td>lastname:&nbsp&nbsp</td><td><input type="text" name="lastname"></td></tr><br>
	<tr><td>email:&nbsp&nbsp</td><td><input type="text" name="email"></td></tr><br>
	<tr><td>smail:&nbsp&nbsp</td><td><input type="text" name="smail"></td></tr><br>
	<tr><td>password:&nbsp&nbsp</td><td><input type="password" name="password"></td></tr><br>
	<tr><td>conform password:&nbsp&nbsp</td><td><input type="password" name="hpassword"></td></tr><br>
	<tr><td>mobile:&nbsp&nbsp</td><td><input type="text" name="mobile"></td></tr><br>
	<tr><td>type:&nbsp&nbsp</td><td><input type="text" name="type" value="<?php echo $row['acc_type'];?>"></td></tr>
	<tr><td colspan=2><input type="submit" value="save" name="submit"></td></tr>
</form>
</table>
	</body>
</html>