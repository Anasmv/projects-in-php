<?php
require_once('database1.php');
//$_SESSION['id']=$id;
$acc_type=$_POST['acc_type'];
$max_chlimit=$_POST['max_chlimit'];
$mon_postlimit=$_POST['mon_postlimit'];
$lin_viewlimit=$_POST['lin_viewlimit'];
$ch_sublimit=$_POST['ch_sublimit'];
$qr="insert into acc_tbl (`acc_type`,`max_chlimit`,`mon_postlimit`,`lin_viewlimit`,`ch_sublimit`) values ('$acc_type','$max_chlimit','$mon_postlimit','$lin_viewlimit','$ch_sublimit')";
echo $qr;
mysqli_query($con,$qr);
?>