-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Dec 05, 2018 at 06:17 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `promotion`
--

-- --------------------------------------------------------

--
-- Table structure for table `acc_tbl`
--

CREATE TABLE IF NOT EXISTS `acc_tbl` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `acc_type` varchar(50) NOT NULL,
  `max_chlimit` int(30) NOT NULL,
  `mon_postlimit` int(30) NOT NULL,
  `lin_viewlimit` int(50) NOT NULL,
  `ch_sublimit` int(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `acc_tbl`
--

INSERT INTO `acc_tbl` (`id`, `acc_type`, `max_chlimit`, `mon_postlimit`, `lin_viewlimit`, `ch_sublimit`) VALUES
(1, 'bronze', 1, 5, 4000, 1),
(2, 'star', 1, 15, 15, 1),
(5, 'silver', 1, 25, 2000, 1),
(6, 'gold', 1, 30, 4000, 2),
(7, 'platinum', 1, 0, 7000, 5),
(9, 'diamond', 1, 0, 10000, 10);

-- --------------------------------------------------------

--
-- Table structure for table `like`
--

CREATE TABLE IF NOT EXISTS `like` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `link` varchar(50) NOT NULL,
  `like` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `like`
--

INSERT INTO `like` (`id`, `link`, `like`) VALUES
(1, 'like-unlike-using-ajax-jquery-', '0'),
(3, 'Sublime Text Build 3176 x64 Se', '0');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `smail` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `hpassword` varchar(50) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `type` varchar(50) NOT NULL,
  `status` int(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `link` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `type`, `link`, `email`) VALUES
(1, 'bronze', 'like-unlike-using-ajax-jquery-', 'gokul@gmail.com'),
(3, 'bronze', 'Sublime Text Build 3176 x64 Se', 'kiran@gmail.com'),
(4, 'bronze', 'registration (1).sql', 'gk@gmail.com'),
(5, 'bronze', 'registration (1).sql', 'gk@gmail.com'),
(6, 'bronze', 'DTLiteInstaller.exe', 'vishnu@gmail.com'),
(7, 'bronze', 'DTLiteInstaller.exe', 'vishnu@gmail.com'),
(8, 'bronze', 'DTLiteInstaller.exe', 'vishnu@gmail.com'),
(9, 'bronze', 'login.sql', 'vishnu@gmail.com'),
(10, 'bronze', 'login.sql', 'vishnu@gmail.com'),
(11, 'bronze', 'Sublime Text Build 3176 x64 Se', 'kiran@gmail.com');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
