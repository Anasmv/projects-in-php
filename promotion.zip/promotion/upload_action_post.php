<?php
require_once('database1.php');
if(isset($_POST['submit']))
{
$type=$_POST['type'];
$upload=$_POST['upload'];
$email=$_POST['email'];
$qr="insert into user(`id`,`type`,`link`,`email`) values ('','$type','$upload','$email')";
echo $qr;
mysqli_query($con,$qr);
$qr1="insert into like (`id`,`link`,`like`) values ('','$upload','')";
echo $qr1;
mysqli_query($con,$qr1);
}
?>