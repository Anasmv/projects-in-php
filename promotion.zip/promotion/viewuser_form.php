<?php
require_once('database1.php');
echo"<table border=1>";
echo"<tr><td>id</td><td>firstname</td><td>lastname</td><td>email</td><td>smail</td><td>password</td><td>mobile</td><td>type</td><td>status</td></tr>";
$qr="select * from login";
$data=mysqli_query($con,$qr);
while($row=mysqli_fetch_assoc($data))
{
echo"<tr><td>$row[id]</td><td>$row[firstname]</td><td>$row[lastname]</td><td>$row[email]</td><td>$row[smail]</td><td>$row[password]</td><td>$row[mobile]</td><td>$row[type]</td><td>$row[status]</td><td><a href='useredit_form.php?ed=$row[id]'>edit</a></td></tr>";
}
echo"</table>";
?>