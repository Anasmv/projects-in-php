<?php
require_once('database1.php');
if(isset($_POST['submit']))
{
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$smail=$_POST['smail'];
$password=$_POST['password'];
$pass=$_POST['hpassword'];
$mobile=$_POST['mobile'];
$type=$_POST['type'];
$hashed=md5('$pass');
$qr="insert into login ('id','firstname','lastname','email','smail','password','hpassword','mobile','type','status')values ('','$firstname','$lastname','$email','$smail','$password','$hashed',$mobile','$type','')";
echo $qr;
mysqli_query($con,$qr);
}
?>