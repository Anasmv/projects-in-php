<?php
require_once('database1.php');
if(isset($_GET['del']))
{
$id=$_GET['del'];
$qr="delete  from acc_tbl where id='$id'";
echo $qr;
mysqli_query($con,$qr);
}
?>