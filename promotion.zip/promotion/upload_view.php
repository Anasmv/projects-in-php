<?php
require_once('database1.php');
echo"<table  align=center>";
echo"<tr><td>type</td><td>link</td></tr>";
$qr="select * from user";
$data=mysqli_query($con,$qr);
while($row=mysqli_fetch_assoc($data))
{
echo"<tr><td>$row[type]</td><td>$row[link]</td><td><a href='like.php?id=$row[id]'>like</a></td><td><a href='subscribe.php?id=$row[id]'>subscribe</a></td><td><a href='watch.php?id=$row[id]'>watch</a></tr>";
}
echo"</table>";
?>
