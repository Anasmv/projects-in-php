<?php
require_once('database1.php');
if(isset($_GET['ed']))
{
$id=$_GET['ed'];
$qr="select * from acc_tbl where id='$id'";
$data=mysqli_query($con,$qr);
$s=mysqli_fetch_assoc($data);
}
?>
<form action="adminedd_accnt.php?id=<?php echo $s['id'];?>" method=POST>
Account type : <input name="acc_type" value="<?php echo $s['acc_type'];?>">
Max.channel limit:<input name="max_chlimit" value="<?php echo $s['max_chlimit'];?>">
Mon.post limit:<input  name="mon_postlimit" value="<?php echo $s['mon_postlimit'];?>" >
Link view limit:<input  name="lin_viewlimit" value="<?php echo $s['lin_viewlimit'];?>" >
Channel subcribtion limit:<input  name="ch_sublimit" value="<?php echo $s['ch_sublimit'];?>" >																			<button type="submit" name="uu">edit</button>																																																										
	</form>