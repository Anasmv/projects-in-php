<?php
require_once('database1.php');
if(isset($_POST['uu']))
{
$id=$_GET['id'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$email=$_POST['email'];
$smail=$_POST['smail'];
$password=$_POST['password'];
$mobile=$_POST['mobile'];
$qr="update login set firstname='$firstname',lastname='$lastname',email='$email',smail='$smail',password='$password',mobile='$mobile', where id='$id'";
echo $qr;
mysqli_query($con,$qr);
}
?>