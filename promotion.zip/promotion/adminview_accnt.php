<?php
require_once('database1.php');
echo"<table border=1>";
echo"<tr><td>id</td><td>accounttype</td><td>max.channellimit</td><td>mon.postlimit</td><td>link viewlimit</td><td>cha.subscribelimit</td></tr>";
$qr="select * from acc_tbl";
$data=mysqli_query($con,$qr);
while($row=mysqli_fetch_assoc($data))
{
echo"<tr><td>$row[id]</td><td>$row[acc_type]</td><td>$row[max_chlimit]</td><td>$row[mon_postlimit]</td><td>$row[lin_viewlimit]</td><td>$row[ch_sublimit]</td><td><a href='adminedit_accnt.php?ed=$row[id]'>edit</a></td><td><a href='admindelete_accnt.php?del=$row[id]'>delete</a></td></tr>";
}
echo"</table>";
?>