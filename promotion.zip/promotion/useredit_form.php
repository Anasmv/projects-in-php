<?php
require_once('database1.php');
if(isset($_GET['ed']))
{
$id=$_GET['ed'];
$qr="select * from login where id='$id'";
$data=mysqli_query($con,$qr);
$s=mysqli_fetch_assoc($data);
}
?>
<form action="useredd_form.php?id=<?php echo $s['id'];?>" method=POST>
firstname : <input name="firstname" value="<?php echo $s['firstname'];?>">
lastname:<input name="lastname" value="<?php echo $s['lastname'];?>">
email:<input  name="email" value="<?php echo $s['email'];?>" >
smail:<input  name="smail" value="<?php echo $s['smail'];?>" >
password:<input  name="password" value="<?php echo $s['password'];?>" >
mobile:<input  name="mobile" value="<?php echo $s['mobile'];?>" >																	
<button type="submit" name="uu">edit</button>																																																										
	</form>