<?php
session_start();
$license="1234";
$con=mysqli_connect("localhost","root","","promotion");
?>