<?php
include("./include/headerout.php");
include("./include/link.php");
include('./include/conn/con.php');
include("./include/style.php");
    if (!isset($_SESSION)) 
            {
                session_start(); 
            }
            echo $cand_id= $_SESSION['emply_id'];
?>
    <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <br>
                    <br><br><br>
                    
                        <div class="progress round">
                            <div class="progress-bar" style="width:0%" id="prog"></div>
                        </div>
                        <br><br><br><br>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" align="center">
                                    <!--<div class="form-group col-xl-1 col-lg-1 col-md-1 col-sm-4 col-4 ">-->
                                    <!--<lable ><h3 style="font-size:20px"></h3></lable>-->
                                    
                                    <!--</div>-->
                                    
                            
                                <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-6 col-6 bg-primary text-light round text-center" id="personal" onclick="next();"> 
                                <lable ><h3 style="font-size:20px">Personal Details</h3></lable>
                                </div>
                                
                                <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-10 col-10 bg-secondary text-light round text-center" id="contact" onclick="next1();">
                                <lable ><h3>Contact Details</h3></lable>
                                </div>
                                
                                <!--<div class="form-group col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 bg-secondary text-light round text-center" id="education" onclick="next2();">-->
                                    <!--<lable ><h3>Educational Details</h3></lable>-->
                                <!--</div>-->
                                
                                <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" id="skill" onclick="next3();">
                                    <lable ><h3>Skill Set</h3></lable>
                                </div>
                                
                                <!--<div class="form-group col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 bg-secondary text-light round text-center" id="work" onclick="next4();">-->
                                    <!--<lable ><h3>Work Experience</h3></lable>-->
                                <!--</div>-->
                    </div>
                        
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
                            <form class="row" role="form" action="" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" onsubmit=" return validateform()">
                                
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="personal_details">
                                    <div class="form-group col-xl-9 col-lg-9 col-md-9 col-sm-7 col-7 text-center"> </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next1()">
                                    <lable ><h3>NEXT >> </h3></lable>
                                     </div>
                
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group ">
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-4 form-group float-left">
                                        <img class="round shadow border-light" border="1" width="100" height="100" name="image"  id="thumbnil">
                                        </div>
                                        <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-8 form-group float-left">
                                        <label for="InputName">Image <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="file" class="" name="myfile" id="image"  accept="image/*" onchange="showMyImage(this)" required>
                                        <label class="text-danger" for="InputName">image must be 'jpeg' or 'png'</label>
                                        </div>
                                    </div>
                    
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                            <label for="InputName">First Name <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="fname" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                         <label for="InputName">Last Name <span class="fas fa-star-of-life text-danger"></span></label>   
                                        <input type="text" class="form-control round" name="lname" id="InputName" required/>
                                         </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                            <label for="InputName"> Mother Name<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="mname" id="InputName" required/>
                                        </fieldset>
                                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                            <label for="InputName"> Father Name<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="faname" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="Inputsex"> Gender<span class="fas fa-star-of-life text-danger"></span></label>
                                        <select class="round form-control" name="sex">
                                          <option value="Male">Male</option>
                                          <option value="Female">Female</option>
                                          <option value="both">Both</option>
                                        </select>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputEmail">Date of Birth<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="date" class="round form-control" id="InputEmailFirst" name="dob" required/>
                                        </fieldset>
                        
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="Inputreligion">Religion <span class="fas fa-star-of-life text-danger"></span></label>
                                        <select name="religion"class="round form-control" required>
                                            <?php
                                            $s1 = "SELECT DISTINCT religion FROM `religion`" ;
                                            $q1=mysqli_query($emply_option,$s1);
                                            if(mysqli_num_rows($q1)>0)
                                            { 
                                            while($row1=mysqli_fetch_assoc($q1))
                                            {
                                            ?>
                                            <option value="<?php echo $row1['religion'];?>"><?php echo $row1['religion'];?></option>
                                            <?php
                                            }
                                    		}
                                            ?>
                                        </select>
                                         </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="Inputcast">Cast  <span class="fas fa-star-of-life text-danger"></span></label>
                                        <select name="cast" class="round form-control" required>
                                            <?php
                                            $s = "SELECT DISTINCT cast FROM `religion`" ;
                                            $q=mysqli_query($emply_option,$s);
                                            if(mysqli_num_rows($q)>0)
                                            { 
                                            while($row=mysqli_fetch_assoc($q))
                                            {
                                            ?>
                                            <option value="<?php echo $row['cast'];?>"><?php echo $row['cast'];?></option>
                                                                           
                                            <?php
                                            }
                                            }
                                            ?>
                                        </select>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="Identity Card Type">Identity Card Type <span class="fas fa-star-of-life text-danger"></label>
                                        <select name="identity_card_type" class="round form-control" required>
                                            <?php
                                            $s3 = "SELECT DISTINCT identity_card_type FROM `identity_card_type`" ;
                                            $q3=mysqli_query($emply_option,$s3);
                                            if(mysqli_num_rows($q3)>0)
                                            { 
                                            while($row3=mysqli_fetch_assoc($q3))
                                            {
                                            ?>
                                            <option value="<?php echo $row3['identity_card_type'];?>"><?php echo $row3['identity_card_type'];?></option>
                                                                               
                                            <?php
                                            }
                                            }
                                            ?>
                                        </select>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputEmail">Identity Card No<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" id="InputEmailFirst" name="id_no" required/>
                                        </fieldset>
                                    </div>                                    
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                            <label for="Inputlanguage">Language Known<span class="fas fa-star-of-life text-danger"></span></label><br>
                                            <input type="checkbox" name="vehicle[]" value="English" id="InputEmailFirst"> English<br>
                                            <input type="checkbox" name="vehicle[]" value="Malayalam" id="InputEmailFirst" checked> Malayalam<br>
                                        <!--<input type="text" class="form-control round" id="InputEmailFirst" name="language" required/>-->
                                                                                
                                         </fieldset>                                                                              
                        
                                    </div>
                                    
                                    <div class="form-group col-xl-9 col-lg-9 col-md-9 col-sm-7 col-7 text-center"> </div>
                                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" tabindex="7" onclick="next1()">
                                            <lable ><h3>NEXT >> </h3></lable>
                                        </div>
                                </div>
                    
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="contact_details">
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next()">
                                        <lable ><h3> << BACK</h3></lable>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next3()">
                                        <lable ><h3>NEXT >> </h3></lable>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Address1 <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="add1" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Address2 <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="add2" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName"> Address3<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="add3" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Pin code <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="number" class="form-control round" name="pin" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                   
                                        <SELECT type="text" class="round form-control"  tabindex="8" name="country" id="mylist" required onChange="showState(this)">
                                           
                                            <?php
                                            $sql = "SELECT DISTINCT country FROM area_table ORDER BY `area_table`.`country` ASC";
                                            $res=mysqli_query($emply_option,$sql);
                                            ?>
            								<option value="" >Please Select country</option>
                                            <?php while($row=$res->fetch_assoc())
            								{ ?>
                                                <option  value="<?php echo $row["country"]; ?>"><?php echo $row["country"]; ?></option>
                                            <?php } ?>
                                        </SELECT>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                        <SELECT type="text" class="round form-control" name="state" tabindex="9" id="output1" onchange="showDistrict(this);">
                                            <option value="" >Please Select state</option>
                                        </SELECT>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                        <SELECT type="text" class="round form-control" name="district" tabindex="10" id="output2" onchange="showlclType(this);">>
                                            <option value="" >Please Select district</option>
                                        </SELECT>
                                    </div>
                                   <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" id="newplace1">
                                     
                                        <SELECT type="text" class="round form-control" name="loc_type" tabindex="11" id="output5" onchange="showLclArea(this);">
                                            <option value="" >Select Local Body Type</option>
                                        </SELECT>
                                    </div>
                                    
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" id="newplace2">
                                        <SELECT type="text" class="round form-control" name="loc_name" tabindex="12" id="output3" onchange="showPlace(this);" >
                                            <option value="" >Select Local Body Name</option>
                                        </SELECT>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in" id="newplace3">
                                        <SELECT type="text" class="round form-control" name="place"  tabindex="13" id="output4" onchange="changeFunc2();" >
                                            <option value="" >Please Select Place</option>
                                        </SELECT>
                                    </div>
                                    
                                   
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next()">
                                        <lable ><h3> << BACK</h3></lable>
                                     </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6">
                                    </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next3()">
                                        <lable ><h3>NEXT >> </h3></lable>
                                    </div>
                                </div>
                                
                                <!--<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="Educational_Details">-->
                                <!--    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next1()">-->
                                <!--        <lable ><h3> << BACK</h3></lable>-->
                                <!--    </div>-->
                                <!--    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">-->
                            
                                <!--    </div>-->
                                <!--    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next3()">-->
                                <!--        <lable ><h3>NEXT >> </h3></lable>-->
                                <!--    </div>-->
                                <!--   <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">-->
                                <!--        <fieldset>-->
                                <!--        <label for="Inputcast">Qualification <span class="fas fa-star-of-life text-danger"></span></label>-->
                   
                                <!--        <SELECT type="text" class="round form-control"  tabindex="8" name="quali" id="mylist" required onChange="showState(this)">-->
            
                                            <?php
                                            
                                            // $sql = "SELECT DISTINCT Qualification FROM course ORDER BY `course`.`Qualification` ASC";
                                            // $res=mysqli_query($emply_option,$sql);
                                            ?>
            								<!--<option value="" ></option>-->
                                             <?php
                                            // while($row=$res->fetch_assoc())
            								// { 
            								?>
                                                <!--<option  value="<?php //echo $row["Qualification"]; ?>"><?php //echo $row["Qualification"]; ?></option>-->
                                            <?php //} ?>
                                <!--        </SELECT>-->
                                <!--    </div>-->
                                     
                                  
                                <!--    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">-->
                                <!--        <fieldset>-->
                                <!--        <label for="InputName">College<span class="fas fa-star-of-life text-danger"></span></label>-->
                                <!--        <input type="text" class="form-control round" name="college" id="InputName" required/>-->
                                <!--        </fieldset>-->
                              <!--    </div>-->
                                   
                                <!--     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">-->
                                <!--        <fieldset>-->
                                        <!--<label for="InputName">University<span class="fas fa-star-of-life text-danger"></span></label>-->
                                <!--        <input type="text" class="form-control round" name="university" id="InputName" required/>-->
                                <!--        </fieldset>-->
                                <!--    </div>-->
                                   
                                <!--     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">-->
                                <!--        <fieldset>-->
                                <!--        <label for="InputName">Year of Passing<span class="fas fa-star-of-life text-danger"></span></label>-->
                                <!--        <input type="text" class="form-control round" name="yop" id="InputName" required/>-->
                                <!--        </fieldset>-->
                                <!--    </div>-->
                                <!--    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">-->
                                <!--        <fieldset>-->
                                <!--        <label for="InputName">Grade<span class="fas fa-star-of-life text-danger"></span></label>-->
                                <!--        <input type="text" class="form-control round" name="grade" id="InputName" required/>-->
                                <!--        </fieldset>-->
                                <!--    </div>-->
                                <!--    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">-->
                            
                                <!--    </div>-->
                                   
                                <!--    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next1()">-->
                                <!--        <lable ><h3> << BACK</h3></lable>-->
                                <!--     </div>-->
                                <!--    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">-->
                            
                                <!--    </div>-->
                                <!--    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next3()">-->
                                <!--        <lable ><h3>NEXT >> </h3></lable>-->
                                <!--    </div>-->
                                <!--</div>-->
                                
                                 <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="skill_Details">
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next1()">
                                        <lable ><h3> << BACK</h3></lable>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    
                                    <!--<div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next4()">-->
                                    <!--    <lable ><h3>NEXT >> </h3></lable>-->
                                    <!--</div>-->
                                    <div ><h4><b style="color:red">NOTE:-</b>If you Select One or More Skills, Use the Control Button</h4></div>
                                    <div class=" col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                                        <select class="round form-control" name='subject[]' id="lstFruits" multiple="multiple">
                                            <option class="round form-control" value="Hard Working">Hard working</option>
                                            <option class="round form-control" value="Leadership"> Leadership</option>
                                            <option class="round form-control" value="Ability to Handle Pressure">Ability to Handle Pressure</option>
                                            <option class="round form-control" value="Communication">Communication</option>
                                            <option class="round form-control" value="Computer Skills">Computer Skills</option>
                                            <option class="round form-control" value="Customer Service">Customer Service</option>
                                            <option class="round form-control" value="Interpersonal Skills">Interpersonal Skills</option>
                                            <option class="round form-control" value="Management Skills">Management Skills</option>
                                            <option class="round form-control" value="Problem-Solving">Problem-Solving</option>
                                            <option class="round form-control" value="Time Managements">Time Managements</option>
                                            <option class="round form-control" value="Transferable Skills">Transferable Skills</option>
                                            <option class="round form-control" value="Active Listening">Active Listening</option>
                                            
                                            
                                        </select>
                                    </div>
                                    
                                   
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                     
                        
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next1()">
                                        <lable ><h3> << BACK</h3></lable>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    <!--<div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next4()">-->
                                    <!--    <lable ><h3>NEXT >> </h3></lable>-->
                                    <!--</div>-->
                                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                                </div>
                                
                                
                                 <!--<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="work_experience">-->
                                 <!--   <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next3()">-->
                                 <!--       <lable ><h3> << BACK</h3></lable>-->
                                 <!--   </div>-->
                                 <!--   <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">-->
                            
                                 <!--   </div>-->
                                 <!--   <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next4()">-->
                                 <!--       <lable ><h3>NEXT >> </h3></lable>-->
                                 <!--   </div>-->
                                 <!--    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">-->
                                 <!--       <fieldset>-->
                                 <!--       <label for="InputName">Company<span class="fas fa-star-of-life text-danger"></span></label>-->
                                 <!--       <input type="text" class="form-control round" name="company" id="InputName" required/>-->
                                 <!--       </fieldset>-->
                                 <!--   </div>-->
                                 <!--   <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">-->
                                 <!--       <fieldset>-->
                                 <!--       <label for="InputName">Position<span class="fas fa-star-of-life text-danger"></span></label>-->
                                 <!--       <input type="text" class="form-control round" name="position" id="InputName" required/>-->
                                 <!--       </fieldset>-->
                                 <!--   </div>-->
                                 <!--    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">-->
                                 <!--       <fieldset>-->
                                 <!--       <label for="Identity Card Type">Total Work Experience <span class="fas fa-star-of-life text-danger"></label>-->
                                 <!--       <select name="exp_in_months" class="round form-control" required>-->
                                            <?php
                                            // $s = "SELECT DISTINCT months FROM `months`" ;
                                            // $q=mysqli_query($emply_option,$s);
                                            // if(mysqli_num_rows($q)>0)
                                            // { 
                                            // while($row=mysqli_fetch_assoc($q))
                                            // {
                                            ?>
                                            <!--<option value="<?php// echo $row['months'];?>"><?php// echo $row['months'];?></option>-->
                                                                               
                                            // <?php
                                            // }
                                            // }
                                            ?>
                                <!--        </select>-->
                                <!--        </fieldset>-->
                                        
                                <!--    </div>-->
                                <!--    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">-->
                                <!--        <fieldset>-->
                                <!--        <label for="InputName">Year<span class="fas fa-star-of-life text-danger"></span></label>-->
                                <!--        <input type="text" class="form-control round" name="exp_in_year" id="InputName"   required/>-->
                                <!--        </fieldset>-->
                                <!--    </div>-->
                                <!--    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next3()">-->
                                <!--        <lable ><h3> << BACK</h3></lable>-->
                                <!--    </div>-->
                                <!--    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">-->
                            
                                <!--    </div>-->
                                <!--    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next4()">-->
                                <!--        <lable ><h3>NEXT >> </h3></lable>-->
                                <!--    </div>-->
                                <!--</div>-->
                                
                                
                                    
                                    <div class="form-group col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                               <input type="submit" name="register" id="submit" value="Submit" class="btn btn-info mx-auto round form-control col" onclick="editorg()";>
                                            </div>
                                    </div>
                                </form>
                
                                
                            </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                </div>
        </div>
    </div>    

	    <?php  
 
     if(isset($_POST['register']))
	 {
		
	    $fname=$_POST['fname'];
	    $lname=$_POST['lname'];
	    $mother=$_POST['mname'];
	    $father=$_POST['faname'];
	    $gender=$_POST['sex'];
        $db=$_POST['dob'];
	    $religion=$_POST['religion'];
	    $cast=$_POST['cast'];
	    $ict=$_POST['identity_card_type'];
	    $icn=$_POST['id_no'];
	    $lng=implode(',', $_POST['vehicle']);
        $ad1=$_POST['add1'];
        $ad2=$_POST['add2'];
        $ad3=$_POST['add3'];
    	$country=$_POST['country'];
        $state=$_POST['state'];
    	$district=$_POST['district'];
    	$loc_type=$_POST['loc_type'];
    	$loc_name=$_POST['loc_name'];
    	$place=$_POST['place'];
        $pincode=$_POST['pin'];
    	$quali=$_POST['quali'];
        $college=$_POST['college'];
        $university=$_POST['university'];
        $yop=$_POST['yop'];
        $grade=$_POST['grade'];
        $sub = implode(',',$_POST['subject']);
        $company=$_POST['company'];
        $position=$_POST['position'];
        $em=$_POST['exp_in_months'];
        $ey=$_POST['exp_in_year'];
            if (!isset($_SESSION)) 
            {
                session_start(); 
            }
            
           
           echo $_SESSION['acc'];
				 $sql=" INSERT INTO `reg_candidate`(`id`, `u_id`, `first_name`, `last_name`, `mothers_name`, `fathers_name`, `gender`, `date_of_birth`, `religion`, `cast`, `identity_card_type`, `identity_card_no`, `language_known`, `address1`, `address2`, `address3`, `country`, `state`, `district`, `loc_type`, `loc_name`, `place`, `pincode`, `qualification`, `college`, `university`, `year_of_pass`, `grade`, `skills`, `company`, `position`, `exp_in_month`, `exp_in_year`)
				        VALUES (NULL,'$cand_id','$fname','$lname','$mother','$father','$gender','$db','$religion','$cast','$ict','$icn','$lng','$ad1','$ad2','$ad3','$country','$state','$district','$loc_type','$loc_name','$place','$pincode','$quali','$college','$university','$yop','$grade','$sub','$company','$position','$em','$ey')";
					  $r=mysqli_query($emply_emply,$sql);
					  
					  //echo "hello";
					 if($r)
					 {
					  echo "data inserted";
						 // header("refresh:2;url=login.php");
					  }
					  else
					  {
						  echo "not inserted";
					  
					  }

				   
	 
    $msg = '';
    $image=$_FILES['myfile']['tmp_name'];
    $img = file_get_contents($image);
    //$un=$_GET['user_name'];
    $sql2 = "INSERT INTO `image_table`( `id`,`user_id`, `name`, `data`)values(NULL,'$cand_id','$image',?)";
    $stmt = mysqli_prepare($emply_img ,$sql2);
    mysqli_stmt_bind_param($stmt, "s",$img);
    mysqli_stmt_execute($stmt);

    $check = mysqli_stmt_affected_rows($stmt);
    if($check=$r)
    {
    echo '<script>alert("succesfull");</script>';
   echo"<script>window.open('add_edu.php','_self')</script>";
    }
    ?>
    <script>
    
   function editorg() {    
        $(document).attr("title", "EducationalDetails");
        
        $("#main").html("");
        
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/embloyability/php/dashbord/add_edu.php",
                cache: false,
                beforeSend: function() {
                    $('#main').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#main").html(html);
            }
            });
            }
</script>
    <?php
	 }
		 
		 ?>
		 
		 <script>
function showMyImage(fileInput) {
var files = fileInput.files;
for (var i = 0; i < files.length; i++) {
var file = files[i];
var imageType = /image.*/;
if (!file.type.match(imageType)) {
continue;
}
var img=document.getElementById("thumbnil");
img.file = file;
var reader = new FileReader();
reader.onload = (function(aImg) {
return function(e) {
aImg.src = e.target.result;
};
})(img);
reader.readAsDataURL(file);
}
}


function changeFunc2() {
var select2 = document.getElementById("output4");
var selectedValue = select2.options[select2.selectedIndex].value;
if (selectedValue=="not_listed"){
$('#textboxes').show();
$('#textbox1').show();
$("#newplace1").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
$("#newplace2").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
$("#newplace3").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
}
else {
$('#textboxes').hide();
$('#textbox1').hide();

$("#newplace1").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
$("#newplace2").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
$("#newplace3").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
}
}

function changeFunc3() {
var select3 = document.getElementById("caste");
var selectedValue1 = select3.options[select3.selectedIndex].value;
if (selectedValue1=="not_listed2"){
$('#txtEnglish133').show();
$('#txtbox').show();
$("#rel").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
$("#caste1").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
}
else {
$('#txtEnglish133').hide();
$('#txtbox').hide();
$("#rel").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12");
$("#caste1").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12");
}
}
    function showState(sel) {
        var country_id = sel.options[sel.selectedIndex].value;
        $("#output1").html("");
        /*
        $("#output2").html("");
        $("#output3").html("");
        $("#output4").html("");
        $("#output5").html("");
        */
        if (country_id.length > 0) {

            $.ajax({
                type: "POST",
               
                url: "areacode/fetch_area.php",
                data: "country=" + country_id,
                cache: false,
                beforeSend: function() {
                    $('#output1').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output1").html(html);
                }
            });
        }
    }

    function showDistrict(sel) {
        var state_id = sel.options[sel.selectedIndex].value;
        if (state_id.length > 0) {
            $.ajax({
                type: "POST",
                url: "areacode/fetch_area.php",
                data: "state=" + state_id,
                cache: false,
                beforeSend: function() {
                    $('#output2').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output2").html(html);
                }
            });	
        } else {
            $("#output2").html("");
        }
    }
    
    function showlclType(sel) {
        
        var district = sel.options[sel.selectedIndex].value;
		document.cookie = "district=" + district;
        if (district.length > 0){
            $.ajax({
                type: "POST",
                url: "areacode/fetch_type1.php",
                data: "district=" + district ,
                cache: false,
                beforeSend: function() {
                    $('#output5').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output5").html(html);
                }
            });
        } else {
            $("#output5").html("");
        }
    }
     function showLclArea(sel) {
        var lcltype = sel.options[sel.selectedIndex].value;
        if (lcltype.length > 0) {
            $.ajax({
                type: "POST",
                url: "areacode/fetch_area.php",
                data: "lcltype=" + lcltype,
                cache: false,
                beforeSend: function() {
                    $('#output3').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output3").html(html);
                }
            });
        } else {
            $("#output3").html("");
        }
    }
    
    function showPlace(sel) {
        var lclarea = sel.options[sel.selectedIndex].value;
        if (lclarea.length > 0) {
            $.ajax({
                type: "POST",
                url: "areacode/fetch_area.php",
                data: "lclarea=" + lclarea,
                cache: false,
                beforeSend: function() {
                    $('#output4').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output4").html(html);
                }
            });
        } else {
            $("#output4").html("");
        }
    }
    window.onload = function fresh(){
	    $("#personal_details").show();
	    $("#contact_details").hide();
	   // $("#Educational_Details").hide();
	    $("#skill_Details").hide();
	   // $("#work_experience").hide();
    }
    
function next() {
	    document.getElementById("contact").classList.add('bg-secondary');
	    document.getElementById("contact").classList.remove('bg-primary');
	    document.getElementById("personal").classList.add('bg-primary');
	    document.getElementById("personal").classList.remove('bg-secondary');
	   // document.getElementById("education").classList.add('bg-secondary');
	   // document.getElementById("education").classList.remove('bg-primary');
	    document.getElementById("skill").classList.add('bg-secondary');
	    document.getElementById("skill").classList.remove('bg-primary');
	   // document.getElementById("work").classList.add('bg-secondary');
	   // document.getElementById("work").classList.remove('bg-primary');
	    document.getElementById("prog").style.width="35%";
	    
	    $("#personal_details").show();
	    $("#contact_details").hide();
	   // $("#Educational_Details").hide();
	    $("#skill_Details").hide();
	   // $("#work_experience").hide();
	};
	function next1() {
	    document.getElementById("contact").classList.add('bg-primary');
	    document.getElementById("contact").classList.remove('bg-secondary');
	    document.getElementById("personal").classList.add('bg-secondary');
	    document.getElementById("personal").classList.remove('bg-primary');
	   // document.getElementById("education").classList.add('bg-secondary');
	   // document.getElementById("education").classList.remove('bg-primary');
	    document.getElementById("skill").classList.add('bg-secondary');
	    document.getElementById("skill").classList.remove('bg-primary');
	   // document.getElementById("work").classList.add('bg-secondary');
	   // document.getElementById("work").classList.remove('bg-primary');
	    document.getElementById("prog").style.width="60%";
	    
	    $("#personal_details").hide();
	    $("#contact_details").show();
	   // $("#Educational_Details").hide();
	    $("#skill_Details").hide();
	   // $("#work_experience").hide();
	};
// 	function next2() {
// 	    document.getElementById("contact").classList.add('bg-secondary');
// 	    document.getElementById("contact").classList.remove('bg-primary');
// 	    document.getElementById("personal").classList.add('bg-secondary');
// 	    document.getElementById("personal").classList.remove('bg-primary');
// 	    document.getElementById("education").classList.add('bg-primary');
// 	    document.getElementById("education").classList.remove('bg-secondary');
// 	    document.getElementById("skill").classList.add('bg-secondary');
// 	    document.getElementById("skill").classList.remove('bg-primary');
// 	    document.getElementById("work").classList.add('bg-secondary');
// 	    document.getElementById("work").classList.remove('bg-primary');
    //  document.getElementById("prog").style.width="50%";
	    
// 	    $("#personal_details").hide();
// 	    $("#contact_details").hide();
// 	    $("#Educational_Details").show();
// 	    $("#skill_Details").hide();
// 	    $("#work_experience").hide();
// 	};
		function next3() {
		document.getElementById("contact").classList.remove('bg-primary');
	    document.getElementById("contact").classList.add('bg-secondary');
	    document.getElementById("personal").classList.add('bg-secondary');
	    document.getElementById("personal").classList.remove('bg-primary');
	   // document.getElementById("education").classList.add('bg-secondary');
	   // document.getElementById("education").classList.remove('bg-primary');
	    document.getElementById("skill").classList.add('bg-primary');
	    document.getElementById("skill").classList.remove('bg-secondary');
	   // document.getElementById("work").classList.add('bg-secondary');
	   // document.getElementById("work").classList.remove('bg-primary');
	    document.getElementById("prog").style.width="45%";
	    
	    $("#personal_details").hide();
	    $("#contact_details").hide();
	   // $("#Educational_Details").hide();
	    $("#skill_Details").show();
	   // $("#work_experience").hide();
	};
// 		function next4() {
// 		document.getElementById("contact").classList.remove('bg-primary');
// 	    document.getElementById("contact").classList.add('bg-secondary');
// 	    document.getElementById("personal").classList.add('bg-secondary');
// 	    document.getElementById("personal").classList.remove('bg-primary');
// 	    document.getElementById("education").classList.add('bg-secondary');
// 	    document.getElementById("education").classList.remove('bg-primary');
// 	    document.getElementById("skill").classList.add('bg-secondary');
// 	    document.getElementById("skill").classList.remove('bg-primary');
// 	    document.getElementById("work").classList.add('bg-primary');
// 	    document.getElementById("work").classList.remove('bg-secondary');
//	    document.getElementById("prog").style.width="100%";
	    
// 	    $("#personal_details").hide();
// 	    $("#contact_details").hide();
// 	    $("#Educational_Details").hide();
// 	    $("#skill_Details").hide();
// 	    $("#work_experience").show();
// 	};
	

</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
$(function() {
// Multiple images preview in browser
var imagesPreview = function(input, placeToInsertImagePreview) {
if (input.files) {
var filesAmount = input.files.length;
for (i = 0; i < filesAmount; i++) {
var reader = new FileReader();
reader.onload = function(event) {
$($.parseHTML('<img>')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
}
reader.readAsDataURL(input.files[i]);
}
}
};
$('#gallery-photo-add').on('change', function() {
imagesPreview(this, 'div.gallery');
});
});
</script> 
<!--input type="file" multiple id="gallery-photo-add">
<div class="gallery"-->


<script type="text/javascript">
    $(function () {
        $('#lstFruits').multiselect({
            includeSelectAllOption: true
        });
    });
</script>

     <script src="http://www.sahayikendra.com/php/dashbord/script/multiselect.js" type="text/javascript">
         
     </script>
   
    

     