 
$(document).ready(function() { 
    $("#send-otp-phone-eamil-form").validate({
        rules: {
        	uid: {
                required: true,
                aadhaarUID:true                
            },
            phone: {
            	digits: true,
                required: true,
                minlength: 10,
                maxlength: 10
            },
            email: {
                required: true,
                email: true,
                minlength: 5,
                maxlength: 100
            } 
        },
        messages: {
        	uid: {
                required: "Aadhaar/UID number is required"
            },
        	phone: {
	            required: "Phone number is required"
	        },
        	email: {
	            required: "Email is required"
	        }
        },
        errorPlacement: function(error, element) {
        	error.insertAfter(element.parent('.form-group'));
        },
        submitHandler: function(form) {
        	$('#loader-modal').modal('show');
        	return true;
        }
    });
    $("#verify-otp-phone-email-form").validate({
        rules: { 
        	phoneEntOtp: {
            	digits: true,
                required: true, 
                maxlength: 10
            },
            emailEntOtp: {
            	digits: true,
                required: true, 
                maxlength: 10                
            } 
        },
        messages: {
        	phoneEntOtp: {
        		digits: "Enter valid OTP",
        		required: "Enter valid OTP",
        		maxlength: "Enter valid OTP"
            },
            emailEntOtp: {
            	digits: "Enter valid OTP",
        		required: "Enter valid OTP",
        		maxlength: "Enter valid OTP"
	        } 
        },
        errorPlacement: function(error, element) {
        	error.insertAfter(element.parent('.form-group'));
        },
        submitHandler: function(form) {
        	$('#loader-modal').modal('show');
        	return true;
        }
    });
    $("#link-aadhaar-form").validate({
        rules: { 
        	uid: {
                required: true,
                aadhaarUID:true                
            } 
        },
        messages: {
        	uid: {
                required: "Aadhaar/UID number is required"
            }
        },
        errorPlacement: function(error, element) {
        	error.insertAfter(element.parent('.form-group'));
        },
        submitHandler: function(form) {
        	$('#loader-modal').modal('show');
        	return true;
        }
    });
    $("#verify-otp-aadhaar").validate({
        rules: { 
        	otp: {
            	digits: true,
                required: true,
                minlength: 6,
                maxlength: 10
            } 
        },
        messages: {
        	otp: {
        		digits: "Enter valid OTP",
        		required: "Enter valid OTP",
        		minlength: "Enter valid OTP",
        		maxlength: "Enter valid OTP"
            } 
        },
        errorPlacement: function(error, element) {
        	error.insertAfter(element.parent('.form-group'));
        },
        submitHandler: function(form) {
        	$('#loader-modal').modal('show');
        	return true;
        }
    });
});