$(window).load(function(){ 
 	$('#ajax-loader').fadeOut("slow");
 });
    $(document).ajaxStart(function(){
    	$('#ajax-loader').fadeOut("slow");
    });

    $(document).ajaxComplete(function(){
    	$('#ajax-loader').fadeOut("slow");
    }); 
    
$(document).ready(function() { 
            $.fn.onMainPageLoad();            
            
        });
 
 jQuery.fn.extend({  
                    onMainPageLoad: function() { 
                    	 $(".select-multiple").select2({ placeholder: "Select"}); 
                    	 
                    	 $('.datepicker').datepicker({ dateFormat: 'dd/mm/yy', changeMonth: true, changeYear: true , yearRange: '-60:+0'}).attr('readonly','readonly');
                    	 
                         $('.checkUserName').change(function(){   
                        	 var emailRegExp = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
                        	 var obj = $(this);
                        	 obj.val(obj.val().trim().toLowerCase());
                        	 var email_address = obj.val().trim();                        	 
                        	 var flagValidate = emailRegExp.test(email_address);
                        	 if(flagValidate){
	                        	 if(email_address != ''){
		                         	 $.post($UrlLinks.checkUserNameUrl,{email: email_address}, function(data, status){
		                         		if(data.checkUserName=='false' || data.checkUserName==false){
		                         	    	obj.val(""); 
		                         	    	bootbox.alert("There is an existing user with the same email.  Before proceeding further, please check whether this user has already been registered or not.");
		                         	   	 }else if(data.checkTrueEmail=='false' || data.checkTrueEmail==false){ 
		                         	   		obj.val("");  
		                         	   		bootbox.alert("Sorry! The email '"+email_address+"' is either wrong or does not exist."); 
		                         	   	 }
		                             });
	                        	 }
                        	 }else{
                        		 bootbox.alert("Sorry! The email '"+email_address+"' is either wrong or does not exist.");
                        	 }
                 	 	}); 
                         
                         $('.checkPhoneNumber').change(function(){   
                        	 var obj = $(this);
                 	       $.post($UrlLinks.checkPhoneNumberUrl,{phoneNumber: obj.val()}, function(data, status){
                 	    		if(data=='true'){ 
                 	    	    	bootbox.alert("There is an existing user with the same phone number: "+obj.val());
                 	    	    	obj.val(""); 
                 	    	   	 }
                 	        });  
                 	 	}); 
                         
                         $('.news-more-btn').click(function(){   
                        	var id = this.id;                        	 
                 	        $.post($UrlLinks.getNewsUrl,{'news.id': id}, function(data, status){
                 	    		var obj = $('#news-modal');
                 	    		obj.find('.modal-title').html(data.newsHeader + " <br/> " + $.fn.dateFormater(data.newsDate));
                 	    		obj.find('.modal-body').html(data.newsContent);
                 	    		obj.modal('show');
                 	        });
                 	 	}); 
                         
                         
                         
                        $("#candidate-reg-form" ).validate({
	      		     		  rules: {
		      		     			firstName: { required: true, alpha:true, maxlength:100 },
		      		     			phoneNumber: { required: true, digits: true,minlength:10, maxlength:12},
		      		     			password: { required: true},
		      		     			DOB: { required: true},
		      		     			confirmPassword: { required: true,  equalTo: '[name="password"]'},
		      		     			email: { required: true, email:true},
		      		     			captcha: { required: true, maxlength:10}
	      		     		  },
	      		     		  messages: {
		      		     			firstName: {
		      		                   required: "First Name required!",
		      		                   maxlength: "Name should be less than {0} characters"
		      		               },
		      		               phoneNumber: {
		      		                   required: "Mobile number required!",
		      		                   minlength: "Mobile number should be minimum {0} digits",
		      		                   maxlength: "Mobile number should be maximum {0} digits",
		      		                   digits: "Numbers only!"
		      		               },
		      		               DOB:{
		    		                   required: "Date Of Birth Required!"  
		    		               },
		      		               password:{
		    		                   required: "Password Required!"  
		    		               },
		    		               confirmPassword: {
		    		                   required: "Confirm Password Required!",
		    		                   equalTo: "Passwords do not match"
		    		               },
		      		              email: {
		    		                   required: "Email Required!",
		    		                   email: "Enter a valid email eg: abc@xyz.com" 
		    		               },
		    		               captcha: { 
		    		            	   required: "Captcha required!"
		    		               }
	      		     		  },
	      		     		  errorPlacement: function(error, element) {
	      		     			  error.insertAfter(element.parent('.input-group'));
	      		     		  }
                        });
                        
                        $("#employer-reg-form" ).validate({
	      		     		  rules: {
	      		     			  	employerName: { required: true, maxlength:100 },
		      		     			phoneNumber: { required: true, digits: true,minlength:10, maxlength:12},
		      		     			password: { required: true}, 
		      		     			confirmPassword: { required: true,  equalTo: '[name="password"]'},
		      		     			email: { required: true, email:true},
		      		     			captcha: { required: true, maxlength:10}
	      		     		  },
	      		     		  messages: {
	      		     			   employerName: {
		      		                   required: "First Name required!" 
	      		     			   },
		      		               phoneNumber: {
		      		                   required: "Mobile number required!",
		      		                   minlength: "Mobile number should be minimum {0} digits",
		      		                   maxlength: "Mobile number should be maximum {0} digits",
		      		                   digits: "Numbers only!"
		      		               },
		      		               DOB:{
		    		                   required: "Date Of Birth Required!"  
		    		               },
		      		               password:{
		    		                   required: "Password Required!"  
		    		               },
		    		               confirmPassword: {
		    		                   required: "Confirm Password Required!",
		    		                   equalTo: "Passwords do not match"
		    		               },
		      		              email: {
		    		                   required: "Email Required!",
		    		                   email: "Enter a valid email eg: abc@xyz.com" 
		    		               },
		    		               captcha: { 
		    		            	   required: "Captcha required!"
		    		               }
	      		     		  },
	      		     		  errorPlacement: function(error, element) {
	      		     			  error.insertAfter(element.parent('.input-group'));
	      		     		  }
                      });
                        
                        $("#loginForm" ).validate({
	      		     		  rules: {
	      		     			j_username: { required: true},
	      		           		j_password: { required: true}, 
	      		     		  },
	      		     		  messages: {
	      		     			j_username: {
	      		                   required: "Enter your email" 
	      		                },
	      		                j_password: {
	      		                   required: "Enter your password" 
	      		                } 
	      		     		  },
	      		     		  errorPlacement: function(error, element) {
	      		     			  error.insertAfter(element.parent('.input-group'));
	      		     		  }
                        });
                        $("#rest-password-form" ).validate({
	      		     		  rules: {
	      		     			newPassword: { required: true},
	      		           		confirmPassword: { required: true, equalTo: "#newPassword"}, 
	      		     		  },
	      		     		  messages: {
	      		     			newPassword: {
	      		                   required: "Enter new password" 
	      		                },
	      		                confirmPassword: {
	      		                   required: "Enter confirm password",
	      		                   equalTo: "Confirm password & new password do not match"
	      		                } 
	      		     		  },
	      		     		  errorPlacement: function(error, element) {
	      		     			  error.insertAfter(element.parent('.input-group'));
	      		     		  }
                      });
                        $("#reset-link-form" ).validate({
	      		     		  rules: {
	      		     			username: { required: true, email:true},
                        		captcha: { required: true, maxlength:10} 
	      		     		  },
	      		     		  messages: {
	      		     			username: {
	      		                   required: "Enter your email" 
	      		                }, 
	    		               captcha: { 
	    		            	   required: "Enter captcha text"
	    		               }
	      		     		  },
	      		     		  errorPlacement: function(error, element) {
	      		     			  error.insertAfter(element.parent('.input-group'));
	      		     		  }
                        });  
                    },
                    captchaReset: function (form) { 
                    	$(form).find(".captcha-text-box" ).val("");
                    	var captchaImage=$(form).find(".captcha-image");
                    	var newSrc=captchaImage.attr("src")+ '?' +new Date();
                    	captchaImage.attr("src",newSrc)
                    },
                    dateFormater: function (date) { 
                    	if(date!=null && date!=""){
                    		date = date.trim();
                    		date = new Date(date);
                            var year = date.getFullYear();
                            var month = (1 + date.getMonth()).toString();
                            month = month.length > 1 ? month : '0' + month;
                            var day = date.getDate().toString();
                            day = day.length > 1 ? day : '0' + day;
                            return day + '/' + month + '/' + year;
                    	}else{
                    		return "DD/MM/YYYY";
                    	}
                    },
                    
                   
                    
              });
 
    