    <?php
        
        include('include/link.php');
        include('include/style.php');
        include('include/headerout.php');
         
    ?>
                
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="container">
                                <div class="row">
                                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                        <?php   include "emp_sidebar.php"; ?>
                                    </div>
                                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 card shadow" id="main">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                
            
            <script>
                    window.onload = function fresh(){
            	     $(document).attr("title", "HOME");
               
                // document.cookie = "cmpy=" + company;
                $("#main").html("");
                
                            $.ajax({
                                type: "POST",
                                url: "http://www.sahayikendra.com/embloyability/php/dashbord/main_emp.php",
                                
                                cache: false,
                                beforeSend: function() {
                                    $('#main').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                                },
                                success: function(html) {
                                $("#main").html(html);
                            }
                            });
                    
            
            	}; 
            
            </script>
            