<?php
include("./include/headerout.php");
include("./include/link.php");
include('./include/conn/con.php');
//include("./include/style.php");
    if (!isset($_SESSION)) 
            {
                session_start(); 
            }
            echo $cand_id= $_SESSION['emply_id'];
?>
    <div class="banner7">
        <div class="container">
            <h3>
                Add Education's
            </h3>
        </div>
        <?php
        include("sidebar.php");
        include("./include/style.php");
        ?>
    </div>
<br><br><br>
    <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
                            <form class="row" role="form" action="" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" onsubmit=" return validateform()">
                                
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="Educational_Details">
                                   <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                        <fieldset>
                                        <label for="Inputcast">Qualification <span class="fas fa-star-of-life text-danger"></span></label>
                                        <SELECT type="text" class="round form-control"  tabindex="8" name="quali" id="mylist" required onChange="showState(this)">
            
                                            <?php
                                            
                                            $sql = "SELECT DISTINCT Qualification FROM course ORDER BY `course`.`Qualification` ASC";
                                            $res=mysqli_query($emply_option,$sql);
                                            ?>
            								<option value="" ></option>
                                             <?php
                                            while($row=$res->fetch_assoc())
            								{ 
            								?>
                                                <option  value="<?php echo $row["Qualification"]; ?>"><?php echo $row["Qualification"]; ?></option>
                                            <?php } ?>
                                        </SELECT>
                                    </div>
                                     
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">College<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="college" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                   
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">University<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="university" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                   
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Year of Passing<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="yop" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Grade<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="grade" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    <div class="form-group col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                                <input type="submit" name="register" id="submit" value="Submit" class="btn btn-info mx-auto round form-control col">
                                            </div>
                                    </div>
                                   
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
        </div>
    </div>
                                
                                
                                
                                
    <?php  
     if(isset($_POST['register']))
	 {
        $quali=$_POST['quali'];
        $college=$_POST['college'];
        $university=$_POST['university'];
        $yop=$_POST['yop'];
        $grade=$_POST['grade'];
	    $sql=" INSERT INTO `education`(`id`, `u_id`, `qualification`, `college`, `university`, `year_of_pass`, `grade`)
				        VALUES (NULL,'$cand_id','$quali','$college','$university','$yop','$grade')";
		$r=mysqli_query($emply_emply,$sql);
        if($r)
		{
		echo '<script>alert("succesfull");</script>';
        echo"<script>window.open('addmore_edu.php','_self')</script>";				
		}
		else
		{
		echo "not inserted";
					  
		}
	 }