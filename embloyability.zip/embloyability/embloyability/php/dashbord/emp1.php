<?php
include("include/headerout.php");
include("include/emp_sidebar");
?>