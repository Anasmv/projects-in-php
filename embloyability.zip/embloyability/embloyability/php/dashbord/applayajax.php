<?php
 
    include('./include/conn/con.php');
    if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
     $aa= $_SESSION['emply_id'];
     $iddd=$_GET['idd_id'];
    
    
    ?>
    
    
    <?php
     if(isset($_POST['vac_id']))
	 {
	     
	    echo $vac_id = $_POST['vac_id'];
	     
	    //$notifi=$_POST['noti'];
        date_default_timezone_set("Asia/Kolkata");
        echo $time= date('d-m-Y h:i:a');
        
	   // $empidd=$_POST['empid'];
    //     $vaciddd= $_POST['vacidd'];
        
        echo $empidd = $_COOKIE['emp_id'];
        echo $cand_id = $_COOKIE['cand_id'];

 $sqlap = "SELECT `app_id`, `cand_id`, `emp_id`, `vac_id`, `date_time` FROM `applay_jobs` WHERE vac_id = '$vac_id' 
 AND date_time <> '' 
 AND cand_id = '$cand_id'
 AND emp_id = $empidd ";
 $resap=mysqli_query($emply_cand,$sqlap);
 $rowap=mysqli_fetch_array($resap);
 $appid = $rowap['app_id'];
 if($appid)
 {
     echo "<script> alert ('Already Aproved'); </script>"; 
     
 }
 else
 {
     
     $sql1="INSERT INTO `applay_jobs`(`app_id`, `cand_id`, `emp_id`, `vac_id`,`date_time`) VALUES (NULL,'$cand_id','$empidd','$vac_id','$time')";
					
        $r=mysqli_query($emply_cand,$sql1);
        if($r)
            {
                echo'<script>alert("Applied");</script>';
            }
			 else
			{
				 echo'<script>alert("Not Applied");</script>';
			}
     
 }
        
        
	 }
	 ?>
					

