
      <?php
               $emply_img = new mysqli("localhost", "sahayikendra", "sahayikendra@Azalea", 'emply_image');
                                       $res=mysqli_query($emply_img,"select * from image_table WHERE user_id='25'");
                                         
                                             while($row=mysqli_fetch_array($res))
                                               {
               
                                                 $abc=$row['data'];
                                                   echo '<img class="round shadow" src="data:image/jpeg;base64,'.base64_encode($row['data'] ).'" height="500px" width="500px" alt="rounded" />';
                                               }
                						?>
    