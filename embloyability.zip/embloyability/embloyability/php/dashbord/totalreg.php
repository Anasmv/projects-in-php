<?php
//include('./include/conn/con.php');
 $sql="select id from reg_candidate";
    $r=mysqli_query($emply_emply,$sql);
    while($row=$r->fetch_assoc())
                            {
    $i=$row['id'];
                            }
                            //count code....
                                $post1="SELECT  COUNT(*) as total FROM reg_candidate ";
                                $post2=mysqli_query($emply_emply,$post1);
                                $roo1=mysqli_fetch_assoc($post2);
                                $post=$roo1['total'];
                                //end count code
    $sql3="SELECT id FROM `reg_employer`";
    $r1=mysqli_query($emply_emply,$sql3);
    while($row1=$r1->fetch_assoc())
                            {
   $ii=$row1['id'];
                            }
                            //count code....
                                $post3="SELECT  COUNT(*) as total FROM reg_employer ";
                                $post4=mysqli_query($emply_emply,$post3);
                                $roo4=mysqli_fetch_assoc($post4);
                                $post6=$roo4['total'];
                                //end count code
    ?>