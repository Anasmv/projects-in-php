<?php

include('./include/link.php');
include('./include/headerout.php');
include('./include/conn/con.php');
if (!isset($_SESSION)) 
            {
                session_start(); 
            }
                      
   $iddd=$_GET['idd_id'];
    
   
?>
	    
   
      <!-- banner1 -->
      <div class="banner2">
         <div class="container">
            <h3>
              Add Vacancies
               
            </h3>
         </div>
         <?php
        include('emp_sidebar.php');
        include('./include/style.php');
?>
      </div>
      <br><br>
      <!-- //banner1 -->
      <!-- Jobs Brief-->
    
      <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                    <div class="col-xl-14 col-lg-14 col-md-14 col-sm-14 col-14">
                    
                    </div>
      
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                    <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                            <form class="row" role="form" action="" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" onsubmit=" return validateform()">
                               <input type="hidden" name="id" value="" id="id" />
                               <div class="row">
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 texting-in">
                                        <fieldset>
                                            <label for="InputName">Job Title<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="job" id="InputName" required/>
                                        
                                        </fieldset>
                                    </div>
                                  <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                            <label for="InputName">Company<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="cmp" id="InputName" required/>
                                        
                                        </fieldset>
                                    </div>
                                  <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                            <label for="InputName">Location<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="lcn" id="InputName" required/>
                                        
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                            <label for="InputName">Qualification<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="quali" id="InputName" required/>
                                        
                                        </fieldset>
                                    </div>
                    
                
                                  <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                            <label for="InputName">Experience<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="exp" id="InputName" required/>
                                        
                                        </fieldset>
                                    </div>
                                  <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="Inputsex"> Gender<span class="fas fa-star-of-life text-danger"></span></label>
                                        <select class="round form-control" name="sex">
                                          <option value="Male">Male</option>
                                          <option value="Female">Female</option>
                                          <option value="Does not Matter">Does not Matter</option>
                                        </select>
                                        </fieldset>
                                    </div>
               
                                   <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                            <label for="InputName">Salary<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="sal" id="InputName" required/>
                                        
                                        </fieldset>
                                    </div>
                                    
                                  <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                            <label for="InputName">Last Date to Applay<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="date" class="form-control round" name="lda" id="InputName" required/>
                                        
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                            <label for="InputName">Number of vaccancies<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="number" class="form-control round" name="numv" id="InputName" required/>
                                        
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                                <input type="submit" name="register" id="submit" value="Submit" class="btn btn-info mx-auto round form-control col">
                                            </div>
                                    </div>
                                </form>
                
                                </div>
                            </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                </div>
        </div>
    </div>
    
    
    
    
	 <?php  
	 
    if(isset($_POST['register']))
	{
	    $notifi=$_POST['noti'];
        date_default_timezone_set("Asia/Kolkata");
        $time= date('d-m-Y h:i:a');
		
    $job=$_POST['job'];
    $comp=$_POST['cmp'];
    $locn=$_POST['lcn'];
	$qualif=$_POST['quali'];
	$expi=$_POST['exp'];
	$gend=$_POST['sex'];
	$sala=$_POST['sal'];
	$date=$_POST['lda'];
	$nov=$_POST['numv'];
                
                 
                 	 $sql="INSERT INTO `add_vac`( `emp_id`, `job_title`, `company`, `location`, `qualification`, `experience`, `gender`, `salary`, `last_date _to_applay`, `no_of_vac`,`date_time`)VALUES ( '$iddd','$job','$comp','$locn','$qualif','$expi','$gend','$sala','$date','$nov','$time')";
                //  	 VALUES('5','2','j','c','l','q','e','g','s','p','12/06/1997')
					  $r=mysqli_query($emply_employer,$sql);
					  
					  //echo "hello";
					 if($r)
					 {
					  echo "data inserted";
						 // header("refresh:2;url=login.php");
					  }
					  else
					  {
						  echo "not inserted";
					  
					  }
	}
				  ?>
   

      <!-- //end jobs -->
  
</body>
</html>
<?php
include("include/footerout.php");
?>
