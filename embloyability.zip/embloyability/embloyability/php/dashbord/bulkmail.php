<?php
    include "../../include/link.php"; 
    include "../../include/nav1.php"; 
    ?>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<div class="form-gap" style='padding-top: 70px;'></div>
<div class="container">
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
            <div class="panel panel-default">
              <div class="panel-body">
                <div class="text-center">
                  <h3><i class="fa fa-envelope"></i></h3>
                  <h2 class="text-center">Send Email to Groups</h2>
                  <div class="panel-body">
                    <form enctype="multipart/form-data" action="<?php echo $_SERVER['PHP_SELF'];?>" method="post" <?php echo $flags;?>>
                      <div class="form-group">
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-align-justify"></i></span>
                          <input id="subject" name="subject" placeholder="Subject" class="form-control"  type="text">
                        </div>
                         <div class="form-group">
                        <div class="input-group">
                          <span class="input-group-addon"><i class="glyphicon glyphicon-file color-blue"></i></span>
                          <input id="file" name="file"  class="form-control"  type="file" multiple >
                        </div>
                         
                      <div class="form-group" align="left">
                        <div class="input-group">
                          <span class="input-group-addon"><i class="fa fa-users"></i></span>
                           <label for="InputEmail">Group <span class=""></span></label>&nbsp
                             <select name="group" required>
                                                  <?php
                                                $conn1 = mysqli_connect('localhost','sahayikendra','sahayikendra@Azalea','mail') or die('Unable To connect');
                                                $s = "SELECT DISTINCT group_name FROM `contacts`" ;
                                                $q=mysqli_query($conn1,$s);
                                            if(mysqli_num_rows($q)>0)
                                                { 
                                                while($row=mysqli_fetch_assoc($q))
                                                	{
                                                	?>
                                                	<option value="<?php echo $row['group_name'];?>"><?php echo $row['group_name'];?></option>
                                                       
                                                   <?php
                                                   }
                                    			}
                                                    ?>
                                                 </select>
                      </div><br><br>
                      
                        <input name="sub"  value="SEND" type="submit">
                      
                    
                    </form>
    
                  </div>
                </div>
              </div>
            </div>
          </div>
	</div>
</div>




<?php
$conn = mysqli_connect('localhost','sahayikendra','sahayikendra@Azalea','user') or die('Unable To connect');
if(isset($_POST['sub']))
{
    
            session_start();
            $id= $_SESSION['i'];
            $res1=mysqli_query($conn,"select * from user_table where user_id='$id'");
            $row2=mysqli_fetch_array($res1);
      
            $uid=$row2['user_id'];
            $mail=$row2['email'];
        
            $insert = mysqli_connect('localhost','sahayikendra','sahayikendra@Azalea','mail') or die('Unable To connect');
            $fullname = strip_tags($_POST['subject']);
            $grp=$_POST['group'];
            $tel = strip_tags($_POST['tel']);
            
            $sqll ="INSERT INTO `datas`( `user_id`, `subject`, `group`,`data`) VALUES('$uid','$fullname','$grp',?)";
        
            $ress=mysqli_query($insert,$sqll);
  

                         $con = mysqli_connect('localhost','sahayikendra','sahayikendra@Azalea','mail') or die('Unable To connect');
                         $res2=mysqli_query($con,"SELECT * FROM `contacts` WHERE group_name='$grp'");
                          while($row3=mysqli_fetch_array($res2))
                           {
                          $email=$row3['email'];
                       
                       
                       
                     
                        //Set the form flag to no display (cheap way!)
                        $flags = 'style="display:none;"';
                
                        //Deal with the email
                        $to = $email;
                        $subject = 'Sahayihendra Official Mail';
                        
                        

                        $attachment = chunk_split(base64_encode(file_get_contents($_FILES['file']['tmp_name'])));
                        $filename = $_FILES['file']['name'];
                
                        $boundary =md5(date('r', time())); 
                
                        $headers = "From: $mail\r\nReply-To: $mail";
                        $headers .= "\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=\"_1_$boundary\"";
                
                        $fullname="This is a multi-part
        fullname in MIME format.

--_1_$boundary
Content-Type: multipart/alternative; boundary=\"_2_$boundary\"

--_2_$boundary
Content-Type: text/plain; charset=\"iso-8859-1\"
Content-Transfer-Encoding: 7bit

$fullname

--_2_$boundary--
--_1_$boundary
Content-Type: application/octet-stream; name=\"$filename\" 
Content-Transfer-Encoding: base64 
Content-Disposition: attachment 

$attachment
--_1_$boundary--";



        mail($to, $subject, $fullname, $headers);
                                            
                    ?>
                    <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
                    <html>
                    <head>
                    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
                    <title>MailFile</title>
                    </head>
                    
                    <body>
                        <?php
                           }
                        
    $image=$_FILES['file']['tmp_name'];
    $img = file_get_contents($image);
    $insert = mysqli_connect('localhost','sahayikendra','sahayikendra@Azalea','mail') or die('Unable To connect');
    $z="SELECT COUNT(group_name) AS total FROM contacts where group_name='A'";
    $ress1=mysqli_query($insert,$z);
    $result=mysqli_fetch_assoc($ress1);
       $qqe= $result['total'];
    $fullname = strip_tags($_POST['subject']);
    $grp=$_POST['group'];
    $tel = strip_tags($_POST['tel']);
    date_default_timezone_set("Asia/Kolkata");
    $time= date('d-m-Y h:i:sa');
    $sqll ="INSERT INTO `datas`( `user_id`, `subject`, `group`,`date_time`,`send_count`,`data`) VALUES('$uid','$fullname','$grp','$time','$qqe',?)";

    $stmt = mysqli_prepare($insert,$sqll);

    mysqli_stmt_bind_param($stmt, "s",$img);
    mysqli_stmt_execute($stmt);

    $check = mysqli_stmt_affected_rows($stmt);
                        
                    
                
                           
                           echo'<script>alert("Messege Sent Successfully!");</script>';
                
            }
        ?>


;
                     
 