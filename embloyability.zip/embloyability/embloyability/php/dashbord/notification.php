<?php

include('./include/link.php');
include('../conn/con.php');
include('emp_sidebar.php');
include('./include/style.php');
if (!isset($_SESSION)) 
            {
                session_start(); 
            }
                  
          
 //echo $iddd= $_SESSION['emply_id'];    
   // $iddd=$_GET['idd_id'];
    
  echo $iddd=$_POST['tt1'];
?>
<?php
                 
                         $sql1="SELECT emp_id, cand_id FROM `applay_jobs`where vac_id='$iddd' ";
                         $r1=mysqli_query($emply_cand,$sql1);
                         if(mysqli_num_rows($r1)>0)
                         { 
                         while($row1=$r1->fetch_assoc())
                          {
                              $v=$row1['emp_id'];
                              $z=$row1['cand_id'];
                          }
                         }
                          $sql7="SELECT email FROM `login`where user_id='$v'";
                        $rrr=mysqli_query($emply_emply,$sql7);
                        if(mysqli_num_rows($rrr)>0)
                         { 
                         while($row3=$rrr->fetch_assoc())
                         {
                          $se=$row3['email'];
                         }
                         }
                           $sql3="SELECT email FROM `login`where user_id='$z'";
                        $rre=mysqli_query($emply_emply,$sql3);
                        if(mysqli_num_rows($rre)>0)
                         { 
                         while($row5=$rre->fetch_assoc())
                         {
                          $ss=$row5['email'];
                         }
                         }
?>
<br><br><br><br><br><br>
<div class="container">
    <div class="row">
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
           <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                    <h2 class="text-center" style="color:red">Add Notification </h2>
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
                    <form class="row" role="form" action="" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" >
                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                            <fieldset>
                            <textarea class="form-control round" name="noti" id="InputName" required/></textarea>
                            <label for="InputName">Subject </label>
                            <? echo $iddd=$_POST['tt1'];?>
                            </fieldset>
                        </div>
                        
                         
                        <div class="form-group col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                    <input type="submit" name="sub" id="submit" value="Add" class="btn btn-info mx-auto round form-control col">
                                </div>
                    </form>
                        </div>
                </div>



                
	           <?php
                        if(isset($_POST['sub']))
                        {
                             
                        $notifi=$_POST['noti'];
                        date_default_timezone_set("Asia/Kolkata");
                        $time= date('d-m-Y h:i:a');
                        
                        $sql="INSERT INTO `notification`( `vac_id`, `emp_id`, `cand_id`, `messege`,`date_time`)VALUES ('$iddd','$v','$z','$notifi','$time')";
                        $res=mysqli_query($emply_employer,$sql);
    
                        if($res)
                        {
                           
                         echo'<script>alert("success");</script>';
                        }
                        else
                        {
                            
                         echo'<script>alert("Not Registerd");</script>';   
                        }
                        }
     

                ?>