 <form name="form1" enctype="multipart/form-data" method="post" action="" id="application-form" class="form">
              <div class="row clearfix">
                <div class="col-md-5 col-sm-12 col-xs-12">
                  <div class="form-group">
                    <label class="form-label">Name</label>
                    <input type="text" value="" placeholder="Enter Your Name"  name="name" required>
                  </div>
                  <div class="form-group">
                    <label class="form-label">Email</label>
                    <input type="email" value="" placeholder="Enter Your Email Address" name="email" required >
                  </div>
                  <div class="form-group">
                    <label class="form-label">Phone</label>
                    <input type="phone" value="" placeholder="Contact Number" name="phone" required >
                  </div>
                  <div class="clearfix"></div>
                  
                </div>
                <div class="col-md-7 col-sm-12 col-xs-12">
                  <div class="form-group">
                    <label class="form-label">Message</label>
                    <textarea name="message" placeholder="Type Message Here"></textarea>
                  </div>
                </div>
              </div>
                <p>
                 
                  <input type="file" id="exampleInputFile" name="my_file">
                </p>
              <div class="form-group text-right">
                <button type="submit"  class="theme-btn dark-btn hvr-bounce-to-right">
                  <span class="fa fa-envelope"></span> Send Message </button>
              </div>
            </form>
            <?php 

if($_POST && isset($_FILES['my_file']))
{

    $from_email = $_POST['email']; //sender email
    $recipient_email = 'thameemckal@gmail.com'; //recipient email
    $subject = 'Enquiry'; //subject of email
    $message = 'Name:'.$_POST['name']; //message body
    $message.=',phone :'.$_POST['phone'].',';
    $message.=',email :'.$_POST['email'].',';
     $message.='message:'.$_POST['message'].'';
    
    //get file details we need
    $file_tmp_name    = $_FILES['my_file']['tmp_name'];
    $file_name        = $_FILES['my_file']['name'];
    $file_size        = $_FILES['my_file']['size'];
    $file_type        = $_FILES['my_file']['type'];
    $file_error       = $_FILES['my_file']['error'];
    
    $user_email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);

    if($file_error>0)
    {
        die('upload error');
    }
    //read from the uploaded file & base64_encode content for the mail
    $handle = fopen($file_tmp_name, "r");
    $content = fread($handle, $file_size);
    fclose($handle);
    $encoded_content = chunk_split(base64_encode($content));


         $boundary = md5("e-p-c-l"); 
        //header
        $headers = "MIME-Version: 1.0\r\n"; 
        $headers .= "From:".$from_email."\r\n"; 
        $headers .= "Reply-To: ".$user_email."" . "\r\n";
        $headers .= "Content-Type: multipart/mixed; boundary = $boundary\r\n\r\n"; 
        
        //plain text 
         $body = "--$boundary\r\n";
        $body .= "Content-Type: text/plain; charset=ISO-8859-1\r\n";
        $body .= "Content-Transfer-Encoding: base64\r\n\r\n"; 
        $body .= chunk_split(base64_encode($message)); 
        
        //attachment
          $body .= "--$boundary\r\n";
        $body .="Content-Type: $file_type; name=\"$file_name\"\r\n";
        $body .="Content-Disposition: attachment; filename=\"$file_name\"\r\n";
        $body .="Content-Transfer-Encoding: base64\r\n";
        $body .="X-Attachment-Id: ".rand(1000,99999)."\r\n\r\n"; 
        $body .= $encoded_content; 
    
    $sentMail = @mail($recipient_email, $subject, $body, $headers);
    if($sentMail) //output success or failure messages
    {       
       echo "send";
    }else{
        die('Please contact by phone or email');  
    }
}?>