<?php
   include('./include/link.php');
   include('./include/style.php');
include('./include/headerout.php');
include('./include/conn/con.php');


        

    if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
    $iddd=$_GET['idd_id'];
    
    ?>
    <div class="banner3">
         <div class="container">
            <h3>
             Applied Jobs
               
            </h3>
         </div>
         <?php
        
        include('emp_sidebar.php');
        include("./include/style.php");
        
        
        ?>
      </div>
 <br><br> 
  <?php
                        $sql1="SELECT DISTINCT vac_id  FROM `applay_jobs` where emp_id='$iddd'";
                        $r1=mysqli_query($emply_cand,$sql1);
                         
                        while($row1=$r1->fetch_assoc())
                        {
                            $v=$row1['vac_id'];
                            $sql="SELECT * FROM `add_vac` where `emp_id`='$iddd' and `vac_id`='$v'";
                            $r=mysqli_query($emply_employer,$sql);
                            while($row=$r->fetch_assoc())
                            {
                            $qq=$row['vac_id'];
                            $f=$row['job_title'];
                            $a=$row['company'];
                            $b=$row['location'];
                            $c=$row['qualification'];
                            $d=$row['experience'];
                            $e=$row['gender'];
                            $g=$row['salary'];
                            $h=$row['no_of_vac'];
                            $i=$row['last_date _to_applay'];
                            //count code....
                                $post1="SELECT COUNT(*) as total FROM applay_jobs WHERE vac_id='$v'";
                                $post2=mysqli_query($emply_cand,$post1);
                                $roo1=mysqli_fetch_assoc($post2);
                                $post=$roo1['total'];
                            //end count code
                            
                        ?>
                        <div class="col-12 col-12 col-12 col-12 col-12 ">
  
    <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                <form action="" method="post" role="form" class="row " enctype="multipart/form-data">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group row">
                          
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                        
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Post:&nbsp</label> <?php echo $f; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                               
                                <label class="">company:&nbsp</label><?php echo $a; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                              
                                <label class="">Location:&nbsp</label><?php echo $b; ?>
                            </fieldset>
                        </div>
                        
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                               
                                <label class="">Qualification:&nbsp</label><?php echo $c; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Experience:&nbsp</label><?php echo $d; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Gender:&nbsp</label><?php echo $e; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">salary:&nbsp</label><?php echo $g; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <input type='hidden' name='lda' value='<?php echo $i;?>'>
                                <div style="color:red"><label class="">Last_Date_to_Applay:&nbsp</label><?php echo $i; ?></div>
                                <input type='hidden' name='vacidd' value='<?php echo $v_id;?>'>
                                <input type='hidden' name='empid' value='<?php echo $emp;?>'>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Number of vaccancies:&nbsp</label><?php echo $h; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Status:&nbsp</label><button type="buton" class="btn btn-success"><b><?php echo $post,'APPLIED'; ?></button>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Message:&nbsp</label> <a href="mail.php?idd_id=<?php echo $qq;?>"class="btn btn-danger"><b>Send Messege</b></a>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Notification:&nbsp</label><a  href="notification.php?idd_id=<?php echo $qq;?>"class="btn btn-danger" ><b>Add Notification</b></a>
                            </fieldset>
                        </div>
                        
                    </div>
                </form>
                 </div>
                 </div>
                 </div>
                  </div>
    <?php
                        }
                     }    
                        
                         ?>
                
                    
                    <!--<div class="col-xl-9 col-lg-9 col-md-9 col-sm-9 col-9">-->
                    <!--<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">-->
                    <!--<div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-8 ">-->
                    <!--</div>-->
                    
                    <!--<div class="container">-->
                    <!--  <table class="table" border="1">-->
                    <!--    <thead>-->
                    <!--      <tr>-->
                    <!--        <th>Post</th>-->
                    <!--        <th>company</th>-->
                    <!--        <th>Location</th>-->
                    <!--        <th>Quialification</th>-->
                    <!--        <th>Experience</th>-->
                    <!--        <th>Gender</th>-->
                    <!--        <th>Salary</th>-->
                    <!--        <th>Number of vaccancies</th>-->
                    <!--        <th>Last Date to Applay</th>-->
                            <!--<th>Published</th>-->
                    <!--        <th>status</th>-->
                    <!--        <th>Messege</th>-->
                    <!--        <th>Notification</th>-->
                    <!--      </tr>-->
                    <!--    </thead>-->
                    <!--    <tbody>-->

                       
                    <!--    <tr>-->
                    <!--        <td><?php// echo $f; ?></td>-->
                    <!--        <td><?php //echo $a; ?></td>-->
                    <!--        <td><?php// echo $b; ?></td>-->
                    <!--        <td><?php //echo $c; ?></td>-->
                    <!--        <td><?php //echo $d; ?></td>-->
                    <!--        <td><?php //echo $e; ?></td>-->
                    <!--        <td><?php //echo $g; ?></td>-->
                    <!--        <td><?php //echo $h; ?></td>-->
                    <!--        <td><?php //echo $i; ?></td>-->
                    <!--        <td><button type="buton" class="btn btn-success"><b><?php //echo $post,'APPLIED'; ?></b> </button></td>-->
                    <!--        <td><a  href="mail.php?idd_id=<?php //echo $qq;?>"class="btn btn-danger" ><b>Send Messege</b> </button></td>-->
                    <!--        <td><a  href="notification.php?idd_id=<?php //echo $qq;?>"class="btn btn-danger" ><b>Add Notification</b> </button></td>-->
                    <!--      </tr>-->
                    <!--    </tbody>-->
                        
                    
                         
                                 
                    <!--          </table>-->
                    <!--          </div>-->
                    <!--          </div>-->
                    <!--          <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>-->
                    <!--        </div>-->
                              
                    <!--        </div>-->
                    <!--    </div>-->


