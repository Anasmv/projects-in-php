<?php
include("./include/link.php");
include('./include/conn/con.php');
include('./include/headerout.php');
include("./include/sessionlog.php");
if (!isset($_SESSION)) 
        {
          session_start(); 
        }
          $cand_id= $_SESSION['emply_id'];
        //echo$iddd=$_GET['idd_id'];
        // $aa= $_SESSION['emply_id'];
    $sql="select * from reg_candidate where u_id='$cand_id'ORDER BY `reg_candidate`.`id` ASC";
    $r=mysqli_query($emply_emply,$sql);
    $sql1="select * from login where user_id='$cand_id'";
    $r2=mysqli_query($emply_emply,$sql1);
?>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" id="mains">
<div class="banner1">
         <div class="container">
            <h3>
             Home
               
            </h3>
         </div>
         <?php
         //echo $cand_id= $_SESSION['emply_id'];
         include("sidebar.php");
	    include("./include/style.php")
	?>
        
      </div>
      
<?php
    if($r->num_rows>0)
    {				     
        $row3=$r->fetch_assoc();
        $a=$row3['first_name'];
        $c=$row3['last_name'];
        $d=$row3['date_of_birth'];
        $k=$row3['address1'];
        $l=$row3['address2'];
        $m=$row3['address3'];
    }
         if($r2->num_rows>0)
    {				     
        $row=$r2->fetch_assoc();
        $i=$row['email'];
        $j=$row['mob'];
          

    }
   
    ?>
    <script>
        function aprvcdd() {
                               
        var id=<?php echo $cand_id;?>;
        // document.cookie = "emp_id=<?php //echo $emp;?>";
        // document.cookie = "cand_id=<?php //echo $cand_id;?>";
        $("#mains").html("");
        $(document).attr("title", "VIEW MEMBERS");
            $.ajax({
                type: "POST",
                // url: "http://sahayikendra.com/embloyability/php/dashboard/applayajax.php",
                url: "cv/cvv.php",
                 //data :{  : id},
                  data: "id_can=" + id,
                cache: false,
                 beforeSend: function() {
                    $('#mains').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                 success: function(html) {
                     $("#mains").html(html);
                     
              	 //   document.getElementById(id).innerHTML = "Applied";
              	 //   document.getElementById(id).style.backgroundColor = "green";
              	    
              	 //       alert('Applied Success');
              	    w3_close();
                 }
            });   
    }
    </script>
<br><br>

    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12">
        <?php  include "./include/profemp.php"; ?>
    </div>
    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 card shadow" >
        <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                    <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        </div>
                        <form class="row" role="form" action="" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" onsubmit=" return validateform()">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group ">
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-4 form-group float-left">
                                        <?php
                                        $res=mysqli_query($emply_img,"select * from image_table WHERE user_id='$cand_id'");
                                        while($row=mysqli_fetch_array($res))
                                        {
                                        $abc=$row['data'];
                                        echo '<img class="round shadow" src="data:image/jpeg;base64,'.base64_encode($row['data'] ).'" height="150" width="150" alt="rounded" />';
                                        }
                						?>
                                </div>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                <fieldset>
                                        <label class="">Name:&nbsp</label> <span style="font-size:13px" ><?php echo $a; ?>  <?php echo $c; ?></span>
                                </fieldset>
                                </div>
                                                   
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                <fieldset>
                                    <label class="">Email:&nbsp</label><span style="font-size:13px" ><?php echo $i; ?></span>
                                </fieldset>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                <fieldset>
                                    <label class="">Mobile Number:&nbsp</label><span style="font-size:13px" > <?php echo $j; ?></span>
                                </fieldset>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                <fieldset>
                                   <label class="">Address:&nbsp</label><span style="font-size:13px" > <?php echo $k ?></span><br>
                                   
                                     <label class=""></label><span style="font-size:13px" ><div class="col-xl-4 col-lg-4 col-md-4col-sm-12 col-12 form-group texting-in"> </div> <?php echo $l ?></span><br>
                                     
                                      <label class=""> </label><span style="font-size:13px" ><div class="col-xl-4 col-lg-4 col-md-4col-sm-12 col-12 form-group texting-in"> </div> <?php echo $m?></span>
                                </fieldset>
                            </div>
                            <!--<div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">-->
                            <!--    <fieldset>-->
                            <!--        <label class="">Address2:&nbsp</label> <?php echo $j; ?>-->
                            <!--    </fieldset>-->
                            <!--</div>-->
                            <!--<div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">-->
                            <!--    <fieldset>-->
                            <!--        <label class="">Address3:&nbsp</label> <?php echo $k; ?>-->
                            <!--    </fieldset>-->
                            <!--</div>-->
                        </form>

                    </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                </div>
        </div>
    </div>
 
    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12">
        <?php  include "include/news.php"; ?>
    </div>
                             
</div>
                       <?php  
     if(isset($_POST['register']))
	 {
        $certif=$_POST['certi'];
       
	    $sql="INSERT INTO `resume`(`id`, `u_id`,`certificates`) VALUES (NULL,'$cand_id','$certif')";
		$r=mysqli_query($emply_CV,$sql);
		 if($emply_CV) 
           {
               echo 'hello';
           }

        if($r)
		{
		echo '<script>alert("succesfull");</script>';
        echo"<script>window.open('cv/certi_ajax.php','_self')</script>";				
		}
		else
		{
		echo "not inserted";
					  
		}
	 }
	 ?>
