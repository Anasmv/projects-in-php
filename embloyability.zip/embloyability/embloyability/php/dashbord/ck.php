<?php
session_start(); 
echo $_SESSION['acc_emply'];
echo $_SESSION['emply_id'];
?>