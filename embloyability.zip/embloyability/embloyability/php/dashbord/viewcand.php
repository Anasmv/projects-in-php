<?php
	include("header1.php");
	include("sidebar.php");
?>

         <br><br>
<?php
	session_start();
 
  
		include('connection.php');
			$u=$_SESSION['login_id'];
			$sql="select * from register where id='$u'";
			$res=mysqli_query($con,$sql);
	if($res->num_rows>0)
		{
?>
			<div align="center">
			<table border="1">
				<tr>
					<th>first name</th>
					<th>last name</th>
					<th>mobile_number</th>
					<th>email</th>
					<th>dob</th>
					<th>password</th>
				</tr>
				</div>

	
<?php
	while($row=$res->fetch_assoc())
		{
?>
	<tr>
	
		<td><?php echo $row['first_name'];?></td>
		<td><?php echo $row['last_name'];?></td>
		<td><?php echo $row['mobile_number'];?></td>
		<td><?php echo $row['email'];?></td>
		<td><?php echo $row['dob'];?></td>
		<td><?php echo $row['password'];?></td>
	</tr>
	</table>
		<td><a href="edit.php?id=<?php echo $row['id'];?>"> <button name="edit" class="btn btn-primary" >	<span class="glyphicon glyphicon-edit"></span>EDIT</button></a>
		<a href="edited.php?id=<?php echo $row['id'];?>"> <button name="edit" class="btn btn-primary" style="background-color:red" ><span class="glyphicon glyphicon-trash"></span>DELETE</button></a></td>
<?php }?>
<?php
}
else
{
	echo "error";
}
$con->close();
?>



	<a href="logout.php"><button name="logout" class="btn btn-primary" ><span class="glyphicon glyphicon-off"></span>Logout</button></a>
		</body>
			</html>