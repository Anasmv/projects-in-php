<?php 
include("include/link.php");
include("include/conn/connection.php");

 session_start();
 
  
	  
 ?>
<html>
  <head>

</head>
   <body>
    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"></div>               
       <div class="container">
          <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"><br><br><br>
             <div class="jumbotron text-center" style="background-color:honeydew">
               <div class="container">
        
                   <form action="" method="POST">
                      <div id="l" style="bgcolor:green"><legend align="center">Login</legend></div>

   <div align="center">
	<fieldset>
		<table class='table' align="center">
			<div class='form-group' align="center">
			    <div align="left"><span class="glyphicon glyphicon-user"></span></div>
                 <input type="text" name="name"  class="form-control bdr" placeholder="user name ,email or phone">
            </div>

            <div class='form-group'> 
                <div align="left"><span class="glyphicon glyphicon-lock"></span></div>
                <input type="password" name="password" class="form-control bdr" id="t" placeholder="password" />

            </div><br><br>

                <button type="submit" name="sub" value="SUBMIT" class="btn btn-primary active">login</button>&nbsp
                <a href="regcand.php">sign up?</a><br><br>
			<div align="left">
				<a href="regcand.php">Forgot password?</a></tr>
			</div>

	</table>
		</fieldset>
			</div>
				</div>
					</div>
						</body>
							</html>




        <?php 
        $con3 = mysqli_connect('localhost','thameem_employ','Employability(*)','thameem_embloyability') or die('Unable To connect');
        $res3=mysqli_query($con3,"select * from login");
        $row3=mysqli_fetch_array($res3);
        {
        echo  $uid=$row3['user_id'];
        }
        if(isset($_POST['sub']))
        {
       // $uname=$_POST[''];
        $us=$_POST['name'];
        $pwd=md5($_POST['password']);
        
        $con4 = mysqli_connect('localhost','thameem_employ','Employability(*)','thameem_embloyability') or die('Unable To connect');
        $res1=mysqli_query($con4,"select * from reg_candidate");
        $row2=mysqli_fetch_array($res1);
        {
        echo  $id=$row2['user_id'];
        }
        $sql="select * from login where password='$pwd' and (email='$us' or mob='$us' or user_name='$us')";
        $ww=mysqli_query($con,$sql);
        $s=mysqli_num_rows($ww);
        $row=mysqli_fetch_array($ww);
        $acc=$row['account_type'];
        if($s>0)
        {
           if($acc=='candidate')
            {
                if($id == $uid)
                {
                
            echo'<script>alert("logined cand");</script>';        
            echo"<script>window.open('regcand.php','_self')</script>";
            }
            else
            {
             //  echo"<script>window.open('login.php','_self')</script>"; 
            }
            if($acc=='Employer')
            {
        	echo "<h1> logined in employer/h1>";
        	echo"<script>window.open('regemploy.php','_self')</script>";
            }
            
        	$_SESSION['login_id']=$row['user_id'];
        	$_SESSION['login_name']=$row['name'];
        	
        	
        }
         else
        {
        	
        		echo "<h1>incorrept user name and password</h1>";
        }
        
      /*  }
        else if($sql="select * from regemploy where confirm_password='$pwd' and (email='$us' or mobile_number='$us')")
        {
        $ww=mysqli_query($con,$sql);
        $s=mysqli_num_rows($ww);
        $row=mysqli_fetch_array($ww);
        if($s>0)
        {
        	echo "<h1> logined in</h1>";
        	header("Location:viewemploy.php");
        	$_SESSION['login_id']=$row['id'];
        	$_SESSION['login_name']=$row['email'];
        	
        }
        }*/
       
        }
        }
        
        ?>
