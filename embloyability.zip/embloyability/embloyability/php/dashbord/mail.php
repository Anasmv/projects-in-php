<?php
include('./include/headerout.php');
include('./include/link.php');
include('./include/conn/con.php');
include('emp_sidebar.php');
include('./include/style.php');
if (!isset($_SESSION)) 
            {
                session_start(); 
            }
                      
    $iddd=$_GET['idd_id'];
    
   
?>
<br><br><br><br><br><br>
<div class="container">
    <div class="row">
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
           <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                    <h2 class="text-center" style="color:red"> Send Information</h2>
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
                    <form class="row" role="form" action="" method="post" <?php echo $flags;?> enctype="multipart/form-data" name="thameem" role="form" class="row" <?php echo $flags;?>>
                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                            <fieldset>
                            <textarea class="form-control round" name="mail" id="InputName" required/></textarea>
                            <label for="InputName">Subject </label>
                            </fieldset>
                        </div>
                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                            <fieldset>
                            <input id="file" name="file"  class="form-control"  type="file" multiple >
                            <label for="InputName">file </label>
                            </fieldset>
                        </div>
                        <div class="form-group col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                    <input type="submit" name="sub" id="submit" value="send" class="btn btn-info mx-auto round form-control col">
                                </div>
                    </form>
                        </div>
                </div>



                <?php
                if(isset($_POST['sub']))
                        {
                        echo $mail=strip_tags($_POST['mail']);
                         $sql1="SELECT emp_id, cand_id FROM `applay_jobs`where vac_id='$iddd' ";
                         $r1=mysqli_query($emply_cand,$sql1);
                         if(mysqli_num_rows($r1)>0)
                         { 
                         while($row1=$r1->fetch_assoc())
                          {
                              $v=$row1['emp_id'];
                              $z=$row1['cand_id'];
                          }
                         }
                          $sql7="SELECT email FROM `login`where user_id='$v'";
                        $rrr=mysqli_query($emply_emply,$sql7);
                        if(mysqli_num_rows($rrr)>0)
                         { 
                         while($row3=$rrr->fetch_assoc())
                         {
                          $se=$row3['email'];
                         }
                         }
                           $sql3="SELECT email FROM `login`where user_id='$z'";
                        $rre=mysqli_query($emply_emply,$sql3);
                        if(mysqli_num_rows($rre)>0)
                         { 
                         while($row5=$rre->fetch_assoc())
                         {
                          $ss=$row5['email'];
                         }
                         }
	                    
                            //require_once('./include/PHPMailer-master');
                        $flags = 'style="display:none;"';
                        $to = $ss;
                        $subject = "SAHAYIKENDRA OFFICIAL MAIL";
                        $attachment = chunk_split(base64_encode(file_get_contents($_FILES['file']['tmp_name'])));
                        $filename =$_FILES['file']['name'];
                        $boundary =md5(date('r', time()));
                        //$headers = "";
                        //$headers = $se;
                        $headers = "From: abu@gmail.com\r\n Reply-To: abu547@gmail.com";
                        $headers .= "\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=\"_1_$boundary\"";
                        

                        $mail="This is a multi-part
        fullname in MIME format.

--_1_$boundary
Content-Type: multipart/alternative; boundary=\"_2_$boundary\"

--_2_$boundary
Content-Type: text/plain; charset=\"iso-8859-1\"
Content-Transfer-Encoding: 7bit

$mail

--_2_$boundary--
--_1_$boundary
Content-Type: application/octet-stream; name=\"$filename\" 
Content-Transfer-Encoding: base64 
Content-Disposition: attachment 

$attachment
--_1_$boundary--";



       // mail($to, $subject, $fullname, $headers);
                        $ma=mail($to,$subject,$mail,$headers);
                        if($ma)
                        {
                        echo"<script>alert('SENDING SUCCESSFULLY')</script>";
                        }
                        
                         else
                         {
                         		echo "<h1>MSG NOT SEND</h1>";
                        }
                        
                         }
     

                ?>
                 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">