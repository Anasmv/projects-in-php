   <?php

include('./include/style.php');
  include("include/sessionlog.php");
   if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
 $aa= $_SESSION['emply_id'];
echo'<br><br><br><br><br>';
?>

   
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> </link>

    <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
         
        <button class="w3-bar-item w3-button w3-large"onclick="w3_close()">Close &times;</button>
        <a href="main_emp.php"><span class="glyphicon glyphicon-home w3-bar-item w3-button" style="font-size:18px">Home</a></span>
        <a href="add_vac.php?idd_id=<?php echo $aa;?>"><span class="glyphicon glyphicon-briefcase w3-bar-item w3-button" style="font-size:18px">Add vacancies</a></span>
        <a href="#clients"><span class="glyphicon glyphicon-bullhorn w3-bar-item w3-button" style="font-size:18px">Add Jobs Fairs</a></span>
        <a href="job_view.php?idd_id=<?php echo $aa;?>"><span class="glyphicon glyphicon-ok w3-bar-item w3-button" style="font-size:18px">Applied jobs</a></span>
        <a href="#contact"><span class="glyphicon glyphicon-folder-open w3-bar-item w3-button" style="font-size:18px">Add Job offers</a>
        <a href="update_emp.php?idd_id=<?php echo $aa;?>"><span class="glyphicon glyphicon-folder-open w3-bar-item w3-button" style="font-size:18px">Update Profile</a>
    </div>
    <div id="main">
            <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;Menu</button>
    </div>
    
   
<script>
function w3_open() {
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidebar").style.width = "25%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}
function w3_close() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}
</script>





<!--<style>-->
<!--.body {-->
<!--  font-family: "Lato", sans-serif;-->
<!--}-->

<!--.sidenav {-->
<!--  height: 100%;-->
<!--  width: 180px;-->
<!--  position: fixed;-->
<!--  z-index: 1;-->
<!--  top: 0;-->
<!--  bottom:90%;-->
<!--  left: 0;-->
<!--  background-color: #111;-->
<!--  overflow-x: hidden;-->
<!--  padding-top: 110px;-->
<!--}-->

<!--.sidenav a {-->
<!--  padding: 6px 8px 6px 16px;-->
<!--  text-decoration: none;-->
<!--  font-size: 25px;-->
<!--  color: #818181;-->
<!--  display: block;-->
<!--}-->

<!--.sidenav a:hover {-->
<!--  color: #f1f1f1;-->
<!--}-->

<!--.main {-->
  <!--margin-left: 160px; /* Same as the width of the sidenav */-->
  <!--font-size: 28px; /* Increased text to enable scrolling */-->
<!--  padding: 0px 10px;-->
<!--}-->

<!--@media screen and (max-height: 450px) {-->
<!--  .sidenav {padding-top: 50px;}-->
<!--  .sidenav a {font-size: 18px;}-->
<!--}-->
<!--</style>-->



<!--<div class="sidenav">-->
  <!--<a href="main_emp.php"><span class="glyphicon glyphicon-home" style="font-size:18px">Home</a></span>-->
  <!--<a href="add_vac.php?idd_id=<?php //echo $aa;?>"><span class="glyphicon glyphicon-briefcase" style="font-size:18px">Add vacancies</a></span>-->
  <!--<a href="#clients"><span class="glyphicon glyphicon-bullhorn" style="font-size:18px">Add Jobs Fairs</a></span>-->
  <!--<a href="job_view.php?idd_id=<?php //echo $aa;?>"><span class="glyphicon glyphicon-ok" style="font-size:18px">Applied jobs</a></span>-->
  <!--<a href="#contact"><span class="glyphicon glyphicon-folder-open" style="font-size:18px">Add Job offers</a>-->
  <!--<a href="update_emp.php?idd_id=<?php //echo $aa;?>"><span class="glyphicon glyphicon-folder-open" style="font-size:18px">Update Profile</a>-->
<!--</div>-->


<!--haii-->




