<?php
include('connection.php');
$id=($_GET['id']);
$sql="select * from register where id='$id'";
$res=mysqli_query($con,$sql);
while($row=$res->fetch_assoc())
{
?>
<html>
<head>
<style type="text/css">
body
{
	
background-color:lightgray;
}
</style>

</head>
<body>
 <fieldset>
  <table class="table" >
    
	<form  action="" method="post" name="thameem" onsubmit="  return validateform()"s>
		
			<div class='form-group'>
			
			  <span class="glyphicon glyphicon-user"></span>
			  <input type="text" name="first_name" class='form-control bdr' placeholder="First Name" value="<?php echo $row['first_name'];?>"> </tr> </div> 
		        <div class='form-group'>
		       <tr>
			   <span class="glyphicon glyphicon-user"></span>
			   <input type="text" name="last_name"  class='form-control bdr' placeholder="Last Name" value="<?php echo $row['last_name'];?>"></tr></div>
			       <div class='form-group'>
			    <tr>
			     <span class="glyphicon glyphicon-phone"></span>
				 <input type="number" name="mobile_number"   pattern="[789][0-9]{9}"  class='form-control bdr' placeholder="Mobile Number"  value="<?php echo $row['mobile_number'];?>"></tr> </div>
		<div class='form-group'>
			<tr>
			<span class="glyphicon glyphicon-envelope"></span>
			<input type="email" name="email"  class='form-control bdr' placeholder="Email" value="<?php echo $row['email'];?>"></tr></div>
			<div class='form-group'>
			<tr>
		<span class="glyphicon glyphicon-calendar"></span>
			<input type="date" name="dob"  class='form-control bdr' placeholder="Date of Birth" value="<?php echo $row['dob'];?>"></tr></div>
		<div class='form-group'>
			<tr>
			<span class="glyphicon glyphicon-lock"></span>
			<input type="password" name="password"  class='form-control bdr' placeholder="Password" onkeyup="validate()" value="<?php echo $row['password'];?>">
			Strength:<span id="mylocation">no strength</span></tr></div>
 
	 	<div class='form-group'>
			<tr>
			<span class="glyphicon glyphicon-lock"></span>
			<input type="password" name="confirm_password"  class='form-control bdr' placeholder="confirm Password" value="<?php echo $row['confirm_password'];?>"></tr></div><br><br>
		
			<tr align="center">
			<input type="reset" name="reset" class='btn btn-active' >
			<input type="submit" name="sub" class='btn btn-danger'  value="UPDATE"  />
					<a href="login.php">login?</a></tr>
	</fieldset>				
	  </form>
	 
		</table>
			</div>
				</body>
    <?php  
   include('connection.php');
     if(isset($_POST['sub']))
	 {
		
		$fname=$_POST['first_name'];
	    $lname=$_POST['last_name'];
		$mob=$_POST['mobile_number'];
	    $email=$_POST['email'];
		$dob=$_POST['dob'];
		$pwd=md5($_POST['password']);
		$cpwd=md5($_POST['confirm_password']);
		
		
				 $sql="update register set first_name='$fname',last_name='$lname',mobile_number='$mob',email='$email',dob='$dob',Password='$pwd',confirm_password='$cpwd' where id=$id";
				
					  $r=mysqli_query($con,$sql);
					  echo "hello";
					 if($r)
					 {
					  echo "data inserted";
						  header("refresh:2;url=viewcand.php");
					  }
					  else
					  {
						  echo "not inserted";
					  
					  }
 
				   
	 }
}
		  ?>
     