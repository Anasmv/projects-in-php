<?php
    include("./include/link.php");
    //include("./include/headerout.php");
    //include('sidebar.php');
    include('./include/conn/con.php');
    include("./include/style.php");
    include("include/sessionlog.php");
    if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
     echo$aa= $_SESSION['emply_id'];
     $iddd=$_GET['idd_id'];
    
    ?>
    
 


                
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                    
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1">
                        
                    </div>
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-8">
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1">
                    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9 col-9">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                    
                    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-8 ">
                    </div>
                    
                    <div class="container">
                       
                      <!--<table class="table" border="1">-->
                      <!--  <thead>-->
                      <!--    <tr>-->
                      <!--      <th>Post</th>-->
                      <!--      <th>company</th>-->
                      <!--      <th>Location</th>-->
                      <!--      <th>Quialification</th>-->
                      <!--      <th>Experience</th>-->
                      <!--      <th>Gender</th>-->
                      <!--      <th>Salary</th>-->
                      <!--      <th>Posted by</th>-->
                      <!--      <th>Last Date to Applay</th>-->
                      <!--      <th>status</th>-->
                      <!--      <th>Messege</th>-->
                      <!--    </tr>-->
                      <!--  </thead>-->
                      <!--  <tbody>-->

                        <?php
                        // $sql1="SELECT DISTINCT  cand_id FROM `applay_jobs` where emp_id='$iddd'";
                        // $r1=mysqli_query($emply_cand,$sql1);
                        // while($row1=$r1->fetch_assoc())
                        // {
                        //     echo $v=$row1['cand_id'];
                        //     $sql="SELECT DISTINCT `job-title`, `company`, `location`, `qualification`, `exp`, `gender`, `salary`, `posted_by`, `last_date _to_applay`, `status` FROM `applay_jobs` where `emp_id`='$iddd' and `vac_id`='$v'";
                        //     $r=mysqli_query($emply_cand,$sql);
                        //     while($row=$r->fetch_assoc())
                        //     {
                     
                        //     $f=$row['job-title'];
                        //     $a=$row['company'];
                        //     $b=$row['location'];
                        //     $c=$row['qualification'];
                        //     $d=$row['exp'];
                        //     $e=$row['gender'];
                        //     $g=$row['salary'];
                        //     $h=$row['posted_by'];
                        //     $i=$row['last_date _to_applay'];
                        //     //count code....
                        //         $post1="SELECT COUNT(*) as total FROM applay_jobs WHERE vac_id='$v'";
                        //         $post2=mysqli_query($emply_cand,$post1);
                        //         $roo1=mysqli_fetch_assoc($post2);
                        //         $post=$roo1['total'];
                        //         //end count code 
                        //     $j=$row['status'];
                            $sql7="SELECT email FROM `login`where user_id='$iddd'";
                            $rrr=mysqli_query($emply_emply,$sql7);
                            if(mysqli_num_rows($rrr)>0)
                                                { 
                            while($row3=$rrr->fetch_assoc())
                            {
                                echo $ss=$row3['email'];
                            }
                                                }
                            
                            
                            
                        ?>
                        <!--<tr>-->
                        <!--    <td><?php echo $f; ?></td>-->
                        <!--    <td><?php echo $a; ?></td>-->
                        <!--    <td><?php echo $b; ?></td>-->
                        <!--    <td><?php echo $c; ?></td>-->
                        <!--    <td><?php echo $d; ?></td>-->
                        <!--    <td><?php echo $e; ?></td>-->
                        <!--    <td><?php echo $g; ?></td>-->
                        <!--    <td><?php echo $h; ?></td>-->
                        <!--    <td><?php echo $i; ?></td>-->
                        <!--    <td><button type="buton" class="btn btn-success"><b><?php echo $post,$j; ?></b> </button></td>-->
                        <!--    <td><a  href="mail.php?idd_id=<?php echo $aa;?>"class="btn btn-danger" ><b>Send Messege</b> </button></td>-->
                        <!--  </tr>-->
                        <!--</tbody>-->
                        
                        <?php
                    //     }
                    //   }    
                        
                         ?>
                         
                                 
                              </table>
                              </div>
                              </div>
                              <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                            </div>
                              
                            </div>
                        </div>


