<?php
include('include/conn/con.php');
include("include/headindex.php");
include("include/style.php");

?>
<html lang="en">
<head>
     <script>  
            function validateform(){  
            var name=document.thameem.uname.value;  
            var password=document.thameem.pwd.value; 
            var mob=document.thameem.mob.value;
             var firstpassword=document.thameem.pwd.value;  
            var secondpassword=document.thameem.cpwd.value; 

 
              
            if (name==null || name==""){  
              alert("Name can't be blank");  
              return false;  
            }else if(password.length<6){  
              alert("Password must be at least 6 characters long.");  
              return false;  
              }   
            
             if(mob.length<8){
            	  alert("Mobile number must type 10 numbers");
            	  return false;
              }
             
              
            if(firstpassword==secondpassword){  
            return true;  
            }  
            else{  
            alert("password must be same!");  
            return false;  
            }  
            } 
              function validate() {  
                var msg;
            if(document.thameem.pwd.value.length>=5&&document.thameem.pwd.value.length<=8){  
            msg="good";  
            }  
            else if (document.thameem.pwd.value.length>8)
            {
            msg="strong";
            }
            else{
            
            msg="poor";  
            }  
            document.getElementById('mylocation').innerText=msg;  
             }  
 </script>
</head>
  <!-- banner1 -->
	<div class="banner1">
		<div class="container">
			<h3>Candidate Registration</h3>
		</div>
	</div>
<!-- //banner1 -->
<!-- about -->
	<div class="about" >
		<div class="container" style="min-height: 600px;">
		<div class="col-md-12 test-center" style="margin-bottom: 20px;">
	
		</div>
		
			
			
			<div class="col-md-4   col-md-offset-1">
			 <div class="well">
			  				
	                         <form action="" method="POST">
	                   		
	
		                        <div class="form-group">
		                             <div class="input-group"> 
		                              <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
										  <input class="form-control" id="username" name="name" required="required" placeholder="Email" type="text">
										 
									 </div> 
		                        </div>
		                        <div class="form-group"> 
		                         	 <div class="input-group"> 
		                         	  <span class="input-group-addon"><i class="fa fa-key" aria-hidden="true"></i></span>
										 <input class="form-control" id="password" name="password"   required="required" placeholder="Password" type="password">
										
									 </div> 
		                        </div>
		                        
		                        <div class="form-group">
		                         <button type="submit" name="sub" value="SUBMIT" class="btn btn-primary active">login</button>
		                        </div>
		                        
		                          <div class="form-group">
		                         <a href="../forgotPassword/index.html" class="reset">Forgot Password ?</a>  
		                          
		                        </div>
	                         
	
	                        
	                       
	                    	</form>
	                </div> 
			
			</div>
			
			<div class="col-md-6  left-bor col-md-offset-1">
			<hr>
			<div class="col-md-6">
			  				 
			  				 
                     				<img src="style/aadhaar/aadhaar_logo.jpg"  class="img-responsive"  />
                     				
                
			  			 
			  				</div>
			  				<div class="col-md-6" style="padding-top: 30px;">
			  				
			  				<a  href="/aadhaarAuthPublic/verifyPhoneEmail.html" class="btn btn-success btn-block">Register using your AADHAAR</a><br/>
			  				</div>
			  				
			  				<div class="col-md-12" style="padding: 0px;margin-top: 25px;">
			  				<hr>
			 <div class="well">
			  				 
	                
	                            <div id="loginErrorMsg" class="alert alert-error text-danger"> 
	                            	
	                            	 
									 
	                            </div>
	                               
                      <form class="row" role="form" action="" method="post" enctype="multipart/form-data" name="thameem" onsubmit=" return validateform()">	
		                        <div class="form-group">
		                             <div class="input-group"> 
		                             	 <span class="input-group-addon"><i class="fa fa-user"></i></span>
										 
										 <input class="form-control" id="thameem" name="uname" value="" placeholder="User Name" type="text"> 
									 </div> 
									</div> 
								 <div class="form-group">	  
									  <div class="input-group"> 
		                             	 <span class="input-group-addon"><i class="fa fa-phone"></i></span>
										 <input class="form-control" id="thameem" name="mob" value="" maxlength="10" required="required" placeholder="Mobile No" type="number"> 
									 </div> 
									 </div> 
								 <div class="form-group">	  
									  <div class="input-group"> 
		                             	 <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
										 <input class="form-control checkUserName" id="thameem" name="email" value="" required="required" placeholder="Email" maxlength="100" type="email"> 
									 </div>  
									 </div> 
								
								 <div class="form-group">	  
									 <div class="input-group"> 
		                             	 <span class="input-group-addon"><i class="fa fa-key"></i></span>
										 <input class="form-control" id="thameem" name="pwd" value="" required="required" placeholder="Password" type="password" onkeyup="validate()"/> 
                            		Strength:<span id="mylocation">no strength</span> 
									 </div>
									 </div> 
								 <div class="form-group">	  
									 <div class="input-group"> 
		                             	 <span class="input-group-addon"><i class="fa fa-key"></i></span>
										 <input class="form-control" id="thameem" name="cpwd" value="" required="required" placeholder="Confirm Password" type="password"> 
									 </div>   
		                        </div>
		                         
							
		                        
		                        <div class="form-group" >
		                        	 <input type="submit" name="register" id="submit" value="Submit" class="btn btn-success mx-auto round form-control col">
		                        </div> 
	                       
	                    	</form>
	                </div> 
	                </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //about -->
 
<!-- for custom -->
<script src="style/js/public.site.js"></script>
<!-- //for custom --> 
 
<?php
include("include/empfooter.php");

?>
</body>

<!-- Mirrored from www.employabilitycentre.org/publicSite/candidate_reg by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 19 Jun 2019 05:55:40 GMT -->
</html>


<?php
	      
   
    if(isset($_POST['register']))
     {
        echo$usname=$_POST['uname'];
       echo $email=$_POST['email'];
        echo$pwd1=$_POST['pwd'];
        echo$pwd2=$_POST['cpwd'];
       echo $mobile=$_POST['mob'];
    if($pwd1==$pwd2)
    {
        $pwd=password_hash($pwd1, PASSWORD_DEFAULT);  
        $sql="INSERT INTO `login`( `user_name`, `email`, `mob`, `account_type`, `password`) VALUES('$usname','$email','$mobile','candidate','$pwd')";
        $res=mysqli_query($emply_emply,$sql);
        }
    else
    {
         echo'<script>alert("PASSWORD DOESNOT MATCH");</script>';
    }
    if($res)
    {
        echo'<script>alert("success");</script>';
    }
    else
    {
     echo'<script>alert("Not Registerd");</script>';   
    }
    }
    ?>
    <?php
    
 
       $res3=mysqli_query($emply_emply,"select * from login");
       $row3=mysqli_fetch_array($res3);
       {
       echo  $uid=$row3['user_id'];
        }
      
         
        if(isset($_POST['sub']))
        {
        
        if (!isset($_SESSION)) 
        {
            session_start(); 
        }
       // $uname=$_POST[''];
         $us=$_POST['name'];
         $pwd=$_POST['password'];
       
        $sql="select * from login where (email='$us' or mob='$us' or user_name='$us')";
        $ww=mysqli_query($emply_emply,$sql);
        $s=mysqli_num_rows($ww);
        $row=mysqli_fetch_array($ww);
        $acc=$row['account_type'];
       
         $_SESSION['acc_emply']=$acc;
        $pass=$row['password'];
        $uid=$row['user_id'];
        $_SESSION['emply_id']=$uid;
        $res2=mysqli_query($emply_emply,"select * from reg_candidate where u_id='$uid'");
          while( $row2=mysqli_fetch_array($res2))
           {
             $id=$row2['u_id'];
           }
         
         if(password_verify($pwd, $pass))
            {
                if($s>0)
                {
                   if($acc=='candidate')
                    {
                       if($uid==$id)
                       {
                        //echo'<script>alert("logined cand");</script>';        
                         echo"<script>window.open('sidebar.php','_self')</script>";
                        }
                        
                        else
                        {
                           echo"<script>window.open('regcand.php','_self')</script>"; 
                        }
                    }
                    $res3=mysqli_query($emply_emply,"select * from reg_employer where emp_id='$uid'");
          while( $row3=mysqli_fetch_array($res3))
           {
             $idd=$row3['emp_id'];
           }
                    if($acc=='Employer')
                    {
                        if($uid==$idd)
                       {
                           $_SESSION['emply_id']=$uid;
                    	//echo "<h1> logined in employer/h1>";
                     	echo"<script>window.open('main_emp.php','_self')</script>";
                        }
                        else
                        {
                             echo"<script>window.open('regemp.php','_self')</script>"; 
                        }
                    
                	
                    }
                   
            
                }
            } 
            else
            {
            	
            		echo "<h1>incorrept user name and password</h1>";
            }
        }
?>