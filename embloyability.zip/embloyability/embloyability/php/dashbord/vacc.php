<html lang="en">
<head>
  <title>employability</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bdr.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script>  
function validateform(){  
var name=document.thameem.qualification.value;  

if (name==null || name==""){  
  alert("qualification can't be blank");  
  return false;  
}
document.getElementById('mylocation').innerText=msg;  
 }  
 </script>
</head>
<body>
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"></div>

<div class="container">
<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"><br><br><br>
<div class="jumbotron text-center" style="color:blue;background-color:MediumSeaGreen">
  <h2 align="center" style="color:navy">Add vacancies</h2> </div>
          
		  </style>
  <fieldset>
  <table class="table" >
    
	<form  action="" method="post" name="thameem" onsubmit="  return validateform()">
		
			<div class='form-group'>
			
			  <label><span class="glyphicon glyphicon-user"></span>Position : </label>
			  <input type="text" name="position" class='form-control bdr' placeholder="eg:manager"></div>
		       
			       <div class='form-group'>
				   <tr>
			<label><span class="glyphicon glyphicon-phone"></span>Company :</label>
				 <input type="text" name="company"     class='form-control bdr' placeholder="eg:Reliance" /></tr> </div>
		<div class='form-group'>
			<tr>
			<label><span class="glyphicon glyphicon-map-marker"></span>Location :</label>
			<input type="text" name="location"  class='form-control bdr' placeholder="eg:malappuram"/></tr></div>
			
			
		<div class='form-group'>
			<tr>
			<label><span class="glyphicon glyphicon-education"></span>Qualification :</label>
			<input type="text" name="qualification"  class='form-control bdr' placeholder="eg:degree" /></tr></div>
 
	 	<div class='form-group'>
			<tr>
			<label><span class="glyphicon glyphicon-lock"></span>Experience  :</label>
			<input type="text" name="experience"  class='form-control bdr' placeholder="eg:0-4 years"/> </tr></div>
		<div class='form-group'>
			<tr>
			<label><span class="glyphicon glyphicon-lock"></span>Gender  :</label>
			<input type="text" name="gender"  class='form-control bdr' placeholder="eg:Male or Female"/> </tr></div>
		<div class='form-group'>
			<tr>
			<label><span class="glyphicon glyphicon-lock"></span>Salary  :</label>
			<input type="number" name="salary"  class='form-control bdr' placeholder="eg:100000.00"/> </tr></div>
			<div class='form-group'>
			<tr>
			<label><span class="glyphicon glyphicon-lock"></span>Posted by  :</label>
			<input type="text" name="postedby"  class='form-control bdr' placeholder="eg:center place"/> </tr></div>
			
			<div class='form-group'>
			<tr>
			<label><span class="glyphicon glyphicon-calendar"></span>Last Date to Applay  :</label>
			<input type="date" name="last_date_to_apply"  class='form-control bdr' placeholder="eg:12/june/2019"/> </tr></div><br><br>
			
			<div align="center"><a href="regcand.php" class="btn btn-primary" >view</a>
				<input type="submit" name="sub" class='btn btn-danger'  value="Submit"  />

	</fieldset>				
	  </form>
	 
		</table>
			</div>
				</body>
	 	 <?php
//include("footer.php");
?>
	
	 </html>


	    <?php  
   include('connection.php');
     if(isset($_POST['sub']))
	 {
		 
		$posi=$_POST['position'];
		$com=$_POST['company'];
	    $loc=$_POST['location'];
		$quali=$_POST['qualification'];
		$exp=$_POST['experience'];
		$gend=$_POST['gender'];
		$sal=$_POST['salary'];
		$by=$_POST['postedby'];
		$lda=$_POST['last_date_to_apply'];
		
		
				 
				 $sql="INSERT INTO `vacancies`(`position`,`company`,`location`,`qualification`,`experience`,`gender`,`salary`,`postedby`,`last_date_to_apply`) VALUES ('$posi','$com','$loc','$quali','$exp','$gend','$sal','$by','$lda')";
					  $r=mysqli_query($con,$sql);
					  echo "hello";
					 if($r)
					 {
					  echo "data inserted";
						  header("refresh:2;url=login.php");
					  }
					  else
					  {
						  echo "not inserted";
					  
					  }
 
				   
	 }
		 
		 ?>
     