
		<?php
include("./include/link.php");
include("./include/sessionlog.php");
include("./include/style.php");
echo'<br><br><br><br><br>';
 if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
   $aa=  $_SESSION['emply_id'];
?>


   <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> </link>

    <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
         
        <button class="w3-bar-item w3-button w3-large"onclick="w3_close()">Close &times;</button>
        <a href="main_cand.php"><span class="glyphicon glyphicon-home w3-bar-item w3-button" style="font-size:18px"> Home </a></span>
        <a href="vacanciview.php?idd_id=<?php echo $aa;?>"><span class="glyphicon glyphicon-briefcase w3-bar-item w3-button" style="font-size:18px"> vacancies </a></span>
        <a href="#clients"><span class="glyphicon glyphicon-bullhorn w3-bar-item w3-button" style="font-size:18px"> Jobs Fairs </a></span>
        <a href="applied_jobs.php?idd_id=<?php echo $aa;?>"><span class="glyphicon glyphicon-ok w3-bar-item w3-button" style="font-size:18px"> Applied jobs </a></span>
        <a href="#contact"><span class="glyphicon glyphicon-folder-open w3-bar-item w3-button" style="font-size:18px"> Job offers </a></span>
        <a href="update_cand.php?idd_id=<?php echo $aa;?>"><span class="fa fa-refresh w3-bar-item w3-button" style="font-size:18px">  Update Profile </a></span>
        <a href="update_edu.php?idd_id=<?php echo $aa;?>"><span class="fa fa-refresh w3-bar-item w3-button" style="font-size:18px">  Update Education </a></span>
        <a href="update_work.php?idd_id=<?php echo $aa;?>"><span class="fa fa-refresh w3-bar-item w3-button" style="font-size:18px">  Update Experience </a></span>
        <a  onClick="aprvcdd();"><span class="fa fa-refresh w3-bar-item w3-button" style="font-size:18px">  Create CV  </a></span>
    </div>
    <div id="main">
            <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;Menu</button>
    </div>
   
               
    
   
<script>
function w3_open() {
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidebar").style.width = "25%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}
function w3_close() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}
</script>

