 
<?php
include('../include/conn/con.php');
 echo $dist_id = ($_REQUEST["district"] <> "") ? trim($_REQUEST["district"]) : "";
 if ($dist_id <> "") {
    $sql = "SELECT DISTINCT local_area_type FROM area_table WHERE  district = '$dist_id' ORDER BY `area_table`.`local_area_type` ASC";
    $res=mysqli_query($emply_option,$sql); 
        ?>
                <option value="" >Please Select Type</option>
                <?php while($row=$res->fetch_assoc())
										{ ?> 
                    <option value="<?php echo $row["local_area_type"]; ?>"><?php echo $row["local_area_type"]; ?></option>
                <?php } ?>
            
		
        <?php
}
?>