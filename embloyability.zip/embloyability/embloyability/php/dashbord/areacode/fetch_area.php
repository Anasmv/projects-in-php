<?php
include('../include/conn/con.php');
 $country_id = ($_REQUEST["country"] <> "") ? trim($_REQUEST["country"]) : "";
 $state_id = ($_REQUEST["state"] <> "") ? trim($_REQUEST["state"]) : "";
 $loctyp_id = ($_REQUEST["lcltype"] <> "") ? trim($_REQUEST["lcltype"]) : "";
 $locname_id = ($_REQUEST["lclarea"] <> "") ? trim($_REQUEST["lclarea"]) : "";
 $relegion_id = ($_REQUEST["relegion"] <> "") ? trim($_REQUEST["relegion"]) : "";
echo $dist=$_COOKIE['district'];
if ($country_id <> "") {
    $sql = "SELECT DISTINCT state FROM area_table WHERE  country = '$country_id' ORDER BY `area_table`.`state` ASC";
    $res=mysqli_query($emply_option,$sql); 
        ?>
                <option value="" >Please Select</option>
                <?php while($row=$res->fetch_assoc())
										{ ?> ?>
                    <option value="<?php echo $row["state"]; ?>"><?php echo $row["state"]; ?></option>
                <?php } ?>
            
		
        <?php
}

if ($state_id <> "") {
    $sql = "SELECT DISTINCT district FROM area_table WHERE  state = '$state_id' ORDER BY `area_table`.`district` ASC";
    $res=mysqli_query($emply_option,$sql); 
        ?>
		
        
                <option value="" >Please Select</option>
                <?php while($row=$res->fetch_assoc())
										{ ?> 
                    <option value="<?php echo $row["district"]; ?>"><?php echo $row["district"]; ?></option>
                <?php } ?>
            
		
        <?php
}

if ($loctyp_id <> "") {
    $sql = "SELECT DISTINCT local_area_name FROM area_table WHERE  local_area_type = '$loctyp_id' 
	AND district = '$dist'
	ORDER BY `area_table`.`local_area_name` ASC";
    $res=mysqli_query($emply_option,$sql); 
        ?>
		
        
                <option value="" >Please Select</option>
                <?php while($row=$res->fetch_assoc())
										{ ?> 
                    <option value="<?php echo $row["local_area_name"]; ?>"><?php echo $row["local_area_name"]; ?></option>
                <?php } ?>
            
		
        <?php
}

if ($locname_id <> "") {
    $sql = "SELECT DISTINCT place FROM area_table WHERE  local_area_name = '$locname_id' ORDER BY `area_table`.`place` ASC";
    $res=mysqli_query($emply_option,$sql); 
        ?>
		
        
                <option value="" >Please Select</option>
                <?php while($row=$res->fetch_assoc())
										{ ?> 
                    <option value="<?php echo $row["place"]; ?>"><?php echo $row["place"]; ?></option>
                <?php } ?>
                <option value="other">Others</option>
            
		
        <?php
}
?>

