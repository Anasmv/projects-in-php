  <?php 
         session_start();
        ?>
  <!--<div id="ajax-loader">
                  <img alt="" src="style/images/admin_loader.gif">
               </div>-->
<!--navigation-->
	<div class="top-nav">
		<div class="container">
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					
					 <a   href="http://www.sahayikendra.com/embloyability/" > </a>
					<img src="http://www.sahayikendra.com/embloyability/php/dashbord/style/images/a.jpg?fileName=PUBLIC_SITE_LOGO.jpg" class="img-responsive" align="left" style="height: 85px;width: 160px;" alt=""></a></div>
					<div align="right">
					     <label class="logoutLblPos">
					      <a href="http://www.sahayikendra.com/embloyability/php/dashbord/logout.php" ><button class="btn btn-primary"><i class="fa fa-sign-out fa-2x" style="color:white"></i></span></button></a>
                         
                          </label>
					</div>
					</nav>
				</div>
		</div>	
        <!--<nav class="navbar  navbar-default ">-->
        <!--    <div class="col-xl-1 col-lg-1 col-md-12 col-sm-12 col-12"></div>-->
        <!--    <div id="navbar">-->
        <!--            <a class="navbar-brand" href="#">-->
        <!--            <img class="round head-logo" src="http://sahayikendra.com/embloyability/php/dashbord/style/images/a.jpg?fileName=PUBLIC_SITE_LOGO.jpg" class="img-responsive" style="width: 95%;height: 85px;width: 160px;" id="logo" alt="logo"  >-->
        <!--            </a>-->
        <!--    </div>-->
        <!--      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">-->
        <!--        <span class="navbar-toggler-icon"></span>-->
        <!--      </button>-->
        <!--      <div class="collapse navbar-collapse" id="navbarNav">-->
        <!--        <ul class="navbar-nav">-->
        <!--             <li class="nav-item">-->
        <!--                <a class="nav-link" href="http://www.sahayikendra.com/">Home</a>-->
        <!--            </li>-->
        <!--            <li class="nav-item active">-->
        <!--                <a class="nav-link" href="http://www.sahayikendra.com/php/dashboard/main/profile.php">Profile<span class="sr-only">(current)</span></a>-->
        <!--            </li>-->
        <!--            <li class="nav-item">-->
        <!--                <a class="nav-link" href="#">Notification</a>-->
        <!--            </li>-->
        <!--            <li class="nav-item">-->
        <!--                <a class="nav-link" href="#">Updates</a>-->
        <!--            </li>-->
        <!--            <li class="nav-item">-->
        <!--                <a class="nav-link" href="#"><i class="fas fa-phone fa-fw"></i>Contacts</a>-->
        <!--            </li>-->
                    
                    <!-- Dropdown -->
                    <!--
        <!--            <li class="nav-item dropdown">-->
        <!--                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">-->
        <!--                Voters-->
        <!--                </a>-->
        <!--                <div class="round-curve dropdown-menu">-->
        <!--                    <a class="nav-item dropdown-item" href="#">Veiw Voters</a>-->
        <!--                    <a class="nav-item dropdown-item" href="#">Enter Details</a>-->
        <!--                    <a class="nav-item dropdown-item" href="#">Search</a>-->
        <!--                </div>-->
        <!--            </li>-->
                    
                    
        <!--            <li class="nav-item dropdown">-->
        <!--                <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">-->
        <!--                Accound-->
        <!--                </a>-->
        <!--                <div class="round-curve dropdown-menu">-->
        <!--                    <a class="nav-item dropdown-item" href="#">Veiw Accounds</a>-->
        <!--                    <a class="nav-item dropdown-item" href="#">Add Accountw</a>-->
        <!--                    <a class="nav-item dropdown-item" href="#">Search</a>-->
        <!--                </div>-->
        <!--            </li>-->
        <!--            -->-->

        <!--        </ul>-->
                  
        <!--          <ul class="nav navbar-nav ml-auto">-->
        <!--                <li class="nav-item">-->
        <!--                    <a class="nav-link " id="myBtn" href="http://www.sahayikendra.com/embloyability/php/dashbord/logout.php" ><span class="fas fa-lock" ></span> LogOut</a>-->
        <!--                </li>-->
        <!--            </ul>-->
        <!--      </div>-->
        <!--    <div class="col-xl-1 col-lg-1 col-md-0 col-sm-0 col-0"></div>-->
        <!--</nav>-->






<!--navigation-->

 