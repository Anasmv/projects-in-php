  <?php 
         session_start();
        ?>
<html lang="en">
<head>
<title>Welcome to  ECMS</title>
<!-- for-mobile-apps -->
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="keywords" content="ECMS"/>
<!-- FAV & Touch Icons -->
<link rel="shortcut icon" <img src="http://sahayikendra.com/embloyability/php/dashbord/style/images/a.jpg"	type="image/x-icon" />
<script type="application/x-javascript"> 
		addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } 
 </script>
<!-- for-mobile-apps --> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<link href='https://fonts.googleapis.com/css?family=Sanchez:400,400italic' rel='stylesheet' type='text/css'>
<link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet">
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Roboto:400,700' rel='stylesheet' type='text/css'>
<link href="http://sahayikendra.com/embloyability/php/dashbord/style/publicsite/css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
<link href="http://sahayikendra.com/embloyability/php/dashbord/style/publicsite/css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/fontawesome/css/font-awesome.min.css" type="text/css" />
<link href="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/jqueryui/jquery-ui.css" rel="stylesheet" type="text/css" />
<link href="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/select2/select2.min.css" rel="stylesheet"	type="text/css" />
<link href="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/easypaginate/easyPaginate.css" rel="stylesheet" type="text/css" media="all" /> 
<link href="http://sahayikendra.com/embloyability/php/dashbord/style/css/public.site.css" rel="stylesheet" type="text/css" media="all" /> 

<!-- JQuery 2.1.4 -->
<script	src="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/jQuery/jQuery-2.1.4.min.js"></script>
<!-- js -->
<!-- start-smoth-scrolling -->
<script type="text/javascript" src="http://sahayikendra.com/embloyability/php/dashbord/style/style/publicsite/js/move-top.js"></script>
<script type="text/javascript" src="http://sahayikendra.com/embloyability/php/dashbord/style/publicsite/js/easing.js"></script>
<!-- JQuery Validation -->
<script type="text/javascript"	src="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/jqueryvalidation/jquery.validate.js"></script>
<script type="text/javascript"	src="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/jqueryvalidation/additional-methods.js"></script> 
<!-- for bootstrap working -->
<script src="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/bootstrap/js/bootstrap.min.js"></script>
<!-- for bootstrap working -->
<!-- JQuery UI --> 
<script type="text/javascript"	src="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/jqueryui/jquery-ui.js"></script> 
<!-- Select2 -->
<script src="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/select2/select2.full.min.js"></script>
<script type="text/javascript"	src="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/fontawesome/js/fa.js"></script> 
<!--easyPaginate -->
<script src="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/bootbox/bootbox.js"></script>	
<!--EasyPaginate -->
<script type="text/javascript" src="http://sahayikendra.com/embloyability/php/dashbord/style/ui/portal_plugins/easypaginate/jquery.easyPaginate.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <!--- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>-->
<script type="text/javascript">
	jQuery(document).ready(function($) {
		$(".scroll").click(function(event){		 
			event.preventDefault();
			$('html,body').animate({scrollTop:$(this.hash).offset().top},1000);
		});
	});
	$UrlLinks = {
				checkUserNameUrl : "/commonElements/checkUserName",
				checkPhoneNumberUrl: "/commonElements/checkPhoneNumber",
				getCenterByNameUrl : "/publicSite/getCenterByName",
				getNewsUrl : "/publicSite/getNews",
				getAjaxDistrictByStatetUrl: "/commonElements/getAjaxDestricts",
			  	getAjaxTalukByDistrictUrl: "/commonElements/getTalukByDistrict",
			  	validateCandidateDuplicateUrl: "/commonElements/validateCandidateDublicate",
			} 
</script>
 


	
        <meta name="layout" content="public_site_main">
        
        
        <style type="text/css">
        .wthree_steps_grid1_sub span {
		    color: #80c127;
		    font-size: 2em;
		    top: 0.4em;
		}
		.agile_count_grid {
			cursor: pointer;
		}
		 
        </style>
</head>
