<?php
include('./include/conn/con.php');
if (!isset($_SESSION)) 
        {
          session_start(); 
        }
        $cand_id= $_SESSION['emply_id'];
        
?>
<div class="sidebarr widget">
              <h3>Latest News</h3>
 <?php
            $sql1="SELECT messege,date_time FROM `notification` where cand_id='$cand_id'";
            $r1=mysqli_query($emply_employer,$sql1);
          
            while($row1=$r1->fetch_assoc())
            {
             $v=$row1['messege']; 
            //echo '<br>';
             $z=$row1['cand_id'];
             $dd=$row1['date_time'];
           
?>
          
              <ul>
                <li>
                    <div class="sidebarr-thumb">
                        <img class="animated rollIn" src="http://shop.spotlayer.com/demo/soft-mag/demo1/wp-content/uploads/16555399183_33b1b1bc26_o-90x75.jpg" alt="" />
                    </div><!-- .Sidebar-thumb -->
                    <div class="sidebarr-content">
                        <h5 class="animated bounceInRight"><a href="#" ><?php echo $v;?></a></h5>
                    </div><!-- .Sidebar-thumb -->
                    <div class="sidebar-meta">
                       <span class="time"  style="color:red"><i style="color:blue"class="fa fa-clock-o"></i><?php echo $dd;?></span>
                        <!--<span class="comment"><i class="fa fa-comment"></i> 10 comments</span>-->
                    </div><!-- .Sidebar-meta ends here -->
                </li><!-- .Li ends here -->
                
              
                
              </ul><!-- .Ul ends here -->
              
          <!-- .Widget ends here -->
      <?php
            }
            ?>
        </div>
<style>
  /*  body{*/
  /*margin-top: 40px;*/
}
/*ul, li {*/
/*    list-style: none;*/
}
h5{
  margin: 0;
  
}
h3{
  color: #2996bd;
  margin: 10px 0px 15px;
  padding-bottom:10px;
  padding-left: 10px;
  border-left: 5px solid #32aae1;
}
.sidebarr.widget {
  background: #f2f2f2;
  border: 1px solid #ddd;
  padding: 20px 20px;
}
.sidebarr.widget ul {
    margin: 0px;
    padding: 0;
    overflow: hidden;
}
.sidebarr.widget ul li {
    overflow: hidden;
    font-size: 14px;
    margin-bottom: 20px;
    border-bottom: 1px dashed #ddd;
    padding-bottom: 20px
}
.sidebarr-thumb{
    float: left;
    overflow: hidden;
    margin-right: 15px;
}
.sidebarr-thumb img{
  background: #fff;
  border: 1px dashed #e0e0e0;
  padding: 6px;
  height: 75px;
  width: 75px;
  
  -webkit-border-radius: 100px;
  -moz-border-radius: 100px;
  border-radius: 100px;
}
.sidebarr-content h5{ 
    font-size: 16px;
    cursor: pointer;
    line-height: 24px;
}
.sidebarr-content h5 a:hover{ 
  color: #2996bd;
}

.sidebarr-content h5 a{ 
    color: #202020;
    outline: 0 none;
    text-decoration: none;
    font-weight: bold
}
.sidebarr-meta{
  margin-top: 10px;
  
}
.sidebarr-meta span{
  color: #2e2e2e;
}
.sidebarr-meta span.time{
  margin-right: 10px;
  
  
}
.sidebarr-meta span i{
  color: #2996bd
}
</style>