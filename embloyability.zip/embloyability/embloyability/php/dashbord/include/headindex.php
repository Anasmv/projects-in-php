  <?php 
         session_start();
        ?>
<body>
  <!--<div id="ajax-loader">
                  <img alt="" src="style/images/admin_loader.gif">
               </div>-->
<!--navigation-->
	<div class="top-nav">
		<div class="container">
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					 <a   href="http://sahayikendra.com/embloyability/index.html" > 
					 <img src="http://sahayikendra.com/embloyability/php/dashbord/style/commonElements/a.jpg?fileName=PUBLIC_SITE_LOGO.jpg" class="img-responsive" style="width: 95%;height: 85px;width: 160px;" alt=""></a></div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav class="menu menu--shylock" style="max-height: 350px;overflow-y: auto;">
						<ul class="nav navbar-nav link-effect-7" id="link-effect-7"> 
							<li><a href="http://www.sahayikendra.com/embloyability/index1.php">Home</a></li>
							<li><a href="about-us.html">About</a></li>
							<li><a href="centers.html" >Centre</a></li>
							<li><a href="employers.html" >Employers</a></li>
							<li><a href="jobs.html">Jobs</a></li> 
							<li><a href="fair-calender.html">Fair Calendar</a></li> 
							<li><a href="news.html" >News</a></li>
							<li><a href="frequently-ask-questions.html" >FAQ</a></li><li class="avc-sp">
							
		                            	<a class="avc-log" href="http://sahayikendra.com/embloyability/php/dashbord/rnow.php" >Log in </a>
										<a class="avc-reg" href="http://sahayikendra.com/embloyability/php/dashbord/rnow.php" >Register now </a>
		                            
							</li>
						</ul>
					</nav>
				</div>
			</nav>	
		</div>	
	</div>	 