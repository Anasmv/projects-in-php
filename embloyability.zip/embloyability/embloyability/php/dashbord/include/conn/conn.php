<?php
    $hostname = "localhost";
    $userid = "sahayikendra";
    $password = "sahayikendra@Azalea";
    $emply_cand = mysqli_connect($servername, $userid, $password, 'emply_candidate');
    $emply_emply=  mysqli_connect($hostname, $userid, $password, 'emply_embloyability');
    $emply_employer =  mysqli_connect($hostname, $userid, $password, 'emply_employer');
    $emply_img = mysqli_connect($hostname, $userid, $password, 'emply_image');
    $emply_option =  mysqli_connect($hostname, $userid, $password, 'emply_options');
    $emply_CV =  mysqli_connect($hostname, $userid, $password, 'emply_CAND_CV');
   
   
?>