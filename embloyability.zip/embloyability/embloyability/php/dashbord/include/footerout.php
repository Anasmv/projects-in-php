  <?php 
         session_start();
        ?>
        <!-- footer -->
 <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                   
	<div class="footer">
		<div class="container">
			<div class="agileinfo_footer_grids">
				<div class="col-md-4 text-center agileinfo_footer_grid"> 
				 	<h3 style="margin-bottom: 0.5em;text-align: left;text-transform: capitalize;">A joint initiative of :</h3> 
					<div class="col-md-5 col-sm-2" style="padding: 0px">
							<span class="intro"> Employment Department, Kerala  </span>  
							<img src="style/publicsite/images/dget-logo.gif"  class="dget-logo"  alt="">
					</div>
					<div class="col-md-2" style="padding: 0px;">
							<span class="intro"> & </span> <br/>
							<img src="style/publicsite/images/v-line.png" class="logo-v-line" alt=""> 
					</div>
					<div class="col-md-5" style="padding: 0px">
							<span class="intro"> Kerala Academy for Skills Excellence</span> 
						 	<img src="style/publicsite/images/kase.png" class="kase-logo"  alt="">
					</div> 
					<div class="col-md-12" style="margin-top: 20px;">
						<ul class="social-icons">
							<li><a href="https://www.facebook.com/Employability-Centre-583780955109638/"  target="_blank" class="icon-button twitter"><i class="icon-twitter"></i><span></span></a></li>
							<li><a href="https://twitter.com/skillfullyyours" target="_blank" class="icon-button google"><i class="icon-google"></i><span></span></a></li>
							<li><a href="https://in.pinterest.com/skillKerala/" target="_blank"   class="icon-button pinterest"><i class="pinterest"></i><span></span></a></li>
						</ul>
					</div>
				</div>
				<div class="col-md-4 agileinfo_footer_grid">
					<h3 style="margin-bottom: 0.5em;">Contact Info</h3>
					<ul class="agileinfo_footer_grid_list"> 
						<ul>
	<li>Directorate of Employment Sixth Floor, Thozhil Bhavan, Vikasbhavan P.O, Thiruvananthapuram 695033</li>
	<li>Kerala Academy for Skills Excellence(KASE), 3rd Floor, Carmel Tower, Vazhuthacaud, Thiruvananthapuram-695014.</li>
</ul>
					</ul>
				</div>
				<div class="col-md-4 agileinfo_footer_grid">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3945.910134980793!2d76.94546371432953!3d8.508106293883275!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b05bbbbc0000001%3A0x870fdd2632b1494f!2sNational+Employment+Service%2C+Kerala!5e0!3m2!1sen!2sin!4v1485252591798" height="250"  frameborder="0" style="border:0" allowfullscreen></iframe>
				</div>
				<div class="clearfix"> </div>
			</div>
			<div class="w3agile_footer_copy">
				<p>&copy; 2019 
				<a href="http://www.kase.in/" target="_blank">KASE</a>. All rights reserved</p>
			</div>
		</div>
	</div>
	 </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                </div>
        </div>
    </div>
      
<!-- //footer -->