<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
   position: nofixed;
   left: 0;
   bottom: 300px;
   width: 100%;
   height:100px;
   background-color:blue;
   color: white;
   text-align: center;
}
</style>
</head>
<div class="footer"><br><br>
<p align="center"> © 2019 KASE. All rights reserved</p>
</div>
</html> 


