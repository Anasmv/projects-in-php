
<?php

// date_default_timezone_set("Asia/Kolkata");
//     $time= date('Y-m-d');
//     $emply_emply = new mysqli("localhost", "sahayikendra", "sahayikendra@Azalea", 'emply_embloyability');
//         $sql="select * from reg_candidate where u_id='25'";
//         $result5 = $emply_emply->query($sql);
//         while($row = $result5->fetch_assoc())
//         {
             
//             $a="<b>".$row['first_name']."</b>";
//             $b="<b>".$row['last_name']."</b>";
//             $l="<b>".$row['address1']."<b>";
//             $m="<b>".$row['address2']."<b>";
//             $n="<b>".$row['address3']."<b>";
//             $q="<b>".$row['skills']."<b>";
//             $r="<b>".$row['language_known']."<b>";
//             $s="<b>".$row['place']."<b>";
//             $mpdf->WriteHTML($a.'<br>'.$b.'<br>'.$l.'<br>'.$m.'<br>'.$n.'<br>'.$q.'<br>'.$r.'<br>'.$s.'<br>'.$time);

//         }

//         $sql1="select * from login where user_id='25'";
//         $result6 = $emply_emply->query($sql1);
//         while($row1 = $result6->fetch_assoc())
//         {
                 
//             $c="<b>".$row1['email']."</b>";
//             $d="<b>".$row1['mob']."</b>";
//             $mpdf->WriteHTML($c.'<br>'.$d);

//         }
        
//         $sql2="select * from work_exp where u_id='25'";
//         $result7 = $emply_emply->query($sql2);
//         while($row2 = $result7->fetch_assoc())
//         {
                 
//             $e="<b>".$row2['company']."</b>";
//             $f="<b>".$row2['position']."</b>";
//             $g="<b>".$row2['exp_in_month']."</b>";
//             $h="<b>".$row2['exp_in_year']."</b>";
//             $mpdf->WriteHTML($e.'<br>'.$f.'<br>'.$g.'<br>'.$h);
//         }
        
//         $sql3="select * from education where u_id='25'";
//         $result8 = $emply_emply->query($sql3);
//         while($row3 = $result8->fetch_assoc())
//         {
                 
//             $i="<b>".$row3['qualification']."</b>";
//             $j="<b>".$row3['university']."</b>";
//             $k="<b>".$row3['year_of_pass']."</b>";
//             $mpdf->WriteHTML($i.'<br>'.$j.'<br>'.$k);
//         }
        
//         $emply_cv = new mysqli("localhost", "sahayikendra", "sahayikendra@Azalea", 'emply_CAND_CV');
//         $sql4="select * from resume where u_id='25'";
//         $result9 = $emply_cv->query($sql4);
//         while($row4 = $result9->fetch_assoc())
//         {
                 
//             $p="<b>".$row4['certificates']."</b>";
//             $mpdf->WriteHTML($p);
           
//         }
        $emply_img = new mysqli("localhost", "sahayikendra", "sahayikendra@Azalea", 'emply_image');
        $sq8 = "select * from image_table where user_id='25'";
        $resultt = $emply_img->query($sq8);
        while($row12 = $resultt->fetch_assoc())
        {
            $abc=$row12['data'];
            echo $asdadadad= '<img  src="data:image/jpeg;base64,'.base64_encode($abc ).'"  height="150" width="150" />';
            $pdf->WriteHTML($asdadadad);
        }



?>




    

