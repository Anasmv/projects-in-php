<?php
include('include/conn/con.php');
include("include/link.php");
if($con)
{
    echo "ss";
}
?>
<html lang="en">
<head>
     <script>  
            function validateform(){  
            var name=document.thameem.uname.value;  
            var password=document.thameem.pwd.value; 
            var mob=document.thameem.mob.value;
             var firstpassword=document.thameem.pwd.value;  
            var secondpassword=document.thameem.cpwd.value; 

 
              
            if (name==null || name==""){  
              alert("Name can't be blank");  
              return false;  
            }else if(password.length<6){  
              alert("Password must be at least 6 characters long.");  
              return false;  
              }   
            
             if(mob.length<8){
            	  alert("Mobile number must type 10 numbers");
            	  return false;
              }
             
              
            if(firstpassword==secondpassword){  
            return true;  
            }  
            else{  
            alert("password must be same!");  
            return false;  
            }  
            } 
              function validate() {  
                var msg;
            if(document.thameem.pwd.value.length>=5&&document.thameem.pwd.value.length<=8){  
            msg="good";  
            }  
            else if (document.thameem.pwd.value.length>8)
            {
            msg="strong";
            }
            else{
            
            msg="poor";  
            }  
            document.getElementById('mylocation').innerText=msg;  
             }  
 </script>
</head>
<body>
   <div class="container">
    <div class="row">
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
        <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10 card shadow">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                <form class="row" role="form" action="" method="post" enctype="multipart/form-data" name="thameem" onsubmit=" return validateform()">
                    
                   <h1>Employer registration</h1>
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                        <fieldset>
                            <input type="text" class="form-control bdr" name="uname" id="thameem" required/>
                            <label for="InputName">User Name <span class="glyphicon glyphicon-user"></span></label>
                        </fieldset>
                    </div>
                   
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                        <fieldset>
                            <input type="email" class="form-control bdr" id="thameem" name="email" required/>
                            <label for="InputEmail">Email <span class="fas fa-star-of-life text-danger"></span></label>
                        </fieldset>
                        
                    </div>
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                        <fieldset>
                           <span class="glyphicon glyphicon-lock"></span>
                            		<input type="password" name="pwd"  class='form-control bdr' placeholder="Password" onkeyup="validate()"/> 
                            		Strength:<span id="mylocation">no strength</span>
                        </fieldset>
                    </div>
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                        <fieldset>
                            <input type="password" class="form-control bdr" id="thameem" name="cpwd"  required/>
                            <label for="InputEmail">Confirm Password  <span class="fas fa-star-of-life text-danger"></span></label>
                        </fieldset>
                    </div>
                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                        <fieldset>
                            <input type="text" class="form-control bdr"  name="mob"  id="thameem" required/>
                            <label for="mobile">Mobile Number  <span class="fas fa-star-of-life text-danger"></label>
                        </fieldset>
                    </div>
                  
                    
                    <div class="form-group col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                            <input type="submit" name="register" id="submit" value="Submit" class="btn btn-info mx-auto round form-control col">
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
    </div>
</div>
<br><br><br><br><br>

	
	 </html>


	    <?php  
   
    if(isset($_POST['register']))
     {
        echo$usname=$_POST['uname'];
       echo $email=$_POST['email'];
        echo$pwd1=$_POST['pwd'];
        echo$pwd2=$_POST['cpwd'];
       echo $mobile=$_POST['mob'];
    if($pwd1==$pwd2)
    {
        $sql="INSERT INTO `login`( `user_name`, `email`, `mob`, `account_type`, `password`) VALUES('$usname','$email','$mobile','Employer','md5($pwd2)')";
        $res=mysqli_query($con,$sql);
        }
    else
    {
         echo'<script>alert("PASSWORD DOESNOT MATCH");</script>';
    }
    if($res)
    {
        echo'<script>alert("success");</script>';
    }
    else
    {
     echo'<script>alert("Not Registerd");</script>';   
    }
    }
