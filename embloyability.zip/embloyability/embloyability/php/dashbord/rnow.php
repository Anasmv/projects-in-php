
<?php
if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
        
include('include/conn/con.php');
include('include/style.php');
include('include/headindex.php');
?>
 
      <!-- banner1 -->
      <div class="banner1">
         <div class="container">
            <h3>Account Log in</h3>
         </div>
      </div>
      <!-- //banner1 -->
      <!-- about -->
      <div class="about" >
         <div class="container">
            <div class="col-md-12 test-center" style="margin-bottom: 20px;">
               <h3 class="head"> Log In / Register</h3>
            </div>
            <div class="col-md-4 col-md-offset-1">
               <div class="well">
                  
                  <form action="" method="POST">
	                   		
	
		                        <div class="form-group">
		                             <div class="input-group"> 
		                              <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
										  <input class="form-control" id="username" name="name" required="required" placeholder="Email" type="text">
										 
									 </div> 
		                        </div>
		                        <div class="form-group"> 
		                         	 <div class="input-group"> 
		                         	  <span class="input-group-addon"><i class="fa fa-key" aria-hidden="true"></i></span>
										 <input class="form-control" id="password" name="password"   required="required" placeholder="Password" type="password">
										
									 </div> 
		                        </div>
		                        
		                        <div class="form-group">
		                         <button type="submit" name="sub" value="SUBMIT" class="btn btn-primary active">login</button>
		                        </div>
		                        
		                          <div class="form-group">
		                         <a href="../forgotPassword/index.html" class="reset">Forgot Password ?</a>  
		                          
		                        </div>
	                         
	
	                        
	                       
	                    	</form>
	                </div> 
			
			</div>
            <div class="col-md-6 left-bor col-md-offset-1">
               <div class="row">
                  <div class="col-md-8 col-md-offset-3"><br/><br/>
                     <a  href="cand_login.php" class="btn btn-primary btn-block">Register as candidate</a><br/>
                  </div>
                  <div class="col-md-8 col-md-offset-3">
                     <a href="employ_login.php"  class="btn btn-success btn-block">Register as Employer</a>
                  </div>
               </div>
            </div>
            <div class="clearfix"> </div>
         </div>
      </div>
  

<!-- //for custom --> 
<?php
include("include/empfooter.php");
?>

</body>

</html>
<?php
         
        if(isset($_POST['sub']))
        {
        
        if (!isset($_SESSION)) 
        {
            session_start(); 
        }
       // $uname=$_POST[''];
         $us=$_POST['name'];
         $pwd=$_POST['password'];
       
        $sql="select * from login where (email='$us' or mob='$us' or user_name='$us')";
        $ww=mysqli_query($emply_emply,$sql);
        $s=mysqli_num_rows($ww);
        $row=mysqli_fetch_array($ww);
        $acc=$row['account_type'];
       
        $_SESSION['acc_emply']=$acc;
        $pass=$row['password'];
        $uid=$row['user_id'];
        $_SESSION['emply_id']=$uid;
        $res2=mysqli_query($emply_emply,"select * from reg_candidate where u_id='$uid'");
          while( $row2=mysqli_fetch_array($res2))
           {
             $id=$row2['u_id'];
           }
         
         if(password_verify($pwd, $pass))
            {
                if($s>0)
                {
                   if($acc=='candidate')
                    {
                       if($uid==$id)
                       {
                        echo'<script>alert("logined cand");</script>';        
                         echo"<script>window.open('main_cand.php','_self')</script>";
                        }
                        
                        else
                        {
                            echo'<script>alert("logined reg");</script>';  
                           echo"<script>window.open('regcand.php','_self')</script>"; 
                        }
                    }
                    $res3=mysqli_query($emply_emply,"select * from reg_employer where emp_id='$uid'");
          while( $row3=mysqli_fetch_array($res3))
           {
             $idd=$row3['emp_id'];
           }
                    if($acc=='Employer')
                    {
                        if($uid==$idd)
                       {
                           $_SESSION['emply_id']=$uid;
                    	//echo "<h1> logined in employer/h1>";
                    	    echo'<script>alert("logined emp");</script>'; 
                     	echo"<script>window.open('main_emp.php','_self')</script>";
                     	
                        }
                        else
                        {
                            echo'<script>alert("logined regemp");</script>'; 
                             echo"<script>window.open('regemp.php','_self')</script>"; 
                        }
                    
                	
                    }
                   
            
                }
            } 
            else
            {
            	
            		echo "<h1>incorrept user name and password</h1>";
            }
        }

?>
