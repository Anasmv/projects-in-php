
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/multi-select/0.9.12/css/multi-select.css">
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.0.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/multi-select/0.9.12/js/jquery.multi-select.min.js"></script>


<html>
<div id="output"></div>
<form method="get">
  <select data-placeholder="Choose tags ..." name="tags[]" multiple class="chosen-select">
    <option value="Engineering">Engineering</option>
    <option value="Carpentry">Carpentry</option>
    <option value="Plumbing">Plumbing</option>
    <option value="Electical">Electrical</option>
    <option value="Mechanical">Mechanical</option>
    <option value="HVAC">HVAC</option>
  </select>
  <input type="submit">
</form>
         </html>
         <style>
* {
  margin: 0px;
  padding: 0px;
  outline: none;
}

.ms-container {
  background: #fff;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
</style>
<script>
$('output').multiSelect();
</script>