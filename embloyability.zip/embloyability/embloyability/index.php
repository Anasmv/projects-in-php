
<?php
 
            session_start(); 
            
        
                include('php/dashbord/include/conn/con.php');
			    if($_SESSION['emply_id']!='')
			    {
			        if($_SESSION['acc_emply']=='candidate')
			        {
			        $uid=$_SESSION['emply_id'];
			        $res2=mysqli_query($emply_emply,"select * from reg_candidate where u_id='$uid'");
                    $row2=mysqli_fetch_array($res2);
                    $id=$row2['u_id'];
                    if($uid==$id)
                       {
                        //echo'<script>alert("logined cand");</script>';        
                          echo"<script type='text/javascript'>
    					    window.location='http://www.sahayikendra.com/embloyability/php/dashbord/sidebar.php';</script>";
                        }
                        
                        else
                        {
                           echo"<script type='text/javascript'>
					    window.location='http://www.sahayikendra.com/embloyability/php/dashbord/regcand.php';</script>"; 
                        }
			        }
    			    else
    			    {
    			        if($uid!=$id)
                           {
                    	echo "<h1> logined in employer/h1>";
                     	echo"<script type='text/javascript'>window.location='http://www.sahayikendra.com/embloyability/php/dashbord/regemp.php';</script>";
                        }
                        else
                        {
                             echo"<script text/javascript> window.location='http://www.sahayikendra.com/embloyability/php/dashbord/emp_sidebar.php';</script>"; 
                        }
			       }
			    // header("location:../php/dashboard/index.php");
			}
    		else
    			{
                   if($_SESSION['emply_id']=='')
                			{
                	include('php/dashbord//include/conn/con.php');  
                	include("php/dashbord/include/headindex.php");
                	include("php/dashbord/include/style.php");
                	include("php/dashbord/totalreg.php");
                 ?>
                 
                <!--navigation-->
                        <!-- banner -->
                        <div class="banner">
                            <div class="w3l_banner_info">
                                <div class="container top-banner">
                                    <section class="">
                                        <div class="flexslider-none">
                                            <ul class="slides">
                                                <li>
                                                    <div class="w3l_banner_info_grid">
                
                                                        <!-- count-down -->
                                                        <div class="count" data-toggle="tooltip">
                                                            <div class="container-fluid"  data-placement="bottom" title="Click for details">
                                                               <!--<form class="row" role="form" action="" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" onsubmit=" return validateform()">-->
                                                                <div class="col-md-3 agile_count_grid"  >
                                                                    <div class="agile_count_grid_left">
                                                                        <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                                                                    </div>
                                                                    <div class="agile_count_grid_right">
                                                                        <p class="counter"><?php echo $post?></p>
                                                                    </div>
                                                                    <div class="clearfix"> </div>
                                                                    <h3>Candidates Registered</h3>
                                                                </div>
                                                                <div class="col-md-3 agile_count_grid">
                                                                    <div class="agile_count_grid_left">
                                                                        <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span>
                                                                    </div>
                                                                    <div class="agile_count_grid_right">
                                                                        <p class="counter"><?php echo $post6?></p>
                                                                    </div>
                                                                    <div class="clearfix"> </div>
                                                                    <h3>Employers Registered</h3>
                                                                </div>
                                                                <div class="col-md-3 agile_count_grid">
                                                                    <div class="agile_count_grid_left">
                                                                        <span class="glyphicon glyphicon-book" aria-hidden="true"></span>
                                                                    </div>
                                                                    <div class="agile_count_grid_right">
                                                                        <p class="counter">70963</p>
                                                                    </div>
                                                                    <div class="clearfix"> </div>
                                                                    <h3>Trained</h3>
                                                                </div>
                                                                <div class="col-md-3 agile_count_grid">
                                                                    <div class="agile_count_grid_left">
                                                                        <span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>
                                                                    </div>
                                                                    <div class="agile_count_grid_right">
                                                                        <p class="counter">30342</p>
                                                                    </div>
                                                                    <div class="clearfix"> </div>
                                                                    <h3>Placed</h3>
                                                                </div>
                                                                <div class="clearfix"> </div>
                                                                <!-- Starts-Number-Scroller-Animation-JavaScript -->
                                                                <script src="http://sahayikendra.com/embloyability/php/dashbord/style/publicsite/js/waypoints.min.js"></script>
                                                                <script src="http://sahayikendra.com/embloyability/php/dashbord/style/publicsite/js/counterup.min.js"></script>
                                                                <script>
                                                                    jQuery(document).ready(function($) {
                                                                        $('.counter').counterUp({
                                                                            delay: 20,
                                                                            time: 1000
                                                                        });
                                                                    });
                                                                </script>
                                                                <!-- //Starts-Number-Scroller-Animation-JavaScript -->
                                                            </div>
                                                        </div>
                                                        <h3>Are you Searching for a great job ? You are @ the right place</h3>
                                                        <p>
                                                            <a href="http://sahayikendra.com/embloyability/php/dashbord/rnow.php" class="btn btn-md btn-primary">Register now</a>
                                                        </p>
                                                        <!-- //count-down -->
                                                    </div>
                                                </li>
                
                                            </ul>
                                        </div>
                                    </section>
                
                                    <div class="w3ls_banner_scroll">
                                        <a href="#steps" class="scroll"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- //banner -->
                    
                        <div class="blog" id="blog">
                            <div class="container">
                                <h3 class="head">News & Events</h3>
                                <p class="urna">Latest news and events showing here</p>
                                <div class="w3_blog_grids">
                                
                                    <div class="col-md-6 w3_blog_grid news"> 
                                            <div class="alert alert-info">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                							  <a href="news.html"  class="news-header" >MEGA JOB FAIR in THRISSUR Employability Centre on 21-07-2018 @9:30 AM 
                At St.Aloysious College, Elthuruthu, Thrissur </a> <br/> <span> 21 Jul 2018</span>
                							</div> 
                                    </div> 
                                   
                                    <div class="col-md-6 w3_blog_grid news"> 
                                            <div class="alert alert-info">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                							  <a href="news.html"  class="news-header" >JOB DRIVE @ KASARAGOD EMPLOYABILITY CENTER ON 12-07-2018 </a> <br/> <span> 11 Jul 2018</span>
                							</div> 
                                    </div> 
                                   
                                    <div class="col-md-6 w3_blog_grid news"> 
                                            <div class="alert alert-info">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                							  <a href="news.html"  class="news-header" >JOB DRIVE AT Employability Centre, Thrissur on 18/05/2018 @10 AM with 8 companies </a> <br/> <span> 18 May 2018</span>
                							</div> 
                                    </div> 
                                   
                                    <div class="col-md-6 w3_blog_grid news"> 
                                            <div class="alert alert-info">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                							  <a href="news.html"  class="news-header" >MATHRUBHUMI NEWS </a> <br/> <span> 14 May 2018</span>
                							</div> 
                                    </div> 
                                   
                                    <div class="col-md-6 w3_blog_grid news"> 
                                            <div class="alert alert-info">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                							  <a href="news.html"  class="news-header" >LAKSHYA MEGA JOB FEST 2018 </a> <br/> <span> 10 Mar 2018</span>
                							</div> 
                                    </div> 
                                   
                                    <div class="col-md-6 w3_blog_grid news"> 
                                            <div class="alert alert-info">
                                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                							  <a href="news.html"  class="news-header" >DISTRICT MEGA JOB FAIR </a> <br/> <span> 03 Mar 2018</span>
                							</div> 
                                    </div> 
                                    
                                     <div class="clearfix"> </div>
                                      <div class="row text-center avc-bot"  >
                							<a href="news.html" class="btn btn-md btn-primary">More News</a>
                						</div>
                                </div>
                            </div>
                        </div>
                       <!-- //blog -->
                       
                
                        <!-- blog -->
                        <!-- steps -->
                        <div class="steps" id="steps">
                            <div class="container">
                                <h3 class="head">How Employability Centres Works</h3>
                                <p class="urna">Why Skill Development and Employability Centres.</p>
                                <div class="wthree_steps_grids">
                                    <div class="col-md-3 wthree_steps_grid">
                                        <div class="wthree_steps_grid1 wthree_steps_grid1_after">
                                            <div class="wthree_steps_grid1_sub">
                                                <span class="glyphicon glyphicon-user" aria-hidden="true"></span>
                                            </div>
                                        </div>
                                        <h4>Register</h4>
                                        <p>You can register at the Employability Centre in your District.</p>
                                    </div>
                                    <div class="col-md-3 wthree_steps_grid">
                                        <div class="wthree_steps_grid1 wthree_steps_grid1_after">
                                            <div class="wthree_steps_grid1_sub">
                                                <span class="glyphicon glyphicon-bookmark" aria-hidden="true"></span>
                                            </div>
                                        </div>
                                        <h4>Assess</h4>
                                        <p>We will assess your Aptitude for the right employment.</p>
                                    </div>
                                     <div class="col-md-3 wthree_steps_grid">
                                        <div class="wthree_steps_grid1 wthree_steps_grid1_after">
                                            <div class="wthree_steps_grid1_sub">
                                                <span class="glyphicon glyphicon-blackboard" aria-hidden="true"></span>
                                            </div>
                                        </div>
                                        <h4>Train</h4>
                                        <p>We will train you and make you employment ready.</p>
                                    </div>
                                     
                                     <div class="col-md-3 wthree_steps_grid">
                                        <div class="wthree_steps_grid1">
                                            <div class="wthree_steps_grid1_sub">
                                                <span class="glyphicon glyphicon-briefcase" aria-hidden="true"></span>
                                            </div>
                                        </div>
                                        <h4>Employ</h4>
                                        <p> We will help you identify and secure the right employment.</p>
                                    </div>
                                    <div class="clearfix"> </div>
                                </div>
                            </div>
                        </div>
                        <!-- //steps -->
                       
                      
                 
                        
                        <!-- //newsletter -->
                        <div class="clearfix"> </div>
                        
                        
                        
                        
                        <!-- Companies -->
                        <div class="work avc-fix">
                            <h3 class="head">Companies</h3>
                            <p class="urna">Companies where our candidates have been placed</p>
                            <div class="agileits_work_grids">
                                <ul id="flexiselDemo1">
                                    
                                        
                                            <li>
                                                <div class="agileits_work_grid view view-sixth" style="height: 120px;margin-right: 15px;">
                
                					        		<img src="http://sahayikendra.com/embloyability/php/dashbord/style/commonElements/renderImage89fe.jpg?fileName=AS_HEALTHCARE_ASSISTANCE_PVT_LTD.jpg" class="img-responsive halfway" style="height: 100px;padding-top: 15px;margin: auto;" alt="">
                					        	
                                                </div>
                                            </li>
                                        
                                    
                                        
                                            <li>
                                                <div class="agileits_work_grid view view-sixth" style="height: 120px;margin-right: 15px;">
                
                					        		<img src="http://sahayikendra.com/embloyability/php/dashbord/style/commonElements/renderImage5fb2.png?fileName=1559885000Screenshot_from_2018-06-18_14%3A15%3A28.png" class="img-responsive halfway" style="height: 100px;padding-top: 15px;margin: auto;" alt="">
                					        	
                                                </div>
                                            </li>
                                        
                                   <li>
                                                <div class="agileits_work_grid view view-sixth" style="height: 120px;margin-right: 15px;">
                
                					        		<img src="http://sahayikendra.com/embloyability/php/dashbord/style/commonElements/renderImage929e.jpg?fileName=SMART_LEADER_TRAINING_CONSULTANTS.jpg" class="img-responsive halfway" style="height: 100px;padding-top: 15px;margin: auto;" alt="">
                					        	
                                                </div>
                                            </li>
                                        
                                    
                                        
                                            <li>
                                                <div class="agileits_work_grid view view-sixth" style="height: 120px;margin-right: 15px;">
                
                					        		<img src="http://sahayikendra.com/embloyability/php/dashbord/style/commonElements/renderImage2c51.png?fileName=Gjinfotech_pvt_Ltd.png" class="img-responsive halfway" style="height: 100px;padding-top: 15px;margin: auto;" alt="">
                					        	
                                                </div>
                                            </li>
                                        
                                    
                                        
                                            <li>
                                                <div class="agileits_work_grid view view-sixth" style="height: 120px;margin-right: 15px;">
                
                					        		<img src="http://sahayikendra.com/embloyability/php/dashbord/style/commonElements/renderImage00d7.png?fileName=ATMA_FOUNDATION.png" class="img-responsive halfway" style="height: 100px;padding-top: 15px;margin: auto;" alt="">
                					        	
                                                </div>
                                            </li>
                                        
                                    
                                        
                                            <li>
                                                <div class="agileits_work_grid view view-sixth" style="height: 120px;margin-right: 15px;">
                
                					        		<img src="http://sahayikendra.com/embloyability/php/dashbord/style/commonElements/renderImage99f7.jpg?fileName=1550660767Index.jpg" class="img-responsive halfway" style="height: 100px;padding-top: 15px;margin: auto;" alt="">
                					        	
                                                </div>
                                            </li>
                                        
                                    
                                        
                                            <li>
                                                <div class="agileits_work_grid view view-sixth" style="height: 120px;margin-right: 15px;">
                
                					        		<img src="http://sahayikendra.com/embloyability/php/dashbord/style/commonElements/renderImage6540.jpg?fileName=KRHS_PANDIKASALA.jpg" class="img-responsive halfway" style="height: 100px;padding-top: 15px;margin: auto;" alt="">
                					        	
                                                </div>
                                            </li>
                                        
                                    
                                        
                                            <li>
                                                <div class="agileits_work_grid view view-sixth" style="height: 120px;margin-right: 15px;">
                
                					        		<img src="http://sahayikendra.com/embloyability/php/dashbord/style/commonElements/renderImage7161.png?fileName=CITS_SOLUTIONS.png" class="img-responsive halfway" style="height: 100px;padding-top: 15px;margin: auto;" alt="">
                					        	
                                                </div>
                                            </li>
                                        
                                    
                                        
                                            <li>
                                                <div class="agileits_work_grid view view-sixth" style="height: 120px;margin-right: 15px;">
                
                					        		<img src="http://sahayikendra.com/embloyability/php/dashbord/style/commonElements/renderImage25fa.jpg?fileName=AMALA_INSTITUTE_OF_ENGINEERING_AND_TECHNOLOGY.jpg" class="img-responsive halfway" style="height: 100px;padding-top: 15px;margin: auto;" alt="">
                					        	
                                                </div>
                                            </li>
                                        
                                    
                                        
                                            <li>
                                                <div class="agileits_work_grid view view-sixth" style="height: 120px;margin-right: 15px;">
                
                					        		<img src="http://sahayikendra.com/embloyability/php/dashbord/style/commonElements/renderImage8fa3.jpg?fileName=Beauty_Mark_Group_of_Companies.jpg" class="img-responsive halfway" style="height: 100px;padding-top: 15px;margin: auto;" alt="">
                					        	
                                                </div>
                                            </li>
                                        
                                    
                
                                </ul>
                
                            </div>
                        </div>
                        <!-- //Companies -->
                
                        <!-- here stars scrolling icon -->
                        <!-- flexSlider -->
                        <link rel="stylesheet" href="http://sahayikendra.com/embloyability/php/dashbord/style/publicsite/css/flexslider.css" type="text/css" media="screen"  />
                        <script type="text/javascript" src="http://sahayikendra.com/embloyability/php/dashbord/style/publicsite/js/jquery.flexisel.js"></script>
                        <script type="text/javascript" src="http://sahayikendra.com/embloyability/php/dashbord/style/publicsite/js/jquery.flexslider.js"></script>
                
                        <script>
                            $(document).ready(function() {
                
                            	  $('[data-toggle="tooltip"]').tooltip(); 
                            	  
                            $(".agile_count_grid").on('click', function(){
                				     window.location = "statistics.html";    
                				});
                                $('.flexslider').flexslider({
                                    animation: "slide",
                                    start: function(slider) {
                                        $('body').removeClass('loading');
                                    }
                                });
                                $("#flexiselDemo1").flexisel({
                                    visibleItems: 5,
                                    animationSpeed: 1000,
                                    autoPlay: true,
                                    autoPlaySpeed: 3000,
                                    pauseOnHover: true,
                                    enableResponsiveBreakpoints: true,
                                    responsiveBreakpoints: {
                                        portrait: {
                                            changePoint: 480,
                                            visibleItems: 1
                                        },
                                        landscape: {
                                            changePoint: 640,
                                            visibleItems: 2
                                        },
                                        tablet: {
                                            changePoint: 768,
                                            visibleItems: 3
                                        }
                                    }
                                });
                
                                $("#flexiselDemo-test").flexisel({
                                    visibleItems: 1,
                                    animationSpeed: 1000,
                                    autoPlay: true,
                                    autoPlaySpeed: 6000,
                                    pauseOnHover: true,
                                    enableResponsiveBreakpoints: true,
                                    responsiveBreakpoints: {
                                        portrait: {
                                            changePoint: 480,
                                            visibleItems: 1
                                        },
                                        landscape: {
                                            changePoint: 640,
                                            visibleItems: 2
                                        },
                                        tablet: {
                                            changePoint: 768,
                                            visibleItems: 3
                                        }
                                    }
                                });
                
                                $('.prev').on('click', function() {
                                    $('#flexiselDemo-test').flexslider('prev');
                                    return false;
                                })
                
                                $('.next').on('click', function() {
                                    $('#flexiselDemo-test').flexslider('next');
                                    return false;
                                })
                
                                $().UItoTop({
                                    easingType: 'easeOutQuart'
                                });
                
                            });
                        </script>
                        <!-- //here ends scrolling icon -->
                <?php
                include("php/dashbord/include/empfooter.php");
                //include("php/dashbord/totalreg.php");
                }
    		}
                ?>
                
                  
                <!-- for custom -->
                <script src="http://www.sahayikendra.com/embloyability/php/dashbord/style/js/publicsite/public.site.js"></script>
                <!-- //for custom --> 
                                     
                                    
                                   

