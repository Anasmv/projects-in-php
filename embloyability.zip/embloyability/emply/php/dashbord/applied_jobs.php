<?php
    include("../include/link.php");
    include('../conn/con.php');
    
    if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
               
    $iddd=$_POST['zz1'];
    
    ?>
    <div class="banner4">
         <div class="container">
            <h3>
             Applied Jobs
               
            </h3>
         </div>
         <?php
        include('sidebar.php');
        include("../include/style.php");
    ?>
      </div>
      <br><br>
     <?php
                        $sql1="SELECT vac_id,date_time FROM `applay_jobs` where cand_id='$iddd'";
                        $r1=mysqli_query($emply_cand,$sql1);
                        while($row1=$r1->fetch_assoc())
                        {
                        $v=$row1['vac_id'];
                        $z=$row1['date_time'];
                        
                        $sql="select * from add_vac where vac_id='$v'";
                        $r=mysqli_query($emply_employer,$sql);
                        if(mysqli_num_rows($r)>0)
                        {
                        while($row=$r->fetch_assoc())
                        {
                        $f=$row['job_title'];
                        $a=$row['company'];
                        $b=$row['location'];
                        $c=$row['qualification'];
                        $d=$row['exp'];
                        $e=$row['gender'];
                        $g=$row['salary'];
                        $i=$row['last_date _to_applay'];
                        $h=$row['no_of_vac'];
                        ?>
    
<div class="col-12 col-12 col-12 col-12 col-12 ">
  
    <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                <form action="" method="post" role="form" class="row " enctype="multipart/form-data">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group row">
                          
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                        
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Job Name:&nbsp</label> <?php echo $f; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                               
                                <label class="">company:&nbsp</label><?php echo $a; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                              
                                <label class="">Location:&nbsp</label><?php echo $b; ?>
                            </fieldset>
                        </div>
                        
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                               
                                <label class="">Qualification:&nbsp</label><?php echo $c; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Experience:&nbsp</label><?php echo $d; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Gender:&nbsp</label><?php echo $e; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">salary:&nbsp</label><?php echo $g; ?>
                            </fieldset>
                        </div>
                        <!--<div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">-->
                        <!--    <fieldset>-->
                        <!--        <input type='hidden' name='lda' value='<?php echo $i;?>'>-->
                        <!--        <div style="color:red"><label class="">Last_Date_to_Applay:&nbsp</label><?php //echo $i; ?></div>-->
                        <!--        <input type='hidden' name='vacidd' value='<?php// echo $v_id;?>'>-->
                        <!--        <input type='hidden' name='empid' value='<?php //echo $emp;?>'>-->
                        <!--    </fieldset>-->
                        <!--</div>-->
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Number of vaccancies:&nbsp</label><?php echo $h; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">Applied Date:&nbsp</label><?php echo $z; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <label class="">status:&nbsp</label><button type="buton" class="btn btn-success"><?php echo 'Applied'; ?> </button>
                            </fieldset>
                        </div>
                    </div>
                </form>
                 </div>
                 </div>
                 </div>
                  </div>
                
                        
                        <?php
                        }
                        }
                        }
   ?>
 


                
                <!--<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">-->
                <!--    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1">-->
                        
                <!--    </div>-->
                <!--    <div class="col-xl-11 col-lg-11 col-md-11 col-sm-11 col-11">-->
                <!--    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1">-->
                <!--    <div class="col-xl-9 col-lg-9 col-md-9 col-sm-9 col-9">-->
                <!--<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">-->
                <!--        <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-8 ">-->
                <!--    </div>-->
                    
                <!--    <div class="container">-->
                       
                <!--      <table class="table" border="1">-->
                <!--        <thead>-->
                <!--          <tr>-->
                <!--            <th>Post</th>-->
                <!--            <th>company</th>-->
                <!--            <th>Location</th>-->
                <!--            <th>Quialification</th>-->
                <!--            <th>Experience</th>-->
                <!--            <th>Gender</th>-->
                <!--            <th>Salary</th>-->
                <!--            <th>NUmber of Vaccancies</th>-->
                <!--            <th>Applied Date </th>-->
                <!--            <th>status</th>-->
                <!--          </tr>-->
                <!--        </thead>-->
                <!--        <tbody>-->

                       
                         
                                 
                <!--              </table>-->
                <!--              </div>-->
                <!--              </div>-->
                <!--              <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>-->
                <!--            </div>-->
                              
                <!--            </div>-->
                <!--        </div>-->


