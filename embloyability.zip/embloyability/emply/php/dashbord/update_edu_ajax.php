<?php
include('../conn/con.php');
if (!isset($_SESSION)) 
    {
         session_start(); 
    }
   echo $iddd=$_POST['ff1'];
    $sql="select * from education  where id='$iddd'";
    $r=mysqli_query($emply_emply,$sql);
    //  $sql2="select id from education  where id='$iddd'";
    // $r2=mysqli_query($emply_emply,$sql2);

?>
    <div class="banner1">
         <div class="container">
            <h3>
            Update Education2
               
            </h3>
         </div>
         <?php
         //echo $cand_id= $_SESSION['emply_id'];
        include("sidebar.php");
	    include("../include/style.php")
	?>
        
      </div>
      
<?php
        if($r->num_rows>0)
        {	
        while($row3=$r->fetch_assoc())
        {
        $a=$row3['qualification'];
        $c=$row3['college'];
        $d=$row3['university'];
        $k=$row3['year_of_pass'];
        $l=$row3['grade'];
        $x=$row3['id'];
        
        
        
    ?>
<br><br>
    <div class="col-12 col-12 col-12 col-12 col-12 ">
                        
                 

<div class="container">
    <div class="row">
          
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
           <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
               
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                     <form class="row" role="form" action="dashbord/checkingdb.php" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" onsubmit=" return validateform()">
               
                             <div class="form-group col-xl-6 col-lg-6 col-md-4 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="Inputcast">Qualification <span class="fas fa-star-of-life text-danger"></span></label>
                                        <select name="cast" class="round form-control" ?>
                                             <option><?php echo $a; ?></option>
                                            <?php
                                             $sql = "SELECT DISTINCT Qualification FROM course ORDER BY `course`.`Qualification` ASC";
                                            $q1=mysqli_query($emply_option,$sql);
                                            if(mysqli_num_rows($q1)>0)
                                            { 
                                            while($row=mysqli_fetch_assoc($q1))
                                            {
                                             ?>
                                              <option  value="<?php echo $row["Qualification"]; ?>"><?php 
                                          if($row['Qualification'] != $a)
                                            {
                                            echo $row['Qualification'];
                                            }
                                          ?>
                                             </option>
                                                                           
                                            <?php
                                           }
                                           }
                                            ?>
                                        </select>
                                        </fieldset>
                                    </div>
                                  
                                    
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">College<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="college" id="InputName" value="<?php echo $c; ?>" />
                                        </fieldset>
                                    </div>
                                   
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">University<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="university" id="InputName" value="<?php echo $d; ?>" />
                                        </fieldset>
                                    </div>
                                    <?php echo $iddd=$_POST['ff1'];?>
                                   
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Year of Passing<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="yop" id="InputName" value="<?php echo $k; ?>" />
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Grade<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="grade" id="InputName" value="<?php echo $l; ?>" />
                                        <input type="hidden" class="form-control round" name="vvv" id="InputName" value="<?php echo $iddd; ?>"/>
                                        </fieldset>
                                    </div>
   
                                    <div class="form-group col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                           <input type="submit" name="qqq"   value="Submit" class="btn btn-info mx-auto round form-control col">
                                            </div>
                                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                               <input type="submit" name="delete"   value="Delete" class="btn btn-danger mx-auto round form-control col" onclick="myFunction()"></a>
                                            </div>
                                    </div>
                                    
                                   
                     
</form>
                    </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                </div>
        </div>
    </div>
     
<script>
function myFunction() {
  confirm("Press a button!");
}
</script>

	
   

      
	  <?php  
 
//      if(isset($_POST['delete']))
// 	 {
	   
//          $sqls="DELETE FROM `education` WHERE id='$iddd'";
			  
// 			$result= mysqli_query($emply_emply,$sqls);
			
// 			 if($result)
// 			 {
// 				 echo"<script>alert('Your education details deleted successfully, Thanks')</script>";
//               echo"<script>window.open('update_edu.php','_self')</script>";
// 			 }
// 			 else
// 			 {
// 				 echo "not update";
// 			 }
// 	 }
	 
	 ?>
	
	 
	 	<?php
        
        }
        }
        
    ?>
