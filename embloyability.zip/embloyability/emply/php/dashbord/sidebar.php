
		<?php
include("../include/link.php");
include("../include/sessionlog.php");
include("../include/style.php");
echo'<br><br><br><br><br>';
 if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
   $aa=  $_SESSION['emply_id'];
?>


   <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> </link>

    <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
         
        <button class="w3-bar-item w3-button w3-large"onclick="w3_close()">Close &times;</button>
        <a span class="glyphicon glyphicon-home w3-bar-item w3-button" style="font-size:18px" id=<?php echo $aa;?> onclick="home(this.id)";> Home </a></span>
        <a span class="glyphicon glyphicon-briefcase w3-bar-item w3-button" style="font-size:18px" id=<?php echo $aa;?> onclick="vacc(this.id)";> vacancies </a></span>
        <a span class="glyphicon glyphicon-bullhorn w3-bar-item w3-button" style="font-size:18px"> Jobs Fairs </a></span>
        <a span class="glyphicon glyphicon-ok w3-bar-item w3-button" style="font-size:18px" id=<?php echo $aa;?> onclick="app(this.id)";> Applied jobs </a></span>
        <a span class="glyphicon glyphicon-folder-open w3-bar-item w3-button" style="font-size:18px"> Job offers </a></span>
        <a span class="fa fa-refresh w3-bar-item w3-button" style="font-size:18px" id=<?php echo $aa;?> onclick="updp(this.id)";> Update Profile </a></span>
        <a span class="fa fa-refresh w3-bar-item w3-button" style="font-size:18px" id=<?php echo $aa;?> onclick="upde(this.id)";> Update Education </a></span>
        <a span class="fa fa-refresh w3-bar-item w3-button" style="font-size:18px" id=<?php echo $aa;?> onclick="updw(this.id)";> Update Experience </a></span>
        <a span class="fa fa-refresh w3-bar-item w3-button" style="font-size:18px" id=<?php echo $aa;?> onclick="aprvcv(this.id)";> Create CV  </a></span>
    </div>
    <div id="main">
            <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;Menu</button>
    </div>
   
               
    
   
<script>
function w3_open() {
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidebar").style.width = "25%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}
function w3_close() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}
</script>
<script>
    
  function vacc(y) {    
        $(document).attr("title","vacancilDetails");
        var yy=y;
        $("#mains").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/vacanciview.php",
                data:{yy1:yy},
                cache: false,
                beforeSend: function() {
                    $('#mains').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#mains").html(html);
            }
            });
            }

    
  function app(z) {    
        $(document).attr("title","APPLIEDlJOBS");
        var zz=z;
        $("#mains").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/applied_jobs.php",
                data:{zz1:zz},
                cache: false,
                beforeSend: function() {
                    $('#mains').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#mains").html(html);
            }
            });
            }
            
            function updp(x) {    
        $(document).attr("title","UPDATE PROFILE");
        var xx=x;
        $("#mains").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/update_cand.php",
                data:{xx1:xx},
                cache: false,
                beforeSend: function() {
                    $('#mains').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#mains").html(html);
            }
            });
            }
            
            function upde(w) {    
        $(document).attr("title","UPDATE EDUCATION");
        var ww=w;
        $("#mains").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/update_edu.php",
                data:{ww1:ww},
                cache: false,
                beforeSend: function() {
                    $('#mains').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#mains").html(html);
            }
            });
            }
            
             function updw(v) {    
        $(document).attr("title","UPDATE WORK");
        var vv=v;
        $("#mains").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/update_work.php",
                data:{vv1:vv},
                cache: false,
                beforeSend: function() {
                    $('#mains').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#mains").html(html);
            }
            });
            }
            function aprvcv(q) {
               $(document).attr("title", "CV");                
        var qq=q;
        $("#mains").html("");
        
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/cvv.php",
                 data :{ qq1: qq},
                cache: false,
                 beforeSend: function() {
                    $('#mains').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                 success: function(html) {
                     $("#mains").html(html);
                     
              	 //   document.getElementById(id).innerHTML = "Applied";
              	 //   document.getElementById(id).style.backgroundColor = "green";
              	    
              	 //       alert('Applied Success');
              	    w3_close();
                 }
            });   
    }
            
             function home(h) {    
        $(document).attr("title","HOME");
        var hh=h;
        $("#mains").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/main_cand.php",
                data:{hh1:hh},
                cache: false,
                beforeSend: function() {
                    $('#mains').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#mains").html(html);
            }
            });
            }
            
</script>
