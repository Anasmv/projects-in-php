
<html>
    <head>
<style>
table {
	font-family: sans-serif;
	border: 7mm solid aqua;
	border-collapse: collapse;
}
</style>
</head>
<?php
    include("../../../sahayi/php/mpdf57/mpdf.php");
   
    $mpdf=new mPDF('utf-8-s');
    $mpdf->debug=true;
    $mpdf->tabSpaces = 6;
    $mpdf->charset_in='windows-1252';
    $mpdf = new mPDF('', 'A4');
    $emply_cv = new mysqli("localhost", "sahayikendra", "sahayikendra@Azalea", 'emply_CAND_CV');
    $sql2 = "SELECT * FROM `cvv` WHERE id = '1' ";
    $result2 = $emply_cv->query($sql2);
    while($row2 = $result2->fetch_assoc())
    {
    $row2['id'];
    $victa= $row2['text'];
    }
    
      
    
    $title = 'resume';
    $mpdf->SetTitle($title);
    $mpdf->AddPage('','A4','','','',10,10,10,10,10,10);
    //$mpdf->WriteHTML($victa);
    $mpdf->SetAuthor('Aboobacker');
    $mpdf->SetDrawColor(100,100,100);
    
    // $mpdf->SetFont('Arial','B',12);
    eval('?>'.$victa.'<?php;');
    
                     $emply_img = new mysqli("localhost", "sahayikendra", "sahayikendra@Azalea", 'emply_image');
                                       $res=mysqli_query($emply_img,"select * from image_table WHERE user_id='25'");
                                         
                                             while($row=mysqli_fetch_array($res))
                                               {
               
                                                $abc=$row['data'];
                                                 ?>
                                              <table>
                                                <tr>
                                                <td>

                                                     <?php
                                                  $img= '<img  src="data:image/jpeg;base64,'.base64_encode($row['data'] ).'" height="15" width="15" alt="rounded"  />';?></td></tr>
                                                  </table>
                                                    
                                             <?php
                    $mpdf = new MPDF();
$mpdf->AddPage();
$mpdf->SetFont('Arial','B',14);
$mpdf->Cell(40,10,'Hello Image!');
$mpdf->Image($img,10,30,40,40,'jpg');
 $mpdf->WriteHTML($img);
              eval('?>'.$victa.'<?php;');       
  
   
    $mpdf->Output();
     exit;
                                               }
?>
  
                                              
