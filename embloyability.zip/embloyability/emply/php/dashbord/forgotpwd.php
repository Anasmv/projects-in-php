<?php
include("../include/link.php");
include("../include/style.php");
?>
<br><br><br><br><br>
<html>
<head>
</head>
<body>
<form action='php/dashbord/checkingdb.php' method="POST">
    <h3>Enter your registerd Username and Mobile Number.</h3>
<table>
<tr>
<td><label>User name</label>
<td><input type ="text" name = "uname" ></td>
</tr>
<tr>
<td><label>Mobile number</label>
<td><input type ="number" name = "mob" ></td>
</tr>
<!--<tr>-->
<!--<td><label>Email</label>-->
<!--<td><input type ="email" name = "mail" ></td>-->
<!--</tr>-->
<!--<tr>-->
   <td><input type="submit" name="forpwd" value="submit"></td>
   </tr>
</table>
</form>
</body>
</html>
