
<?php
if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
?>
 
      <!-- banner1 -->
      <div class="banner1">
         <div class="container">
            <h3>Account Log in</h3>
         </div>
      </div>
      <!-- //banner1 -->
      <!-- about -->
      <div class="about" >
         <div class="container">
            <div class="col-md-12 test-center" style="margin-bottom: 20px;">
               <h3 class="head"> Log In / Register</h3>
            </div>
            <div class="col-md-4 col-md-offset-1">
               <div class="well">
                  
                  
	                   		
	
		                        <div class="form-group">
		                             <div class="input-group"> 
		                              <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
										  <input type="text" class="form-control " id='usr' placeholder="Email or Username" required  >
										 
									 </div> 
		                        </div>
		                        <div class="form-group"> 
		                         	 <div class="input-group"> 
		                         	  <span class="input-group-addon"><i class="fa fa-key" aria-hidden="true"></i></span>
										 <input type="password" class="form-control " id='pw' placeholder="Password" required >
										
									 </div> 
		                        </div>
		                        
		                        <div class="form-group">
		                         <button type="submit" onclick='checklogin();' class="btn btn-primary active">login</button>
		                        </div>
		                        
		                          <div class="form-group">
		                         <a onclick='forgott();' class="reset">Forgot Password ?</a>  
		                          
		                        </div>
	                         
	
	                        
	                       
	                    	
	                </div> 
			
			</div>
            <div class="col-md-6 left-bor col-md-offset-1">
               <div class="row">
                  <div class="col-md-8 col-md-offset-3"><br/><br/>
                     <a onclick='reg_cand();' class="btn btn-primary btn-block" style="color:white";>Register as candidate</a><br/>
                  </div>
                  <div class="col-md-8 col-md-offset-3">
                     <a  onclick='reg_empy();'  class="btn btn-success btn-block" style="color:white";>Register as Employer</a>
                  </div>
               </div>
            </div>
            <div class="clearfix"> </div>
         </div>
      </div>
  

<!-- //for custom --> 
<?php
include("../include/empfooter.php");
?>
<script>
    
</script>
<?php
         
       
?>
