<?php
include "../include/headerout.php";
include("../include/link.php");
include('../conn/con.php');

if (!isset($_SESSION)) 
        {
          session_start(); 
        }
        $cand_id= $_SESSION['emply_id'];
        $sql="select * from resume  where u_id='$cand_id'";
        $r=mysqli_query($emply_CV,$sql);

?>
<div id='mains'>
    <div class="banner1">
        <div class="container">
            <h3>
             Certificates
               
            </h3>
        </div>
        
        <?php
	   include("../include/style.php");
	   ?>
     </div>
      

    <br><br>

    <div class="container" >
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                    <form action="" method="post" role="form" class="row " enctype="multipart/form-data">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                <fieldset>
                                    <label class="">Certificates:&nbsp</label>
                                        <span style="font-size:13px" >
                                            <?php
                                            if($r->num_rows>0)
                                            {	
                                                while($row3=$r->fetch_assoc())
                                                {
                                                $a=$row3['certificates'];
                                            
                                           
      if($a !='0' && $a!=NULL)
      {  ?>
                                                <li> <?php echo $a; ?></li>
                                            <?php
      }
                                                }
                                            }
                                            
                                            ?> 
                                         </span>
                                </fieldset>
                            </div>
                           
                           
                    </form>
 <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                <fieldset>
                                     <a href="cvv.php" class="round btn btn-primary"><b>Add More</b></a>
                                       <button class="btn btn-success round"   id="<?php echo $cand_id; ?>" onClick=" skip(this.id);">Skip</button>
                                </fieldset>
                            </div>
                        </div>
                </div>
            </div>
        </div>
    </div>
</div>          
                   <script>
//   function skip(qw) {    
//         $(document).attr("title","Add Course");
//         var cuu=qw;
//         $("#mains").html("");
//             $.ajax({
//                 type: "POST",
//                 url: "http://www.sahayikendra.com/emply/php/dashbord/course.php",
//                 data:{ cuu1:cuu},
//                 cache: false,
//                 beforeSend: function() {
//                     $('#mains').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
//                 },
//                 success: function(html) {
//                 $("#mains").html(html);
//             }
//             });
//             }
          
            </script>   