 
<?php

       include('../conn/con.php');
  
        if(isset($_POST['user']))
        {
            
        if (!isset($_SESSION)) 
        {
            session_start(); 
        }
         $us=$_POST['user'];
         $pwd=$_POST['pwd'];
       
        $sql="select * from login where (email='$us' or mob='$us' or user_name='$us')";
        $ww=mysqli_query($emply_emply,$sql);
        
        $s=mysqli_num_rows($ww);
        $row=mysqli_fetch_array($ww);
        $acc=$row['account_type'];
       
        $_SESSION['acc_emply']=$acc;
        $pass=$row['password'];
        $uid=$row['user_id'];
        $_SESSION['emply_id']=$uid;
        $res2=mysqli_query($emply_emply,"select * from reg_candidate where u_id='$uid'");
          while( $row2=mysqli_fetch_array($res2))
           {
             $id=$row2['u_id'];
           }
         
         if(password_verify($pwd, $pass))
            {
                if($s>0)
                {
                    if($acc=='admin')
                    {
                       
                        echo'<script>alert("logined admin");</script>';        
                         echo"<script>window.location='http://www.sahayikendra.com/emply/php/dashbord/admin.php';</script>";
                        }
                        
                       
                    
                    
                   if($acc=='candidate')
                    {
                       if($uid==$id)
                       {
                        echo'<script>alert("logined cand");</script>';        
                         echo"<script>window.location='http://www.sahayikendra.com/emply/php/';</script>";
                        }
                        
                        else
                        {
                            echo'<script>alert("logined reg");</script>';  
                           echo"<script>window.location='http://www.sahayikendra.com/emply/php/dashbord/regcand.php';</script>"; 
                        }
                    }
                    
                    $res3=mysqli_query($emply_emply,"select * from reg_employer where emp_id='$uid'");
          while( $row3=mysqli_fetch_array($res3))
           {
             $idd=$row3['emp_id'];
           }
                    if($acc=='Employer')
                    {
                        if($uid==$idd)
                       {
                           $_SESSION['emply_id']=$uid;
                    	//echo "<h1> logined in employer/h1>";
                    	    echo'<script>alert("logined emp");</script>'; 
                     	echo"<script>window.location='http://www.sahayikendra.com/emply/php/';</script>";
                     	
                        }
                        else
                        {
                            echo'<script>alert("logined regemp");</script>'; 
                             echo"<script>window.location='http://www.sahayikendra.com/emply/php/dashbord/regemp.php';</script>"; 
                        }
                    
                	
                    }
                    
                   
            
                }
            } 
            else
            {
            	
            	 echo "<h1>Incorrupt Username and Password</h1>";
            		 	//echo"<script>window.location='http://www.sahayikendra.com/emply/';</script>";
            }
        }
        
        
        // add cand
        
if(isset($_POST['register']))
     {
        $usname=$_POST['uname'];
        $email=$_POST['email'];
        $pwd1=$_POST['pwd'];
        $pwd2=$_POST['cpwd'];
         $mobile=$_POST['mob'];
    if($pwd1==$pwd2)
    {
        $pwd=password_hash($pwd1, PASSWORD_DEFAULT);  
        $sql="INSERT INTO `login`( `user_name`, `email`, `mob`, `account_type`, `password`) VALUES('$usname','$email','$mobile','candidate','$pwd')";
        $res=mysqli_query($emply_emply,$sql);
        }
    else
    {
         echo'<script>alert("PASSWORD DOESNOT MATCH");</script>';
    }
    if($res)
    {
        echo'<script>alert("success");</script>';
        echo"<script>window.location='http://www.sahayikendra.com/emply/';</script>";
    }
    else
    {
     echo'<script>alert("Not Registerd");</script>';   
     echo"<script>window.location='http://www.sahayikendra.com/emply/';</script>";
    }
    }
    ?>
    
    <!--add employ-->
     <?php  
   
    if(isset($_POST['regemp']))
     {
        echo$usname=$_POST['uname'];
       echo $email=$_POST['email'];
        echo$pwd1=$_POST['pwd'];
        echo$pwd2=$_POST['cpwd'];
       echo $mobile=$_POST['mob'];
    if($pwd1==$pwd2)
    {
        $pwd=password_hash($pwd1, PASSWORD_DEFAULT);  
        $sql="INSERT INTO `login`( `user_name`, `email`, `mob`, `account_type`, `password`) VALUES('$usname','$email','$mobile','Employer','$pwd')";
        $res=mysqli_query($emply_emply,$sql);
        }
    else
    {
         echo'<script>alert("PASSWORD DOESNOT MATCH");</script>';
    }
    if($res)
    {
        echo'<script>alert("success");</script>';
        echo"<script>window.location='http://www.sahayikendra.com/emply/';</script>";
    }
    else
    {
     echo'<script>alert("Not Registerd");</script>';
     echo"<script>window.location='http://www.sahayikendra.com/emply/';</script>";
    }
    }
?>

    
    
    
    <?php  
        echo $iddd=$_GET['iddd_id'];
     if(isset($_POST['edit']))
	 {
	    $quali=$_POST['cast'];
        $college=$_POST['college'];
        $university=$_POST['university'];
        $yop=$_POST['yop'];
        $grade=$_POST['grade'];
        
         $sqls="UPDATE `education` SET `qualification`='$quali',`college`='$college',`university`='$university',`year_of_pass`='$yop',`grade`='$grade' where id='$iddd'";
			  
			$result= mysqli_query($emply_emply,$sqls);
			
			 if($result)
			 {
				 echo"<script>alert('Your Account profile has been Updated successfully, Thanks')</script>";
               echo"<script>window.location='http://www.sahayikendra.com/emply/php';</script>"; 
			 }
			 else
			 {
				 echo "not update";
			 }
	 }
	 
	 ?>
	 
	   <?php  
 include('../conn/con.php');
     if(isset($_POST['qqq']))
	 {
	    $eduid=$_POST['vvv'];
	    $quali=$_POST['cast'];
        $college=$_POST['college'];
        $university=$_POST['university'];
        $yop=$_POST['yop'];
        $grade=$_POST['grade'];
        
         $sqls="UPDATE `education` SET `qualification`='$quali',`college`='$college',`university`='$university',`year_of_pass`='$yop',`grade`='$grade' where id='$eduid'";
			  
			$result= mysqli_query($emply_emply,$sqls);
			
			 if($result)
			 {
				 echo"<script>alert('Your Account profile has been Updated successfully, Thanks')</script>";
              echo"<script>window.location='http://www.sahayikendra.com/emply/php';</script>"; 
			 }
			 else
			 {
				 echo "not update";
			 }
	 }
	 
	 ?>
	 
	  <?php  
 
     if(isset($_POST['www']))
	 {
	     $eduidd=$_POST['eee'];
	    echo $cmp=$_POST['cmp'];
        echo $pos=$_POST['pos'];
        echo $exp1=$_POST['exp'];
        echo $exp2=$_POST['expy'];
   
        
         $sqls="UPDATE `work_exp` SET `company`='$cmp',`position`='$pos',`exp_in_month`='$exp1',`exp_in_year`='$exp2' where id='$eduidd'";
			  
			$result= mysqli_query($emply_emply,$sqls);
			
			 if($result)
			 {
				 echo"<script>alert('Your Account work experience has been Updated successfully, Thanks')</script>";
                echo"<script>window.location='http://www.sahayikendra.com/emply/php';</script>"; 
			 }
			 else
			 {
				 echo "not update";
			 }
	 }
	 ?>
	  <?php  
 
     if(isset($_POST['delete']))
	 {
	   
         $sqls="DELETE FROM `work_exp` WHERE id='$iddd'";
			  
			$result= mysqli_query($emply_emply,$sqls);
			
			 if($result)
			 {
				 echo"<script>alert('Your education details deleted successfully, Thanks')</script>";
               echo"<script>window.location='http://www.sahayikendra.com/emply/php';</script>";
			 }
			 else
			 {
				 echo "not update";
			 }
	 }
	 
	 ?>
	 
	 
	 
	 
	 
	 <?php  
	 include('../conn/con.php');
     if(isset($_POST['cv']))
	 {
        $certif=$_POST['certi'];
         $resume=$_POST['cvv'];
       
	    $sql="INSERT INTO `resume`(`id`, `u_id`,`certificates`,`course`)
				        VALUES (NULL,'$resume','$certif','0')";
		$r=mysqli_query($emply_CV,$sql);
		 if($emply_CV) 
           {
               echo 'hello';
           }

        if($r)
		{
		echo '<script>alert("succesfull");</script>';
      echo"<script>window.location='http://www.sahayikendra.com/emply/php/dashbord/viewcerti.php';</script>";				
		}
		else
		{
		echo "not inserted";
					  
		}
	 }
	 ?>
	 
	 
	 <?php  
     if(isset($_POST['cour']))
	 {
        $cou=$_POST['cours'];
         $resumec=$_POST['cuu'];
       
	    $sql="INSERT INTO `resume`(`id`, `u_id`,`certificates`,`course`)
				        VALUES (NULL,'$resumec','0','$cou')";
		$r=mysqli_query($emply_CV,$sql);
		 if($emply_CV) 
           {
               echo 'hello';
           }

        if($r)
		{
		echo '<script>alert("succesfull");</script>';
      echo"<script>window.location='http://www.sahayikendra.com/emply/php/dashbord/viewcourse.php';</script>";				
		}
		else
		{
		echo "not inserted";
					  
		}
	 }
	 ?>
	 
	 
	 
	 
	 
	    <?php  
 
     if(isset($_POST['register']))
	 {
		$iddd=$_POST['profile'];
	    $fname=$_POST['fname'];
	    $lname=$_POST['lname'];
	    $mother=$_POST['mname'];
	    $father=$_POST['faname'];
	   echo $gender=$_POST['sex'];
        $db=$_POST['dob'];
	    $religion=$_POST['religion'];
	    $cast=$_POST['cast'];
	    $ict=$_POST['identity_card_type'];
	    $icn=$_POST['id_no'];
	    $lng=implode(',', $_POST['vehicle']);
        $ad1=$_POST['add1'];
        $ad2=$_POST['add2'];
        $ad3=$_POST['add3'];
    	$country=$_POST['country'];
        $state=$_POST['state'];
    	$district=$_POST['district'];
    	$loc_type=$_POST['loc_type'];
    	$loc_name=$_POST['loc_name'];
    	$place=$_POST['place'];
        $pincode=$_POST['pin'];
    	$quali=$_POST['quali'];
        $college=$_POST['college'];
        $university=$_POST['university'];
        $yop=$_POST['yop'];
        $grade=$_POST['grade'];
        $sub = implode(',',$_POST['subject']);
        $company=$_POST['company'];
        $position=$_POST['position'];
        $em=$_POST['exp_in_months'];
        $ey=$_POST['exp_in_year'];
            if (!isset($_SESSION)) 
            {
                session_start(); 
            }
         
            $sqls="UPDATE `reg_candidate` SET `first_name`='$fname',`last_name`='$lname',`mothers_name`='$mother',`fathers_name`='$father',`gender`='$gender',`date_of_birth`='$db',`religion`='$religion',`cast`='$cast',`identity_card_type`='$ict',`identity_card_no`='$icn',`language_known`='$lng',`address1`='$ad1',`address2`='$ad2',`address3`='$ad3',`country`='$country',`state`='$state',`district`='$district',
            `loc_type`='$loc_type',`loc_name`='$loc_name',`place`='$place',`pincode`='$pincode',`qualification`='$quali',`college`='$college',`university`='$university',`year_of_pass`='$yop',`grade`='$grade',`skills`='$sub',`company`='$company',`position`='$position',`exp_in_month`='$em',`exp_in_year`='$ey' where u_id='$iddd'";
			  
			$result= mysqli_query($emply_emply,$sqls);
			
			
            $uimageData = mysqli_real_escape_string($emply_img,(file_get_contents($_FILES['myfile']['tmp_name'])));
            if($uimageData == '')
            {
                $uimageData=$abc;
            }
			$sqli = "UPDATE image_table SET data='$uimageData'  WHERE  user_id='$iddd'";
            $stmt = mysqli_prepare($emply_img,$sqli);
            mysqli_stmt_bind_param($stmt, "s",$img);
            mysqli_stmt_execute($stmt);
            $check = mysqli_stmt_affected_rows($stmt);
    
			 if($result)
			 {
				echo"<script>alert('Your Account profile has been Updated successfully, Thanks')</script>";
                echo"<script>window.location='http://www.sahayikendra.com/emply/php';</script>"; 
			 }
			 else
			 {
				 echo "not update";
			 }
           
   
	 }
		 
		 ?>




<!--ADD vacc-->


	<?php  
    if(isset($_POST['emply']))
	{
	   if (!isset($_SESSION)) 
        {
            session_start(); 
        }
        $iddd=$_POST['add'];
	    $notifi=$_POST['noti'];
        date_default_timezone_set("Asia/Kolkata");
        $time= date('d-m-Y h:i:a');
		
    $job=$_POST['job'];
    $comp=$_POST['cmp'];
    $locn=$_POST['lcn'];
	$qualif=$_POST['quali'];
	$expi=$_POST['exp'];
	$gend=$_POST['sex'];
	$sala=$_POST['sal'];
	$date=$_POST['lda'];
	$nov=$_POST['numv'];
                
                 
                 	 $sql="INSERT INTO `add_vac`( `emp_id`, `job_title`, `company`, `location`, `qualification`, `experience`, `gender`, `salary`, `last_date _to_applay`, `no_of_vac`,`date_time`)VALUES ( '$iddd','$job','$comp','$locn','$qualif','$expi','$gend','$sala','$date','$nov','$time')";
                //  	 VALUES('5','2','j','c','l','q','e','g','s','p','12/06/1997')
					  $r=mysqli_query($emply_employer,$sql);
					  
					  //echo "hello";
					 if($r)
					 {
				    echo"<script>alert('Vaccanci Added')</script>";
                    echo"<script>window.location='http://www.sahayikendra.com/emply/php';</script>"; 
					  }
					  else
					  {
						  echo"<script>alert('Not Inserted')</script>";
					  
					  }
	}
				  ?>
				  
				  
				  
				  
				  
				  
				  <!--MAIL-->
				   <?php
                if(isset($_POST['mailll']))
                        {
                            $iddd=$_POST['ma'];
                        echo $mail=strip_tags($_POST['mail']);
                         $sql1="SELECT emp_id, cand_id FROM `applay_jobs`where vac_id='$iddd' ";
                         $r1=mysqli_query($emply_cand,$sql1);
                         if(mysqli_num_rows($r1)>0)
                         { 
                         while($row1=$r1->fetch_assoc())
                          {
                              $v=$row1['emp_id'];
                              $z=$row1['cand_id'];
                          }
                         }
                          $sql7="SELECT email FROM `login`where user_id='$v'";
                        $rrr=mysqli_query($emply_emply,$sql7);
                        if(mysqli_num_rows($rrr)>0)
                         { 
                         while($row3=$rrr->fetch_assoc())
                         {
                          $se=$row3['email'];
                         }
                         }
                           $sql3="SELECT email FROM `login`where user_id='$z'";
                        $rre=mysqli_query($emply_emply,$sql3);
                        if(mysqli_num_rows($rre)>0)
                         { 
                         while($row5=$rre->fetch_assoc())
                         {
                          $ss=$row5['email'];
                         }
                         }
	                    
                            //require_once('./include/PHPMailer-master');
                        $flags = 'style="display:none;"';
                        $to = $ss;
                        $subject = "SAHAYIKENDRA OFFICIAL MAIL";
                        $attachment = chunk_split(base64_encode(file_get_contents($_FILES['file']['tmp_name'])));
                        $filename =$_FILES['file']['name'];
                        $boundary =md5(date('r', time()));
                        //$headers = "";
                        //$headers = $se;
                        $headers = "From: abu@gmail.com\r\n Reply-To: abu547@gmail.com";
                        $headers .= "\r\nMIME-Version: 1.0\r\nContent-Type: multipart/mixed; boundary=\"_1_$boundary\"";
                        

                        $mail="This is a multi-part
        fullname in MIME format.

--_1_$boundary
Content-Type: multipart/alternative; boundary=\"_2_$boundary\"

--_2_$boundary
Content-Type: text/plain; charset=\"iso-8859-1\"
Content-Transfer-Encoding: 7bit

$mail

--_2_$boundary--
--_1_$boundary
Content-Type: application/octet-stream; name=\"$filename\" 
Content-Transfer-Encoding: base64 
Content-Disposition: attachment 

$attachment
--_1_$boundary--";



       // mail($to, $subject, $fullname, $headers);
                        $ma=mail($to,$subject,$mail,$headers);
                        if($ma)
                        {
                        echo"<script>alert('SENDING SUCCESSFULLY')</script>";
                        echo"<script>window.location='http://www.sahayikendra.com/emply/php';</script>"; 
                        }
                        
                         else
                         {
                         		echo"<script>alert('Can't Send)</script>";
                        }
                        
                         }
     

                ?>
                 <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
                 
                 
                 
                 
                 
                 
                 
                 <!--update employ-->
                 
                 
     <?php  
   
     if(isset($_POST['upemp']))
	 {
	     $abc=$_POST['ff'];
	$iddd=$_POST['rrr'];	
    echo $ename=$_POST['ename'];
    echo "<br>";
    echo $cname=$_POST['cname'];
    echo "<br>";
	echo $email=$_POST['cemail'];
	echo "<br>";
	echo $cnumber=$_POST['cnumber'];
	echo "<br>";
    echo $mob=$_POST['mob'];
    echo "<br>";
	echo $mobile=$_POST['amob'];
	echo "<br>";
	echo $cemail=$_POST['email'];
	echo "<br>";
	echo $pin=$_POST['pincode'];
	echo "<br>";
	echo $ad1=$_POST['add1'];
    echo "<br>";
    echo $ad2=$_POST['add2'];
    echo "<br>";
    echo $ad3=$_POST['add3'];
    echo "<br>";
    echo $country=$_POST['country'];
    echo "<br>";
    echo $state=$_POST['state'];
    echo "<br>";
    echo $district=$_POST['district'];
    echo "<br>";
    if (!isset($_SESSION)) 
            {
                session_start(); 
            }
         
            $sqls="UPDATE `reg_employer` SET `employer_name`='$ename',`point_of_contact_name`='$cname',`point_of_contact_email`='$email',
            `contact_number`='$cnumber',`phone_number`='$mob',`alternate_number`='$mobile',`email`='$cemail',`pincode`='$pin',`address1`='$ad1',`address2`='$ad2',`address3`='$ad3',`country`='$country',`state`='$state',`district`='$district' where emp_id='$iddd'";
			$result= mysqli_query($emply_emply,$sqls);
			
		
              
                                       $res=mysqli_query($emply_img,"select * from emp_img WHERE emp_id='$iddd'");
                                         
                                             while($row=mysqli_fetch_array($res))
                                               {
               
                                                 $abc=$row['data'];
                                                //   echo '<img class="round shadow" src="data:image/jpeg;base64,'.base64_encode($row['data'] ).'" height="150" width="150" alt="rounded" />';
                                               }
                						
            $uimageData = mysqli_real_escape_string($emply_img,(file_get_contents($_FILES['meefile']['tmp_name'])));
            if($uimageData == '')
            {
                $uimageData=$abc;
            }
			$sqli = "UPDATE emp_img SET data='$uimageData'  WHERE  emp_id='$iddd'";
            $stmt = mysqli_prepare($emply_img,$sqli);
            mysqli_stmt_bind_param($stmt, "s",$img);
            mysqli_stmt_execute($stmt);
            $check = mysqli_stmt_affected_rows($stmt);
          
		
              
                                       $res3=mysqli_query($emply_img,"select * from emp_docs WHERE emp_id='$iddd'");
                                         
                                             while($row4=mysqli_fetch_array($res3))
                                               {
               
                                                 $abcd=$row4['data'];
                                                   //echo '<img class="round shadow" src="data:image/jpeg;base64,'.base64_encode($row4['data'] ).'" height="150" width="150" alt="rounded" />';
                                               }
                					
		
             $uimageData = mysqli_real_escape_string($emply_img,(file_get_contents($_FILES['mrrfile']['tmp_name'])));
            if($uimageData == '')
            {
                $uimageData=$abcd;
            }
			$sql5 = "UPDATE emp_docs SET data='$uimageData'  WHERE  emp_id='$iddd'";
            $stmt1 = mysqli_prepare($emply_img,$sql5);
            mysqli_stmt_bind_param($stmt1, "s",$img);
            mysqli_stmt_execute($stmt1);
            $check1 = mysqli_stmt_affected_rows($stmt1);
           
            
           // $imageFileType = strtolower(pathinfo($vimageData,PATHINFO_EXTENSION));
            //if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif" ) 
			//{
			if($result || $check ||  $check1)
			{
				    echo "<script>alert('Your Account profile has been Updated successfully, Thanks');</script>";
                    echo"<script>window.location='http://www.sahayikendra.com/emply/php';</script>"; 
				 //echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			}else
			{
			    echo "<script>alert('Not Updated');</script>";
			     echo"<script>window.location='http://www.sahayikendra.com/emply/php';</script>";
			}
			    
	 }
            
		 ?>
		 
		 
		 
		 
		 
		 <!--Add Notification-->
		 
		  <?php
		  
		  
		  
                        if(isset($_POST['addnot']))
                        {
                            
                        echo $iddd=$_POST['notification'];   
                        $notifi=$_POST['noti'];
                        date_default_timezone_set("Asia/Kolkata");
                        $time= date('d-m-Y h:i:a');
                 
                         $sql1="SELECT emp_id, cand_id FROM `applay_jobs`where vac_id='$iddd' ";
                         $r1=mysqli_query($emply_cand,$sql1);
                         if(mysqli_num_rows($r1)>0)
                         { 
                         while($row1=$r1->fetch_assoc())
                          {
                              $v=$row1['emp_id'];
                              $z=$row1['cand_id'];
                          }
                         }
                          $sql7="SELECT email FROM `login`where user_id='$v'";
                        $rrr=mysqli_query($emply_emply,$sql7);
                        if(mysqli_num_rows($rrr)>0)
                         { 
                         while($row3=$rrr->fetch_assoc())
                         {
                          $se=$row3['email'];
                         }
                         }
                           $sql3="SELECT email FROM `login`where user_id='$z'";
                        $rre=mysqli_query($emply_emply,$sql3);
                        if(mysqli_num_rows($rre)>0)
                         { 
                         while($row5=$rre->fetch_assoc())
                         {
                          $ss=$row5['email'];
                         }
                         }
                       echo $iddd=$_POST['notification'];   
                        $notifi=$_POST['noti'];
                        date_default_timezone_set("Asia/Kolkata");
                        $time= date('d-m-Y h:i:a');
                        
                        $sql="INSERT INTO `notification`( `vac_id`, `emp_id`, `cand_id`, `messege`,`date_time`)VALUES ('$iddd','$v','$z','$notifi','$time')";
                        $res=mysqli_query($emply_employer,$sql);
    
                        if($res)
                        {
                           
                         echo'<script>alert("success");</script>';
                         echo"<script>window.location='http://www.sahayikendra.com/emply/php';</script>";
                        }
                        else
                        {
                            
                         echo'<script>alert("Not Registerd");</script>'; 
                         echo"<script>window.location='http://www.sahayikendra.com/emply/php';</script>";
                        }
                        }
                        
                        
                        
                        
                        
                        
                    
include('../conn/con.php');
    if(!$emply_emply)
    {
        echo"failed";
    }

if(isset($_POST['forpwd']))
{
 $us=$_POST['uname'];
  $mob=$_POST['mob'];
 $mail=$_POST['mail'];
  $pass=rand ( 10000 , 99999 );

$sql="select * from login  where mob='$mob' or email='$mail' ";
$ww=mysqli_query($emply_emply,$sql);
$s=mysqli_num_rows($ww);
$row=mysqli_fetch_array($ww);
 $o=$row['email'];
if($s>0)
{
	$sql1="select * from login where user_name='$us' or email='$o' ";
	
	$a=mysqli_query($emply_emply,$sql1);
	$b=mysqli_num_rows($a);
	if($b>0)
    {
     $to = $o;
     $subject = "My subject";
     $txt = $pass;
    $headers = "From:employability@gmail.com";
    $ma=mail($to,$subject,$txt,$headers);
    if($ma)
    {
        $pas=password_hash($pass, PASSWORD_DEFAULT);
        //  $pas=md5($pass);
	    $query="update login set password='$pas' where user_name='$us'";
		$c=mysqli_query($emply_emply,$query);
		if($c)
		{
			echo"<script>alert('Sending Email to Your Redisterd Email id ,SUCCESSFULLY')</script>";
			echo"<script>window.location='http://www.sahayikendra.com/emply/';</script>";
		}
}
}
}
else
{
		echo "<h1>MSG NOT SEND</h1>";
}

}

     

                ?>
   

