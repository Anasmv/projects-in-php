<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<?php
include("../include/link.php");
include('../conn/con.php');
//include("sidebar.php");
include("../include/style.php");

    if (!isset($_SESSION))
        {
            session_start(); 
            
        }
    $cand_id= $_SESSION['emply_id'];  
    $iddd=$_GET['idd_id'];
    $sql="select * from reg_candidate where u_id='$cand_id'";
    $r=mysqli_query($emply_emply,$sql);
    
    $sql1="select * from login where user_id='$cand_id'";
    $r2=mysqli_query($emply_emply,$sql1);
    
     date_default_timezone_set("Asia/Kolkata");
     $time= date('Y-m-d');
  
       

    ?>
<style>    
    
    .body {
  margin: 0;
  padding: 0;
  background-color: #FAFAFA;
  font: 12pt "Tahoma";
}

* {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
}

.page {
  width: 21cm;
  min-height: 29.7cm;
  padding: 2cm;
  margin: 1cm auto;
  border: 1px #D3D3D3 solid;
  border-radius: 5px;
  background: white;
  /*box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);*/
}
.right {
  position: absolute;
  right: 0px;
  width: 550px;
  padding: 3px;
}
.subpage {
  padding: 1cm;
  border: 5px red solid;
  height: 256mm;
  outline: 2cm #FFEAEA solid;
}

@page {
  size: A4;
  margin: 0;
}
.img {
  border: 1px solid #ddd;
  border-radius: 4px;
  padding: 5px;
  width: 150px;
}

@media print {
  .page {
    margin: 0;
    border: initial;
    border-radius: initial;
    width: initial;
    min-height: initial;
    box-shadow: initial;
    background: initial;
    page-break-after: always;
  }
}

</style>

<div class="book" id='book'>
  <div class="page">
    <!--<div class="subpage"></div>-->
     <?php
    if($r->num_rows>0)
    {				     
        $row=$r->fetch_assoc();
        $a=$row['first_name'];
        $b=$row['last_name'];
        $c=$row['mothers_name'];
        $d=$row['fathers_name'];
        $e=$row['gender'];
        $f=$row['date_of_birth'];
        $g=$row['religion'];
        $h=$row['cast'];
        $i=$row['identity_card_type'];
        $j=$row['identity_card_no'];
        $k=$row['language_known'];
        $l=$row['address1'];
        $m=$row['address2'];
        $n=$row['address3'];
        $o=$row['country'];
        $p=$row['state'];
        $q=$row['district'];
        $r=$row['loc_type'];
        $s=$row['loc_name'];
        $t=$row['place'];
        $u=$row['pincode'];
        $v=$row['qualification'];
        $w=$row['college'];
        $x=$row['university'];
        $y=$row['year_of_pass'];
        $z=$row['grade'];
        $aa=$row['skills'];
       
        

    }
         if($r2->num_rows>0)
    {				     
        $row=$r2->fetch_assoc();
        $ii=$row['email'];
        $jj=$row['mob'];
          

    }
    
       
  
    ?>
    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 form-group texting-in">
      
        <?php
            $res=mysqli_query($emply_img,"select * from image_table WHERE user_id='$cand_id'");
            while($row=mysqli_fetch_array($res))
                {
                    $abc=$row['data'];
                    
                    echo '<img class="w3-border"" src="data:image/jpeg;base64,'.base64_encode($row['data'] ).'" height="150" width="150" alt="rounded" />';
              }
        ?>

    </div>
    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 form-group texting-in">
        <fieldset>
        <label class=""> <?php echo $a;?>&nbsp<?php echo $b;?></label><br>
        <label class=""> <?php echo $l;?>(H)</label><br>
        <label class=""> <?php echo $m;?></label><br>
        <label class=""> <?php echo $n;?></label><br>
        <label class="">Mob:<?php echo $jj;?></label><br>
        <label class="">Email:<?php echo $ii;?></label><br>
        </fieldset>
    </div>
    <br><br><br><br><br><br><br><br><br>
    <div class="w3-container">
        <div class="w3-bar w3-border w3-light-grey">
            <div class="w3-bar-item"><b>EXPERIENCE</b></div>
        </div>
    </div>
    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 form-group texting-in">
       <?php
      $sql2="select id,company,position,exp_in_month,exp_in_year from work_exp  where u_id='$cand_id'";
    $r3=mysqli_query($emply_emply,$sql2);
     if($r3->num_rows>0)
        {	
        while($row3=$r3->fetch_assoc())
        {
        $xx=$row3['company'];
        $zz=$row3['position'];
        $yy=$row3['exp_in_month'];
        $cc=$row3['exp_in_year'];
    ?>
    <ul>
        <li><b><?php echo $zz;?></b></li>
          &nbsp&nbsp&nbsp<?php echo $yy;?> Experience at <?php echo $xx;?>
    </ul>
      <?php
        }
        }
    ?>
        
    </div>
  
     <div class="w3-container">
        <div class="w3-bar w3-border w3-light-grey">
            <div class="w3-bar-item"><b>Educational Qualification</b></div>
        </div>
    </div>
    
    <div class="container">
        <table class="table">
            <thead>
              <tr>
                <th>Qualification</th>
                <th>Board/University</th>
                <th>Year of Pass</th>
              </tr>
            </thead>
            
    <?php
      $sql2="select * from education  where u_id='$cand_id'";
    $r3=mysqli_query($emply_emply,$sql2);
     if($r3->num_rows>0)
        {	
        while($row3=$r3->fetch_assoc())
        {
        $qq=$row3['qualification'];
        $uu=$row3['university'];
        $yyp=$row3['year_of_pass'];
    
    ?>
            <tbody>
              <tr>
                <td><?php echo $qq;?></td>
                <td><?php echo $uu;?></td>
                <td><?php echo $yyp;?></td>
              </tr>
              
            </tbody>
        
	<?php
        }
        }
    ?>
 </table>
    </div>
     <div class="w3-container">
        <div class="w3-bar w3-border w3-light-grey">
            <div class="w3-bar-item"><b>Course</b></div>
        </div>
    </div>
    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 form-group texting-in">
    <?php
      $sql4="select course from resume  where u_id='$cand_id'";
    $r4=mysqli_query($emply_CV,$sql4);
     if($r4->num_rows>0)
        {	
        while($row4=$r4->fetch_assoc())
        {
        $coursee=$row4['course'];
        
    
    ?>
     <ul type="square">
      <?php
       if($coursee !='0' && $coursee !=NULL)
      {
          ?>
     <li><?php echo "$coursee"?> </li>
     <?php
      }
      ?>
    </ul>
    <?php
        }
        }
        ?>
        </div>
    <div class="w3-container">
        <div class="w3-bar w3-border w3-light-grey">
            <div class="w3-bar-item"><b>Certificates</b></div>
        </div>
    </div>
     <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 form-group texting-in">
    <?php
      $sql4="select * from resume  where u_id='$cand_id'";
    $r4=mysqli_query($emply_CV,$sql4);
     if($r4->num_rows>0)
        {	
        while($row4=$r4->fetch_assoc())
        {
        $cert=$row4['certificates'];
    
    ?>
    <ul type="square">
      <?php 
      if($cert !='0' && $cert !=NULL)
      {
          ?>
          
     <li> <?php echo $cert ?></li>
     <?php
      }
      ?>
    </ul>
  <?php
        }
        }
    ?>
    </div>
    <div class="w3-container">
        <div class="w3-bar w3-border w3-light-grey">
            <div class="w3-bar-item"><b>Skills</b></div>
        </div>
    </div>
     <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 form-group texting-in">
    <?php
      $sql5="select * from reg_candidate  where u_id='$cand_id'";
    $r5=mysqli_query($emply_emply,$sql5);
     if($r5->num_rows>0)
        {	
        while($row5=$r5->fetch_assoc())
        {
        $skl=$row5['skills'];
    
    ?>
    <ul type="circle">
      <li><?php echo $skl?></li>
    </ul>
  <?php
        }
        }
    ?>
    </div>

  </div>
  <div class="page">
    <!--<div class="subpage"></div>-->
    <div class="w3-container">
        <div class="w3-bar w3-border w3-light-grey">
            <div class="w3-bar-item"><b>LANGUAGES KNOWN</b></div>
        </div>
    </div>
    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 form-group texting-in">
    <?php
      $sql6="select * from reg_candidate  where u_id='$cand_id'";
    $r6=mysqli_query($emply_emply,$sql6);
     if($r6->num_rows>0)
        {	
        while($row6=$r6->fetch_assoc())
        {
        $lng=$row6['language_known'];
    
    ?>
    <ul type="disc">
      <li><?php echo $lng?></li>
    </ul>
  <?php
        }
        }
    ?>
    </div>
    <div class="w3-container">
        <div class="w3-bar w3-border w3-light-grey">
            <div class="w3-bar-item"><b>Declaration</b></div>
        </div>
    </div><br>
    <p>I hereby solemnly affirm that all the details provided above are true to the best of my knowledge and belief.I shall carry myself in a manner that lends diginity to the organization and worthy enough of the person.</p><br>
    
    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 form-group texting-in">
        <fieldset>
        
        <label class="">Place : <?php echo $t;?></label><br>
        <label class="">Date : <?php echo $time;?></label>
        </fieldset>
    </div>
     <div align="right" >
    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-4 form-group texting-in">
        <fieldset>
        <label class="">Signature</label><br>
        <label class="">(<?php echo$a;?>&nbsp<?php echo $b;?>)</label>
        </fieldset>
    </div>
    </div>
  </div>
</div>
<button onclick="javascript:printDiv('book')">Print this page</button>

<script>
function myFunction() {
  window.print();
}
</script>

    <script language="javascript" type="text/javascript">
        function printDiv(book) {
            alert('print this page');
            //Get the HTML of div
            var divElements = document.getElementById(book).innerHTML;
            //Get the HTML of whole page
            var oldPage = document.body.innerHTML;

            //Reset the page's HTML with div's HTML only
            document.body.innerHTML = 
              "<html><head><title></title></head><body>" + 
              divElements + "</body>";

            //Print Page
            window.print();

            //Restore orignal HTML
            document.body.innerHTML = oldPage;

          
        }
    </script>

</head>
<body>
    <form id="form1" runat="server">
    <!--<div id="printablediv" style="width: 100%; background-color: Blue; height: 200px">-->
    <!--    Print me I am in 1st Div-->
    <!--</div>-->
    <!--<div id="donotprintdiv" style="width: 100%; background-color: Gray; height: 200px">-->
    <!--    I am not going to print-->
    <!--</div>-->
    <input type="button" value="Print 1st Div" onclick="javascript:printDiv('printablediv')" />
    </form>
</body>
</html>
    