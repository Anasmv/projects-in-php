 <?php
    session_start(); 
 if(session_destroy())
    {  
      echo"<script type='text/javascript'>
                        alert('SUCESSFULLY LOGOUT');
					    window.location='http://www.sahayikendra.com/emply/';
					 </script>";
	
    }

?>
