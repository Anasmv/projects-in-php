<?php
//include("./include/headerout.php");
include("../include/link.php");
include('../conn/con.php');
if (!isset($_SESSION)) 
        {
          session_start(); 
        }
         echo $cand_id= $_SESSION['emply_id'];
        //echo$iddd=$_GET['idd_id'];
        // $aa= $_SESSION['emply_id'];
    $sql="select company,position,exp_in_month,exp_in_year from work_exp where u_id='$cand_id'";
    $r=mysqli_query($emply_emply,$sql);

?>
<div class="banner1">
         <div class="container">
            <h3>
             Home
               
            </h3>
         </div>
         <?php
         //echo $cand_id= $_SESSION['emply_id'];
       // include("sidebar.php");
	    include("../include/style.php")
	?>
        
      </div>
      
<?php
        if($r->num_rows>0)
        {	
        while($row3=$r->fetch_assoc())
        {
        $a=$row3['company'];
        $c=$row3['position'];
        $k=$row3['exp_in_month'];
        $l=$row3['exp_in_year'];
    
    ?>
<br><br>
    <div class="col-12 col-12 col-12 col-12 col-12 ">
                        
                 

<div class="container">
    <div class="row">
          
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
           <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
               
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                <form action="" method="post" role="form" class="row " enctype="multipart/form-data">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group row">
                          
                        </div>
                       
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                        
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                <fieldset>
                                        <label class="">company:&nbsp</label> <span style="font-size:13px" ><?php echo $a; ?> </span>
                                </fieldset>
                                </div>
                                                   
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                <fieldset>
                                    <label class="">position:&nbsp</label><span style="font-size:13px" ><?php echo $c; ?></span>
                                </fieldset>
                            </div>
                            
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                <fieldset>
                                    <label class="">Total Experience Month :&nbsp</label><span style="font-size:13px" > <?php echo $k; ?></span>
                                </fieldset>
                            </div>
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                <fieldset>
                                   <label class="">Total Experience year :&nbsp</label><span style="font-size:13px" > <?php echo $l ?></span><br>
                                   
                                </fieldset>
                            </div>
                        
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                 <a href="add_work.php" class="round btn btn-primary"><b>Add More</b></a>
                                 <a href="http://www.sahayikendra.com/emply/php/" class="round btn btn-success"><b>Skip</b></a>
                            </fieldset>
                        </div>
                  <!--          <div class="col-md-8 col-md-offset-3"><br/><br/>-->
                  <!--   <a  href="add_edu.php" class="btn btn-primary btn-block">Add More</a><br/>-->
                  <!--</div>-->
                           
                        </form>

                    </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                </div>
        </div>
    </div>
    <?php
    }
        }
    ?>