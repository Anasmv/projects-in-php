<?php
include('./include/link.php');
include('../conn/con.php');
include('emp_sidebar.php');
include('../include/style.php');
if (!isset($_SESSION)) 
            {
                session_start(); 
            }
                      
    //$iddd=$_GET['idd_id'];
   echo $iddd=$_POST['tt1'];
    
   

?>
<br><br><br><br><br><br>
<div class="container">
    <div class="row">
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
           <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                    <h2 class="text-center" style="color:red">Add Notification </h2>
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
                    <form class="row" role="form" action="dashbord/checkingdb.php" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" >
                        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                            <fieldset>
                            <textarea class="form-control round" name="noti" id="InputName" required/></textarea>
                            <label for="InputName">Subject </label>
                            <input type='hidden' name='notification' value='<?php echo $iddd;?>'>
                            </fieldset>
                        </div>
                         
                        <div class="form-group col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                    <input type="submit" name="addnot" id="submit" value="Add" class="btn btn-info mx-auto round form-control col">
                                </div>
                    </form>
                        </div>
                </div>



                
	          