<?php
    // Total candidate
    include('../conn/con.php'); 
    $sql="select id from reg_candidate";
    $r=mysqli_query($emply_emply,$sql);
    while($row=$r->fetch_assoc())
    {
        $i=$row['id'];
    }
    //count code....
    $post1="SELECT  COUNT(*) as total FROM reg_candidate ";
    $post2=mysqli_query($emply_emply,$post1);
    $roo1=mysqli_fetch_assoc($post2);
    $post=$roo1['total'];echo '<br>';
              //end count code
              
        //  Total employers 
    $sql3="SELECT id FROM `reg_employer`";
    $r1=mysqli_query($emply_emply,$sql3);
    while($row1=$r1->fetch_assoc())
    {
        $ii=$row1['id'];
    }
    //count code....
    $post3="SELECT  COUNT(*) as total FROM reg_employer ";
    $post4=mysqli_query($emply_emply,$post3);
    $roo4=mysqli_fetch_assoc($post4);
    $post6=$roo4['total'];
                                
                                
    //  Total Vccancies                           
    $sql4="SELECT * FROM `add_vac`";
    $r1=mysqli_query($emply_employer,$sql4);
    while($row1=$r1->fetch_assoc())
    {
        $ii=$row1['vac_id'];
    }
                    //count code....
    $post4="SELECT  COUNT(*) as total FROM add_vac ";
    $post5=mysqli_query($emply_employer,$post4);
    $roo5=mysqli_fetch_assoc($post5);
    $post7=$roo5['total'];
                                
                                    
    //  Total Applied                               
    $sql5="SELECT * FROM `applay_jobs`";
    $r1=mysqli_query($emply_cand,$sql5);
    while($row1=$r1->fetch_assoc())
    {
        $ii=$row1['app_id'];
    }
    //count code....
    $postx="SELECT  COUNT(*) as total FROM applay_jobs ";
    $posty=mysqli_query($emply_cand,$postx);
    $roo7=mysqli_fetch_assoc($posty);
    $postz=$roo7['total'];
                                
                                
        //end count code
    ?>