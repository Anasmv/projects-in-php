
<?php
include("../include/headerout.php");
include("../include/link.php");
include('../conn/con.php');
include("../include/style.php");

if (!isset($_SESSION)) 
            {
                session_start(); 
            }
            
            
           echo $idddddd= $_SESSION['emply_id'];
            //$iddd=$_GET['idd_id'];
?>
   <br><br><br><br>
    <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <br>
                        <div class="progress round">
                            <div class="progress-bar" style="width:0%" id="prog"></div>
                        </div>
                        <br>
                    </div>
                           
                                <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-6 col-6 bg-primary text-light round text-center" id="info" >
                                <lable ><h3>Employer Information</h3></lable>
                                </div>
                                <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-10 col-10 bg-secondary text-light round text-center" id="contact">
                                <lable ><h3>Contact Details</h3></lable>
                                </div>
                                <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" id="upload">
                                    <lable ><h3>Upload Document</h3></lable>
                                </div>
                               
                            </div>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
                            <form class="row" role="form" action="" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" onsubmit=" return validateform()">
                                
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="information">
                                    <div class="form-group col-xl-9 col-lg-9 col-md-9 col-sm-7 col-7 text-center"> </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next1()">
                                    <lable ><h3>NEXT >> </h3></lable>
                                     </div>
                
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group ">
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-4 form-group float-left">
                                        <img class="round shadow border-light" border="1" width="100" height="100" name="image"  id="thumbnil" >
                                        </div>
                                        <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-8 form-group float-left">
                                        <label for="InputName">Employer Logo <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="file" class="" name="myfile" id="image"  accept="image/*" onchange="showMyImage(this)" required>
                                        <label class="text-danger" for="InputName">image must be 'jpeg' or 'png'</label>
                                        </div>
                                    </div>
                    
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Employer Name <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="ename" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Contact Name <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="cname" id="InputName" required/>
                                         </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName"> Contact Email <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="email" class="form-control round" name="cemail" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName"> Contact Number<span class="fas fa-star-of-life text-danger"></span></label>    
                                        <input type="number" class="form-control round" name="cnumber" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    
                                   
                                    
                                    <div class="form-group col-xl-9 col-lg-9 col-md-9 col-sm-7 col-7 text-center"> </div>
                                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" tabindex="7" onclick="next1()">
                                            <lable ><h3>NEXT >> </h3></lable>
                                        </div>
                                </div>
                    
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="contact_details">
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next()">
                                        <lable ><h3> << BACK</h3></lable>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next2()">
                                        <lable ><h3>NEXT >> </h3></lable>
                                    </div>
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Phone Number <span class="fas fa-star-of-life text-danger"></span></label>    
                                        <input type="number" class="form-control round" name="mob" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Alternate Number <span class="fas fa-star-of-life text-danger"></span></label>    
                                        <input type="number" class="form-control round" name="amob" id="InputName" />
                                        </fieldset>
                                    </div>
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">email <span class="fas fa-star-of-life text-danger"></span></label>    
                                        <input type="email" class="form-control round" name="email" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">pincode <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="number" class="form-control round" name="pincode" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Address1 <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="add1" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Address2 <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="add2" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName"> Address3<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="add3" id="InputName" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                   
                                        <SELECT type="text" class="round form-control"  tabindex="8" name="country" id="mylist" required onChange="showState(this)">
                                        
                                          <?php
                                            
                                            $sql = "SELECT DISTINCT country FROM area_table ORDER BY `area_table`.`country` ASC";
                                            $res=mysqli_query($emply_option,$sql);
                                            ?>
            								<option value="" >Please Select country</option>
                                            <?php while($row=$res->fetch_assoc())
            								{ ?>
                                                <option  value="<?php echo $row["country"]; ?>"><?php echo $row["country"]; ?></option>
                                            <?php } ?>
                                        </SELECT>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                        <SELECT type="text" class="round form-control" name="state" tabindex="9" id="output1" onchange="showDistrict(this);">
                                            <option value="" >Please Select state</option>
                                        </SELECT>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                        <SELECT type="text" class="round form-control" name="district" tabindex="10" id="output2" onchange="showlclType(this);">>
                                            <option value="" >Please Select district</option>
                                        </SELECT>
                                    </div>
                                  
                                  
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next()">
                                        <lable ><h3> << BACK</h3></lable>
                                     </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next2()">
                                        <lable ><h3>NEXT >> </h3></lable>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="Upload_Document">
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next1()">
                                        <lable ><h3> << BACK</h3></lable>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next3()">
                                        <lable ><h3>NEXT >> </h3></lable>
                                    </div>
                                  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group ">
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-4 form-group float-left">
                                        <img class="round shadow border-light" border="1" width="100" height="100" name="imagee"  id="thumbnill" >
                                        </div>
                                        <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-8 form-group float-left">
                                        <label for="InputName">upload Documents <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="file" class="" name="mefile" id="imagee"  accept="image/*" onchange="showMyImage1(this)" required>
                                        <label class="text-danger" for="InputName">image must be 'jpeg' or 'png'</label>
                                        </div>
                                    </div>
                                    
                                 
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next1()">
                                        <lable ><h3> << BACK</h3></lable>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    
                                </div>
                                    
                                    <div class="form-group col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                                <input type="submit" name="register" id="submit" value="Submit" class="btn btn-info mx-auto round form-control col">
                                            </div>
                                    </div>
                                </form>
                
                                
                            </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                </div>
        </div>
    </div>    

	    <?php  
   
     if(isset($_POST['register']))
	 {
		
    echo $ename=$_POST['ename'];
    echo "<br>";
    echo $cname=$_POST['cname'];
    echo "<br>";
	echo $email=$_POST['cemail'];
	echo "<br>";
	echo $cnumber=$_POST['cnumber'];
	echo "<br>";
    echo $mob=$_POST['mob'];
    echo "<br>";
	echo $mobile=$_POST['amob'];
	echo "<br>";
	echo $cemail=$_POST['email'];
	echo "<br>";
	echo $pin=$_POST['pincode'];
	echo "<br>";
	echo $ad1=$_POST['add1'];
    echo "<br>";
    echo $ad2=$_POST['add2'];
    echo "<br>";
    echo $ad3=$_POST['add3'];
    echo "<br>";
    echo $country=$_POST['country'];
    echo "<br>";
    echo $state=$_POST['state'];
    echo "<br>";
    echo $district=$_POST['district'];
    echo "<br>";
    
    if (!isset($_SESSION)) 
            {
                session_start(); 
            }
            
            echo $_SESSION['acc'];
				 $sql="INSERT INTO `reg_employer`(`id`,`emp_id`, `employer_name`, `point_of_contact_name`, `point_of_contact_email`, `contact_number`, `phone_number`, `alternate_number`, `email`, `pincode`, `address1`, `address2`, `address3`, `country`, `state`, `district`) VALUES (NULL,'$idddddd','$ename','$cname','$email','$cnumber','$mob','$mobile','$cemail','$pin','$ad1','$ad2','$ad3','$country','$state','$district')";
					  $r=mysqli_query($emply_emply,$sql);
					  
					  //echo "hello";
					 if($r)
					 {
					  echo "data inserted";
						 // header("refresh:2;url=login.php");
					  }
					  else
					  {
						  echo "not inserted";
					  
					  }

				   
	 
    $msg = '';
    $image=$_FILES['myfile']['tmp_name'];
    $img = file_get_contents($image);
    //$un=$_GET['user_name'];
     $sql2 = "INSERT INTO `emp_img`( `id`,`emp_id`, `name`, `data`)values(NULL,'$idddddd','$image',?)";

    $stmt = mysqli_prepare($emply_img,$sql2);

    mysqli_stmt_bind_param($stmt, "s",$img);
    mysqli_stmt_execute($stmt);

    $check = mysqli_stmt_affected_rows($stmt);
    
    $image=$_FILES['mefile']['tmp_name'];
    $img = file_get_contents($image);
    
    //$un=$_GET['user_name'];
     $sql3 = "INSERT INTO `emp_docs`( `id`,`emp_id`, `name`, `data`)values(NULL,'$idddddd','$image',?)";

    $stmt = mysqli_prepare($emply_img,$sql3);

    mysqli_stmt_bind_param($stmt, "s",$img);
    mysqli_stmt_execute($stmt);

    $check2 = mysqli_stmt_affected_rows($stmt);
    
    $image=$_FILES['doc']['tmp_name'];
    $img = file_get_contents($image);
    
    //$un=$_GET['user_name'];
     $sql4 = "INSERT INTO `emp_docs`( `id`,`emp_id`, `name`, `data`)values(NULL,'$idddddd','$image',?)";

    $stmt = mysqli_prepare($emply_img,$sql4);

    mysqli_stmt_bind_param($stmt, "s",$img);
    mysqli_stmt_execute($stmt);

    $check3 = mysqli_stmt_affected_rows($stmt);
    
    if($check=$r)
    {
    echo '<script>alert("succesfull");</script>';
    	echo"<script>window.location='http://www.sahayikendra.com/emply/';</script>";
    }
	 }
		 
		 
		 ?>
		 
		 <script>
function showMyImage1(fileInput) {
var files = fileInput.files;
for (var i = 0; i < files.length; i++) {
var file = files[i];
var imageType = /image.*/;
if (!file.type.match(imageType)) {
continue;
}
var img=document.getElementById("thumbnill");
img.file = file;
var reader = new FileReader();
reader.onload = (function(aImg) {
return function(e) {
aImg.src = e.target.result;
};
})(img);
reader.readAsDataURL(file);
}
}
function showMyImage(fileInput) {
var files = fileInput.files;
for (var i = 0; i < files.length; i++) {
var file = files[i];
var imageType = /image.*/;
if (!file.type.match(imageType)) {
continue;
}
var img=document.getElementById("thumbnil");
img.file = file;
var reader = new FileReader();
reader.onload = (function(aImg) {
return function(e) {
aImg.src = e.target.result;
};
})(img);
reader.readAsDataURL(file);
}

}
function showMyImage3(fileInput) {
var files = fileInput.files;
for (var i = 0; i < files.length; i++) {
var file = files[i];
var imageType = /image.*/;
if (!file.type.match(imageType)) {
continue;
}
var img=document.getElementById("thumbnilll");
img.file = file;
var reader = new FileReader();
reader.onload = (function(aImg) {
return function(e) {
aImg.src = e.target.result;
};
})(img);
reader.readAsDataURL(file);
}

}

function changeFunc2() {
var select2 = document.getElementById("output4");
var selectedValue = select2.options[select2.selectedIndex].value;
if (selectedValue=="not_listed"){
$('#textboxes').show();
$('#textbox1').show();
$("#newplace1").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
$("#newplace2").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
$("#newplace3").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
}
else {
$('#textboxes').hide();
$('#textbox1').hide();

$("#newplace1").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
$("#newplace2").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
$("#newplace3").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
}
}

function changeFunc3() {
var select3 = document.getElementById("caste");
var selectedValue1 = select3.options[select3.selectedIndex].value;
if (selectedValue1=="not_listed2"){
$('#txtEnglish133').show();
$('#txtbox').show();
$("#rel").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
$("#caste1").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
}
else {
$('#txtEnglish133').hide();
$('#txtbox').hide();
$("#rel").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12");
$("#caste1").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12");
}
}
    function showState(sel) {
        var country_id = sel.options[sel.selectedIndex].value;
        $("#output1").html("");
        /*
        $("#output2").html("");
        $("#output3").html("");
        $("#output4").html("");
        $("#output5").html("");
        */
        if (country_id.length > 0) {

            $.ajax({
                type: "POST",
               
                url: "http://www.sahayikendra.com/emply/php/dashbord//fetch_area.php",
                data: "country=" + country_id,
                cache: false,
                beforeSend: function() {
                    $('#output1').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output1").html(html);
                }
            });
        }
    }

    function showDistrict(sel) {
        var state_id = sel.options[sel.selectedIndex].value;
        if (state_id.length > 0) {
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord//fetch_area.php",
                data: "state=" + state_id,
                cache: false,
                beforeSend: function() {
                    $('#output2').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output2").html(html);
                }
            });	
        } else {
            $("#output2").html("");
        }
    }
    
    function showlclType(sel) {
        
        var district = sel.options[sel.selectedIndex].value;
		document.cookie = "district=" + district;
        if (district.length > 0){
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord//fetch_type1.php",
                data: "district=" + district ,
                cache: false,
                beforeSend: function() {
                    $('#output5').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output5").html(html);
                }
            });
        } else {
            $("#output5").html("");
        }
    }
     function showLclArea(sel) {
        var lcltype = sel.options[sel.selectedIndex].value;
        if (lcltype.length > 0) {
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord//fetch_area.php",
                data: "lcltype=" + lcltype,
                cache: false,
                beforeSend: function() {
                    $('#output3').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output3").html(html);
                }
            });
        } else {
            $("#output3").html("");
        }
    }
    
    function showPlace(sel) {
        var lclarea = sel.options[sel.selectedIndex].value;
        if (lclarea.length > 0) {
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/fetch_area.php",
                data: "lclarea=" + lclarea,
                cache: false,
                beforeSend: function() {
                    $('#output4').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output4").html(html);
                }
            });
        } else {
            $("#output4").html("");
        }
    }
     window.onload = function fresh(){
	    $("#information").show();
	    $("#contact_details").hide();
	    $("#Upload_Document").hide();
	    
    }
    
function next() {
	    document.getElementById("info").classList.add('bg-primary');
	    document.getElementById("info").classList.remove('bg-secondary');
	    document.getElementById("contact").classList.add('bg-secondary');
	    document.getElementById("contact").classList.remove('bg-primary');
	    document.getElementById("upload").classList.add('bg-secondary');
	    document.getElementById("upload").classList.remove('bg-primary');
	    document.getElementById("prog").style.width="20%";
	    
	    $("#information").show();
	    $("#contact_details").hide();
	    $("#Upload_Document").hide();
	   
	};
	function next1() {
	    document.getElementById("info").classList.add('bg-secondary');
	    document.getElementById("info").classList.remove('bg-primary');
	    document.getElementById("contact").classList.add('bg-primary');
	    document.getElementById("contact").classList.remove('bg-secondary');
	    document.getElementById("upload").classList.add('bg-secondary');
	    document.getElementById("upload").classList.remove('bg-primary');
	    document.getElementById("prog").style.width="75%";
	    
	    $("#information").hide();
	    $("#contact_details").show();
	    $("#Upload_Document").hide();
	};
	function next2() {
	    document.getElementById("info").classList.add('bg-secondary');
	    document.getElementById("info").classList.remove('bg-primary');
	    document.getElementById("contact").classList.add('bg-secondary');
	    document.getElementById("contact").classList.remove('bg-primary');
	    document.getElementById("upload").classList.add('bg-primary');
	    document.getElementById("upload").classList.remove('bg-secondary');
	    document.getElementById("prog").style.width="100%";

	    $("#information").hide();
	    $("#contact_details").hide();
	    $("#Upload_Document").show();
	  
	};
	
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
$(function() {
// Multiple images preview in browser
var imagesPreview = function(input, placeToInsertImagePreview) {
if (input.files) {
var filesAmount = input.files.length;
for (i = 0; i < filesAmount; i++) {
var reader = new FileReader();
reader.onload = function(event) {
$($.parseHTML('<img>')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
}
reader.readAsDataURL(input.files[i]);
}
}
};
$('#gallery-photo-add').on('change', function() {
imagesPreview(this, 'div.gallery');
});
});
</script> 
<!--input type="file" multiple id="gallery-photo-add">
<div class="gallery"-->


<script type="text/javascript">
    $(function () {
        $('#lstFruits').multiselect({
            includeSelectAllOption: true
        });
    });
</script>


     <script src="http://www.sahayikendra.com/php/dashbord/script/multiselect.js" type="text/javascript">
         
     </script>
   
    
    

     