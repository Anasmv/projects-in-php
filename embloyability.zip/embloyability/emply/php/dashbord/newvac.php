<?php
    include("../include/link.php");
    include('../conn/con.php');
   // include("../include/headerout.php");
//	include('../include/sessionlog.php');
	

   if (!isset($_SESSION)) 
        {
          session_start(); 
        }
      $zzz= $_POST['uu1'];
         if(!isset($_POST['uu1']))
         {
             $cand_id= $_SESSION['emply_id'];
         }
     
?>
<div class="banner1">
         <div class="container">
            <h3>
             Vaccancies
               
            </h3>
         </div>
         <?php
        include("sidebar.php");
	    include("../include/style.php")
	?>
        
      </div>
      <br><br>
<script>
function changeQuestion(answer)
	{
document.getElementById(answer).style.backgroundColor = "RED";
document.getElementById(answer).value="APPLIED";
	}
	
// jQuery('.icon-box').on('click', function() {
//  if (jQuery(this).hasClass('clicked')) {
//   $(this).removeClass('clicked');
//   }
//   else
//   {
//   $(this).addClass('clicked');
//   }

// });
	
</script>
 
    <?php
    // $iddd ;
    
    // $sql3="SELECT * FROM `applay_jobs` where ";
    
    
    
    //  $sql3="SELECT vac_id,emp_id FROM `applay_jobs` WHERE cand_id='$iddd'";
    // $res2=mysqli_query($emply_cand,$sql3);
    // if(mysqli_num_rows($res2)>0)
    // {
    // while($row2=$res2->fetch_assoc())
    // {
    //   echo $candd=$row2['vac_id']; 
    //   $emp=$row2['emp_id']; 
    // }
    // }
    //  $sql4="SELECT vac_id FROM `add_vac` WHERE vac_id='$candd'";
    // $res4=mysqli_query($emply_employer,$sql4);
    // if(mysqli_num_rows($res4)>0)
    // {
    // while($row4=$res4->fetch_assoc())
    // {
    //  echo $vvv=$row4['vac_id'];  
    // }
    // }
    
    
    
        
    $sql="SELECT * FROM `add_vac` where vac_id='$zzz'";
    $res=mysqli_query($emply_employer,$sql);
    if(mysqli_num_rows($res)>0)
    {
    while($row=$res->fetch_assoc())
    {
    $emp=$row['emp_id'];
    $v_id=$row['vac_id'];
    $f=$row['job_title'];
    $a=$row['company'];
    $b=$row['location'];
    $c=$row['qualification'];
    $d=$row['experience'];
    $e=$row['gender'];
    $g=$row['salary'];
    $h=$row['posted_by'];
    $i=$row['last_date _to_applay'];
    $j=$row['no_of_vac'];
    $k=$row['date_time'];
    
     $sqlap = "SELECT `app_id`, `cand_id`, `emp_id`, `vac_id`, `date_time` FROM `applay_jobs` WHERE vac_id = '$v_id' AND cand_id = '$cand_id'";
     $resap=mysqli_query($emply_cand,$sqlap);
     $rowap=mysqli_fetch_array($resap);
     $appid = $rowap['app_id'];
     $vacidd = $rowap['vac_id'];
     if($vacidd != $v_id)
     {
    
    
    ?>
     <div class="col-12 col-12 col-12 col-12 col-12 ">
                        
                 

<div class="container">
    <div class="row">
          
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
           <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
               
                </div>
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                <form action="" method="post" role="form" class="row " enctype="multipart/form-data">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group row">
                          
                        </div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 ">
                        
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <input type='hidden' name='job' value='<?php echo $f;?>'>
                                <label class="">Job Name:&nbsp</label> <?php echo $f; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <input type='hidden' name='cmp' value='<?php echo $a;?>'>
                                <label class="">company:&nbsp</label><?php echo $a; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                               <input type='hidden' name='location' value='<?php echo $b;?>'>
                                <label class="">Location:&nbsp</label><?php echo $b; ?>
                            </fieldset>
                        </div>
                        
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <input type='hidden' name='quali' value='<?php echo $c;?>'>
                                <label class="">Qualification:&nbsp</label><?php echo $c; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <input type='hidden' name='exp' value='<?php echo $d;?>'>
                                <label class="">Experience:&nbsp</label><?php echo $d; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <input type='hidden' name='gender' value='<?php echo $e;?>'>
                                <label class="">Gender:&nbsp</label><?php echo $e; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <input type='hidden' name='sal' value='<?php echo $g;?>'>
                                <label class="">salary:&nbsp</label><?php echo $g; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <input type='hidden' name='lda' value='<?php echo $i;?>'>
                                <div style="color:red"><label class="">Last_Date_to_Applay:&nbsp</label><?php echo $i; ?></div>
                                <input type='hidden' name='vacidd' value='<?php echo $v_id;?>'>
                                <input type='hidden' name='empid' value='<?php echo $emp;?>'>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <input type='hidden' name='sal' value='<?php echo $j;?>'>
                                <label class="">Number of vaccancies:&nbsp</label><?php echo $j; ?>
                            </fieldset>
                        </div>
                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                            <fieldset>
                                <input type='hidden' name='sal' value='<?php echo $k;?>'>
                                <label class="">Published:&nbsp</label><?php echo $k; ?>
                            </fieldset>
                        </div>
                    </div>
                </form>
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group" id='btn_save' >
                          <button class="btn btn-info round"   id="<?php echo $v_id; ?>" onClick=" aprvcd(this.id);">Applay</button>
                           <a href="http://www.sahayikendra.com/emply/php" <button class="btn btn-danger round"   onclick=history.go(-1)> Cancel </button></a>
                </div>
                 <div id='lllll'></div>
                <script>
                            function aprvcd(id) {
                                
                                

                                document.cookie = "emp_id=<?php echo $emp;?>";
                                document.cookie = "cand_id=<?php echo $cand_id;?>";
                                var aprovcd =  id;
                                    $.ajax({
                                        type: "POST",
                                        // url: "http://sahayikendra.com/embloyability/php/dashboard/applayajax.php",
                                        url: "dashbord/applayajax.php",
                                        data: "vac_id=" + aprovcd,
                                        cache: false,
                                         success: function(html) {
                                             $("#lllll").html(html);
                                             
                                      	    document.getElementById(id).innerHTML = "Aproved";
                                      	    document.getElementById(id).style.backgroundColor = "green";
                                      	    
                                      	        alert('Aprove Success');
                                      	    
                                         }
                                    });   
                            }
                         </script>
                
            </div>
        </div>
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
    </div>
 </div>
<?php
}
}
}
?>
<?php
//      if(isset($_POST['apply']))
// 	 {
	     
// 	    //$notifi=$_POST['noti'];
//         date_default_timezone_set("Asia/Kolkata");
//         $time= date('d-m-Y h:i:a');
        
// 	    $empidd=$_POST['empid'];
//         $vaciddd= $_POST['vacidd'];
//         $sql1="INSERT INTO `applay_jobs`(`app_id`, `cand_id`, `emp_id`, `vac_id`,`status`,`date_time`) VALUES (NULL,'$iddd','$empidd','$vaciddd','Applied','$time')";
					
//         $r=mysqli_query($emply_cand,$sql1);
//         if($r)
//             {
//                 echo'<script>alert("Applied");</script>';
//             }
// 			 else
// 			{
// 				 echo'<script>alert("Already Applied");</script>';
// 			}
					
					 
// 	 }
	        
?>


 <!--<button class="btn btn-danger round"  id="//<?php// echo $candi; ?>" onClick=" aprvcd(this.id); ">Aprove</button>-->
        
 
<!--if(isset($_GET['aprovecandidateid']))-->
<!--{-->
<!--    echo $id=$_GET['aprovecandidateid'];-->
<!--    $sqlsl = "select * from candidate where id = '$id'";-->
<!--    $ressl=mysqli_query($kofa_candidate,$sqlsl);-->
<!--    $rowsl = mysqli_fetch_assoc($ressl);-->
<!--    echo $apr = $rowsl['aprove'];-->
    
<!--    if($apr == '1')-->
<!--    {-->
<!--            echo "<script> alert('already arproved');-->
        
<!--        	</script>";-->
<!--    }-->
<!--    else-->
<!--    {-->
<!--        $sql="update candidate set aprove = '1' where id = '$id' ";-->
<!--        $res=mysqli_query($kofa_candidate,$sql);-->
<!--        if($res)-->
<!--        {-->
<!--        	echo "<script> alert('Data aproved');-->
        	
<!--        	</script>";-->
<!--        }-->
<!--        else-->
<!--        {-->
<!--        	echo "<script> alert('aprove failed');-->
        	
<!--        	</script>";-->
<!--        } -->
<!--    }-->
<!--}-->
