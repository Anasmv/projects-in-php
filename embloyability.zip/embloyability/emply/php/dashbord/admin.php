<?php
include("sidebar.php");
include ('emp_sidebar.php');
echo "hi";
?>