   <?php

include('./include/style.php');
include("include/sessionlog.php");
   if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
 $aa= $_SESSION['emply_id'];
echo'<br><br><br><br><br>';
?>

   
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> </link>

    <div class="w3-sidebar w3-bar-block w3-card w3-animate-left" style="display:none" id="mySidebar">
         
        <button class="w3-bar-item w3-button w3-large"onclick="w3_close()">Close &times;</button>
        <a span class="glyphicon glyphicon-home w3-bar-item w3-button" style="font-size:18px" id=<?php echo $aa;?> onclick="homee(this.id)";> Home </a></span>
        <a span class="glyphicon glyphicon-briefcase w3-bar-item w3-button" style="font-size:18px" id=<?php echo $aa;?> onclick="addvac(this.id)";>Add vacancies</a></span>
        <a span class="glyphicon glyphicon-bullhorn w3-bar-item w3-button" style="font-size:18px">Add Jobs Fairs</a></span>
        <a span class="glyphicon glyphicon-ok w3-bar-item w3-button" style="font-size:18px" id=<?php echo $aa;?> onclick="appjob(this.id)";>Applied jobs</a></span>
        <a span class="glyphicon glyphicon-folder-open w3-bar-item w3-button" style="font-size:18px">Add Job offers</a>
        <a span class="glyphicon glyphicon-folder-open w3-bar-item w3-button" style="font-size:18px" id=<?php echo $aa;?> onclick="updpe(this.id)";>Update Profile</a>
    </div>
    <div id="main">
            <button id="openNav" class="w3-button w3-teal w3-xlarge" onclick="w3_open()">&#9776;Menu</button>
    </div>
    
   
<script>
function w3_open() {
  document.getElementById("main").style.marginLeft = "25%";
  document.getElementById("mySidebar").style.width = "25%";
  document.getElementById("mySidebar").style.display = "block";
  document.getElementById("openNav").style.display = 'none';
}
function w3_close() {
  document.getElementById("main").style.marginLeft = "0%";
  document.getElementById("mySidebar").style.display = "none";
  document.getElementById("openNav").style.display = "inline-block";
}
</script>

<script>
    
  function homee(a) {  
        $(document).attr("title","HOME");
        var aa=a;
        $("#maine").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/main_emp.php",
                data:{aa1:aa},
                cache: false,
                beforeSend: function() {
                    $('#maine').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#maine").html(html);
            }
            });
            }
            function addvac(av) {  
        $(document).attr("title","HOME");
        var bb=av;
        $("#maine").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/add_vac.php",
                data:{bb1:bb},
                cache: false,
                beforeSend: function() {
                    $('#maine').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#maine").html(html);
            }
            });
            }
            
            
             function appjob(aj) {  
        $(document).attr("title","HOME");
        var cc=aj;
        $("#maine").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/job_view.php",
                data:{cc1:cc},
                cache: false,
                beforeSend: function() {
                    $('#maine').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#maine").html(html);
            }
            });
            }
             
             function updpe(up) {  
        $(document).attr("title","HOME");
        var dd=up;
        $("#maine").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/update_emp.php",
                data:{dd1:dd},
                cache: false,
                beforeSend: function() {
                    $('#maine').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#maine").html(html);
            }
            });
            }
</script>



