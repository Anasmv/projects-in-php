
<?php
include('../include/link.php');
include('../conn/con.php');
if (!isset($_SESSION)) 
        {
            session_start(); 
            
        }
 echo $iddd= $_SESSION['emply_id'];
            
                      
    echo $iddds=$_POST['dd1'];
    $sql="select * from reg_employer where emp_id='$iddd'";
    $r=mysqli_query($emply_emply,$sql);
    ?>
    <div class="banner5">
         <div class="container">
           
             <h3>Update your Profile
               
            </h3>
         </div>
          <?php
       
         
        include('emp_sidebar.php');
        include("../include/style.php");
        
        ?>
      </div>
     
    <?php
    if($r->num_rows>0)
    {				     
        $row=$r->fetch_assoc();
        $a=$row['employer_name'];
        $b=$row['point_of_contact_name'];
        $c=$row['point_of_contact_email'];
        $d=$row['contact_number'];
        $e=$row['phone_number'];
        $f=$row['alternate_number'];
        $g=$row['email'];
        $h=$row['pincode'];
        $i=$row['address1'];
        $j=$row['address2'];
        $k=$row['address3'];
        //$l=$row['country'];
        //$m=$row['state'];
       //$n=$row['district'];


    }
    ?>
    
    <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <br>
                        <div class="progress round">
                            <div class="progress-bar" style="width:0%" id="prog"></div>
                            
                        </div>
                        <br><br><br><br>
                    </div>
                           <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                                <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-6 col-6 bg-primary text-light round text-center" id="personal" onclick="next();" >
                                <lable ><h3>Employer Information</h3></lable>
                                </div>
                                <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-10 col-10 bg-secondary text-light round text-center" id="address" onclick="next1();">
                                <lable ><h3>Contact Details</h3></lable>
                                </div>
                                <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" id="identity" onclick="next2();">
                                    <lable ><h3>Upload Document</h3></lable>
                                </div>
                              <?php echo $iddd= $_SESSION['emply_id'];
                              echo $iddds=$_POST['dd1'];?>
                            </div>
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
                            <form class="row" role="form" action="dashbord/checkingdb.php" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" onsubmit=" return validateform()">
                                
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="personal_details">
                                    <div class="form-group col-xl-9 col-lg-9 col-md-9 col-sm-7 col-7 text-center"> </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next1()">
                                    <lable ><h3>NEXT >> </h3></lable>
                                     </div>
                
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group ">
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-4 form-group float-left">
                                        <img class="round shadow border-light"  width="100" height="100" name="image"  id="thumbnil" >
                                        <?php
              
                                       $res=mysqli_query($emply_img,"select * from emp_img WHERE emp_id='$iddd'");
                                         
                                             while($row=mysqli_fetch_array($res))
                                               {
               
                                                 $abc=$row['data'];
                                                   echo '<img class="round shadow" src="data:image/jpeg;base64,'.base64_encode($row['data'] ).'" height="150" width="150" alt="rounded" />';
                                               }
                						?>
                						 <input type='hidden' name='ff' value='<?php  $abc;?>'>
                                        </div>
                                        <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-8 form-group float-left">
                                        <label for="InputName">Employer Logo <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="file" class="" name="meefile" id="image"  accept="image/*" onchange="showMyImage(this)">
                                        <label class="text-danger" for="InputName">image must be 'jpeg' or 'png'</label>
                                        </div>
                                    </div>
                    
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Employer Name <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="ename" id="InputName" value="<?php echo $a; ?>" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Contact Name <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="cname" id="InputName"  value="<?php echo $b; ?>"required/>
                                         </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName"> Contact Email <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="cemail" id="InputName" value="<?php echo $c; ?>" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName"> Contact Number<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="cnumber" id="InputName" value="<?php echo $d; ?>"required/>
                                        </fieldset>
                                    </div>
                                    
                                   
                                    
                                    <div class="form-group col-xl-9 col-lg-9 col-md-9 col-sm-7 col-7 text-center"> </div>
                                        <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" tabindex="7" onclick="next1()">
                                            <lable ><h3>NEXT >> </h3></lable>
                                        </div>
                                </div>
                    

                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="address_details">
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next()">
                                        <lable ><h3> << BACK</h3></lable>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next2()">
                                        <lable ><h3>NEXT >> </h3></lable>
                                    </div>
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Phone Number <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="number" class="form-control round" name="mob" id="InputName"  value="<?php echo $e; ?>"required/>
                                        </fieldset>
                                    </div>
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Alternate Number <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="number" class="form-control round" name="amob" id="InputName" value="<?php echo $f; ?>" />
                                        </fieldset>
                                    </div>
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">email <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="email" class="form-control round" name="email" id="InputName" value="<?php echo $g; ?>"required/>
                                        </fieldset>
                                    </div>
                                     <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">pincode <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="pincode" class="form-control round" name="pincode" id="InputName" value="<?php echo $h; ?>" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Address1 <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="add1" id="InputName" value="<?php echo $i; ?>" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName">Address2 <span class="fas fa-star-of-life text-danger"></span></label>    
                                        <input type="text" class="form-control round" name="add2" id="InputName" value="<?php echo $j; ?>" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in">
                                        <fieldset>
                                        <label for="InputName"> Address3<span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="text" class="form-control round" name="add3" id="InputName" value="<?php echo $k; ?>" required/>
                                        </fieldset>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                   
                                        <SELECT type="text" class="round form-control"  tabindex="8" name="country" id="mylist" required onChange="showState(this)">
                                        
                                          <?php
                                            
                                            $sql = "SELECT DISTINCT country FROM area_table ORDER BY `area_table`.`country` ASC";
                                            $res=mysqli_query($emply_option,$sql);
                                            ?>
            								<option value="" >Please Select country</option>
                                            <?php while($row=$res->fetch_assoc())
            								{ ?>
                                                <option  value="<?php echo $row["country"]; ?>"><?php echo $row["country"]; ?></option>
                                            <?php } ?>
                                        </SELECT>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                        <SELECT type="text" class="round form-control" name="state" tabindex="9" id="output1" onchange="showDistrict(this);">
                                            <option value="" >Please Select state</option>
                                        </SELECT>
                                    </div>
                                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                        <SELECT type="text" class="round form-control" name="district" tabindex="10" id="output2" onchange="showlclType(this);">>
                                            <option value="" >Please Select district</option>
                                        </SELECT>
                                    </div>
                                  
                                  
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next()">
                                        <lable ><h3> << BACK</h3></lable>
                                     </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next2()">
                                        <lable ><h3>NEXT >> </h3></lable>
                                    </div>
                                </div>
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row" id="identity_details">
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next1()">
                                        <lable ><h3> << BACK</h3></lable>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            <input type='hidden' name='rrr' value='<?php echo $iddd;?>'>
                                    </div>
                                    
                                  <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group ">
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-4 form-group float-left">
                                        <img class="round shadow border-light" border="1" width="100" height="100" name="imagee"  id="thumbnill" >
                                        <?php
              
                                       $res3=mysqli_query($emply_img,"select * from emp_docs WHERE emp_id='$iddd'");
                                         
                                             while($row4=mysqli_fetch_array($res3))
                                               {
               
                                                 $abcd=$row4['data'];
                                                   echo '<img class="round shadow" src="data:image/jpeg;base64,'.base64_encode($row4['data'] ).'" height="150" width="150" alt="rounded" />';
                                               }
                						?>
                                        </div> 
                                        
                                        <div class="col-xl-8 col-lg-8 col-md-8 col-sm-8 col-8 form-group float-left">
                                        <label for="InputName">upload Documents <span class="fas fa-star-of-life text-danger"></span></label>
                                        <input type="file" class="" name="mrrfile" id="imagee"  accept="image/*" onchange="showMyImage2(this)" >
                                        <label class="text-danger" for="InputName">image must be 'jpeg' or 'png'</label>
                                        
                                        </div>
                                       
                                       
                                    </div>
                                 
                                    <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-5 col-5 bg-primary text-light round text-center" onclick="next1()">
                                        <lable ><h3> << BACK</h3></lable>
                                    </div>
                                    <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-2 col-2 text-center">
                            
                                    </div>
                                    
                                </div>
                                    
                                    <div class="form-group col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                                        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12"></div>
                                            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                                                <input type="submit" name="upemp" id="submit" value="Submit" class="btn btn-info mx-auto round form-control col">
                                            </div>
                                    </div>
                                </form>
                
                                
                            </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                </div>
        </div>
    </div>    

	    
		 
		 <script>
function showMyImage2(fileInput) {
var files = fileInput.files;
for (var i = 0; i < files.length; i++) {
var file = files[i];
var imageType = /image.*/;
if (!file.type.match(imageType)) {
continue;
}
var img=document.getElementById("thumbnill");
img.file = file;
var reader = new FileReader();
reader.onload = (function(aImg) {
return function(e) {
aImg.src = e.target.result;
};
})(img);
reader.readAsDataURL(file);
}
}

function showMyImage(fileInput) {
var files = fileInput.files;
for (var i = 0; i < files.length; i++) {
var file = files[i];
var imageType = /image.*/;
if (!file.type.match(imageType)) {
continue;
}
var img=document.getElementById("thumbnil");
img.file = file;
var reader = new FileReader();
reader.onload = (function(aImg) {
return function(e) {
aImg.src = e.target.result;
};
})(img);
reader.readAsDataURL(file);
}

}
function changeFunc2() {
var select2 = document.getElementById("output4");
var selectedValue = select2.options[select2.selectedIndex].value;
if (selectedValue=="not_listed"){
$('#textboxes').show();
$('#textbox1').show();
$("#newplace1").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
$("#newplace2").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
$("#newplace3").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
}
else {
$('#textboxes').hide();
$('#textbox1').hide();

$("#newplace1").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
$("#newplace2").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
$("#newplace3").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
}
}

function changeFunc3() {
var select3 = document.getElementById("caste");
var selectedValue1 = select3.options[select3.selectedIndex].value;
if (selectedValue1=="not_listed2"){
$('#txtEnglish133').show();
$('#txtbox').show();
$("#rel").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
$("#caste1").attr("class", "form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12");
}
else {
$('#txtEnglish133').hide();
$('#txtbox').hide();
$("#rel").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12");
$("#caste1").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12");
}
}
    function showState(sel) {
        var country_id = sel.options[sel.selectedIndex].value;
        $("#output1").html("");
        /*
        $("#output2").html("");
        $("#output3").html("");
        $("#output4").html("");
        $("#output5").html("");
        */
        if (country_id.length > 0) {

            $.ajax({
                type: "POST",
               
                url: "areacode/fetch_area.php",
                data: "country=" + country_id,
                cache: false,
                beforeSend: function() {
                    $('#output1').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output1").html(html);
                }
            });
        }
    }

    function showDistrict(sel) {
        var state_id = sel.options[sel.selectedIndex].value;
        if (state_id.length > 0) {
            $.ajax({
                type: "POST",
                url: "areacode/fetch_area.php",
                data: "state=" + state_id,
                cache: false,
                beforeSend: function() {
                    $('#output2').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output2").html(html);
                }
            });	
        } else {
            $("#output2").html("");
        }
    }
    
    function showlclType(sel) {
        
        var district = sel.options[sel.selectedIndex].value;
		document.cookie = "district=" + district;
        if (district.length > 0){
            $.ajax({
                type: "POST",
                url: "areacode/fetch_type1.php",
                data: "district=" + district ,
                cache: false,
                beforeSend: function() {
                    $('#output5').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output5").html(html);
                }
            });
        } else {
            $("#output5").html("");
        }
    }
     function showLclArea(sel) {
        var lcltype = sel.options[sel.selectedIndex].value;
        if (lcltype.length > 0) {
            $.ajax({
                type: "POST",
                url: "areacode/fetch_area.php",
                data: "lcltype=" + lcltype,
                cache: false,
                beforeSend: function() {
                    $('#output3').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output3").html(html);
                }
            });
        } else {
            $("#output3").html("");
        }
    }
    
    function showPlace(sel) {
        var lclarea = sel.options[sel.selectedIndex].value;
        if (lclarea.length > 0) {
            $.ajax({
                type: "POST",
                url: "areacode/fetch_area.php",
                data: "lclarea=" + lclarea,
                cache: false,
                beforeSend: function() {
                    $('#output4').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#output4").html(html);
                }
            });
        } else {
            $("#output4").html("");
        }
    }
    
    
	window.onload = function fresh(){
	    $("#personal_details").show();
	    $("#address_details").hide();
	    $("#identity_details").hide();
	    $("#textboxes").hide();
	    $("#textbox1").hide();
	   
	    
	    $("#txtEnglish133").hide();
	    $("#txtbox").hide();
	    
	};
	function next() {
	    document.getElementById("address").classList.add('bg-secondary');
	    document.getElementById("address").classList.remove('bg-primary');
	    document.getElementById("personal").classList.add('bg-primary');
	    document.getElementById("personal").classList.remove('bg-secondary');
	    document.getElementById("identity").classList.add('bg-secondary');
	    document.getElementById("identity").classList.remove('bg-primary');
	    document.getElementById("prog").style.width="33%";
	    
	    $("#personal_details").show();
	    $("#address_details").hide();
	    $("#identity_details").hide();
	};
	function next1() {
	    document.getElementById("address").classList.add('bg-primary');
	    document.getElementById("address").classList.remove('bg-secondary');
	    document.getElementById("personal").classList.add('bg-secondary');
	    document.getElementById("personal").classList.remove('bg-primary');
	    document.getElementById("identity").classList.add('bg-secondary');
	    document.getElementById("identity").classList.remove('bg-primary');
	    document.getElementById("prog").style.width="66%";
	    
	   $("#personal_details").hide();
	   $("#address_details").show();
	   $("#identity_details").hide();
	};
	function next2() {
	    document.getElementById("address").classList.add('bg-secondary');
	    document.getElementById("address").classList.remove('bg-primary');
	    document.getElementById("personal").classList.add('bg-secondary');
	    document.getElementById("personal").classList.remove('bg-primary');
	    document.getElementById("identity").classList.add('bg-primary');
	    document.getElementById("identity").classList.remove('bg-secondary');
	    document.getElementById("prog").style.width="99%";
	    
	    $("#personal_details").hide();
	    $("#address_details").hide();
	    $("#identity_details").show();
	};


// function next() {
// 	    document.getElementById("info").classList.add('bg-primary');
// 	    document.getElementById("info").classList.remove('bg-secondary');
// 	    document.getElementById("contact").classList.add('bg-secondary');
// 	    document.getElementById("contact").classList.remove('bg-primary');
// 	    document.getElementById("upload").classList.add('bg-secondary');
// 	    document.getElementById("upload").classList.remove('bg-primary');
// 	    document.getElementById("prog").style.width="20%";
	    
// 	    $("#information").show();
// 	    $("#contact_details").hide();
// 	    $("#upload_documents").hide();
	   
// 	};
// 	function next1() {
// 	    document.getElementById("info").classList.add('bg-secondary');
// 	    document.getElementById("info").classList.remove('bg-primary');
// 	    document.getElementById("contact").classList.add('bg-primary');
// 	    document.getElementById("contact").classList.remove('bg-secondary');
// 	    document.getElementById("upload").classList.add('bg-secondary');
// 	    document.getElementById("upload").classList.remove('bg-primary');
// 	    document.getElementById("prog").style.width="75%";
	    
// 	    $("#information").hide();
// 	    $("#contact_details").show();
// 	    $("#upload_documents").hide();
// 	};
// 	function next2() {
// 	    document.getElementById("info").classList.add('bg-secondary');
// 	    document.getElementById("info").classList.remove('bg-primary');
// 	    document.getElementById("contact").classList.add('bg-secondary');
// 	    document.getElementById("contact").classList.remove('bg-primary');
// 	    document.getElementById("upload").classList.add('bg-primary');
// 	    document.getElementById("upload").classList.remove('bg-secondary');
// 	    document.getElementById("prog").style.width="100%";

// 	    $("#information").hide();
// 	    $("#contact_details").hide();
// 	    $("#upload_documents").show();
	  
// 	};
	
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script>
$(function() {
// Multiple images preview in browser
var imagesPreview = function(input, placeToInsertImagePreview) {
if (input.files) {
var filesAmount = input.files.length;
for (i = 0; i < filesAmount; i++) {
var reader = new FileReader();
reader.onload = function(event) {
$($.parseHTML('<img>')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
}
reader.readAsDataURL(input.files[i]);
}
}
};
$('#gallery-photo-add').on('change', function() {
imagesPreview(this, 'div.gallery');
});
});
</script> 
<!--input type="file" multiple id="gallery-photo-add">
<div class="gallery"-->


<script type="text/javascript">
    $(function () {
        $('#lstFruits').multiselect({
            includeSelectAllOption: true
        });
    });
</script>


     <script src="http://www.sahayikendra.com/script/multiselect.js" type="text/javascript">
         
     </script>
  
    

     