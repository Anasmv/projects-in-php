<?php
include('include/conn/con.php');
include("include/headindex.php");
include("include/style.php");

?>
<html lang="en">
<head>
     <script>  
            function validateform(){  
            var name=document.thameem.uname.value;  
            var password=document.thameem.pwd.value; 
            var mob=document.thameem.mob.value;
             var firstpassword=document.thameem.pwd.value;  
            var secondpassword=document.thameem.cpwd.value; 

 
              
            if (name==null || name==""){  
              alert("Name can't be blank");  
              return false;  
            }else if(password.length<6){  
              alert("Password must be at least 6 characters long.");  
              return false;  
              }   
            
             if(mob.length<8){
            	  alert("Mobile number must type 10 numbers");
            	  return false;
              }
             
              
            if(firstpassword==secondpassword){  
            return true;  
            }  
            else{  
            alert("password must be same!");  
            return false;  
            }  
            } 
              function validate() {  
                var msg;
            if(document.thameem.pwd.value.length>=5&&document.thameem.pwd.value.length<=8){  
            msg="good";  
            }  
            else if (document.thameem.pwd.value.length>8)
            {
            msg="strong";
            }
            else{
            
            msg="poor";  
            }  
            document.getElementById('mylocation').innerText=msg;  
             }  
 </script>
</head>
  <!-- banner1 -->
	<div class="banner1">
		<div class="container">
			<h3>Candidate Registration</h3>
		</div>
	</div>
<!-- //banner1 -->
<!-- about -->
	<div class="about" >
		<div class="container" style="min-height: 600px;">
		<div class="col-md-12 test-center" style="margin-bottom: 20px;">
	
		</div>
		
			
			
			<div class="col-md-4   col-md-offset-1">
			 <div class="well">
			  				
	                         
	
		                        <div class="form-group">
		                             <div class="input-group"> 
		                              <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
										  <input class="form-control"  id="usr" required="required" placeholder="Email" type="text">
										 
									 </div> 
		                        </div>
		                        <div class="form-group"> 
		                         	 <div class="input-group"> 
		                         	  <span class="input-group-addon"><i class="fa fa-key" aria-hidden="true"></i></span>
										 <input class="form-control"  id="pw"   required="required" placeholder="Password" type="password">
										
									 </div> 
		                        </div>
		                        
		                        <div class="form-group">
		                         <button type="submit" name="sub" onclick='checklogin();' value="SUBMIT" class="btn btn-primary active">login</button>
		                        </div>
		                        
		                          <div class="form-group">
		                         <a href="../forgotPassword/index.html" class="reset">Forgot Password ?</a>  
		                          
		                        </div>
	                         
	
	                        
	                       
	                </div> 
			
			</div>
			
			<div class="col-md-6  left-bor col-md-offset-1">
			<hr>
			<div class="col-md-6">
			  				 
			  				 
                     				<img src="style/aadhaar/aadhaar_logo.jpg"  class="img-responsive"  />
                     				
                
			  			 
			  				</div>
			  				<div class="col-md-6" style="padding-top: 30px;">
			  				
			  				<a  href="/aadhaarAuthPublic/verifyPhoneEmail.html" class="btn btn-success btn-block">Register using your AADHAAR</a><br/>
			  				</div>
			  				
			  				<div class="col-md-12" style="padding: 0px;margin-top: 25px;">
			  				<hr>
			 <div class="well">
			  				 
	                
	                            <div id="loginErrorMsg" class="alert alert-error text-danger"> 
	                            	
	                            	 
									 
	                            </div>
	                               
                      <form class="row" role="form" action="http://www.sahayikendra.com/emply/php/dashbord/checkingdb.php" method="post" enctype="multipart/form-data" name="thameem" onsubmit=" return validateform()">	
		                        <div class="form-group">
		                             <div class="input-group"> 
		                             	 <span class="input-group-addon"><i class="fa fa-user"></i></span>
										 
										 <input class="form-control" id="thameem" name="uname" value="" placeholder="User Name" type="text"> 
									 </div> 
									</div> 
								 <div class="form-group">	  
									  <div class="input-group"> 
		                             	 <span class="input-group-addon"><i class="fa fa-phone"></i></span>
										 <input class="form-control" id="thameem" name="mob" value="" maxlength="10" required="required" placeholder="Mobile No" type="number"> 
									 </div> 
									 </div> 
								 <div class="form-group">	  
									  <div class="input-group"> 
		                             	 <span class="input-group-addon"><i class="fa fa-envelope-o"></i></span>
										 <input class="form-control checkUserName" id="thameem" name="email" value="" required="required" placeholder="Email" maxlength="100" type="email"> 
									 </div>  
									 </div> 
								
								 <div class="form-group">	  
									 <div class="input-group"> 
		                             	 <span class="input-group-addon"><i class="fa fa-key"></i></span>
										 <input class="form-control" id="thameem" name="pwd" value="" required="required" placeholder="Password" type="password" onkeyup="validate()"/> 
                            		Strength:<span id="mylocation">no strength</span> 
									 </div>
									 </div> 
								 <div class="form-group">	  
									 <div class="input-group"> 
		                             	 <span class="input-group-addon"><i class="fa fa-key"></i></span>
										 <input class="form-control" id="thameem" name="cpwd" value="" required="required" placeholder="Confirm Password" type="password"> 
									 </div>   
		                        </div>
		                         
							
		                        
		                        <div class="form-group" >
		                        	 <input type="submit" name="register" id="submit" value="Submit" class="btn btn-success mx-auto round form-control col">
		                        </div> 
	                       
	                    	</form>
	                </div> 
	                </div>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
<!-- //about -->
 
<!-- for custom -->
<script src="style/js/public.site.js"></script>
<!-- //for custom --> 
 
<?php
include("include/empfooter.php");

?>
</body>

<!-- Mirrored from www.employabilitycentre.org/publicSite/candidate_reg by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 19 Jun 2019 05:55:40 GMT -->
</html>


<?php
	      
   
    
?>