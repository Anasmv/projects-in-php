<?php
include("../include/link.php");
include('../conn/con.php');
if (!isset($_SESSION)) 
            {
                session_start();
            }
  
    $iddd= $_POST['aa1'];
     if(!isset($_POST['aa1']))
         {
            $iddd=  $_SESSION['emply_id'];
         }
    $sql="select * from reg_employer where emp_id='$iddd'";
    $r=mysqli_query($emply_emply,$sql);
?>
<div class="col-xl-12 col-lg-12 col-md-12 col-sm-4 col-4" id="maine">
<div class="banner6">
         <div class="container">
            <h3>
              Home
               
            </h3>
         </div>
        <?php
        include('emp_sidebar.php');
         if(!isset($_POST['aa1']))
         {
             include "include/style.php"; 
         }
         else
         {
         include "../include/style.php"; 
         }
        ?>
      </div>
         <!--<div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12">-->
                                        <?php  //include "./include/profemp.php"; ?>
         <!--                           </div>-->
     <?php
    if($r->num_rows>0)
    {				     
        $row=$r->fetch_assoc();
        $a=$row['employer_name'];
        $c=$row['point_of_contact_email'];
        $d=$row['contact_number'];
        $i=$row['address1'];
        $j=$row['address2'];
        $k=$row['address3'];

    }
    ?>
    <br><br>
    <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
                        <form class="row" role="form" action="" method="post" enctype="multipart/form-data" name="thameem" role="form" class="row" onsubmit=" return validateform()">
                                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 form-group ">
                                    <div class="col-xl-4 col-lg-4 col-md-4 col-sm-4 col-4 form-group float-left">
                                        <?php
                                        $res=mysqli_query($emply_img,"select * from emp_img WHERE emp_id='$iddd'");
                                        while($row=mysqli_fetch_array($res))
                                        {
                                        $abc=$row['data'];
                                        echo '<img class="round shadow" src="data:image/jpeg;base64,'.base64_encode($row['data'] ).'" height="150" width="150" alt="rounded" />';
                                        }
                						?>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                    <fieldset>
                                        <label class="">Embloyer Name:&nbsp</label> <?php echo $a; ?>
                                    </fieldset>
                                </div>
                                                   
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                        <fieldset>
                                            <label class="">Email:&nbsp</label> <?php echo $c; ?>
                                        </fieldset>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                    <fieldset>
                                        <label class="">Contact Number:&nbsp</label> <?php echo $d; ?>
                                    </fieldset>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                    <fieldset>
                                        <label class="">Address1:&nbsp</label> <?php echo $i; ?>
                                    </fieldset>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                    <fieldset>
                                        <label class="">Address2:&nbsp</label> <?php echo $j; ?>
                                    </fieldset>
                                </div>
                                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 form-group texting-in">
                                    <fieldset>
                                        <label class="">Address3:&nbsp</label> <?php echo $k; ?>
                                    </fieldset>
                                </div>
                        </form>

                    </div>
                    <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                </div>
        </div>
    </div>
    </div>
 
    

   
