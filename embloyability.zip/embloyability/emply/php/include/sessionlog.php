
    <?php 
    
    if (!isset($_SESSION)) {
        session_start(); 
    
    	if($_SESSION['emply_id']!='')
			{
			    echo"<script type='text/javascript'>
					    window.location='http://www.sahayikendra.com/emply/';
					 </script>";
			}
			
	}		
         
    
	?>
    
    
	