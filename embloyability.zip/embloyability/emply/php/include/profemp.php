<?php
include('../conn/con.php');
if (!isset($_SESSION)) 
        {
          session_start(); 
        }
        $cand_id= $_SESSION['emply_id'];
        
?>
<div class="sidebarr widget1">
              <h2>New Vaccancies
              </h2>
    <?php
            $sql1="SELECT * FROM `add_vac` ORDER BY `add_vac`.`vac_id` DESC";
            $r1=mysqli_query($emply_employer,$sql1);
          
            while($row1=$r1->fetch_assoc())
            {
            $zzz=$row1['vac_id']; 
            $v=$row1['job_title']; 
            $z=$row1['no_of_vac'];
            $dd=$row1['date_time'];
            $db=$row1['last_date _to_applay'];
            date_default_timezone_set("Asia/Kolkata");
            $time= date('Y-m-d ');
            $sqlap = "SELECT * FROM `applay_jobs` WHERE vac_id = '$zzz' AND cand_id = '$cand_id'";
            $resap=mysqli_query($emply_cand,$sqlap);
            $rowap=mysqli_fetch_array($resap);
            $appid = $rowap['app_id'];
            $vacidd = $rowap['vac_id'];
            if($vacidd != $zzz)
                {
                if($db>$time)
                    {
          
          
     
    ?>
          
             <ul>
                <li>
                    <div class="sidebarr-thumb1">
                        <!--<img class="animated rollIn" src="http://shop.spotlayer.com/demo/soft-mag/demo1/wp-content/uploads/16555399183_33b1b1bc26_o-90x75.jpg" alt="" />-->
                    </div><!-- .Sidebar-thumb -->
                    <div class="sidebarr-content1">
                        <h5 class="animated bounceInRight"><a  id=<?php echo $zzz;?> onclick="vac(this.id)";>You have got a job Vaccanci as <span style="color:red"><?php echo $v;?></span> , <?php echo $z;?> vaccancies are vacant.if you are eligible for this job,last date to appaly is <span style="color:red"><?php echo $db;?></span></a></h5>
                        <!--<h5 class="animated bounceInRight"><a href="#" ><?php echo $z;?></a></h5>-->
                    </div><!-- .Sidebar-thumb -->
                    <div class="sidebar-meta1">
                       <span class="time"  style="color:red"><i style="color:blue"class="fa fa-clock-o"></i><?php echo $dd;?></span>
                        <!--<span class="comment"><i class="fa fa-comment"></i> 10 comments</span>-->
                    </div><!-- .Sidebar-meta ends here -->
                </li><!-- .Li ends here -->
             </ul><!-- .Ul ends here -->
              
          <!-- .Widget ends here -->
        <?php
                    }
                }
            }

        ?>
            <?php

        ?>
        </div>
<style>
  /*  body{*/
  /*margin-top: 40px;*/
}
/*ul, li {*/
/*    list-style: none;*/
}
h5{
  margin: 0;
  
}
h2{
  color: #29bd3d;
  margin: 10px 0px 15px;
  padding-bottom:10px;
  padding-left: 10px;
  border-left: 5px solid #32e161;
  font-size:24px;
}
.sidebarr.widget1 {
  background: #f2f2f2;
  border: 1px solid #ddd;
  padding: 10px 20px;
}
.sidebarr.widget1 ul {
    margin: 0px;
    padding: 0;
    overflow: hidden;
}
.sidebarr.widget1 ul li {
    overflow: hidden;
    font-size: 14px;
    margin-bottom: 20px;
    border-bottom: 1px dashed #ddd;
    padding-bottom: 20px
}
.sidebarr-thumb1{
    float: left;
    overflow: hidden;
    margin-right: 15px;
}
.sidebarr-thumb1 img{
  background: #fff;
  border: 1px dashed #e0e0e0;
  padding: 6px;
  height: 75px;
  width: 75px;
  
  -webkit-border-radius: 100px;
  -moz-border-radius: 100px;
  border-radius: 100px;
}
.sidebarr-content1 h5{ 
    font-size: 16px;
    cursor: pointer;
    line-height: 24px;
}
.sidebarr-content1 h5 a:hover{ 
  color: #2996bd;
}

.sidebarr-content1 h5 a{ 
    color: #202020;
    outline: 0 none;
    text-decoration: none;
    font-weight: bold
}
.sidebarr-meta1{
  margin-top: 10px;
  
}
.sidebarr-meta1 span{
  color: #2e2e2e;
}
.sidebarr-meta1 span.time{
  margin-right: 10px;
  
  
}
.sidebarr-meta1 span i{
  color: #2996bd
}
</style>

<script>
  function vac(u) {    
        $(document).attr("title","VACANCI");
        var uu=u;
        $("#mains").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/newvac.php",
                data:{uu1:uu},
                cache: false,
                beforeSend: function() {
                    $('#mains').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#mains").html(html);
            }
            });
            }
            </script>