 <br>
<nav class=" navbar navbar-expand-lg navbar-gold bg-gold sticky-top">

	<div class="top-nav">
		<div class="container-fluid">
			<nav class="navbar navbar-default">
				<div class="navbar-header navbar-left">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					 <a   href="http://www.sahayikendra.com/emply/index.html" > 
					 <img src="http://www.sahayikendra.com/embloyability/php/dashbord/style/commonElements/a.jpg?fileName=PUBLIC_SITE_LOGO.jpg" class="img-responsive" style="width: 95%;height: 85px;width: 160px;" alt=""></a></div>
				<!-- Collect the nav links, forms, and other content for toggling -->
				<div class="collapse navbar-collapse navbar-right" id="bs-example-navbar-collapse-1">
					<nav class="menu menu--shylock" style="max-height: 350px;overflow-y: auto;">
						<ul class="nav navbar-nav link-effect-7" id="link-effect-7"> 
							<li><a href="http://www.sahayikendra.com/embloyability/index1.php">Home</a></li>
							<li><a href="about-us.html">About</a></li>
							<li><a href="centers.html" >Centre</a></li>
							<li><a href="employers.html" >Employers</a></li>
							<li><a href="jobs.html">Jobs</a></li> 
							<li><a href="fair-calender.html">Fair Calendar</a></li> 
							<li><a href="news.html" >News</a></li>
							<li><a href="frequently-ask-questions.html" >FAQ</a></li><li class="avc-sp">
							<!--href="http://www.sahayikendra.com/embloyability/php/dashbord/rnow.php"-->
		                            	<a class="avc-log"  onclick='login();'>Log in </a>
										<a class="avc-reg"  onclick='login();'>Register now </a>
		                            
							</li>
						</ul>
					</nav>
				</div>
			</nav>	
		</div>	
	</div>	 
</nav>
<script>

 function forgott() {
    $(document).attr("title", "Forgot Password");
        $("#mainbody").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/forgotpwd.php",
                // data: "notify=" + cmn_notify,
                cache: false,
                // beforeSend: function() {
                //     $('#mainbody').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                // },
                success: function(html) {
                $("#mainbody").html(html);
            }
            });
}

    function login() {
    $(document).attr("title", "LOGIN");
        $("#mainbody").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/rnow.php",
                // data: "notify=" + cmn_notify,
                cache: false,
                // beforeSend: function() {
                //     $('#mainbody').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                // },
                success: function(html) {
                $("#mainbody").html(html);
            }
            });
}
function checklogin(){
        
        var   usr=$('#usr').val();
        var   pw=$('#pw').val();
        $("#main1").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/checkingdb.php",
                 data: { user : usr, pwd : pw},
                cache: false,
                beforeSend: function() {
                    $('#main1').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                $("#main1").html(html);
            }
            });
}
function reg_cand() {
    $(document).attr("title", "REGISTRATION CANDIDATE");
        $("#mainbody").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/cand_login.php",
                // data: "notify=" + cmn_notify,
                cache: false,
                // beforeSend: function() {
                //     $('#mainbody').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                // },
                success: function(html) {
                $("#mainbody").html(html);
            }
            });
}


function reg_empy() {
    $(document).attr("title", "REGISTRATION EMPLOYEES");
        $("#mainbody").html("");
            $.ajax({
                type: "POST",
                url: "http://www.sahayikendra.com/emply/php/dashbord/employ_login.php",
                // data: "notify=" + cmn_notify,
                cache: false,
                // beforeSend: function() {
                //     $('#mainbody').html('<img src="http://www.sahayikendra.com/images/loader.gif" alt="" width="24" height="24">');
                // },
                success: function(html) {
                $("#mainbody").html(html);
            }
            });
}


</script>