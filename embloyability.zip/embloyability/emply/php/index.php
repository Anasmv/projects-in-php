
<?php
    session_start();
    $acc=$_SESSION['acc_emply'];
    include("include/link.php");
    include('include/headerout.php');
    include('conn/con.php');
    include("include/style.php");
        
        
        
        if($acc=='candidate')
        {
            include('dashbord/main_cand.php');
        }
        if($acc=='Employer')
        {
             include('dashbord/main_emp.php');
        }
?>
