 <?php 
          session_start(); 
    	 if($_SESSION['emply_id']!='')
			{
			    echo"<script type='text/javascript'>
					    window.location='http://www.sahayikendra.com/emply/php/index.php';
					 </script>";
			    // header("location:../php/dashboard/index.php");
			}
		else
			{
			 //   include "php/include/ss.php";
			   
                include "php/include/link.php";
            ?>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" id='main1'>
            <?php
                include "php/include/headindex.php";
                include "php/include/style.php";
                include "php/include/body.php";
               
                 //include('../dashbord/totalreg.php');
                
                ?>
            </div>
                <?php
            }
    ?>