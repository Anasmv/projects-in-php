<?php
if(!isset($_SESSION))
{
    session_start();
}
if(isset($_SESSION['login_id']) && isset($_SESSION['login_user']) && isset($_SESSION['login_acctype']) )
{
    if($_SESSION['login_acctype']=='admin' || $_SESSION['login_acctype']=='agent')
    {
                
                $id =$_SESSION['login_id'];
                
        include('../../php/conn/conn.php');
            include('header.php');
        //include('header.php');
        
        if($_SESSION['login_acctype']=='admin')
        {
            $sql="select * from course";
        }
        if($_SESSION['login_acctype']=='agent')
        {
             $sql="select * from course where user = '$id'";
        }
        $res=mysqli_query($course,$sql);
        ?>
        <div class="container">
        	<div class="row">
        		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
        			<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
        				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
        					<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
        					</div>  
        				</div>
        				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
        					<div  align="center">
        						<h1>Registered Courses </h1>
        						<?php
        						if($res->num_rows>0)
        						{
        						?>
        
        						<table class="table table-hover ">
        							<tr>
        								<th>Course</th>
        								<th>Institute</th>
        								<th>Tution Fee</th>
        								<th>Donation</th>
        								<th>Duration</th>
        								<th>Duration Type</th>
        								<th>Exam Fee</th>
        								<th>Book and Uniform</th>
        								<th>Library</th>
        								<th>Hostel Charge</th>
        								<th>Comm</th>
        								<?php if($_SESSION['login_acctype']=='admin')
        								{ ?>
        								<th>Action</th>
        							<?php	} ?>
        							</tr>
        							<?php
        							while($row=$res->fetch_assoc())
        							{
        							?>
        							<tr>
        								<td><?php echo $row['course'];?></td>
        								    <?php $inscd = $row['institution_code'];
        								    $sqli="select * from institute where id = '$inscd'";
                                            $resi=mysqli_query($course,$sqli);
                                            while($rowi=$resi->fetch_assoc())
                                            {
                                            ?>
                                            <td><?php echo $rowi['name'].' - '.$rowi['area']; }?></td>
        								
        								
        								<td><?php echo $row['tutionfee'];?></td>
        								<td><?php echo $row['donation'];?></td>
        								
        								<td><?php echo $row['dur'];?></td>
        								<td><?php echo $row['dur_typ'];?></td>
        								
        								<td><?php echo $row['examfee'];?></td>
        								<td><?php echo $row['bookanduniform'];?></td>
        								<td><?php echo $row['library'];?></td>
        								<td><?php echo $row['hostel_charge'];?></td>
        								<td><?php echo $row['comm'];?></td>
        								<?php if($_SESSION['login_acctype']=='admin')
        								{ ?>
        								<td> <a href="deletecourse.php?id=<?php echo $row['id'];?>"> <button class="btn btn-danger rad" name="delet" >Delete</button></a></td>
        							<?php } ?>
        							</tr>
        
        						<?php }?>
        						</table>
        						<?php
        						}
        						else
        						{
        						echo "<script> alert('No Course Added'); 
        				
        						</script>";
        						}
        						mysqli_close($course);
        						?>
        					</div>
        				</div>
        			</div>
        		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
        	</div>
        </div>
        <br><br><br>
        <?php
        include('../php/include/footer.php');
    }
    else
    {
        header("Location: http://course.sahayikendra.com");
        exit();
    }
}
else
{
    echo "<script> alert('Please login again or restart your browser.'); </script>";
    echo "<script> window.location='http://course.sahayikendra.com'; </script> ";
}
?>
</body>
</html>