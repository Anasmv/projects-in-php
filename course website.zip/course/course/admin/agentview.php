<html>
<?php
if(!isset($_SESSION))
{
    session_start();
}
if(isset($_SESSION['login_id']) && isset($_SESSION['login_user']) && isset($_SESSION['login_acctype']) )
{
    if($_SESSION['login_acctype']=='admin')
    {
    include('../../php/conn/conn.php');
        include('header.php');
    //include('header.php');
    $sql="select * from login where acc_type = 'agent'";
    $res=mysqli_query($course,$sql);
    if($res->num_rows>0)
    {
    ?>
    <div class="container">
    	<div class="row">
    		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
        		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
        				</div>  
        			</div>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
        				<div  align="center">
        				<h1>Registered Agents </h1>
        				<table class="table">
        					<tr>
        						<th>Agent Name</th>
        						
        						<th>Mobile No</th>
        						<th>Total Institute</th>
        						<th>Total Course</th>
        						<th>User Name</th>
        			<?php if($_SESSION['login_acctype'] == 'admin')
    				{
    				    ?>
        						<th>Action</th>
        			<?php
    				}
        			?>
        					
        					</tr>
        					<?php
        					while($row=$res->fetch_assoc())
        					{
        					?>
        					<?php
        						    $id=$row['id'];
        						    $sqlh="select * from institute where user = '$id'";
                                    $resh=mysqli_query($course,$sqlh);
                                   
                                    ?>
    						<tr>
    							<td><?php echo $nm= $row['name'];?></td>
    							
        						<td><?php echo $row['contact_number']; ?></td>
        						
        						<td>
        						    
        						    <?php
        						    
        						    
        						    $sqlc="select count(*) as total from institute where user = '$id' ";
                                            $resc=mysqli_query($course,$sqlc);
                                            while($rwsc=$resc->fetch_assoc())
                                            {
                                                echo $rwsc['total'];
                                            }
        						    
        						    
        						    
        						  
        					            
                                    ?>
                                </td>
        						    
        						    
        						    
        						<td>
        						    <?php
        						            $sqlc="select count(*) as total from course where user = '$id' ";
                                            $resc=mysqli_query($course,$sqlc);
                                            while($rwsc=$resc->fetch_assoc())
                                            {
                                                echo $rwsc['total'];
                                            }
        						    
        						    ?>
        						    </td>
        						    <?php
        					
        					?>
    							<td><?php echo $row['username'];?></td>
    				<?php if($_SESSION['login_acctype'] == 'admin')
    				{
    				    ?>
    				
    							<td> <a href="deleted.php?id=<?php echo $row['id'];?>"> <button class="btn btn-danger rad" name="delet" >Delete</button></a></td>
    				<?php
    				}
    				?>
    						</tr>
        					<?php 
        					}?>
        					</table>
        <?php
        }
        	else
        	{
        		echo "<script> alert('No Agent Added'); 
        		window.location.href='index.php';
        		</script>";
        	}
        				mysqli_close($course);
        				?>
        				</div>
        			</div>
        		</div>
    		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
    	</div>
    </div>
    <?php
    include('../php/include/footer.php');
    }
    else
    {
        header("Location: http://course.sahayikendra.com");
        exit();
    }
}
else
{
    echo "<script> alert('Please login again or restart your browser.'); </script>";
    echo "<script> window.location='http://course.sahayikendra.com'; </script> ";
}
?>
</body>
</html>