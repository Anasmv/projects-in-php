<?php
if(isset($_GET['id']))
{
    include('../../php/conn/conn.php');
    $id=$_GET['id'];
    $sql="delete from course where id=$id";
    $res=mysqli_query($course,$sql);
    if($res)
    {
        echo "<script> alert('data deleted');
        window.location='courseview.php'; 
        </script>";
    }
    else
    {
    echo "<script> alert('No course to delete'); 
    window.location='courseview.php';  </script>";
    }
}
else
{
     echo "<script>
			 window.location='courseview.php'; 
			 </script>" ;
}
?>