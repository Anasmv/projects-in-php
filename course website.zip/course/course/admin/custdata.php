
<!--script 1-->


<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam"]);
    var keyVal = 32; // Space key
    $("#txtEnglish").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam").val($("#txtMalayalam").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam").focus();
            $("#txtMalayalam").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish").val($("#txtEnglish").val() + " "); document.getElementById("txtEnglish").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 

<!--script 2-->



<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam2"]);
    var keyVal = 32; // Space key
    $("#txtEnglish2").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish2").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam2").val($("#txtMalayalam2").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam2").focus();
            $("#txtMalayalam2").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam2").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish2").val($("#txtEnglish2").val() + " "); document.getElementById("txtEnglish2").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 

<!--script 3-->



<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam3"]);
    var keyVal = 32; // Space key
    $("#txtEnglish3").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish3").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam3").val($("#txtMalayalam3").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam3").focus();
            $("#txtMalayalam3").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam3").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish3").val($("#txtEnglish3").val() + " "); document.getElementById("txtEnglish3").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 

<!--script 4-->


<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam4"]);
    var keyVal = 32; // Space key
    $("#txtEnglish4").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish4").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam4").val($("#txtMalayalam4").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam4").focus();
            $("#txtMalayalam4").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam4").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish4").val($("#txtEnglish4").val() + " "); document.getElementById("txtEnglish4").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 

<!--script 5-->

<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam5"]);
    var keyVal = 32; // Space key
    $("#txtEnglish5").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish5").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam5").val($("#txtMalayalam5").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam5").focus();
            $("#txtMalayalam5").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam5").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish5").val($("#txtEnglish5").val() + " "); document.getElementById("txtEnglish5").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 

<!--script 6-->



<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam6"]);
    var keyVal = 32; // Space key
    $("#txtEnglish6").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish6").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam6").val($("#txtMalayalam6").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam6").focus();
            $("#txtMalayalam6").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam6").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish6").val($("#txtEnglish6").val() + " "); document.getElementById("txtEnglish6").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 


<!--script 7-->
 
 <script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam7"]);
    var keyVal = 32; // Space key
    $("#txtEnglish7").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish7").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam7").val($("#txtMalayalam7").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam7").focus();
            $("#txtMalayalam7").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam7").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish7").val($("#txtEnglish7").val() + " "); document.getElementById("txtEnglish7").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 

<!--script 8 -->


<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam8"]);
    var keyVal = 32; // Space key
    $("#txtEnglish8").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish8").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam8").val($("#txtMalayalam8").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam8").focus();
            $("#txtMalayalam8").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam8").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish8").val($("#txtEnglish8").val() + " "); document.getElementById("txtEnglish8").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 



<!--script 9 -->


<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam9"]);
    var keyVal = 32; // Space key
    $("#txtEnglish9").on('keydown', function(event){
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish9").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam9").val($("#txtMalayalam9").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam9").focus();
            $("#txtMalayalam9").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam9").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish9").val($("#txtEnglish9").val() + " "); document.getElementById("txtEnglish9").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 


<!--script 10 -->


<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };txtEnglish10
    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam10"]);
    var keyVal = 32; // Space key
    $("#txtEnglish10").on('keydown', function(event){
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish10").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam10").val($("#txtMalayalam10").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam10").focus();
            $("#txtMalayalam10").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam10").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish10").val($("#txtEnglish10").val() + " "); document.getElementById("txtEnglish10").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 


<!--script 11-->


<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam11"]);
    var keyVal = 32; // Space key
    $("#txtEnglish11").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish11").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam11").val($("#txtMalayalam11").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam11").focus();
            $("#txtMalayalam11").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam11").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish11").val($("#txtEnglish11").val() + " "); document.getElementById("txtEnglish11").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 


<!--script 12-->


<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam12"]);
    var keyVal = 32; // Space key
    $("#txtEnglish12").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish12").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam12").val($("#txtMalayalam12").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam12").focus();
            $("#txtMalayalam12").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam12").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish12").val($("#txtEnglish12").val() + " "); document.getElementById("txtEnglish12").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 



<!--script 13-->


<script type="text/jatxtEnglish13ascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam13"]);
    var keyVal = 32; // Space key
    $("#txtEnglish13").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish13").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam13").val($("#txtMalayalam13").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam13").focus();
            $("#txtMalayalam13").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam13").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish13").val($("#txtEnglish13").val() + " "); document.getElementById("txtEnglish13").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 



<!--script 14-->


<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam14"]);
    var keyVal = 32; // Space key
    $("#txtEnglish14").on('keydown', function(event){
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish14").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam14").val($("#txtMalayalam14").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam14").focus();
            $("#txtMalayalam14").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam14").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish14").val($("#txtEnglish14").val() + " "); document.getElementById("txtEnglish14").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 




<!--script 15-->


<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };txtMalayalam15
    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam15"]);
    var keyVal = 32; // Space key
    $("#txtEnglish15").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish15").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam15").val($("#txtMalayalam15").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam15").focus();
            $("#txtMalayalam15").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam15").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish15").val($("#txtEnglish15").val() + " "); document.getElementById("txtEnglish15").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 




<!--script 1txtEnglish16-->


<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam16"]);
    var keyVal = 32; // Space key
    $("#txtEnglish16").on('keydown', function(event) {
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish16").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam16").val($("#txtMalayalam16").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam16").focus();
            $("#txtMalayalam16").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam16").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish16").val($("#txtEnglish16").val() + " "); document.getElementById("txtEnglish16").focus()},0);
    });
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 




<!--script 1txtMalayalam17-->


<script type="text/javascript" src="http://www.google.com/jsapi"></script>

<script type="text/javascript">
google.load("elements", "1", {packages: "transliteration"});
</script> 
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
<script>
function OnLoad() {                
    var options = {
        sourceLanguage:
        google.elements.transliteration.LanguageCode.ENGLISH,
        destinationLanguage:
        [google.elements.transliteration.LanguageCode.MALAYALAM],
        shortcutKey: 'ctrl+g',
        transliterationEnabled: true
    };

    var control = new google.elements.transliteration.TransliterationControl(options);
    control.makeTransliteratable(["txtMalayalam17"]);
    var keyVal = 32; // Space key
    $("#txtEnglish17").on('keydown', function(event){
        if(event.keyCode === 32) {
            var engText = $("#txtEnglish17").val() + " ";
            var engTextArray = engText.split(" ");
            $("#txtMalayalam17").val($("#txtMalayalam17").val() + engTextArray[engTextArray.length-2]);

            document.getElementById("txtMalayalam17").focus();
            $("#txtMalayalam17").trigger ( {
                type: 'keypress', keyCode: keyVal, which: keyVal, charCode: keyVal
            } );
        }
    });

    $("#txtMalayalam17").bind ("keyup",  function (event) {
        setTimeout(function(){ $("#txtEnglish17").val($("#txtEnglish17").val() + " "); document.getElementById("txtEnglish17").focus()},0);
    })txtEnglish17
} //end onLoad function

google.setOnLoadCallback(OnLoad);
</script> 




