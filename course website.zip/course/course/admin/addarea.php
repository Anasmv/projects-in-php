<!DOCTYPE html>
<?php
   if(!isset($_SESSION))
{
    session_start();
}
if( isset($_SESSION['login_id']) && isset($_SESSION['login_user']) && isset($_SESSION['login_acctype']) )
{
    if( ($_SESSION['login_acctype'] == 'admin') || ($_SESSION['login_acctype'] == 'agent') )
    {
            include('header.php');
            include('../../php/conn/conn.php');
            
    
        ?>
        
        
        
        <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10 "><br>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
                        <form action="" method="post" role="form" class="row ">
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="round form-control" name="nation" tabindex="1" id="txtEnglish"required />
                                    <label >Nation:</label>
                                </fieldset>
                            </div>
                            <div class="Rachana form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="Rachana round form-control" name="mal_nation"  id="txtMalayalam" required />
                                    <label class=" ml">രാജ്യം:</label>
                                </fieldset>
                            </div>
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="round form-control" name="state" tabindex="2" id="txtEnglish2" required />
                                    <label>State:</label>
                                </fieldset>
                            </div> 
                             <div class="Rachana form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                 <fieldset>
                                    <input type="text" class="Rachana round form-control" name="mal_state" id="txtMalayalam2" required />
                                    <label class=" ml">സംസ്ഥാനം :</label>
                                 </fieldset>
                            </div>  
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="round form-control" name="district" tabindex="3" id="txtEnglish3" required />
                                    <label>District:</label>
                                </fieldset>
                            </div>
                           <div class="Rachana form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="Rachana round form-control" name="mal_district" id="txtMalayalam3" required />
                                    <label class=" ml">ജില്ല:</label>
                                </fieldset>
                            </div>
                             <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="round form-control" name="mandalam" tabindex="4" id="txtEnglish4" required />
                                    <label>Mandalam:</label>
                                </fieldset>
                            </div>
                            <div class="Rachana form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="Rachana round form-control" name="mal_mandalam" id="txtMalayalam4" required />
                                    <label class=" ml">മണ്ഡലം :</label>
                                </fieldset>
                            </div>
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="round form-control" name="taluk" tabindex="5" id="txtEnglish5" required />
                                    <label>Taluk:</label>
                                </fieldset>
                            </div>
                            <div class="Rachana form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in" >
                                <fieldset>
                                    <input type="text" class="Rachana round form-control" name="mal_taluk" id="txtMalayalam5" required />
                                    <label class=" ml">താലൂക്ക് :</label>
                                </fieldset>
                            </div>
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="round form-control" name="village" tabindex="6" id="txtEnglish6"required />
                                    <label>Village:</label>
                                </fieldset>
                            </div>
                            <div class="Rachana form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="Rachana round form-control" name="mal_village" id="txtMalayalam6"required />
                                    <label class=" ml">വില്ലേജ് :</label>
                                </fieldset>
                            </div>
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    		    <select  name="local_area_type" tabindex="7" class='form-control round'>  
                    		        <option value="select">Select Local Body Type</option> 
                                    <option value="Panchayath">Panchayath</option>
                    		        <option value="municipality">Municipality</option>
                    		        <option value="Corporation">Corporation</option>
                    		    </select>
                            </div>
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                </fieldset>
                            </div>
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="round form-control" name="local_area_name" tabindex="8" id="txtEnglish7" required />
                                    <label>Local Body Name:</label>
                                </fieldset>
                            </div>
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="Rachana round form-control" name="mal_local_area_name" id="txtMalayalam7" required />
                                    <label class=" ml">തദ്ദേശ സ്ഥാപനത്തിന്റെ പേര്: </label>
                                </fieldset>
                            </div>
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="round form-control" name="place" tabindex="9" id="txtEnglish8" required />
                                    <label>Place:</label>
                                </fieldset>
                            </div> 
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in">
                                <fieldset>
                                    <input type="text" class="Rachana round form-control" name="mal_place" id="txtMalayalam8" required />
                                    <label class=" ml">സ്ഥലം :</label>
                                </fieldset>
                            </div>
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                                <button type="submit" class="round btn btn-success btn-block" tabindex="10" name="submit">submit</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
            </div>
        </div>
                   <?php
                  
                  
                  
        if(isset($_POST['submit']))
        {
            $nation=$_POST['nation'];
            $mal_nation=$_POST['mal_nation'];
            $state=$_POST['state'];
            $mal_state=$_POST['mal_state'];
            $district=$_POST['district'];
            $mal_district=$_POST['mal_district'];
            $mandalam=$_POST['mandalam'];
            $mal_mandalam=$_POST['mal_mandalam'];
            $taluk=$_POST['taluk'];
            $mal_taluk=$_POST['mal_taluk'];
            $village=$_POST['village'];
            $mal_village=$_POST['mal_village'];
            $local_area_type=$_POST['local_area_type'];
            //$mal_local_area_type=$_POST['mal_local_area_type'];
         
                if($local_area_type=='Panchayath')
                {
                    $mal_local_area_type="പഞ്ചായത്ത് ";
                }
                else if($local_area_type=='municipality'){
                    $mal_local_area_type="മുനിസിപ്പാലിറ്റി" ;
                
                }
                else{
                    $mal_local_area_type="കോർപ്പറേഷൻ ";  }
                
                    $local_area_name=$_POST['local_area_name'];
                    $mal_local_area_name=$_POST['mal_local_area_name'];
                    $place=$_POST['place'];
                    $mal_place=$_POST['mal_place'];
                    $sql="INSERT INTO `area_table`(`country`, `mal_country`, `state`, `mal_state`, `district`,
                    `mal_district`, `mandalam`, `mal_mandalam`, `taluk`, `mal_taluk`, `village`, `mal_village`,
                    `local_area_type`, `mal_local_area_type`, `local_area_name`, `mal_local_area_name`, `place`, `mal_place`)
                    VALUES('$nation','$mal_nation','$state','$mal_state','$district','$mal_district','$mandalam','$mal_mandalam',
                    '$taluk','$mal_taluk','$village','$mal_village','$local_area_type','$mal_local_area_type','$local_area_name',
                    '$mal_local_area_name','$place','$mal_place')";
                    $res=mysqli_query($area,$sql);
                    if($res)
                    {
                    echo"<script> 
        		alert('success'); 
        		window.location.href=window.location.href; </script>";


                    }
                    else
                    {
                    echo"error";
                    }
        }
        include('../php/include/footer.php');
        
        include('custdata.php');
    }
}
else
{
    echo "<script> alert('Please login again or restart your browser.'); </script>";
    echo "<script> window.location='http://course.sahayikendra.com'; </script> ";
}
    
    ?>
    