<?php
if(!isset($_SESSION))
{
    session_start();
}
if( isset($_SESSION['login_id']) && isset($_SESSION['login_user']) && isset($_SESSION['login_acctype']) )
{
    if( ($_SESSION['login_acctype'] == 'admin') || ($_SESSION['login_acctype'] == 'agent') )
    {
        if(isset($_GET))
        {
            if(isset($_GET['agent']))
            {
                $agn=$_GET['agent'];
            }
            
            if(isset($_GET['type']))
            {
                $actyp = $_GET['type'];
            }
            include('header.php');
            include('../../php/conn/conn.php');
            ?>
            <div class="container">
            	<div class="row">
            		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
            		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
            		<br>
            			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                            <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 "></div>
            				
                            <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 bg-secondary text-light round text-center" >
                                <h2 align="center round bg-progress">
                                    REGISTER
                                    <?php
                                    if(isset($_GET['type']) )
                                    {
                                        if($actyp == 'agent' )
                                        {
                                            echo 'AGENT';
                                        }
                                        if($actyp == 'institute')
                                        {
                                            echo 'INSTITUTE';
                                        }
                                        if($actyp == 'staff')
                                        {
                                            echo 'STAFF';
                                        }
                                    }
                                    if(isset($_GET['agent']))
                                    {
                                        {
                                            echo 'INSTITUTE';
                                        } 
                                    }
                                    ?>
                                </h2>
                            </div>
                            <div class="form-group col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12" ></div>
                        </div>
            			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
    	
                                <form name="myform" action="" method="post" class="row">
                                <?php                           
                                if($actyp == 'institute' || $agn == 'regins')
                                { ?>
            						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            							<fieldset>
            								<SELECT  class="round form-control " name="country" tabindex="1" required onChange="showState(this)">
            								<option  value="">Select Country</option>
            									<?php
            										$sql = "SELECT DISTINCT country FROM area_table ORDER BY `area_table`.`country` ASC";
            										$res=mysqli_query($area,$sql);
            									?>
            										<?php while($row=$res->fetch_assoc())
            											{ ?>
            											<option  value="<?php echo $row["country"]; ?>"><?php echo $row["country"]; ?></option>
            										<?php } ?>
            								</SELECT>	
            							</fieldset>
            						</div>
            						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            							<fieldset>
            								<SELECT  class="round form-control " name="state" id="state" tabindex="2"  onchange="showDistrict(this);">
            									<option  value="dd">Select State</option>
            								</SELECT>	
            							</fieldset>
            						</div>
            						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            							<fieldset>
            								<SELECT  class="round form-control " name="district" tabindex="3" id="district_id" onchange=" showLclType(this);" >
            									<option  value="dd">Select District</option>
            								</SELECT>
            							</fieldset>
            						</div>
            
            						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in " id="newplace1">
            							<fieldset>
            								<SELECT  class="round form-control " name="lclbdtyp" tabindex="4" id="loc_type" onchange="showLclArea(this);" >
            									<option  value="dd">Select Local body type</option>
            								</SELECT>
            							</fieldset>
            						</div>
            						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in " id="newplace2">
            							<fieldset>
            								<SELECT  class="round form-control " name="loc_name" tabindex="5" id="loc_name" onchange="showPlace(this);" >
            									<option  value="dd">Select Local body Name</option>
            								</SELECT>
            							</fieldset>
            						</div>	
            						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in " id="newplace3">
            							<fieldset>
            								<SELECT  class="round form-control " name="place" tabindex="6" id="place_id" onchange="changeFuncPlace();">
            									<option  value="bb" selected>Select Place</option>
            									<option  value="other">Select Place</option>
            								</SELECT>
            							</fieldset>
            						</div>
            						<div class="form-group  col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in" id="otherpalce" >
            							<input type="text" class="round form-control" name="newplace"  tabindex="7" placeholder="Enter New Place" value="0" id="otherpalce" >
                                    </div>
                                <?php
                                }
                                ?>
            						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            							<fieldset>
            								<input type="text" name="name" tabindex="8" class='form-control round' required="reqired"/>
            								<label>Name:</label>
            							</fieldset>
            						</div>
            						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            							<fieldset>
            								<input type="number" name="contactno" class='form-control round'  tabindex="9" required="reqired"/> 
            								<label>Contact Number:</label>
            							</fieldset>
            						</div>
                                <?php
                                if($actyp == 'institute' || $actyp == 'agent' || $actyp == 'staff')
                                { ?>
            						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            							<fieldset>
            							    <input type="text" name="uname" class='form-control round' tabindex="10" required="reqired"/> 
            							    <label>User Name:</label>
            							</fieldset>
            						</div>
            						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
            							<fieldset>
            								<input type="password" name="password" class='form-control round'  tabindex="11" required="reqired"/> 
            								<label>Password:</label>
            							</fieldset>
            						</div>
                                <?php
                                } ?>
            						<div class="col-xl-3 col-lg-3 col-md-3 col-sm-4 col-4">
            						</div>
            						
            						<div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                                        <input type="reset" class="round btn btn-success btn-danger" value="reset" name="submitform">
                                    </div>
            						<div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                                        <input type="submit" name="subbtn" class="round btn btn-success btn-block" value="submit" name="submitform">
                                    </div>
            					</form> 
            				</div>
            			</div>
            		</div>
            		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
            		<div class="row">
            		</div>
            	</div>
            </div>
            <br><br><br>
            <?php  
            include('../php/include/footer.php');
            if(isset($_POST['subbtn']))
            {
                $name=$_POST['name'];
                if($actyp=='agent' || $actyp=='staff' || $actyp=='institute' || $agn=='regins')
                {
                    $username=$_POST['uname'];
                    $cnno =$_POST['contactno'];
                    if($actyp=='agent' || $actyp=='staff' || $actyp=='institute' )
                    {
            	        $psd=$_POST['password'];
            	        $password=password_hash($psd, PASSWORD_DEFAULT); 
                    }
            	    
                    if($actyp == 'agent')
                    {
                        $ghj="INSERT INTO `login`(`name`, `acc_type`, `username`, `password`, `contact_number`) VALUES ('$name','agent','$username','$password','$cnno')"; 
                        
                        
                    }
                    elseif($actyp == 'staff')
                    {
                        $ghj="INSERT INTO `login`(`name`, `acc_type`, `username`, `password`, `contact_number`) VALUES 
                        ('$name','staff','$username','$password','$cnno')";
                    }
                    elseif($actyp == 'institute' || $agn=='regins')
                    {
                        $nation=$_POST['country'];
                    	$state=$_POST['state'];
                    	$district=$_POST['district'];
                    	$lcltype=$_POST['lclbdtyp'];
                    	$local_area_name=$_POST['loc_name']; 
                    	$place = $_POST['place'];
                    	$newplace=$_POST['newplace'];
                        if($place=='other')
                        {
                            $sqlnewplace="INSERT INTO `area_table`( `country`, `mal_country`, `state`, `mal_state`, `district`,
                            `mal_district`, `mandalam`, `mal_mandalam`, `taluk`, `mal_taluk`, `village`, `mal_village`, `local_area_type`,
                            `mal_local_area_type`,
                            `local_area_name`, `mal_local_area_name`, `place`, `mal_place`) VALUES('$nation','0','$state','0','$district','0','0','0','0','0','0','0','$lcltype',
                            '0','$local_area_name','0','$newplace','0')";
                            $resnewplace=mysqli_query($area,$sqlnewplace);
                            
                            if($actyp == 'institute')
                            {
                                $ghj="INSERT INTO `login`(`name`, `acc_type`, `username`, `password`, `contact_number`) VALUES 
                                ('$name','institute','$username','$password','$cnno')";
                            }
                            
                            
                            $accid = $_SESSION['login_id'];
                            
                            
                            $sqii="INSERT INTO `institute`(`name`, `state`, `district`, `area` , `user` , `cont_no`) VALUES ('$name','$state','$district','$newplace','$accid','$cnno')";
                            $insins = mysqli_query($course,$sqii);
                        }
                        else
                        {
                            if($actyp == 'institute')
                            {
                                $ghj="INSERT INTO `login`(`name`, `acc_type`, `username`, `password`, `contact_number`) VALUES 
                                ('$name','institute','$username','$password','$cnno')";
                            }
                                $accid = $_SESSION['login_id'];
                                $sqii="INSERT INTO `institute`(`name`, `state`, `district`, `area` , `user` , `cont_no`) VALUES ('$name','$state','$district','$place','$accid','$cnno')";
                                $insins = mysqli_query($course,$sqii);
                        }    
                    }
                    $ol=mysqli_query($course,$ghj);
                    if($ol || $insins)
            	    {
            	    	echo "<script> alert('insert success');
            	    	window.location.href=window.location.href;
            	    	</script>";
            	    }
            	    else
            	    {
            	    	echo "<script> alert('not insert');</script>";
            	    }
                }
            } ?>
            <script>
            window.onload = function fresh(){
            	$("#otherpalce").hide();
            };
            	
            function changeFuncPlace() 
            {
            	var select2 = document.getElementById("place_id");
            	var selectedValue = select2.options[select2.selectedIndex].value;
            	if (selectedValue=="other")
            	{
            		$('#otherpalce').show();
            		$("#newplace1").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ");
            		$("#newplace2").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
            		$("#newplace3").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
            	}
            	else 
            	{
            		$('#otherpalce').hide();
            		$("#newplace1").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ");
            		$("#newplace2").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ");
            		$("#newplace3").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ");
            	}
            }
            </script>
            <script>
                function showState(sel) {
                    var country_id = sel.options[sel.selectedIndex].value;
                    if (country_id.length > 0) {
            			$.ajax({
                            type: "POST",
                            url: "areacode/fetch_area.php",
                            data: "country=" + country_id,
                            cache: false,
                            beforeSend: function() {
                                $('#state').html('<img src="loader.gif" alt="" width="24" height="24">');
                            },
                            success: function(html) {
                                $("#state").html(html);
                            }
                        });
                    }
                     else {
                        $("#state").html("");
                    }
                }
            	 function showDistrict(sel) {
                    var state_id = sel.options[sel.selectedIndex].value;
                    if (state_id.length > 0) {
                        $.ajax({
                            type: "POST",
                            url: "areacode/fetch_area.php",
                            data: "state=" + state_id,
                            cache: false,
                            beforeSend: function() {
                                $('#district_id').html('<img src="loader.gif" alt="" width="24" height="24">');
                            },
                            success: function(html) {
                                $("#district_id").html(html);
                            }
                        });	
                    } else {
                        $("#district_id").html("");
                    }
                }
            	
            	 
            	 function showLclType(sel) {
                    var district = sel.options[sel.selectedIndex].value;
            		document.cookie = "district=" + district;
                    if (district.length > 0){
                        $.ajax({
                            type: "POST",
                            url: "areacode/fetch_type.php",
                            data: "district=" + district ,
                            cache: false,
                            beforeSend: function() {
                                $('#loc_type').html('<img src="loader.gif" alt="" width="24" height="24">');
                            },
                            success: function(html) {
                                $("#loc_type").html(html);
                            }
                        });
                    } else {
                        $("#loc_type").html("");
                    }
                }
            	
                 
            	
            	function showLclArea(sel) {
                    var lcltype = sel.options[sel.selectedIndex].value;
                    if (lcltype.length > 0){
                        $.ajax({
                            type: "POST",
                            url: "areacode/fetch_area.php",
                            data: "lcltype=" + lcltype ,
                            cache: false,
                            beforeSend: function() {
                                $('#loc_name').html('<img src="loader.gif" alt="" width="24" height="24">');
                            },
                            success: function(html) {
                                $("#loc_name").html(html);
                            }
                        });
                    } else {
                        $("#loc_name").html("");
                    }
                }
            	
            	
               
                function showPlace(sel) {
                    var lclarea = sel.options[sel.selectedIndex].value;
                    if (lclarea.length > 0) {
                        $.ajax({
                            type: "POST",
                            url: "areacode/fetch_area.php",
                            data: "lclarea=" + lclarea,
                            cache: false,
                            beforeSend: function() {
                                $('#place_id').html('<img src="loader.gif" alt="" width="24" height="24">');
                            },
                            success: function(html) {
                                $("#place_id").html(html);
                            }
                        });
                    } else {
                        $("#place_id").html("");
                    }
                }
            </script>
        <?php
        }
        else
        {
            header("Location: http://course.sahayikendra.com");
            exit();
        }
    }
}
else
{
    echo "<script> alert('Please login again or restart your browser.'); </script>";
    echo "<script> window.location='http://course.sahayikendra.com'; </script> ";
}
?>
</body>
</html>