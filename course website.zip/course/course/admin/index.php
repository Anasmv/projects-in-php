<?php
if(!isset($_SESSION))
{
    session_start();
}
if(isset($_SESSION['login_id']) && isset($_SESSION['login_user']) && isset($_SESSION['login_acctype']) )
{
    if($_SESSION['login_acctype']=='admin')
    { 
        include('header.php');
        ?>
        <br>
        <h1 align="center"> Admin </h1><br>
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 "></div>
            <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 row">
                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='addagent.php?type=agent' target="_blank">Register Agent</a>
                </div>
                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='addagent.php?type=institute' target="_blank">Register Institute</a>
                </div>
                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                   <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='addagent.php?type=staff' target="_blank">Register Staff </a> 
                </div>
                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='staffview.php' target="_blank">View Regitered Staff</a>
                </div>
                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='agentview.php' target="_blank">View Regitered Agent</a>
                </div>
                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='instituteview.php' target="_blank">View Regitered Institute</a>
                </div>
                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='courseview.php' target="_blank">View Registered Course</a>
                </div>
                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='search.php' target="_blank">View Users Searched</a>
                </div>
                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='http://course.sahayikendra.com/php/dashboard/viewers.php' target="_blank">View Refer Details</a>
                </div>
                <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
                    <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='addarea.php' target="_blank">Add Area</a>
                </div>
            </div>
            
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
            <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 "></div>
        </div>
        <div align="center">
        	
        	<br><br>
        	<br><br>
        	<br><br>
        	<br><br>
        	<br><br>
        	<br><br>
        	<br><br>
        </div>
        <?php
        include('../php/include/footer.php');
    }
    else
    {
        header("Location: http://course.sahayikendra.com");
        exit();
    }
}
else
{
    echo "<script> alert('Please login again or restart your browser.'); </script>";
    echo "<script> window.location='http://course.sahayikendra.com'; </script> ";
}
?>