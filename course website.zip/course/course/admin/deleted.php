<?php
if(isset($_GET['id']))
{
    include('../../php/conn/conn.php');
    $id=$_GET['id'];
    $sql="delete from institute where id=$id";
    $res=mysqli_query($course,$sql);
    if($res)
    {
    	echo "<script> alert('data deleted');
    	 window.location='instituteview.php';
    	</script>";
    }
    else
    {
    	echo "<script> alert('No institute to delete');
    	window.location='instituteview.php';
    	</script>";
    }
}
else
{
     echo "<script>
			 window.location='instituteview.php'; </script>" ;
}
?>