<?php
if(!isset($_SESSION))
{
    session_start();
}
if( isset($_SESSION['login_id']) && ($_SESSION['login_acctype'] == 'admin') )
{
    if(isset($_GET['id']) && isset($_GET['name']) && isset($_GET['mob']))
    {
        $date=$_GET['dt'];
        $id=$_GET['id'];
        $nam=$_GET['name'];
        $mob=$_GET['mob'];
        include('header.php');
        include('../../php/conn/conn.php');
        ?>
        <div class="container">
        	<div class="row">
        		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
        		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
        		<br>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
        			</div>
        				
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
                            <h2 align="center round bg-progress">ADD DETAILS</h2>
                        </div>
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
        				<h5 align="center"><?php echo $date; ?></h5>
        				 <h5 align="center"><?php echo $nam; ?>&nbsp - &nbsp<?php echo $mob?></h5>
        				  <?php $sqll2="select * from search where name = '$nam' AND phone = '$mob' AND status = '0'";
                                $resl2=mysqli_query($course,$sqll2);   
                                ?>
                                <table class="table table-hover">
                                    <tr>
                                        <th>institute</th>
                                        <th>course</th>
                                        <th>course details</th>
                                    </tr>
                            <tr>
                                <td>
                    	    <?php
                            $sqltype="select distinct search_field_type, search_field  from search where phone = '$mob' AND name = '$nam' AND status = '0'";
                            $restype=mysqli_query($course,$sqltype);
                    		while($rowtype=$restype->fetch_assoc())
                            {
                              $type=$rowtype['search_field_type'];
                                  $srchfd=$rowtype['search_field'];
                                
                                
                                	if($type == 'institute')
                    			{
                    			$sqllin="select name from institute WHERE id = '$srchfd'";
                                $reslin=mysqli_query($course,$sqllin);
                                $lowin=mysqli_num_rows($reslin);
                                $highin=mysqli_fetch_array($reslin);
                               
                                 echo $highin['name']; ?>,&nbsp;<br/> 
                                <?php
                    			}
                    			else
                    			{
                    			    echo " ";
                    			}
                    		}
                    		?>
                    		</td>
                    		<td>
                    		<?php
                            $sqltypeco="select DISTINCT search_field_type, search_field  from search where phone = '$mob' AND status = '0'";
                            $restypeco=mysqli_query($course,$sqltypeco);
                    		while($rowtypeco=$restypeco->fetch_assoc())
                            {
                    			$type=$rowtypeco['search_field_type'];
                    			$srchfd=$rowtypeco['search_field'];
                    			if($type == 'course')
                    			{
                    			    $sqllcou="select course from course WHERE id = '$srchfd'";
                    			    $reslcou=mysqli_query($course,$sqllcou);
                    			    $lowcou=mysqli_num_rows($reslcou);
                    			    $highcou=mysqli_fetch_array($reslcou);
                    				echo $coursft = $highcou['course']; ?>, &nbsp;<br/>
                    			<?php
                    			// echo implode(",", $cours); 
                    			// echo implode(", ",$highcou['course']);
                    			//$idss[] = $highcou['course'];
                    			?>
                                <?php
                    			}
                    			else
                    			{
                    			    echo " ";
                    			}
                    		}
                    		//$implode = implode(', ', $idss);
                    	//	echo $implode;
                    		?>
                            </td>
                    		<td>
                    		<?php
                    			$sqldet="select distinct search_field_type, search_field  from search where phone = '$mob' AND 
                    			search_field_type='coursedetails' AND status = '0'";
                    			$resdet=mysqli_query($course,$sqldet);
                    			while($rowdet=$resdet->fetch_assoc())
                    			{
                    				$type=$rowdet['search_field_type'];
                    				$srchfd=$rowdet['search_field'];
                    				$sqllcou="select course from course WHERE id = '$srchfd'";
                    			    $reslcou=mysqli_query($course,$sqllcou);
                    			    $lowcou=mysqli_num_rows($reslcou);
                    			    $highcou=mysqli_fetch_array($reslcou);
                                 echo $highcou['course']; ?>,&nbsp;<br/> 
                    			 <?php
                    			 //$implode = implode(', ', $highcou['course']);
                    			 //echo $implode;
                    			}
                    			
                    		?>
                    		</td>
                            </tr>
                        </table>
                        
        				 
        				 
        				 
        				    <form name="mform" method="post" class="row">
        				        <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    							    <fieldset>
    								    <select name="willsts" class='form-control round'>
    								        <option value="">Select will status</option>
                                            <option value="interest">Interest</option>
                                            <option value="notinterest">Not Interest</option>
                                        </select>
    							    </fieldset>
    						    </div>
    						    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    							    <fieldset>
    							        <select name="status" class='form-control round'>
    							            <option value="">Select Status</option>
                                            <option value="no">No</option>
                                            <option value="yes">Yes</option>
                                        </select>
    							    </fieldset>
    						    </div>
    						    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    							    <fieldset>
    							        <input type="text" name="follwup" class='form-control round' required>
    							        <label>Follow UP</label>
    							    </fieldset>
    						    </div>
    						    <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    							    <fieldset>
                                        <input type="text" name="rmarks" class='form-control round' required >
                                        <label>Remarks</label>
    							    </fieldset>
    						    </div>
                                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-4 col-4">
    						    </div>
    						    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                                    <input type="reset" class="round btn btn-success form-control  btn-danger" value="reset" name="submitform">
                                </div>
    						    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                                    <input type="submit" name="sbmt" class="round btn btn-success form-control  btn-block" value="submit" name="submitform">
                                </div>
                            </form>
        				</div>
        				
        		<br>		
        				
        			    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
        				
        				
        				
            				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                                
            					<div class="form-group  col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
            						<?php $sqlinstt = "SELECT * FROM `institute` ";         
            						$res=mysqli_query($course,$sqlinstt);
            						?>
            						<SELECT name="mylist" class="round form-control" id="mylistinstitute"  name="country" onChange=" myFunctionInstitute(); ">
            							<option value="">Select institute</option>
            							<?php
            							while($row=$res->fetch_assoc())
            							{ ?>
            							<option  value="<?php echo $row["name"]; ?>"><?php echo $row["name"]; ?></option>
            							<?php } ?>
            						</SELECT>
            					</div>
            					<div class="form-group  col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
            						<?php
            						$sqlinstt = "SELECT * FROM `course`  ";         
            						$res=mysqli_query($course,$sqlinstt);
            						?>
            						<select name="mylistcourse" class="round form-control" id="mylistcourse"  name="country" onChange=" myFunctionCourse();">
            							<option value="">Select course</option>
            							<?php
            							while($row=$res->fetch_assoc())
            								{ ?>
            							<option  value="<?php echo $row["course"]; ?>"><?php echo $row["course"]; ?></option>
            							<?php } ?>
            						</select>	
            					</div>
                            </div>
                                <table class="table table-hover" id="myTable">
                                        <?php
                                		$sqlinst= "select * from course, institute WHERE course.institution_code = institute.id";
                                		$restt=mysqli_query($course, $sqlinst);
                                		?>
                                	<tr>
                                		<th><label>Institute name</label></th>
                                		<th><label>Course Name</label></th>
                                		<th><label>State </label></th>
                                		<th><label>District </label></th>
                                		<th><label>Area </label></th>
                                		<th><label>Details</label></th>
                                	</tr>
                                		<?php
                                		while($rowtbl=$restt->fetch_assoc())
                                		{ ?>
                                	<tr>
                                		<td><?php echo $insnm = $rowtbl['name'];?></td>
                                		<td><?php echo $rowtbl['course'];?></td>
                                		<td>
                                		    <?php 
                                		echo $rowtbl['state'];
                                		
                                		?>
                                		    
                                		    </td>
                                		  
                                		
                                		
                                		<td><?php echo $rowtbl['district']; ?></td>
                                		
                                		
                                		
                                		<td><?php echo $rowtbl['area']; ?></td>
                                		<?php $courw=$rowtbl['course'];
                                		$instrw=$rowtbl['institution_code'];
                                		?>
                                		<td>
                                		    <?php echo '<a href="../php/dashboard/corsedetails.php?course='.$courw.'&inst='.$instrw.'" target="_blank"> <button name="view" class="form-control btn btn-info round">more...</button>
                                	    	</a>';
                                	    	?>
                                		</td>
                                	</tr>
                                		<?php
                                		} ?>
                                </table>
                                    
                    				
                    				
        				
    			        </div>
    			
        			</div>
        		</div>
        	</div>
        </div>
        
        <script>
            
            function myFunctionInstitute() {
                var input, filter, table, tr, td, i;
                input = document.getElementById("mylistinstitute");
                filter = input.value.toUpperCase();
                table = document.getElementById("myTable");
                tr = table.getElementsByTagName("tr");
                for (i = 0; i < tr.length; i++) {
                    td = tr[i].getElementsByTagName("td")[0];
                    if (td) {
                        if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                        } else {
                            tr[i].style.display = "none";
                        }
                    }       
                }
            }
    
            function myFunctionCourse() {
                var input, filter, table, tr, td, i;
                input = document.getElementById("mylistcourse");
                filter = input.value.toUpperCase();
                table = document.getElementById("myTable");
                tr = table.getElementsByTagName("tr");
                for (i = 0; i < tr.length; i++) {
                    td = tr[i].getElementsByTagName("td")[1];
                    if (td) {
                        if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                            tr[i].style.display = "";
                        } else {
                            tr[i].style.display = "none";
                        }
                    }       
                }
            }
        </script>
            
        
        
        <?php
        if(isset($_POST['sbmt']))
        {
            $willsts=$_POST['willsts'];
            $status=$_POST['status'];
            $flwup=$_POST['follwup'];
            $rmks=$_POST['rmarks'];
            if($status=='yes')
            {
        		$sql="update search set will_status='$willsts', follow_up='$flwup', remarks='$rmks', status = '1' where name = '$nam' AND phone = '$mob'";
                $res=mysqli_query($course,$sql);
        		if($res)
                {
                echo "<script> 
        		alert('updated'); 
        		window.location.href='index.php'</script>";
                }
            }
            else
            {
                $sql="update search set will_status='$willsts', follow_up='$flwup', remarks='$rmks',status = '0'  where name='$nam' AND phone='$mob'";
                $res=mysqli_query($course,$sql);
                if($res)
                {
                echo "<script> 
        		alert('updated'); 
        		window.location.href='index.php'</script>";
                }
            }
        }
        mysqli_close($course);
    }
    else
    {
         echo "<script>
        		window.location.href='index.php'</script>";
    }
    include('../php/include/footer.php');
}
else
{
    if(isset($_SESSION))
    {
        session_destroy();
    }
    echo "<script> alert('Please login again or restart your browser.'); </script>";
    echo "<script> window.location='http://course.sahayikendra.com'; </script> ";
}
?>