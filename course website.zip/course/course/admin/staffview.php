<?php
if(!isset($_SESSION))
{
    session_start();
}
if(isset($_SESSION['login_id']) && isset($_SESSION['login_user']) && isset($_SESSION['login_acctype']) )
    {
        if($_SESSION['login_acctype']="admin")
        {
    include('../../php/conn/conn.php');
        include('header.php');
    //include('header.php');
    $sql="select * from login where acc_type = 'staff'";
    $res=mysqli_query($course,$sql);
    if($res->num_rows>0)
    {
    ?>
    <div class="container">
    	<div class="row">
    		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
        		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
        				</div>  
        			</div>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
        				<div  align="center">
            				<h1>Registered Institutes </h1>
            				<table class="table">
            					<tr>
            						<th>Institute</th>
            						<th>District</th>
            						<th>State</th>
            						<th>User Name</th>
            						<th>Action</th>
            					</tr>
            					<?php
            					while($row=$res->fetch_assoc())
            					{
            					?>
            						<tr>
            							<td><?php echo $row['name'];?></td>
            							<td><?php echo $row['district'];?></td>
            							<td><?php echo $row['state'];?></td>
            							<td><?php echo $row['username'];?></td>
            							<td> <a href="deleted.php?id=<?php echo $row['id'];?>"> <button class="btn btn-danger rad" name="delet" >Delete</button></a></td>
            						</tr>
            					<?php 
            					}?>
            					</table>
    <?php
    }
	else
	{
		echo "<script> alert('No Staff Added'); 
		window.location.href='index.php';
		</script>";
	}
	mysqli_close($course);
	?>
        				</div>
        			</div>
        		</div>
    		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
    	</div>
    </div>
    <?php
    include('../php/include/footer.php');
    }
    else
    {
        header("Location: http://course.sahayikendra.com");
        exit();
    }
}
else
{
    echo "<script> alert('Please login again or restart your browser.'); </script>";
    echo "<script> window.location='http://course.sahayikendra.com'; </script> ";
}
?>
</body>
</html>