<?php 
    $con = mysqli_connect('localhost', 'sahayikendra', 'sahayikendra@Azalea', 'course');
?>
	