<?php
if(!isset($_SESSION)) {
    session_start();
}
include('link.php');
// include('../../../../php/conn/conn.php');
?>
<nav class=" navbar navbar-expand-lg navbar-gold bg-gold sticky-top">
    <div class="col-xl-1 col-lg-1 col-md-0 col-sm-0 col-0"></div>
    <div id="navbar">
        <a class="navbar-brand" href="#">
            <img class="round head-logo" src="http://www.sahayikendra.com/images/logo.png" id="logo" alt="logo"  >
        </a>
    </div>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Contact</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" id="mysearchBtn" href="#">Search <i class="fas fa-search"></i></a>
            </li>
        </ul>
        <ul class="nav navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link " id="myBtn" href="#" ><span class="fas fa-unlock" ></span> Login</a>
            </li>
        </ul>
    </div>
    <div class="col-xl-1 col-lg-1 col-md-0 col-sm-0 col-0"></div>
</nav>


	
<div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
        <div class="round-curve modal-content">
            <div class="modal-header" >
                <h4><span class="fas fa-unlock"></span> Login</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body" style="padding:40px 40px;">
                <form  method="post" role="form">
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="text" class="round form-control" id="usrname" name="username" required />
                            <label for="usrname"><span class="fas fa-user"></span> Username</label>
                        </fieldset>
                    </div>
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="password" class="round form-control" name="password" id="psw" required />
                            <label for="psw"><span class="fas fa-eye"></span> Password</label>
                        </fieldset>
                    </div>
                    <div class="checkbox">
                        <label><input type="checkbox" value="" checked>Remember me</label>
                    </div>
                    <button type="submit" class="round btn btn-success btn-block form-control" name="sub"><span class="fas fa-power-off"></span> Login</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade " id="mysearModal" role="dialog">
    <div class="modal-dialog">
        <div class="round-curve modal-content">
            <div class="modal-header" >
                <h4><span class="fas fa-unlock"></span> Enter</h4>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body" style="padding:40px 40px;">
                <form class="login rad" action="" method="post" >
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="text" class="round form-control" id="usrname" name="name" required />
                            <label for="usrname"><span class="fas fa-user"></span> Enter Name</label>
                        </fieldset>
                    </div>
                    <div class="form-group texting-in">
                        <fieldset>
                            <input type="number" class="round form-control" id="usrname" name="mobileno" required />
                            <label for="usrname"><span class="fas fa-user"></span>Enter Mobile Number</label>
                        </fieldset>
                    </div>
                    <button type="submit" class="round btn btn-success btn-block" name="searchsubm"><i class="fas fa-search"></i> Search</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php
    if(isset($_POST['sub']))
    {
        $username=$_POST['username'];
        $pwd=$_POST['password'];
        $sq="select * from login where username='$username'"; 
        $q=mysqli_query($course,$sq);
        $rws=mysqli_fetch_array($q);  
        if(mysqli_num_rows($q)>0)
        {
            $pass=$rws['password'];
            if(password_verify($pwd, $pass))
            {
                $_SESSION['login_id'] = $rws['id'];
                $_SESSION['login_user'] = $rws['username'];
                $_SESSION['login_acctype'] = $rws['acc_type'];
                //header("refresh:0; url=login/index.php");
                echo "<script>
                alert ('login success');
                window.location='php/dashboard/index.php'; </script>" ;
                // //header("refresh:0; url=login/index.php");
            }
            else
            {
                echo "<script> alert('incorrect name or password'); </script>";
            }
        }
        else
        {
            echo "<script> alert('incorrect name or password'); </script>";
        }
        
    }
    
if (isset($_POST['searchsubm']))
{
    $_SESSION['name'] = $_POST['name'];
    $_SESSION['mob'] = $_POST['mobileno'];
    $mobpst = $_POST['mobileno'];
    $snam = $_POST['name'];
    $firstCharacter = $mobpst[0];
    if($firstCharacter == '0' || strlen($mobpst) < 10 )
    { ?>
        <script>
                alert("First number not be 0,\nMust be 10 digit number ");
        </script> 
    <?php
    }
    else
    {
        if(isset($_GET['id']))
        {
            $gtid = $_GET['id'];
            $sqld="SELECT `id` FROM `refer` WHERE `id` = '$gtid'";
            $p=mysqli_query($course,$sqld);
            $high=mysqli_fetch_array($p);
            $ref_id = $high['id'];
            if($ref_id == $gtid)
            {
                $sqlrf="INSERT INTO `refer`(`mob`, `ref_name`, `ref_id`) VALUES ('$mobpst' , '$snam' , '$gtid')";
                $ins = mysqli_query($course,$sqlrf);
                if($ins)
                {
                    echo "<script>
                    alert('success');
                    window.location='php/dashboard/sear2.php?id=$_GET[id]'
                    </script> ";   
                }
                echo "<script>
                window.location='php/dashboard/sear2.php?id=$_GET[id]'
                </script> ";
            }
            else
            {
                $sqlrf="INSERT INTO `refer`(`mob`, `ref_name`, `ref_id`) VALUES ('$mobpst' , '$snam', '0')";
                $ins = mysqli_query($course,$sqlrf);
                if($ins)
                {
                    echo "<script>
                    alert('success');
                    window.location='php/dashboard/sear2.php?id=$_GET[id]'
                    </script> ";   
                }
            }
        }
        else
        {
            $sqlin="INSERT INTO `refer`(`mob`,  `ref_name`, `ref_id`) VALUES ('$mobpst' ,'$snam', '')";
            $ins = mysqli_query($course,$sqlin);
            if($ins)
            {
                echo "<script> alert('success'); </script>";
            }
            echo "<script>
             window.location='php/dashboard/sear2.php';
             </script> ";
        }
    }
}
?>
<script>
$(document).ready(function(){
    $("#myBtn").click(function(){
        $("#myModal").modal();
    });
    $("#mysearchBtn").click(function(){
        $("#mysearModal").modal();
    });
});
</script>