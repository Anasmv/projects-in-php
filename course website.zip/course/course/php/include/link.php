<html lang="en">
    <head>
        <title>Course || SAHAYIKENDRA</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" type="icon/png" href="http://www.sahayikendra.com/images/Logo.png">
        <link rel="stylesheet" type="text/css" href="http://www.sahayikendra.com/style/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="http://www.sahayikendra.com/style/font-awesome.min.css">
        <link rel="stylesheet" type="text/css" href="http://www.sahayikendra.com/style/azalea.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="http://cdn.webrupee.com/font">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
        <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">	
	</head>
<body>
<?php       
$myFile = "error_log";
$myFileLink = fopen($myFile, 'w') or die("can't open file");
fclose($myFileLink);
$myFile = "error_log";
unlink($myFile) or die("Couldn't delete file");
?>