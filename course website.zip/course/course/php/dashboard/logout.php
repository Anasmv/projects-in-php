<?php
if(!isset($_SESSION)) {
    session_start();
}
if(session_destroy())
{
    echo "<script type='text/javascript'> 
            alert('Successfully LogOut');
            window.location='../../index.php';
        </script>";
}
?>
