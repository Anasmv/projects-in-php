<?php
if(!isset($_SESSION)) {
    session_start();
}
//echo $ssmob=$_SESSION['mob'];
//echo $uname=$_SESSION['name'];
include('headerlog.php');
include('../../../php/conn/conn.php');
$id = $_SESSION['refid'];
?>
<div class="container">
    <div class="row">
        <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
        <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
            <h2 align="center" >Refer Details</h2>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card1 shadow">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                    <table class="table table-hover" >
                        <tr>
                            <th>
                                Name
                            </th>
                            <th>
                                Mobile Number
                            </th>
                        </tr>
                        
                        <?php
                        $sql = "SELECT * FROM `refer` where ref_id = '$id' ";
                        $res=mysqli_query($course,$sql);
                        while($row=$res->fetch_assoc())
                        { ?>
                        <tr>
                            <td><?php echo $row['ref_name']; ?></td>
                            <td><?php echo $row['mob']; ?></td>
                        </tr>
                        <?php    
                        }
                        ?>
                        
                    </table>
                    
                </div>
            </div>
        </div>
    </div>
</div>    
<?php
include('../include/footer.php');
?>