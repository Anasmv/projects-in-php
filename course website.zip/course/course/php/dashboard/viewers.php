<?php
if(!isset($_SESSION)) {
    session_start();
}
if( isset($_SESSION['login_id']) && (($_SESSION['login_acctype']=='staff') || ($_SESSION['login_acctype']=='admin')) )
    {
        include('../../../php/conn/conn.php');
        include('headerlog.php');
        ?>
        <br>
            <div class="container">
            	<div class="row">
            		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
            			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
            				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
            				</div>
            				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
            					<h2 align="center round bg-progress">Search Viewers</h2>
            				</div>
            				<br>
            				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
            				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
                			    <table border="1" class="table table-hover">
                			        <tr>
                			            <th>
                			                Mobile Number
                			            </th>
                			            <th>
                			                Name
                			            </th>
                			            <th>
                			                Add Details
                			            </th>
                			        </tr>
                			        <?php 
                			        
                			        $sql = "SELECT * FROM `refer` WHERE `mob` NOT IN (SELECT phone FROM search)";
                			        $res=mysqli_query($course,$sql);
                			        while($row=$res->fetch_assoc())
                                        {
                                        ?>
                                        <tr>
                                            <td>
                                                <?php echo $row['mob']; ?>
                                            </td>
                                            <td>
                                                <?php echo $row['ref_name']; ?>
                                            </td>
                                            
                                            
                                            <td>
                                                
                                                <a href="adddetails.php?id=<?php echo $row['id'];?>&name=<?php echo $row['ref_name'];?>&mob=<?php echo$row['mob'];?>" target="_blank">
                                                    Add Details
                                                </a>
                       
                                            </td>
                                            
                                        </tr>
                                        <?php
                                        }
                                    ?>
                			    </table>
            			    </div>
            			</div>
            		</div>
            	</div>
            </div>
    <?php
    }
    else
    {
        echo "<script> alert('Please login again or restart your browser.'); </script>";
        echo "<script> window.location='index.php'; </script> ";
    }
    ?>