<?php
if(!isset($_SESSION)) {
    session_start();
}
 
    if(isset($_GET['course']) && isset($_GET['inst']))
     {
        include('headerlog.php');
        include('../../../php/conn/conn.php'); 
        
        $coure=$_GET['course'];
        $inst=$_GET['inst'];
       
        if ( isset($_SESSION['name']) && isset($_SESSION['mob']) )
        {
        $name=$_SESSION['name'];
        $mob=$_SESSION['mob'];
        }
        $sql="SELECT * FROM course WHERE course = '$coure' AND institution_code = '$inst'";
        $res=mysqli_query($course,$sql);
    ?>
        <br>
        <div class="container">
            <div class="row">
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
                <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 "></div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
        					<h2 align="center round bg-progress">COURSE DETAILS</h2>
        				</div>
        				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow">
                        <?php
                        if (isset($_SESSION['mob']) )
                            { ?>
                        <p class="align-text-top text-right"><span class="h6 text-danger ml-auto small">All the Amount are approximate. There will be changes. You will be get call back on your Mobile Number.</span><span class="B text-danger"><?php echo "  " . $mob ?></span></p>
                        <?php } ?>
                        <table class="table table-hover">
                        	<tr>
                        		<th><label>Course Name</label></th>
                        		
                        		<th><label>Institute Name</label></th>
                        		
                        		<th><label>Tution Fee</label></th>
                    		<?php
                    		if($_SESSION['login_acctype']  == 'admin' || $_SESSION['login_acctype']  == 'staff' )
                    		{
                        		?>
                        		<th><label>Donation</label></th>
                        		<th><label>Exam Fee</label></th>
                        		<th><label>Book and Uniform</label></th>
                        		<th><label>Library</label></th>
                        		<th><label>Hostel Charge</label></th>
                        		
                        		<th><label>Duration</label></th>
                        		<th><label>Duration Type</label></th>
                        		
                        		<th><label>Fee Structure</label></th>
                        		<?php
                    		}
                    		?>
                        	</tr>
                        	  
                        	<?php
                        	while($row=$res->fetch_assoc())
                        	{?>
                        	<tr>
                        		<td><?php echo $row['course'];?></td>
                        		<td>
                            		<?php
                            		$sq="select * from institute where id='$inst'"; 
                                    $q=mysqli_query($course,$sq);
                                    $rws=mysqli_fetch_array($q);
                                    echo $rws['name']; ?>
                                </td>
                        		
                        		<td><?php echo $row['tutionfee'];?></td>
                        	<?php
                        	if($_SESSION['login_acctype']  == 'admin' || $_SESSION['login_acctype']  == 'staff')
                        	{
                            ?>	
                        		<td><?php echo $row['donation'];?></td>
                        		<td><?php echo $row['examfee'];?></td>
                        		<td><?php echo $row['bookanduniform'];?></td>
                        		<td><?php echo $row['library'];?></td>
                        		<td><?php echo $row['hostel_charge'];?></td>
                        		
                        		<td><?php echo $row['dur'];?></td>
                        		<td><?php echo $row['dur_typ'];?></td>
                        		
                        		<td><?php echo $row['fees_st'];?></td>
                        		<?php 
                        	}
                        	?>
                        	</tr>
                        	<?php 
                        	}
                        	?>
                        </table>
                    </div>
                <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            </div>
        </div>
        
        <?php
        include('../include/footer.php');
        if ( isset($_SESSION['name']) && isset($_SESSION['mob']) )
        {
            $sname = strtoupper($name);
            
            $date = date('Y-m-d');
            $pooi="SELECT * FROM course WHERE course='$coure'";
            $p=mysqli_query($course,$pooi);
            $low=mysqli_num_rows($p);
            $high=mysqli_fetch_array($p);
            $id=$high['id'];
            $sqlins="INSERT INTO `search`(`name`, `phone`, `search_date`, `search_field`, 
            `search_field_type`, `refer`,
            `refer_from`, `status`, `will_status`, `follow_up`, `remarks`, `referer`) 
            VALUES ('$sname', '$mob', '$date', '$id','coursedetails', '', '', '0', '', '', '', '')";
            mysqli_query($course,$sqlins);
            mysqli_close($course);
        }
    }
     else
    {
        echo "<script>
             window.location='sear2.php';
             </script> ";
    }
?>
