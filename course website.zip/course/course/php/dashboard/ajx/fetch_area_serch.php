<?php
include('../../../../php/conn/conn.php');
if (isset($_POST['state']))
{
    $state = ($_REQUEST["state"] <> "") ? trim($_REQUEST["state"]) : "";
    if ($state <> "") {
        $sql = "SELECT DISTINCT district FROM institute WHERE  state = '$state' ORDER BY institute.district";
        $res=mysqli_query($course,$sql);
            ?>      <option value="" >Please Select</option>
                    <?php while($row=$res->fetch_assoc()) { ?>
                        <option value="<?php echo $row["district"]; ?>"><?php echo $row["district"]; ?></option>
                    <?php }
    }
}
if (isset($_POST['district']))
{
    $district = ($_REQUEST["district"] <> "") ? trim($_REQUEST["district"]) : "";
    if ($district <> "") {
        $sql = "SELECT DISTINCT area FROM institute WHERE  district = '$district' ORDER BY institute.area";
        $res=mysqli_query($course,$sql);
            ?>      <option value="" >Please Select</option>
                        <?php while($row=$res->fetch_assoc()) { ?>
                    <option value="<?php echo $row["area"]; ?>"><?php echo $row["area"]; ?></option>
                        <?php }
    }
}
?>