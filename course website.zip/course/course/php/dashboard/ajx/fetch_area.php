<?php
include('../../../../php/conn/conn.php');
if (isset($_POST['country'])) {
    $country_id = ($_REQUEST["country"] <> "") ? trim($_REQUEST["country"]) : "";
    if ($country_id <> "") {
        $sql = "SELECT DISTINCT state FROM area_table WHERE  country = '$country_id' ORDER BY `area_table`.`state` ASC";
        $res=mysqli_query($area,$sql); 
            ?>
            <option value="" >Please Select</option>
            <?php while($row=$res->fetch_assoc())
			{ ?> 
                <option value="<?php echo $row["state"]; ?>"><?php echo $row["state"]; ?></option>
            <?php } 
    }
}
if (isset($_POST['state'])) {
    $state_id = ($_REQUEST["state"] <> "") ? trim($_REQUEST["state"]) : "";
    if ($state_id <> "") {
        $sql = "SELECT DISTINCT district FROM area_table WHERE  state = '$state_id' ORDER BY `area_table`.`district` ASC";
        $res=mysqli_query($area,$sql); 
            ?>
            <option value="" >Please Select</option>
            <?php while($row=$res->fetch_assoc())
            { ?> 
                <option value="<?php echo $row["district"]; ?>"><?php echo $row["district"]; ?></option>
            <?php }
    }
}

if (isset($_POST['lcltype'])) {
    echo $dist=$_COOKIE['district'];
    $loctyp_id = ($_REQUEST["lcltype"] <> "") ? trim($_REQUEST["lcltype"]) : "";
    if ($loctyp_id <> "") {
        $sql = "SELECT DISTINCT local_area_name FROM area_table WHERE 
        local_area_type = '$loctyp_id' AND district = '$dist' ORDER BY `area_table`.`local_area_name` ASC";
        $res=mysqli_query($area,$sql); 
            ?>
            <option value="" >Please Select</option>
            <?php while($row=$res->fetch_assoc())
            { ?> 
                <option value="<?php echo $row["local_area_name"]; ?>"><?php echo $row["local_area_name"]; ?></option>
            <?php } 
    }
}

if (isset($_POST['lclarea'])) {
    $locname_id = ($_REQUEST["lclarea"] <> "") ? trim($_REQUEST["lclarea"]) : "";
    if ($locname_id <> "") {
        $sql = "SELECT DISTINCT place FROM area_table WHERE  local_area_name = '$locname_id' ORDER BY `area_table`.`place` ASC";
        $res=mysqli_query($area,$sql); 
            ?>
            <option value="" >Please Select</option>
            <?php while($row=$res->fetch_assoc())
									{ ?> 
                <option value="<?php echo $row["place"]; ?>"><?php echo $row["place"]; ?></option>
            <?php } ?>
            <option value="other">Others</option>
<?php
    }
}
?>