<?php
include('../../../../php/conn/conn.php');
if(!isset($_SESSION)) {
    session_start();
}
if (isset($_POST['institute']))
{
    $ffname=$_SESSION['name'];
    $name = strtoupper($ffname);
    $mob=$_SESSION['mob'];
    $date = date('Y-m-d');
    $institute = ($_REQUEST["institute"] <> "") ? trim($_REQUEST["institute"]) : "";
    $sqlsel="SELECT `id` FROM `institute` WHERE `name` = '$institute'";
    $p=mysqli_query($course,$sqlsel);
    $low=mysqli_num_rows($p);
    $high=mysqli_fetch_array($p);
    $id=$high['id'];
    
    $sql = "INSERT INTO `search`(`name`, `phone`, `search_date`, 
    `search_field`, `search_field_type`, `refer`, 
    `refer_from`, `status`, `will_status`, `follow_up`, `remarks`, `referer`) 
     values ('$name', '$mob', '$date', '$id', 'institute', '', '', '0', '', '', '', '')";
    $res=mysqli_query($course,$sql);
    $yu=mysqli_query($course,$res);
    mysqli_close($course);
}
if (isset($_POST['course']))
{
    $ffname=$_SESSION['name'];
    $name = strtoupper($ffname);
    $mob=$_SESSION['mob'];
    $date = date('Y-m-d');
    $courseajx = ($_REQUEST["course"] <> "") ? trim($_REQUEST["course"]) : "";
    $sqlsel="SELECT `id` FROM `course` WHERE `course` = '$courseajx'";
    $p=mysqli_query($course,$sqlsel);
    $low=mysqli_num_rows($p);
    $high=mysqli_fetch_array($p);
    $id=$high['id'];
    $sql = "INSERT INTO `search`(`name`, `phone`, `search_date`, `search_field`, 
    `search_field_type`, `refer`, `refer_from`, `status`,
    `will_status`, `follow_up`, `remarks`, `referer`) 
    values ('$name', '$mob', '$date', '$id','course', '', '', '0', '', '', '', '')";
    mysqli_query($course,$sql);
}
?>