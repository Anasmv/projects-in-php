<?php
if(!isset($_SESSION))
    {
        session_start();
    }
if(isset($_SESSION['login_id']) && ($_SESSION['login_acctype'] == 'agent'))
{
    $us=$_SESSION['login_user'];
    include('headerlog.php');
    include('../../../php/conn/conn.php'); 
    ?>
    <div class="container">
    	<div class="row">
    		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
    		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
    		<br>
    			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
    			</div>
    				
                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
                        <h2 align="center round bg-progress">REGISTER INSTITUTE</h2>
                    </div>
                    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
                </div>
    			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
    					<form name="myform" action="" method="post" class="row">
    						
    						<div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 texting-in ">
    						</div>
    						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    							<fieldset>
    								<input type="text" name="institute"  class='form-control round' required="reqired"/>
    								<label>Name:</label>
    							</fieldset>
    						</div>
    
    						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    							<fieldset>
    								<SELECT  class="round form-control " name="country" tabindex="8" required onChange="showState(this)">
    								<option  value="">Select Country</option>
    									<?php
    										$sql = "SELECT DISTINCT country FROM area_table ORDER BY `area_table`.`country` ASC";
    										$res=mysqli_query($area,$sql);
    									?>
    										<?php while($row=$res->fetch_assoc())
    											{ ?>
    											<option  value="<?php echo $row["country"]; ?>"><?php echo $row["country"]; ?></option>
    										<?php } ?>
    								</SELECT>	
    							</fieldset>
    						</div>
    
    						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    							<fieldset>
    								<SELECT  class="round form-control " name="state" id="state" tabindex="9"  onchange="showDistrict(this);">
    									<option  value="">Select State</option>
    								</SELECT>	
    							</fieldset>
    						</div>
    
    						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    							<fieldset>
    								<SELECT  class="round form-control " name="district" tabindex="10" id="district_id" onchange=" showLclType(this);" >
    									<option  value="">Select District</option>
    								</SELECT>
    							</fieldset>
    						</div>
    
    						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in " id="newplace1">
    							<fieldset>
    								<SELECT  class="round form-control " name="lclbdtyp" tabindex="11" id="loc_type" onchange="showLclArea(this);" >
    									<option  value="">Select Local body type</option>
    								</SELECT>
    							</fieldset>
    						</div>
    
    						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in " id="newplace2">
    							<fieldset>
    								<SELECT  class="round form-control " name="loc_name" tabindex="12" id="loc_name" onchange="showPlace(this);" >
    									<option  value="">Select Local body Name</option>
    								</SELECT>
    							</fieldset>
    						</div>	
    
    						<div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in " id="newplace3">
    							<fieldset>
    								<SELECT  class="round form-control " name="place" tabindex="13" id="place_id" onchange="changeFuncPlace();">
    									<option  value="bb" selected>Select Place</option>
    									<option  value="other">Select Place</option>
    								</SELECT>
    							</fieldset>
    						</div>
    						
    						<div class="form-group  col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in" id="otherpalce" >
    								<input type="text" class="round form-control" name="newplace" placeholder="Enter New Place" value="0" id="otherpalce" >
                            </div>
    						
    						 <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    							<fieldset>
    							   <input type="text" name="uname" class='form-control  round' required="reqired"/> 
    								 <label>User Name</label> 
    							</fieldset>
    						</div>
    						
    						 <div class="form-group  col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 texting-in ">
    							<fieldset>
    								<input type="password" name="password" class='form-control  round' required="reqired"/> 
    								<label>Password</label>
    							</fieldset>
    						</div>
    						
    						<div class="col-xl-3 col-lg-3 col-md-3 col-sm-4 col-4">
    						</div>
    						
    						<div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                                <input type="reset" class="round btn btn-success btn-danger" value="reset" name="submitform">
                            </div>
    						<div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                                <input type="submit" name="subbtn" class="round btn btn-success btn-block" value="submit" name="submitform">
                            </div>
    					</form>
    				</div>
    			</div>
    		</div>
    		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
    		
    		<div class="row">
    		
    		</div>
    		
    	</div>
    </div>
    
    
    
                            
                            
    
    <?php
    if(isset($_POST['subbtn']))
    {
    	$nation=$_POST['country'];
    	$state=$_POST['state'];
    	$district=$_POST['district'];
    	$lcltype=$_POST['lclbdtyp'];
    	$local_area_name=$_POST['loc_name']; 
    	 $place = $_POST['place'];
    	
    	$institute=$_POST['institute'];
    	$username=$_POST['uname'];
    	
    	$psd=$_POST['password'];
    	$password=password_hash($psd, PASSWORD_DEFAULT);
    	 $newplace=$_POST['newplace'];
    	
    	/*
    	$sqlarea="SELECT id from area_table where 
    	state = '$state' 
    	AND district = '$district' 
    	AND local_area_name = '$local_area_name'
    	AND place = '$place'";
    	$resarea=mysqli_query($area,$sqlarea);
    	$rowarea=mysqli_fetch_array($resarea);
    	$area_id=$rowarea['id'];
    	*/
    	
    	
    	
    	if($place=='other')
    {
        
        $sqlnewplace="INSERT INTO `area_table`( `country`, `mal_country`, `state`, `mal_state`, `district`,
         `mal_district`, `mandalam`, `mal_mandalam`, `taluk`, `mal_taluk`, `village`, `mal_village`, `local_area_type`,
         `mal_local_area_type`,
         `local_area_name`, `mal_local_area_name`, `place`, `mal_place`) VALUES('$nation','0','$state','0','$district','0','0','0','0','0','0','0','$lcltype',
         '0','$local_area_name','0','$newplace','0')";
         $resnewplace=mysqli_query($area,$sqlnewplace);
         
         /*
    	 $sqlnewarea="SELECT id from area_table where country='$nation' 
            AND state = '$state' 
            AND district = '$district' 
            AND local_area_type ='$lcltype'
            AND local_area_name = '$local_area_name'
            AND place = '$newplace'";
            $resnewarea=mysqli_query($area,$sqlnewarea);
            $rownewarea=mysqli_fetch_array($resnewarea);
            echo $new_area_id=$rownewarea['id'];
    		*/
         
    	 $ghj="INSERT INTO `institute`(`name`, `state`, `district`, `area`, `account_type`, `username`, `password`) VALUES ('$institute','$state','$district','$newplace','institute','$username','$password')";
    	
    	$ol=mysqli_query($course,$ghj);
    	if($ol)
    	{
    		echo "<script> alert('New place inserted');</script>";
    	}
    	else
    	{
    		echo "<script> alert('new area not inserted');</script>";
    	}
           
           
         
    
    
           
    }
    else
    {
    	$ghj="INSERT INTO `institute`(`name`, `state`, `district`, `area`, `account_type`, `username`, `password`) VALUES ('$institute','$state','$district','$place','institute','$username','$password')";
    	
    	$ol=mysqli_query($course,$ghj);
    	if($ol)
    	{
    		echo "<script> alert('already place inserted');</script>";
    	}
    	else
    	{
    		echo "<script> alert('Not inserted');</script>";
    	}
    }
    }?>
    
    <script>
    window.onload = function fresh(){
    	$("#otherpalce").hide();
    };
    	
    function changeFuncPlace() 
    {
    	var select2 = document.getElementById("place_id");
    	var selectedValue = select2.options[select2.selectedIndex].value;
    	if (selectedValue=="other")
    	{
    		$('#otherpalce').show();
    		$("#newplace1").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ");
    		$("#newplace2").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
    		$("#newplace3").attr("class", "form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12");
    	}
    	else 
    	{
    		$('#otherpalce').hide();
    		$("#newplace1").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ");
    		$("#newplace2").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ");
    		$("#newplace3").attr("class", "form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ");
    	}
    }
    </script>
    <script>
        function showState(sel) {
            var country_id = sel.options[sel.selectedIndex].value;
            if (country_id.length > 0) {
    			$.ajax({
                    type: "POST",
                    url: "ajx/fetch_area.php",
                    data: "country=" + country_id,
                    cache: false,
                    beforeSend: function() {
                        $('#state').html('<img src="loader.gif" alt="" width="24" height="24">');
                    },
                    success: function(html) {
                        $("#state").html(html);
                    }
                });
            }
        }
    	 function showDistrict(sel) {
            var state_id = sel.options[sel.selectedIndex].value;
            if (state_id.length > 0) {
                $.ajax({
                    type: "POST",
                    url: "ajx/fetch_area.php",
                    data: "state=" + state_id,
                    cache: false,
                    beforeSend: function() {
                        $('#district_id').html('<img src="loader.gif" alt="" width="24" height="24">');
                    },
                    success: function(html) {
                        $("#district_id").html(html);
                    }
                });	
            } else {
                $("#district_id").html("");
            }
        }
    	
    	 
    	 function showLclType(sel) {
            var district = sel.options[sel.selectedIndex].value;
    		document.cookie = "district=" + district;
            if (district.length > 0){
                $.ajax({
                    type: "POST",
                    url: "ajx/fetch_type.php",
                    data: "district=" + district ,
                    cache: false,
                    beforeSend: function() {
                        $('#loc_type').html('<img src="loader.gif" alt="" width="24" height="24">');
                    },
                    success: function(html) {
                        $("#loc_type").html(html);
                    }
                });
            } else {
                $("#loc_type").html("");
            }
        }
    	
         
    	
    	function showLclArea(sel) {
            var lcltype = sel.options[sel.selectedIndex].value;
            if (lcltype.length > 0){
                $.ajax({
                    type: "POST",
                    url: "ajx/fetch_area.php",
                    data: "lcltype=" + lcltype ,
                    cache: false,
                    beforeSend: function() {
                        $('#loc_name').html('<img src="loader.gif" alt="" width="24" height="24">');
                    },
                    success: function(html) {
                        $("#loc_name").html(html);
                    }
                });
            } else {
                $("#loc_name").html("");
            }
        }
    	
    	
       
        function showPlace(sel) {
            var lclarea = sel.options[sel.selectedIndex].value;
            if (lclarea.length > 0) {
                $.ajax({
                    type: "POST",
                    url: "ajx/fetch_area.php",
                    data: "lclarea=" + lclarea,
                    cache: false,
                    beforeSend: function() {
                        $('#place_id').html('<img src="loader.gif" alt="" width="24" height="24">');
                    },
                    success: function(html) {
                        $("#place_id").html(html);
                    }
                });
            } else {
                $("#place_id").html("");
            }
        }
    </script>
    </body>
    </html>
    <?php
    include('../include/footer.php');
}
else
{
    if( isset($_SESSION['login_id']) )
    {
        session_destroy();
    }
echo "<script> window.location.href='../index.php' </script>";
}
?>