<?php
if(!isset($_SESSION)) {
    session_start();
}
if(isset($_SESSION['login_user']) && isset($_SESSION['login_acctype']) && isset($_SESSION['login_id']))
{
    $us=$_SESSION['login_user'];
    $acctyp = $_SESSION['login_acctype'];
    $accid = $_SESSION['login_id'];
    include('headerlog.php');	
    if($acctyp == 'staff')
    {
// 	include('staff.php');
	?>
	<h1 align="center">Login As Staff </h1> <br>
    	<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
    	    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 "></div>
    	    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 row">
    	        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        	        <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='staff.php' target="_blank">Search Details</a>
        	    </div>
        	    <div class="cform-group ol-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        	        <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='viewers.php' target="_blank">Viewers</a>
        	    </div>
            </div>
        </div>
	
	
	
	<?php
    }
    
    elseif($acctyp == 'agent')
    { ?>
    <br>
    	<h1 align="center">Login As Agent </h1> <br>
    	<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
    	    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 "></div>
    	    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 row">
    	        <div class="form-group col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        	        <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='http://course.sahayikendra.com/admin/addagent.php?agent=regins&type=null' target="_blank">Register Institute</a>
        	    </div>
        	    <div class="form-group ol-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        	        <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='registercource.php?agentid=<?php echo $accid; ?>' target="_blank">Register course</a>
        	    </div>
        	    
        	    <div class="form-group ol-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        	        <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='http://course.sahayikendra.com/admin/courseview.php' target="_blank">View course</a>
        	    </div>
        	    
        	    <div class="form-group ol-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        	        <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='http://course.sahayikendra.com/admin/instituteview.php' target="_blank">View institute</a>
        	    </div>
        	    
        	    <div class="form-group ol-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 ">
        	        <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='http://course.sahayikendra.com/admin/addarea.php' target="_blank">Add Area</a>
        	    </div>
        	    
    	    </div>
    	    
    	    
    	    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 "></div>
    		
    		<!--<a href='registercource.php'>Register Course</a>-->
		</div>
    	<?php
	}
    	
        
	elseif($acctyp == 'institute')
	{ ?>
		<div align="center">
			<h1 align="center">Login As Institute </h1><br>
		</div>
		<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
		    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 "></div>
		    <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 row">
    		    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
    		        <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='registercource.php' target="_blank">Register Course</a>
    		    </div>
    		    <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
    		        <a class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 btn btn-info round form-control" href='viewinscourse.php' target="_blank">View Course</a>
    		    </div>
    		</div>
		    
		    <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 "></div>
		</div>
		
		
	<?php
	}
	elseif($acctyp == 'admin')
	{
	    echo "<script>
                window.location='../../admin/index.php'; </script>" ;
	}
// 	else
//     {
// 	echo "<script>
// 		window.location='../index.php';
// 		</script>";
//     }
        
    include('../include/footer.php');
}
else
{
    echo "<script> alert('Please login again or restart your browser.'); </script>";
    echo "<script> window.location='http://course.sahayikendra.com'; </script> ";
}
?>
</body>
</html>

