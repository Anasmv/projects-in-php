<?php
if(!isset($_SESSION)) {
    session_start();
}
if( isset($_SESSION['login_id']) && ($_SESSION['login_acctype']=='staff') )
    {
        include('headerlog.php');
    include('../../../php/conn/conn.php'); 
    $sqll="select distinct phone from search where status = '0'";
    $resl=mysqli_query($course,$sqll);
    ?>
    <?php
    if($resl->num_rows>0)
    {
     ?>
     <br>
     <div class="container">
    	<div class="row">
    		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
    		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
    			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
    				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
    				</div>
    				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 bg-secondary text-light round text-center" >
    					<h2 align="center round bg-progress">Search Details</h2>
    				</div>
    				<br>
    				<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12" ></div>
    			</div>
    			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
    			    <table border="1" class="table table-hover">
                        <tr>
                            <th>Name</th>
                            <th>Phone No</th>
                            <th>Searched Date</th>
                    		<th>Institute</th>
                    		<th>Course</th>
                    		<th>Searched Course Details</th>
                            <th>Add details</th>
                        </tr>
                        <?php
                        while($rowl=$resl->fetch_assoc())
                        {
                    		$mob=$rowl['phone'];?>
                        <tr>	
                    		<td>
                            <?php
                            $sql2name="select distinct name from search where phone = '$mob' AND status = '0'";
                            $res2name=mysqli_query($course,$sql2name);
                    		while($row2name=$res2name->fetch_assoc())
                            {
                            ?>
                                
                                <?php  echo $row2name['name'];?>
                                  
                            <?php } ?>
                    		</td>
                    		<td><?php echo $rowl['phone'];?></td>
                            <?php
                            $sql2dat="select distinct search_date from search where phone = '$mob' AND status = '0'";
                            $res2dat=mysqli_query($course,$sql2dat);
                    		while($row2dat=$res2dat->fetch_assoc())
                            {
                            ?>
                                <td>
                                <?php  echo $row2dat['search_date'];?>
                                </td>  
                            <?php } ?>
                            <td>
                    	    <?php
                            $sqltype="select distinct search_field_type, search_field  from search where phone = '$mob' AND status = '0'";
                            $restype=mysqli_query($course,$sqltype);
                    		while($rowtype=$restype->fetch_assoc())
                            {
                              $type=$rowtype['search_field_type'];
                                  $srchfd=$rowtype['search_field'];
                                
                                
                                	if($type == 'institute')
                    			{
                    			$sqllin="select name from institute WHERE id = '$srchfd'";
                                $reslin=mysqli_query($course,$sqllin);
                                $lowin=mysqli_num_rows($reslin);
                                $highin=mysqli_fetch_array($reslin);
                               
                                 echo $highin['name']; ?>,&nbsp; 
                                <?php
                    			}
                    			else
                    			{
                    			    echo " ";
                    			}
                    		}
                    		?>
                    		</td>
                    		<td>
                    		<?php
                            $sqltypeco="select DISTINCT search_field_type, search_field  from search where phone = '$mob' AND status = '0'";
                            $restypeco=mysqli_query($course,$sqltypeco);
                    		while($rowtypeco=$restypeco->fetch_assoc())
                            {
                    			$type=$rowtypeco['search_field_type'];
                    			$srchfd=$rowtypeco['search_field'];
                    			if($type == 'course')
                    			{
                    			    $sqllcou="select course from course WHERE id = '$srchfd'";
                    			    $reslcou=mysqli_query($course,$sqllcou);
                    			    $lowcou=mysqli_num_rows($reslcou);
                    			    $highcou=mysqli_fetch_array($reslcou);
                    				echo $coursft = $highcou['course']; ?>, &nbsp;
                    			<?php
                    			// echo implode(",", $cours); 
                    			// echo implode(", ",$highcou['course']);
                    			//$idss[] = $highcou['course'];
                    			?>
                                <?php
                    			}
                    			else
                    			{
                    			    echo " ";
                    			}
                    		}
                    		//$implode = implode(', ', $idss);
                    	//	echo $implode;
                    		?>
                            </td>
                    		<td>
                    		<?php
                    			$sqldet="select distinct search_field_type, search_field  from search where phone = '$mob' AND 
                    			search_field_type='coursedetails' AND status = '0'";
                    			$resdet=mysqli_query($course,$sqldet);
                    			while($rowdet=$resdet->fetch_assoc())
                    			{
                    				$type=$rowdet['search_field_type'];
                    				$srchfd=$rowdet['search_field'];
                    				$sqllcou="select course from course WHERE id = '$srchfd'";
                    			    $reslcou=mysqli_query($course,$sqllcou);
                    			    $lowcou=mysqli_num_rows($reslcou);
                    			    $highcou=mysqli_fetch_array($reslcou);
                                 echo $highcou['course']; ?>,&nbsp; 
                    			 <?php
                    			 //$implode = implode(', ', $highcou['course']);
                    			 //echo $implode;
                    			}
                    			
                    		?>
                    		</td>
                            <?php
                            $sqlid="select * from search where phone = '$mob' AND status = '0'";
                                $reslid=mysqli_query($course,$sqlid);
                                $rowid=mysqli_fetch_array($reslid);
                                ?>
                            <td><a href="adddetails.php?id=<?php echo $rowid['id'];?>&name=<?php echo $rowid['name'];?>&mob=<?php echo $rowid['phone'];?>&dt=<?php echo $rowid['search_date']; ?>">Add Details</a> </td>
                        </tr>
                        <?php
                            }
                        ?>
                    </table>
    			</div>
    		</div>
    		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
    	</div>
    </div>
    				    
    
    <?php
}
else
{
	echo "<script>alert('No Data');</script>";
	//header("refresh:0; url=staff.php");
}
mysqli_close($course);
}
else
{
    echo "<script> alert('Please login again or restart your browser.'); </script>";
    if(isset($_SESSION))
    {
        session_destroy();
    }
    echo "<script> window.location='http://course.sahayikendra.com'; </script>";
}
?>
</body> 
</html>