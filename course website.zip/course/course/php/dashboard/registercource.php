<?php
if(!isset($_SESSION))
    {
        session_start();
    }
if(isset($_SESSION['login_id']) && (($_SESSION['login_acctype'] == 'agent') || ($_SESSION['login_acctype'] == 'institute')))
{
        $idinstit = $_SESSION['login_id'];
    	include('headerlog.php');
    	include('../../../php/conn/conn.php'); 
    	?>
    <div class="container">
    	<div class="row">
    		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
    		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
    		<br>
    			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                    <div class="form-group col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 ">
        			</div>
    				
                    <div class="form-group col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 bg-secondary text-light round text-center" >
                        <h2 align="center round bg-progress">REGISTER COURSE</h2>
                    </div>
                    <div class="form-group col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12" ></div>
                </div>
    			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
    					<form name="myform" action="" method="post" class="row">
    						<!--<div class="form-group  col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6 texting-in ">-->
    						<!--</div>-->
    						<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in">
    							<fieldset>
    								<input type="text" name="course" class='form-control round' required/>
    								<label>Course:</label>
    							</fieldset>
    						</div>
    						<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in">
    							<fieldset>
    								<input type="number" name="tutionfee"  class='form-control round' required/>
    								<label>Tution Fee:</label>
    							</fieldset>
    						</div>
    						<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in">
    							<fieldset>
    								<input type="number" name="donation" class='form-control round' required/>
    								<label>Donation:</label>
    							</fieldset>
    						</div>
    						
    						<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in">
    							<fieldset>
    								<input type="number" name="examfee" class='form-control round' required/>
    								<label>Exam Fee:</label>
    							</fieldset>
    						</div>
    						<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in">
    							<fieldset>
    								<input type="number" name="bookuniform" class='form-control round' required/>
    								<label>Book and Uniform Fee:</label>
    							</fieldset>
    						</div>
    						<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in">
    							<fieldset>
    								<input type="number" name="library" class='form-control round' required/>
    								<label>Library Fee:</label>
    							</fieldset>
    						</div>
    						<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in">
    							<fieldset>
    								<input type="number" name="hostel"  class='form-control round' required/>
    								<label>Hostel Charge:</label>
    							</fieldset>
    						</div>
    						<div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-12 col-12 texting-in">
    						    <select class='form-control round' name='durat'>
    						        <option>Course Duration</option>
    						        <option>1</option>
    						        <option>2</option>
    						        <option>3</option>
    						        <option>4</option>
    						        <option>5</option>
    						        <option>6</option>
    						        <option>7</option>
    						        <option>8</option>
    						        <option>9</option>
    						        <option>10</option>
    						        <option>11</option>
    						    </select>
    						</div>
    						<div class="form-group col-xl-2 col-lg-2 col-md-4 col-sm-12 col-12 texting-in">
    						    <select class='form-control round' name='durat_type'>
    						        <option>Duration Type</option>
    						        <option>Year</option>
    						        <option>Semester</option>
    						        <option>Month</option>
    						    </select>
    						</div>
    						<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in">
    							<fieldset>
    								<input type="text" name="comm"  class='form-control round' required/>
    								<label>Commission:</label>
    							</fieldset>
    						</div>
    						<?php
    						if($_SESSION['login_acctype'] == 'agent')
    						{
    						    if(isset($_GET['agentid']))
        						{
        						        $agentid = $_GET['agentid'];
        						    
        						    ?>
        						<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
        							<select  name="instit"  class='form-control round' required/>
        								<option>
        								    <label>Select Institute:</label>
        								</option>
        								
        								<?php $sqll="SELECT * from institute where user = $agentid";
        								    $res=mysqli_query($course,$sqll);
        								    while($row=$res->fetch_assoc())
                						{
                						    ?>
        								<option value='<?php echo $row['name'] ?>'>
        								    <?php
                						    echo $row['name'].' - '.$row['state'];
                						    ?>
        								<?php
                						}
        								?>
        								</option>
        							</select>
        						</div>
        						<?php
        						}
    						}
    						?>
    						<div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 texting-in">
    							<fieldset>
    								<input type="text" name="fees"  class='form-control round' required/>
    								<label>Fee Structure:</label>
    							</fieldset>
    						</div>
    						
    						<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
    						    <div class="col-xl-3 col-lg-3 col-md-3 col-sm-4 col-4">
        						</div>
        						
        						<div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                                    <input type="reset" name="" class="round btn btn-danger btn-block form-control" value="Reset" name="submitform">
                                </div>
        						
        						<div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12">
                                    <input type="submit" name="subbtn" class="round btn btn-success btn-block form-control" value="Submit" name="submitform">
                                </div>
    						</div>
    					</form>
    				</div>
    			</div>
    		</div>
    		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
    		<div class="row">
    		</div>
    	</div>
    </div>
    
    <br><br>
    <?php 
    include('../include/footer.php');
    if(isset($_POST['subbtn']))
    	{
    	    $cour=$_POST['course'];
    	    $tution=$_POST['tutionfee'];
    		$donation=$_POST['donation'];
    		$examfee=$_POST['examfee'];
    		$bookun=$_POST['bookuniform'];
    		$library=$_POST['library'];
    	    $hostel=$_POST['hostel'];
    	    $comm=$_POST['comm'];
    	    $duration=$_POST['durat'];
    	    $dur_typ=$_POST['durat_type'];
    	    $fees = $_POST['fees'];
    	    
    	    if($_SESSION['login_acctype'] == 'agent')
    		{
    	        echo $instit = $_POST['instit'];
    	        $sq="select id from institute where name='$instit'"; 
                $q=mysqli_query($course,$sq);
                $rws=mysqli_fetch_array($q);
                echo $insidd = $rws['id'];
    	        
    	        $sql="INSERT INTO `course`(`course`, `tutionfee`, `donation`, `examfee`, `bookanduniform`, `library`, `hostel_charge`, `institution_code`, `comm`, `dur`, `dur_typ`, `user`, `fees_st`) VALUES ('$cour','$tution','$donation','$examfee','$bookun','$library','$hostel','$insidd', '$comm', '$duration', '$dur_typ', '$idinstit', '$fees')";
    		    $r=mysqli_query($course,$sql);
    		}
    		
    		if($_SESSION['login_acctype'] == 'institute')
    		{
    	        $sq="select name from login where id='$idinstit'"; 
                $q=mysqli_query($course,$sq);
                $rws=mysqli_fetch_array($q);
                $nam = $rws['name'];
                
                $sq2="select id from institute where name ='$nam'"; 
                $q2=mysqli_query($course,$sq2);
                $rws2=mysqli_fetch_array($q2);
                $insid = $rws2['id'];
                
    		    $sql="INSERT INTO `course`(`course`, `tutionfee`, `donation`, `examfee`, `bookanduniform`, `library`, `hostel_charge`, `institution_code`, `comm`, `dur`, `dur_typ`, `user`, `fees_st`) VALUES ('$cour','$tution','$donation','$examfee','$bookun','$library','$hostel','$insid', '$comm', '$duration', '$dur_typ', '$idinstit', '$fees')";
    		    $r=mysqli_query($course,$sql);
    		}
    		if($r)
    			{
    				echo "<script> alert('Data inserted');
    				window.location.href=window.location.href;
    				</script>";
    				//header("refresh:0; url=loginpage.php");
    				//header("Location: loginpage.php"); 
    				
    			}
    				else
    			{
    				echo "not inserted";
    			}
    	}
    
    mysqli_close($course);
}
else
{
    echo "<script> alert('Please login again or restart your browser.'); </script>";
    echo "<script> window.location.href='../../index.php'; </script>";  
}
?>
</body>
</html>