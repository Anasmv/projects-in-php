<?php
if(!isset($_SESSION)) {
    session_start();
}
if ( isset($_SESSION['name']) && isset($_SESSION['mob']) )
{
    include('headerlog.php');
    $ssmob=$_SESSION['mob'];
    $uname=$_SESSION['name'];
    include('../../../php/conn/conn.php');
    $sqld="SELECT `id` FROM `refer` WHERE `mob` = '$ssmob'";
    $p=mysqli_query($course,$sqld);
    $high=mysqli_fetch_array($p);
    $ref_id = $high['id']; 
    $_SESSION['refid'] = $ref_id;
    ?>
    <br> 
    <div class="container">
        <div class="row">
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
            <div class="col-xl-10 col-lg-10 col-md-10 col-sm-12 col-12">
                <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card1 shadow">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
                            <?php
                                $lnkcp = "http://course.sahayikendra.com/index.php?id=".$ref_id;
                                echo '<a href="http://course.sahayikendra.com/index.php?id='.$ref_id.'">
                                <input type="text" class="h6" value="'.$lnkcp.'" id="myInput"></a>';
                          	?>
                        </div>
                        <div class="form-group col-xl-2 col-lg-6 col-md-6 col-sm-12 col-12">
                          <button class="round btn btn-success col form-control" onclick="mycopyfn()">Copy link</button> 
                        </div>
                        <?php
                        
                       
                        $sql8="SELECT `id` FROM `refer` WHERE `ref_id` = '$ref_id'";
                        $p1=mysqli_query($course,$sql8);
                        $high1=mysqli_fetch_array($p1);
                        $rid = $high1['id'];
                        if($rid != '')
                        { ?>
                        <!--<div class="form-group col-xl-2 col-lg-6 col-md-6 col-sm-12 col-12">-->
                        <!--    <a href="refdetails.php">-->
                        <!--        <button class="round btn btn-success form-control">-->
                        <!--            Reffer Details-->
                        <!--        </button>-->
                        <!--    </a>-->
                        <!--</div>-->
                        <?php
                        }
                        ?>
                        
                        
                        
                        
                    </div>
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
                            <?php
    						$sql = "SELECT DISTINCT state FROM `institute` ";
    						$res=mysqli_query($course,$sql);
    						?>
    						<SELECT name="mylist"  id="myliststate" class="round form-control" name="country" onChange="showDistrict(this); myFunctionState();">
                                <option value="">Select state</option>
                               <?php
                               while($row=$res->fetch_assoc())
    						   { ?>
                                <option  value="<?php echo $row["state"]; ?>"><?php echo $row["state"]; ?></option>
                                <?php } ?>
                            </SELECT>
                        </div>
                        <div class="form-group  col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
    						<SELECT class="round form-control" name="district" id="districtid" tabindex="6" onChange="showArea(this); myFunctionDistrict();">
                                    <option value="" >Select district</option>
                            </SELECT>
    					</div>
    					<div class="form-group  col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
    						<SELECT class="round form-control" name="area" id="area" tabindex="6" onChange="myFunctionArea()">
                                    <option value="" >Select area</option>
                            </SELECT>
    					</div>
    					<div class="form-group  col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
    						<?php $sqlinstt = "SELECT * FROM `institute` ";         
    						$res=mysqli_query($course,$sqlinstt);
    						?>
    						<SELECT name="mylist" class="round form-control" id="mylistinstitute"  name="country" onChange=" myFunctionInstitute(); insInst(this); ">
    							<option value="">Select institute</option>
    							<?php
    							while($row=$res->fetch_assoc())
    							{ ?>
    							<option  value="<?php echo $row["name"]; ?>"><?php echo $row["name"]; ?></option>
    							<?php } ?>
    						</SELECT>
    					</div>
    					<div class="form-group  col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 ">
    						<?php
    						$sqlinstt = "SELECT * FROM `course`  ";         
    						$res=mysqli_query($course,$sqlinstt);
    						?>
    						<select name="mylistcourse" class="round form-control" id="mylistcourse"  name="country" onChange=" myFunctionCourse(); insCourse(this);">
    							<option value="">Select course</option>
    							<?php
    							while($row=$res->fetch_assoc())
    								{ ?>
    							<option  value="<?php echo $row["course"]; ?>"><?php echo $row["course"]; ?></option>
    							<?php } ?>
    						</select>	
    					</div>
                    </div>
                    <table class="table table-hover" id="myTable">
                            <?php
                    		$sqlinst= "select * from course, institute WHERE course.institution_code = institute.id";
                    		$restt=mysqli_query($course, $sqlinst);
                    		?>
                    	<tr>
                    		<th><label>Institute name</label></th>
                    		<th><label>Course Name</label></th>
                    		<th><label>State </label></th>
                    		<th><label>District </label></th>
                    		<th><label>Area </label></th>
                    	</tr>
                    		<?php
                    		while($rowtbl=$restt->fetch_assoc())
                    		{ ?>
                    	<tr>
                    		<td><?php echo $insnm = $rowtbl['name'];?></td>
                    		<td><?php echo $rowtbl['course'];?></td>
                    		<td>
                    		    <?php 
                    		echo $rowtbl['state'];
                    		
                    		?>
                    		    
                    		    </td>
                    		  
                    		
                    		
                    		<td><?php echo $rowtbl['district']; ?></td>
                    		
                    		
                    		
                    		<td><?php echo $rowtbl['area']; ?></td>
                    		<?php $courw=$rowtbl['course'];
                    		$instrw=$rowtbl['institution_code'];
                    		?>
                    		<td>
                        		<?php
                        		echo ' 
                        		        <a href="corsedetails.php?course='.$courw.'&inst='.$instrw.'" target="_blank"> <button name="view" class="form-control btn btn-info round">more...</button>
                                    	</a>';
                        		     
                        		?>
                    		</td>
                    	</tr>
                    		<?php
                    		} ?>
                    </table>
                        <?php
                        
                        mysqli_close($course);
                        ?>
                </div>
            </div>
            <div class="col-xl-1 col-lg-1 col-md-1 col-sm-12 col-12"></div>
        </div>
    </div>
    <br>  <br><br><br> 
    
    <script type="text/javascript">
    function myFunctionState() {
        var input, filter, table, tr, td, i;
        input = document.getElementById("myliststate");
        filter = input.value.toUpperCase();
        table = document.getElementById("myTable");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[2];
            if (td) {
                if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }       
        }
    }
    
    function myFunctionDistrict() {
        var input, filter, table, tr, td, i;
        input = document.getElementById("districtid");
        filter = input.value.toUpperCase();
        table = document.getElementById("myTable");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[3];
            if (td) {
                if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }       
        }
    }
    
    function myFunctionArea() {
        var input, filter, table, tr, td, i;
        input = document.getElementById("area");
        filter = input.value.toUpperCase();
        table = document.getElementById("myTable");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[4];
            if (td) {
                if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }       
        }
    }
    
    function myFunctionInstitute() {
        var input, filter, table, tr, td, i;
        input = document.getElementById("mylistinstitute");
        filter = input.value.toUpperCase();
        table = document.getElementById("myTable");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[0];
            if (td) {
                if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }       
        }
    }
    
    function myFunctionCourse() {
        var input, filter, table, tr, td, i;
        input = document.getElementById("mylistcourse");
        filter = input.value.toUpperCase();
        table = document.getElementById("myTable");
        tr = table.getElementsByTagName("tr");
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[1];
            if (td) {
                if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }       
        }
    }
       
    </script> 
    
    <script type="text/javascript">
    
    function insInst(sel) {
        var institut = sel.options[sel.selectedIndex].value;
        if (institut.length > 0) {
            $.ajax({
                type: "POST",
                 url: "ajx/insert_ajx.php" ,
                data: "institute=" + institut,
                cache: false,
            });  
        }
    }
    
    </script>
    
    <script>
    function insCourse(sel) {
        var course = sel.options[sel.selectedIndex].value;
        if (course.length > 0) {
            $.ajax({
                type: "POST",
                 url: "ajx/insert_ajx.php" ,
                data: "course=" + course,
                cache: false,
                
            });  
        }
    }
    
    
    </script>
    
    <script>
    function showDistrict(sel) {
        var country_id = sel.options[sel.selectedIndex].value;
        $("#districtid").html("");
        if (country_id.length > 0) {
            $.ajax({
                type: "POST",
                url: "ajx/fetch_area_serch.php",
                data: "state=" + country_id,
                cache: false,
                beforeSend: function() {
                    $('#districtid').html('<img src="loader.gif" alt="" width="24" height="24">');
                },
                success: function(html) {
                    $("#districtid").html(html);
                }
            });
        }
        else {
            $("#districtid").html("");
        }
    }
    </script>
    
    <script>
    function showArea(sel) {
        var state_id = sel.options[sel.selectedIndex].value;
        if (state_id.length > 0) {
            $.ajax({
            type: "POST",
            url: "ajx/fetch_area_serch.php",
            data: "district=" + state_id,
            cache: false,
            beforeSend: function() {
                $('#area').html('<img src="loader.gif" alt="" width="24" height="24">');
            },
            success: function(html) {
                $("#area").html(html);
            }
            });	
        }
        else {
            $("#area").html("");
        }
    } 
    </script>
    <script>
                function mycopyfn() {
          /* Get the text field */
          var copyText = document.getElementById("myInput");
        
          /* Select the text field */
          copyText.select();
        
          /* Copy the text inside the text field */
          document.execCommand("copy");
        
          /* Alert the copied text */
          alert("Copied the text: " + copyText.value);
        }
    </script>
    <?php
    include('../include/footer.php');
}
else
{
    echo "<script>
         window.location='../../index.php';
         </script> ";
}
?>