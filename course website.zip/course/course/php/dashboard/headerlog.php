<?php include('../include/link.php');
if(isset($_SESSION))
{ ?>
    <nav class=" navbar navbar-expand-lg navbar-gold bg-gold sticky-top">
        <div class="col-xl-1 col-lg-1 col-md-0 col-sm-0 col-0"></div>
        <div id="navbar">
            <a class="navbar-brand" href="#">
                <img class="round head-logo" src="http://www.sahayikendra.com/images/logo.png" id="logo" alt="logo"  >
            </a>
        </div>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Contact</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#"></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#"></a>
                </li>
                <!--<li class="nav-item">-->
                <!--    <a class="nav-link" id="mysearchBtn" href="#">Search <i class="fas fa-search"></i></a>-->
                <!--</li>-->
            </ul>
            <ul class="nav navbar-nav ml-auto">
                <?php
                if( isset($_SESSION['login_user']) && isset($_SESSION['login_acctype']) )
                { ?>
                <li class="nav-item">
                    <a class="nav-link " id="myBtn" href="">
                        <span>
                            <?php
                            $us = $_SESSION['login_user'];
                            echo $us;
                            ?>
                        </span>
                    </a>
                </li>
                <?php
                } ?>
                <li class="nav-item">
                    <a class="nav-link " id="myBtn" href="logout.php" >
                        <span class="fas fa-unlock" ></span>
                        logout
                    </a>
                </li> 
            </ul>
        </div>
        <div class="col-xl-1 col-lg-1 col-md-0 col-sm-0 col-0"></div>
    </nav>
<?php
}
else
{
     echo "<script> window.location='../../index.php'; </script> ";
}
?>
