<?php
if(!isset($_SESSION))
{
    session_start();
}
if(isset($_SESSION['login_user']) && isset($_SESSION['login_acctype']) && isset($_SESSION['login_id']))
{
    if($_SESSION['login_acctype'] == 'institute')
    {
        include('headerlog.php');
        $lid = $_SESSION['login_id'];
        include('../../../php/conn/conn.php');
        $sql="select * from course where user = '$lid'";
        $res=mysqli_query($course,$sql);
        if($res->num_rows>0)
        {
        ?>
        <div class="container">
        	<div class="row">
        		<div class="col-xl-1 col-lg-1 col-md-1 col-sm-1 col-1"></div>
        		<div class="col-xl-10 col-lg-10 col-md-10 col-sm-10 col-10">
        		<br>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 row">
                        <div class="form-group col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 ">
            			</div>
        				
                        <div class="form-group col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12 bg-secondary text-light round text-center" >
                            <h2 align="center round bg-progress">REGISTER COURSE</h2>
                        </div>
                        <div class="form-group col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12" ></div>
                    </div>
        			<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        				<div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 card shadow"><br>
        				    <table class='table table-hover'>
                                <tr>
                                    <th>
                                        Course
                                    </th>
                                </tr>
                                <tr>
                                    <?php
                                    while($row=$res->fetch_assoc())
                                    {
                                        echo
                                        "<tr>
                                            <td>".$row['course']."</td>
                                        </tr>";
                                    }
                                    ?>
                                </tr>
                            </table>
        			    </div>
        			</div>
        	    </div>
        	</div>
        </div>
            
        <?php
        }
        else
        {
            echo " <script> alert ('no course added'); 
             window.location='index.php';
            </script>";
            
        }
        include('../include/footer.php');
    }
}
else
{
    echo "<script> alert('Please login again or restart your browser.'); </script>";
    echo "<script> window.location='http://course.sahayikendra.com'; </script> ";
    
}
?>