-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Sep 12, 2019 at 11:27 PM
-- Server version: 5.6.44-cll-lve
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `course`
--
CREATE DATABASE IF NOT EXISTS `course` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `course`;

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `course` varchar(100) NOT NULL,
  `tutionfee` varchar(10) NOT NULL,
  `donation` varchar(10) NOT NULL,
  `examfee` varchar(50) NOT NULL,
  `bookanduniform` varchar(50) NOT NULL,
  `library` varchar(50) NOT NULL,
  `hostel_charge` varchar(11) NOT NULL,
  `institution_code` varchar(20) NOT NULL,
  `comm` varchar(20) NOT NULL,
  `dur` varchar(15) NOT NULL,
  `dur_typ` varchar(15) NOT NULL,
  `user` varchar(20) NOT NULL,
  `fees_st` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `course`, `tutionfee`, `donation`, `examfee`, `bookanduniform`, `library`, `hostel_charge`, `institution_code`, `comm`, `dur`, `dur_typ`, `user`, `fees_st`) VALUES
(1, 'B.Sc Forensic Science', '530000', '0', '0', '0', '0', '0', '1', '0', '3', 'Year', '3', '270000, 130000, 130000'),
(2, 'B.Sc Criminology and Forensic Science', '530000', '0', '0', '0', '0', '0', '1', '0', '3', 'Year', '3', '270000, 130000, 130000'),
(3, 'BBA Aviation Management', '418900', '0', '0', '0', '0', '0', '1', '0', '3', 'Year', '3', '198900, 110000, 110000'),
(4, 'B.Sc Aviation and Hospitality Management', '418900', '0', '0', '0', '0', '0', '1', '0', '3', 'Year', '3', '198900, 110000, 110000'),
(5, 'B.Sc Hotel Management and Catering Science', '420000', '0', '0', '0', '0', '0', '1', '0', '3', 'Year', '3', '160000, 130000, 130000'),
(6, 'B.Sc Hospital Management', '290000', '0', '0', '0', '0', '0', '1', '0', '3', 'Year', '3', '110000, 90000, 90000'),
(7, 'B.Sc Marine Science and Hospitality with Cruise Ship Management', '450000', '0', '0', '0', '0', '0', '1', '0', '3', 'Year', '3', '210000, 120000, 120000'),
(8, 'B.Sc Fire and Safety Management', '450000', '0', '0', '0', '0', '0', '1', '0', '3', 'Year', '3', '210000, 120000, 120000'),
(9, 'M.Sc Forensic Science and Criminology 5 yr integrated Programme', '830000', '0', '0', '0', '0', '0', '1', '0', '5', 'Year', '3', '270000, 130000, 130000, 160000, 140000'),
(10, 'B.Sc Nursing', '338000', '0', '0', '0', '0', '203000', '2', '0', '4', 'Year', '3', '121000, 73000, 72000, 72000'),
(11, 'BPT', '399000', '0', '0', '0', '0', '0', '3', '0', '4', 'Year', '3', '117000, 92000, 94000, 96000'),
(12, 'B.Sc Anaesthesia', '242000', '0', '0', '0', '0', '0', '3', '0', '3', 'Year', '3', '97000, 71500, 73500'),
(13, 'B.Sc OT (Operation Theatere)', '242000', '0', '0', '0', '0', '0', '3', '0', '3', 'Year', '3', '97000, 71500, 73500'),
(14, 'B.Sc Cardia Care', '242000', '0', '0', '0', '0', '0', '3', '0', '3', 'Year', '3', '97000, 71500, 73500'),
(15, 'B.Sc Respiratory', '242000', '0', '0', '0', '0', '0', '3', '0', '3', 'Year', '3', '97000, 71500, 73500'),
(16, 'B.Sc Radio', '242000', '0', '0', '0', '0', '0', '3', '0', '3', 'Year', '3', '97000, 71500, 73500'),
(17, 'B.Sc Dialysis', '242000', '0', '0', '0', '0', '0', '3', '0', '3', 'Year', '3', '97000, 71500, 73500'),
(18, 'B.Sc MLT', '242000', '0', '0', '0', '0', '0', '3', '0', '3', 'Year', '3', '97000, 71500, 73500'),
(19, 'B.Sc Neuro Science', '242000', '0', '0', '0', '0', '0', '3', '0', '3', 'Year', '3', '97000, 71500, 73500'),
(20, 'B.Sc MIT', '242000', '0', '0', '0', '0', '0', '3', '0', '3', 'Year', '3', '97000, 71500, 73500'),
(21, 'BE Computer Science', '1200000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '592000, 185000, 185000, 185000, Rf50000'),
(22, 'Aeronotical Engineering', '1105000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '592000, 185000, 185000, 185000, Rf50000'),
(23, 'Information Science and Engineering', '1105000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '592000, 185000, 185000, 185000, Rf50000'),
(24, 'Automobile Engineering', '1000000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '395000, 185000, 185000, 185000, Rf50000'),
(25, 'Electronic and Communication Engineering', '1000000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '395000, 185000, 185000, 185000, Rf50000'),
(26, 'Mechanical Engineering ', '1000000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '395000, 185000, 185000, 185000, Rf50000'),
(27, 'Mechotronics Engineering', '1000000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '395000, 185000, 185000, 185000, Rf50000'),
(28, 'Bio Technology Engineering', '855000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '250000, 185000, 185000, 185000, Rf50000'),
(29, 'Civil Engineering', '855000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '250000, 185000, 185000, 185000, Rf50000'),
(30, 'Electrical and Electronics Engineering', '855000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '250000, 185000, 185000, 185000, Rf50000'),
(31, 'M Tech Computer Science', '525000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(32, 'Digital Communication', '425000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(33, 'Machine Design', '425000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(34, 'Bio Technology', '275000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(35, 'MBA ', '650000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(36, 'PGDM', '700000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(37, 'B. Arch', '1450000', '0', '0', '0', '0', '0', '4', '0', '5', 'Year', '3', '650000, 250000, 250000, 250000, Rf50000'),
(38, 'Master in Pharmacy(Pharmacuticals)', '375000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(39, 'Master in Pharmacy(Pharmacology)', '375000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(40, 'Master in Pharmacy(Industerial Pharmacy)', '375000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(41, 'Master in Pharmacy(Quality Assurance)', '375000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(42, 'Master in Pharmacy(Pharmacutical Chemistry)', '375000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(43, 'Master in Pharmacy(Drug Regulatory Affairs)', '375000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(44, 'Master in Pharmacy(Pharmacognocy)', '375000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(45, 'Master in Pharmacy(Pharmacutical Analysis)', '375000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', ''),
(46, 'B. Pharm', '694000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '204000, 155000, 155000, 155000, Rf25000'),
(47, 'Pharm D (Doctor in Pharmacy)', '1500000', '0', '0', '0', '0', '0', '4', '0', '6', 'Year', '3', '450000, 250000, 250000, 250000, 250000, Rf50000'),
(48, 'Post Baccalaureate Pharm D', '525000', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '250000, 250000, 0, Rf25000'),
(49, 'D Pharm (Diploma in Pharmacy)', '170000', '0', '0', '0', '0', '0', '4', '0', '2', 'Year', '3', '75000, 75000, Rf20000'),
(50, 'Diploma(Aeronotical Engineering)', '195180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '185180/sem, Rf10000'),
(51, 'Diploma(Architecture Engineering)', '195180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '185180/sem, Rf10000'),
(52, 'Diploma(Automobile Engineering)', '175180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '165180/sem, Rf10000'),
(53, 'Diploma(Mechanical Engineering)', '175180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '165180/sem, Rf10000'),
(54, 'Diploma(Mechetronics Engineering)', '1750180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '165180/sem, Rf10000'),
(55, 'Diploma(Computer Science Engineering)', '155180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '145180/sem, Rf10000'),
(56, 'Diploma(Civil Engineering)', '155180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '145180/sem, Rf10000'),
(57, 'Diploma(Electrical and Electronics Engineering)', '155180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '145180/sem, Rf10000'),
(58, 'Diploma(Electronics and Communication Engineering)', '155180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '145180/sem, Rf10000'),
(59, 'Diploma(Mining Engineering)', '155180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '145180/sem, Rf10000'),
(60, 'Apparel Design and Fabrication Technology', '135180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '125180/sem, Rf10000'),
(61, 'Commercial Practice', '135180', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '125180/sem, Rf10000'),
(62, 'LLB', '200000', '0', '0', '0', '0', '0', '4', '0', '3', 'Year', '3', '60000, 60000, 60000, Rf20000'),
(63, 'BA LLB', '920000', '0', '0', '0', '0', '0', '4', '0', '5', 'Year', '3', '45000/sem, Rf20000'),
(64, 'Bachilor of Business Administration LLB', '920000', '0', '0', '0', '0', '0', '4', '0', '5', 'Year', '3', '45000/sem, Rf20000'),
(65, 'Bachelor in Visual Art (BVA) (Graphic Design)', '124000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '60000/sem(odd), 39000/sem(even), Rf25000'),
(66, 'Bachelor in Visual Art (BVA) (Animation and Multimedia Design)', '124000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '60000/sem(odd), 39000/sem(even), Rf25000'),
(67, 'Bachelor in Visual Art (BVA) (Product Design)', '124000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '60000/sem(odd), 39000/sem(even), Rf25000'),
(68, 'Bachelor in Visual Art (BVA) (Interior and Special Design)', '124000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '60000/sem(odd), 39000/sem(even), Rf25000'),
(69, 'Bachelor in Visual Art (BVA) (Painting)', '124000', '0', '0', '0', '0', '0', '4', '0', '4', 'Year', '3', '60000/sem(odd), 39000/sem(even), Rf25000'),
(70, 'Fire And Safty', '400000', '0', '0', '0', '0', '0', '7', '0', '4', 'Year', '3', '100000/Yr, Uf10000'),
(71, 'Aeronotical Engineering', '340000', '0', '0', '0', '0', '0', '7', '0', '4', 'Year', '3', '85000/Yr, Uf10000'),
(72, 'Mechanical Engineering ', '340000', '0', '0', '0', '0', '0', '7', '0', '4', 'Year', '3', '85000/Yr, Uf10000'),
(73, 'Information Technology', '300000', '0', '0', '0', '0', '0', '7', '0', '4', 'Year', '3', '75000/Yr, Uf10000'),
(74, 'Civil Engineering', '300000', '0', '0', '0', '0', '0', '7', '0', '4', 'Year', '3', '75000/Yr, Uf10000'),
(75, 'Electronic and Communication Engineering', '300000', '0', '0', '0', '0', '0', '7', '0', '4', 'Year', '3', '75000/Yr, Uf10000'),
(76, 'Computer Science Engineering', '340000', '0', '0', '0', '0', '0', '7', '0', '4', 'Year', '3', '85000/Yr, Uf10000'),
(77, 'Agriculture', '360000', '0', '0', '0', '0', '0', '7', '0', '4', 'Year', '3', '90000/Yr, Uf10000'),
(78, 'Bio Medical', '360000', '0', '0', '0', '0', '0', '7', '0', '4', 'Year', '3', '90000/Yr, Uf10000'),
(79, 'Food Technology', '360000', '0', '0', '0', '0', '0', '7', '0', '4', 'Year', '3', '90000/Yr, Uf10000'),
(80, 'Fire And Safty', '400000', '0', '0', '0', '0', '0', '6', '0', '4', 'Year', '3', '100000/Yr, Uf10000'),
(81, 'Chemical Tech', '360000', '0', '0', '0', '0', '0', '6', '0', '4', 'Year', '3', '90000/Yr, Uf10000'),
(82, 'Petro Chemical Tech', '360000', '0', '0', '0', '0', '0', '6', '0', '4', 'Year', '3', '90000/Yr, Uf10000'),
(83, 'Mechanical Engineering ', '240000', '0', '0', '0', '0', '0', '6', '0', '4', 'Year', '3', '60000/Yr, Uf10000'),
(84, 'Electrical and Electronics Engineering', '240000', '0', '0', '0', '0', '0', '6', '0', '4', 'Year', '3', '60000/Yr, Uf10000'),
(85, 'B. Arch', '500000', '0', '0', '0', '0', '0', '7', '0', '5', 'Year', '3', '100000/Yr, Uf15000'),
(86, 'M. Arch', '300000', '0', '0', '0', '0', '0', '7', '0', '2', 'Year', '3', '150000/Yr, 10000'),
(87, 'Diploma in Mechanical', '54000', '0', '0', '0', '0', '0', '5', '0', '3', 'Year', '3', '18000/Yr, Uf10000'),
(88, 'Diploma in Civil', '54000', '0', '0', '0', '0', '0', '5', '0', '3', 'Year', '3', '18000/Yr, Uf10000'),
(89, 'Diploma in Automobile', '54000', '0', '0', '0', '0', '0', '5', '0', '3', 'Year', '3', '18000/Yr, Uf10000'),
(90, 'Diploma in Electrical and Electronics Engineering', '54000', '0', '0', '0', '0', '0', '5', '0', '3', 'Year', '3', '18000/Yr, Uf10000'),
(91, 'Diploma in Electronic and Communication Engineering', '54000', '0', '0', '0', '0', '0', '5', '0', '3', 'Year', '3', '18000/Yr, Uf10000'),
(94, 'Basic Developer', '15000', '0', '0', '0', '0', '0', '9', '0', '6', 'Month', '4', '8000, 5000, 2000'),
(95, 'Professional Developer', '55000', '0', '0', '0', '0', '0', '9', '0', '6', 'Month', '4', '25000, 15000, 10000, 5000'),
(96, 'Junior Developer', '12000', '0', '0', '0', '0', '0', '9', '0', '2', 'Month', '4', '8000, 4000'),
(97, 'Basic Computer Course(Sunday)', '5000', '0', '0', '0', '0', '0', '9', '0', '5', 'Month', '4', '5000'),
(98, 'Basic Developer(Sunday)', '16000', '0', '0', '0', '0', '0', '9', '0', '1', 'Year', '4', '7000, 5000, 3000,1000'),
(99, 'Professional Developer(Sunday)', '60000', '0', '0', '0', '0', '0', '9', '0', '1', 'Year', '4', '25000, 15000, 10000, 5000, 5000'),
(100, 'Junior Developer(Sunday)', '13000', '0', '0', '0', '0', '0', '9', '0', '6', 'Month', '4', '7000, 3000, 2000,1000'),
(101, 'B.Sc Cardiac Care Tech', '370000', '0', '0', '0', '0', '0', '10', '0', '3', 'Year', '2', '200000, 85000, 85000, +'),
(102, 'B.Sc OT (Operation Theatere) and AT (Anesthesia Technology)', '270000', '0', '0', '0', '0', '0', '10', '0', '3', 'Year', '2', '150000, 60000, 60000, +'),
(103, 'B.Sc Radiology and Imaging Technology', '270000', '0', '0', '0', '0', '0', '10', '0', '3', 'Year', '2', '150000, 60000, 60000, +'),
(104, 'B.Sc Nursing', '520000', '0', '0', '0', '0', '0', '10', '0', '3', 'Year', '2', 'Package'),
(105, 'BHMS', '875000', '0', '0', '0', '0', '0', '11', '0', '5', 'Year', '2', '875000/Yr'),
(106, 'BPT Physiotherapy', '662500', '0', '0', '0', '0', '0', '11', '0', '4', 'Year', '2', '225000, 125000, 125000, (125000+62500 for Half Yr)'),
(107, 'B.Sc Nursing', '425000', '0', '0', '0', '0', '0', '11', '0', '4', 'Year', '2', '125000, 100000/Yr'),
(108, 'GNM', '225000', '0', '0', '0', '0', '0', '11', '0', '3', 'Year', '2', '75000/Yr');

-- --------------------------------------------------------

--
-- Table structure for table `institute`
--

CREATE TABLE `institute` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `area` varchar(50) NOT NULL,
  `user` varchar(30) NOT NULL,
  `cont_no` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `institute`
--

INSERT INTO `institute` (`id`, `name`, `state`, `district`, `area`, `user`, `cont_no`) VALUES
(1, 'Annai Fathima College', 'TamilNadu ', 'Madurai ', 'Thirumangalam ', '3', ''),
(2, 'RR Institution', 'Karnataka ', 'Bangalore ', 'Chikkabanavara ', '3', ''),
(3, 'Narayana Institution of Cardiac Science', 'Karnataka ', 'Bangalore ', 'Hosure Road ', '3', ''),
(4, 'Acharya Institute', 'Karnataka ', 'Bangalore ', 'Acharya ', '3', ''),
(5, 'Excel Poly Tech', 'TamilNadu ', 'Earode ', 'Earode ', '3', '7907140020'),
(6, 'Excel College of Engineering and Technology ', 'TamilNadu ', 'Earode ', 'Earode ', '3', '7907140020'),
(7, 'Excel College of Engineering', 'TamilNadu ', 'Earode ', 'Earode ', '3', '7907140020'),
(8, 'Mahindra Group of Institutions', 'TamilNadu ', 'Earode ', 'Earode ', '2', '8590178988'),
(9, 'Azalea Technologies', 'Kerala ', 'Malappuram ', 'Indianoor', '1', '7907399949'),
(10, 'Sri Shanmugha Educational Institutions', 'TamilNadu ', 'Earode ', 'Earode ', '2', '00'),
(11, 'Royal College', 'Karnataka ', 'Bangalore ', 'Bangalore', '2', '00');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `acc_type` varchar(15) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(800) NOT NULL,
  `contact_number` varchar(15) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `acc_type`, `username`, `password`, `contact_number`) VALUES
(1, 'Azalea', 'admin', 'Azalea', '$2y$10$S5AsFy2b1GDQ6.v.YkcZGurfLtigFWes2b456tf0tDu.A5.52IdxO', '7907399949'),
(2, 'Aboobacker', 'agent', 'abu', '$2y$10$ARpp2dxNUmG9bacAWOKiMOVNkVSlv7MdMGUEVoNU6embMwI2g7HsC', '7907499939'),
(3, 'Muhsin', 'agent', 'Muhsin', '$2y$10$r5yssICFdWAH3B0eVXYLou0hkkXeX9ioqeCjOB0HdieFODvH5VYwu', '7907140020'),
(4, 'Azalea Technologies', 'institute', 'Azalea1', '$2y$10$S5AsFy2b1GDQ6.v.YkcZGurfLtigFWes2b456tf0tDu.A5.52IdxO', '7907399949');

-- --------------------------------------------------------

--
-- Table structure for table `refer`
--

CREATE TABLE `refer` (
  `id` int(11) NOT NULL,
  `mob` varchar(20) NOT NULL,
  `ref_name` varchar(20) NOT NULL,
  `ref_id` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `refer`
--

INSERT INTO `refer` (`id`, `mob`, `ref_name`, `ref_id`) VALUES
(1, '9656299468', 'musthafa', ''),
(2, '9895025678', 'Muhammed Swalih KV', '1'),
(3, '9995878783', 'Mazin', '1'),
(4, '9497555177', 'RASAK', '2'),
(5, '8592806463', 'Rahmathulla ', '2'),
(10, '9526938457', 'shaheer', ''),
(21, '9876767687', 'sha', ''),
(22, '1234567890', 'aaa', ''),
(23, '9539567552', 'thameem', ''),
(24, '12152454555', '1235648875', ''),
(25, '6599885588', 'hj', ''),
(26, '3434343434343', 'erere', '');

-- --------------------------------------------------------

--
-- Table structure for table `search`
--

CREATE TABLE `search` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `search_date` varchar(50) NOT NULL,
  `search_field` varchar(50) NOT NULL,
  `search_field_type` varchar(20) NOT NULL,
  `refer` varchar(50) NOT NULL,
  `refer_from` varchar(50) NOT NULL,
  `status` varchar(50) NOT NULL,
  `will_status` varchar(50) NOT NULL,
  `follow_up` varchar(50) NOT NULL,
  `remarks` varchar(50) NOT NULL,
  `referer` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `search`
--

INSERT INTO `search` (`id`, `name`, `phone`, `search_date`, `search_field`, `search_field_type`, `refer`, `refer_from`, `status`, `will_status`, `follow_up`, `remarks`, `referer`) VALUES
(1, 'RAHMATHULLA ', '8592806463', '2019-05-30', '11', 'institute', '', '', '0', '', '', '', ''),
(2, 'RAHMATHULLA ', '8592806463', '2019-05-30', '6', 'course', '', '', '0', '', '', '', ''),
(3, 'MUSTHAFA', '9656299468', '2019-05-31', '14', 'coursedetails', '', '', '0', '', '', '', ''),
(4, 'MUSTHAFA', '9656299468', '2019-05-31', '15', 'coursedetails', '', '', '0', '', '', '', ''),
(5, 'MUSTHAFA', '9656299468', '2019-06-01', '9', 'institute', '', '', '0', '', '', '', ''),
(6, 'MUSTHAFA', '9656299468', '2019-06-01', '3', 'course', '', '', '0', '', '', '', ''),
(7, 'MUSTHAFA', '9656299468', '2019-06-01', '3', 'coursedetails', '', '', '0', '', '', '', ''),
(8, 'AAA', '1234567890', '2019-07-04', '2', 'coursedetails', '', '', '0', '', '', '', ''),
(9, 'WQERTY', '1234567890', '2019-07-04', '1', 'coursedetails', '', '', '0', '', '', '', ''),
(10, '1235648875', '12152454555', '2019-08-03', '2', 'institute', '', '', '0', '', '', '', ''),
(11, '1235648875', '12152454555', '2019-08-03', '1', 'course', '', '', '0', '', '', '', ''),
(12, '1235648875', '12152454555', '2019-08-03', '6', 'course', '', '', '0', '', '', '', ''),
(13, 'HJ', '6599885588', '2019-08-04', '9', 'institute', '', '', '0', '', '', '', ''),
(14, 'HJ', '6599885588', '2019-08-04', '7', 'course', '', '', '0', '', '', '', ''),
(15, 'HJ', '6599885588', '2019-08-04', '2', 'course', '', '', '0', '', '', '', ''),
(16, 'HJ', '6599885588', '2019-08-04', '10', 'institute', '', '', '0', '', '', '', ''),
(17, 'HJ', '6599885588', '2019-08-04', '9', 'institute', '', '', '0', '', '', '', ''),
(18, 'HJ', '6599885588', '2019-08-04', '8', 'course', '', '', '0', '', '', '', ''),
(19, 'HJ', '6599885588', '2019-08-04', '1', 'course', '', '', '0', '', '', '', ''),
(20, 'HJ', '6599885588', '2019-08-04', '1', 'institute', '', '', '0', '', '', '', ''),
(21, 'HJ', '6599885588', '2019-08-04', '9', 'institute', '', '', '0', '', '', '', ''),
(22, 'ERERE', '3434343434343', '2019-09-07', '3', 'institute', '', '', '0', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `institute`
--
ALTER TABLE `institute`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `refer`
--
ALTER TABLE `refer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mob` (`mob`);

--
-- Indexes for table `search`
--
ALTER TABLE `search`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `institute`
--
ALTER TABLE `institute`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `refer`
--
ALTER TABLE `refer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `search`
--
ALTER TABLE `search`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
